# V25.8 — Assignment accept/session root fix

- NHẬN ĐƠN không còn phụ thuộc ensureActionSession/profile state trung gian.
- Xác thực thao tác nhận bằng UID hiện tại + assignedUid của đơn.
- Giao diện packer được mở nếu listener đã có đơn assigned cho UID hiện tại dù role UI tạm thời stale.
- Hoàn thành đơn không dùng ensureActionSession làm cổng; Firestore Security Rules vẫn quyết định quyền ghi.
- Giữ luồng: đơn mới → nhận → đơn đã nhận cần hoàn thành → chụp ảnh → hoàn thành.
