# ROLL CÂY CẢNH V26.0 — End-to-End Audit

## Mục tiêu
Ổn định luồng phân công đóng hàng mà không phá giao diện/chức năng cũ.

## Luồng chuẩn
1. Admin tạo đơn tại `/packingOrders/{orderId}` với `status=pending`, `assignedUid`, nhân viên, cây, kích thước, combo 2–100.
2. Nhân viên chỉ nhìn thấy đơn có `assignedUid == Firebase Auth UID`.
3. Bấm `NHẬN ĐƠN`: lưu trạng thái đã nhận ở localStorage theo UID; đơn chuyển vào `Đơn đã nhận · cần hoàn thành` trên máy nhân viên. Không phụ thuộc `ensureActionSession`.
4. Nhân viên chọn đơn, chụp ảnh, ảnh được nén về tối đa 900px và chặn data URL > 900KB.
5. Bấm `XÁC NHẬN HOÀN THÀNH ĐƠN`: gọi duy nhất `completePackingOrder()`. Firestore Rules là lớp quyền cuối cùng; app không dùng session gate trung gian.
6. Firestore chuyển `pending -> completed`, lưu `completionImage`, `completedBy`, `completedAt`, `completedAtMs`.
7. Listener cập nhật lại danh sách, xóa đơn khỏi danh sách cần hoàn thành và thêm vào `Đơn đã hoàn thành`; tiền công được tính từ `packSize × rate` và điều chỉnh nếu có.

## Các lỗi gốc đã loại bỏ trong đợt audit
- Loại bỏ luồng hoàn thành thứ hai trong popup thông báo từng gọi `ensureActionSession(8000)` và có thể tạo lỗi "Phiên đăng nhập chưa sẵn sàng".
- Popup thông báo chỉ làm nhiệm vụ thông báo/nhận đơn; hoàn thành chỉ thực hiện trong danh sách đơn đã nhận.
- Thêm chống bấm hoàn thành hai lần.
- Chặn ảnh bằng chứng quá lớn trước khi gửi Firestore.
- Thêm bảo vệ WebView renderer để nếu renderer chết thì Activity khởi tạo lại WebView thay vì đóng app hoàn toàn.
- Giữ `/packingOrders` là nguồn dữ liệu duy nhất cho assignment.
- Không đưa `packingOrders` trở lại `/apps` trong đồng bộ.
- Khi dữ liệu nghiệp vụ local có dirty flag, `syncNow()` ưu tiên đẩy local lên Cloud trước khi nhận Cloud.

## Firebase Rules
Không thay đổi Rules trong bản này. Rules hiện tại cho phép:
- Admin tạo/xóa/cập nhật toàn bộ đơn.
- Packer chỉ đọc đơn của chính UID.
- Packer chỉ chuyển đơn của mình từ `pending` sang `completed` khi có ảnh và `completedBy` đúng UID.

## Dữ liệu nền kiểm tra
- 6 nhân viên
- 6 mức đơn giá
- 99 dòng danh mục cây
- kỳ 2026-09-01 → 2027-12-31

## Kiểm tra tĩnh
- 4/4 inline JavaScript blocks qua `node --check`.
- Không còn `ensureActionSession(8000)` trong luồng nhận/hoàn thành.
- Không còn `completeOrderFromAlert()`/`orderAlertWork`.
- `acceptAssignedOrder()` kiểm tra `assignedUid` trước khi nhận.
- `completePackingOrder()` kiểm tra UID + ảnh + trạng thái trước khi ghi.
- Workflow GitHub Actions có Android SDK 35, build-tools 35.0.0, Java 17, Gradle 8.13.

## Giới hạn kiểm chứng
Môi trường tạo source hiện tại không có Android SDK/Gradle và không có Firebase runtime của tài khoản thật, nên không thể trung thực tuyên bố đã chạy APK thực tế trên điện thoại. Bản này được chuẩn bị để build một lần và kiểm thử thực tế theo checklist Admin + nhân viên.
