# ROLL CAY CANH V25.5 — NHẬN ĐƠN → DANH SÁCH CẦN HOÀN THÀNH

- Tách rõ 3 nhóm cho nhân viên đóng hàng: Đơn mới được phân công / Đơn đã nhận · cần hoàn thành / Đơn đã hoàn thành.
- Bấm NHẬN ĐƠN chỉ ghi nhận việc nhận trên máy của chính tài khoản nhân viên và chuyển đơn vào danh sách cần hoàn thành.
- Không dùng `go()`/`renderAll()` trong thao tác nhận đơn.
- Sửa lỗi `CloudSync.ensureActionSession is not a function`: completion dùng `CloudSync.state().ensureActionSession()` và đồng thời public API có `ensureActionSession` để tương thích.
- Bấm chụp ảnh rồi XÁC NHẬN HOÀN THÀNH sẽ gọi `completePackingOrder()`; ảnh được lưu vào `completionImage` và đơn chuyển `completed`.
- Khi hoàn tất, ID nhận đơn được loại khỏi danh sách “cần hoàn thành”.
- Không thay Firestore Rules.
- Không thay cấu trúc đơn phân công canonical `/packingOrders`.
- Trạng thái “đã nhận” là trạng thái nghiệp vụ cục bộ theo UID, lưu trong localStorage để không cần mở thêm quyền Firestore cho packer.
