# ROLL CAY CANH V25.4 — ROOT FIX NHAN DON DUOC PHAN CONG

## Muc tieu
Sua rieng luong Nhan don duoc phan cong tu chuong thong bao. Khong thay doi Firebase Rules, khong thay doi cau truc `/packingOrders`.

## Nguyen nhan source da xac dinh
V25.3 van con luong navigation/rerender cu va dac biet phan `goToPendingOrders()` bi long them mot khai bao ham `goToPendingOrders()` ben trong ham cung ten. Ngoai ra, luong cu tiep tuc go/renderDay/renderPackerOrders/scroll khi modal dang dong. Day la mot diem rui ro khong can thiet tren Android WebView.

## Cach V25.4 xu ly
- Khong dieu huong sang tab Day khi bam `NHAN DON`.
- Khong go(), renderDay(), renderAll() hay scrollIntoView() trong luong thong bao.
- Danh sach don nam ngay trong modal thong bao.
- Nhan vien bam mot don => don duoc chon ngay trong modal.
- Nhan vien chup anh ngay trong modal => bam XAC NHAN HOAN THANH.
- Completion van ghi vao `/packingOrders/{orderId}` voi `status=completed`, `completionImage`, `completedAtMs`, `completedBy`.
- Badge thong bao giam ngay sau khi hoan thanh.
- Admin van xem duoc danh sach don trong thong bao; khong thay doi luong phan cong.
- Cac chuc nang kho, bao cao, danh muc, don gia, phan cong va giao dien hien tai duoc giu nguyen.

## Kiem tra
- 5/5 inline JavaScript blocks: syntax OK.
- Khong thay doi Firestore Rules.
- Chua co APK runtime trong moi truong hien tai; APK can duoc build bang GitHub Actions.
