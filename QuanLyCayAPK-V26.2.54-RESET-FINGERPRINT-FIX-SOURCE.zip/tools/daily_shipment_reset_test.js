const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const rules = fs.readFileSync(path.join(root, 'firestore.rules'), 'utf8');
const must = (condition, message) => { if (!condition) throw new Error(message); };
must(gradle.includes('versionName = "26.2.54"') && gradle.includes('versionCode = 106'), 'reset version metadata missing');
must(html.includes("const DAILY_SHIPMENT_RESET_TARGET_DATE='2026-10-18'"), 'reset is not locked to target date');
must(html.includes("if(String(confirmationText||'').trim()!=='XOA 18/10/2026')"), 'destructive reset confirmation guard missing');
must(html.includes("db.collection('dailyShipmentScans').where('date','==',date)"), 'reset must query only the selected daily scan date');
must(html.includes("String(claim.orderId||'')!=='daily_'+String(tracking)"), 'unrelated shipment claims must be preserved');
must(html.includes("String(claim.source||'')!=='daily_shipment_scan'"), 'reset must preserve claims from other order workflows');
must(html.includes('dailyShipmentResetDates') && html.includes('dailyShipmentApplyResetMarkers'), 'stale client-cache guard missing');
must(html.includes('function dailyShipmentIsStaleResetReport(row)'), 'reset marker must distinguish stale reports from fresh rescans');
must(html.includes('const safeScans=scans.filter(r=>!dailyShipmentIsStaleResetReport(r));'), 'fresh scans after reset must remain visible');
must(html.includes('function dailyShipmentQueueRowNeedsReset(row,date)'), 'reset marker must not clear post-reset queue rows');
must(html.includes("status:'imported',claimExists:false"), 'imported labels must be reset to waiting state');
must(html.includes('products') && html.includes('resetQueueRowForDate'), 'reset must preserve imported product payloads');
must(html.includes('previewDailyShipmentReset18') && html.includes('executeDailyShipmentReset18'), 'Admin preview/execute UI missing');
must(html.includes("'dailyShipmentAdminResetCard'"), 'Admin reset card visibility guard missing');
must(rules.includes('match /dailyShipmentScans/{trackingNo}') && rules.includes('allow delete: if isAdmin();'), 'existing Admin scan-delete rule not available');

must(!html.slice(html.indexOf('function resetPreviewSignature'), html.indexOf('async function getDailyShipmentResetPreview')).includes('updatedAtMs:Number(d.updatedAtMs)'), 'volatile scan updatedAtMs must not invalidate an otherwise unchanged reset preview');
must(html.includes('protectedPayrollArchiveCount') && html.includes('protectedSettlementCount'), 'preview must disclose protected payroll archives/settlements');
must(html.includes('Không thể xóa tự động an toàn vì có thể chứa tiền công đóng hàng khác'), 'reset must refuse to destroy mixed/settled payroll snapshots');
must(html.includes('DỪNG: ngày này có tiền công đã bảo lưu/quyết toán'), 'UI must block destructive confirmation if payroll is protected');


// Regression: a reset marker must remove pre-reset cache rows without blocking a new same-day scan.
const vm = require('vm');
const helperStart = html.indexOf('function dailyShipmentDateWasReset(date)');
const helperEnd = html.indexOf('async function previewDailyShipmentReset18()', helperStart);
must(helperStart >= 0 && helperEnd > helperStart, 'date-reset cache marker helper block missing');
const sandbox = {
  D: {
    dailyShipmentResetDates: { '2026-10-18': 1000 },
    dailyShipmentReports: [
      { id: 'daily_old', trackingNo: 'OLD', date: '2026-10-18', source: 'daily_shipment_scan', status: 'recorded', scannedAtMs: 900 },
      { id: 'daily_new', trackingNo: 'NEW', date: '2026-10-18', source: 'daily_shipment_scan', status: 'recorded', scannedAtMs: 1100 },
      { id: 'daily_other', trackingNo: 'OTHER', date: '2026-10-17', source: 'daily_shipment_scan', status: 'recorded', scannedAtMs: 800 }
    ],
    dailyShipmentOrders: [
      { trackingNo: 'OLD', date: '2026-10-18', source: 'pdf_label', status: 'recorded', recordedAtMs: 900, employee: 'Old employee' },
      { trackingNo: 'NEW', date: '2026-10-18', source: 'pdf_label', status: 'recorded', recordedAtMs: 1100, employee: 'New employee' }
    ]
  },
  invalidateInventoryIndexes() {}
};
vm.runInNewContext(html.slice(helperStart, helperEnd) + `
this.resetMarkerRegression = () => { dailyShipmentApplyResetMarkers(); return {reports:D.dailyShipmentReports,orders:D.dailyShipmentOrders}; };`, sandbox);
const resetRegression = sandbox.resetMarkerRegression();
must(resetRegression.reports.length === 2 && resetRegression.reports.some(r => r.trackingNo === 'NEW') && resetRegression.reports.some(r => r.trackingNo === 'OTHER'), 'reset marker must remove only stale target-date reports');
const oldQueue = resetRegression.orders.find(r => r.trackingNo === 'OLD');
const newQueue = resetRegression.orders.find(r => r.trackingNo === 'NEW');
must(oldQueue.status === 'imported' && !oldQueue.employee, 'old cached target-date queue row must be reset');
must(newQueue.status === 'recorded' && newQueue.employee === 'New employee', 'new target-date scan after reset must remain intact');

console.log('Daily shipment date-reset regression test PASS');
