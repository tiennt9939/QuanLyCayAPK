ROLL CÂY CẢNH V20.7 STABLE

Gói này đã sửa triệt để lỗi đồng bộ /config và chức năng phân công đóng hàng bằng cách dùng document /apps/roll-cay-canh đã có quyền trong Rules hiện tại.

Cách dùng:
1. Upload file QuanLyCayAPK_project.zip vào repository GitHub.
2. GitHub Actions -> Build QuanLyCayAPK -> Run workflow.
3. Lấy artifact QuanLyCayAPK-debug.

Không cần sửa Firestore Rules chỉ để dùng chức năng phân công của bản V20.7 này.
