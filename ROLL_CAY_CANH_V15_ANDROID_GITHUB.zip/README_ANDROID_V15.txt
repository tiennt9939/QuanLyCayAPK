ROLL CAY CANH – ANDROID V15

Android project for GitHub Actions APK build.
The Android project is inside:
  QuanLyCayAPK_project/

Important project files:
  settings.gradle.kts
  build.gradle.kts
  app/build.gradle.kts
  app/src/main/
