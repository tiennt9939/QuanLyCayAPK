'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');

const start = html.indexOf('async function createUser(email,password,employeeId,roleValue){');
const end = html.indexOf('\n  let usersListCache=', start);
assert(start >= 0 && end > start, 'production createUser function must exist');
const createUser = html.slice(start, end);

assert(!/createdAuthUser\s*\.\s*delete\s*\(/.test(createUser),
  'createUser must never delete Firebase Auth automatically after an ambiguous Firestore profile failure');
assert(createUser.includes('if(createdAuthUser&&!profileSaved)'),
  'ambiguous newly-created Auth accounts must be surfaced to the Admin');
assert(createUser.includes('hồ sơ /users có thể đã được ghi thành công'),
  'permission-denied guidance must explain that Firestore may already contain the profile');
assert(createUser.includes('thử liên kết lại bằng chính email và mật khẩu'),
  'recovery guidance must allow retrying with the same credential');
assert(createUser.includes("if(sec)await sec.auth().signOut()"),
  'secondary Auth session must still be signed out after the create flow fails');

assert(gradle.includes('versionName = "26.2.155"'), 'release must be V26.2.155');
assert(gradle.includes('versionCode = 207'), 'release versionCode must be 205');

console.log('USER CREATION AUTH/PROFILE ORPHAN SAFETY: PASS');
