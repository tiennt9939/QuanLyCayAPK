# ROLL CÂY CẢNH V26.2.96 — Audit bộ đếm đơn theo cây/kích thước

## Phạm vi

Nền: source V26.2.95 (26.2.95 / code 147). Bản mới: V26.2.96 / code 148.

## Vấn đề trước sửa

Phần `Tổng hợp sản lượng theo cây/kích thước` trong `renderReport()` cộng sản lượng ngày ghi tay với dòng cây từ đơn hoàn tất rồi chỉ hiển thị tên cây/kích thước và tổng số cây. Nó không đếm số đơn cho từng nhóm, không thể mở đúng các đơn thuộc bộ đếm và có thể gây nhầm dữ liệu ghi tay với danh sách đơn hàng.

## Sửa

1. Thêm bộ đếm theo khóa tên cây + kích thước lấy từ dòng cây thực tế của các đơn hoàn tất trong khoảng ngày báo cáo.
2. Mỗi đơn chỉ được tính một lần trong một nhóm; các dòng cùng tên cây/kích thước trong cùng đơn được cộng số cây trước khi đếm đơn.
3. Bấm bộ đếm sẽ dựng danh sách đơn thuộc nhóm đó; bấm từng đơn mới dựng nội dung chi tiết đơn.
4. Danh sách thể hiện SKU/Seller SKU gắn riêng với cây chỉ khi snapshot mapping đã lưu quan hệ cụ thể. Nếu chỉ có SKU của đơn nhưng không có quan hệ cây–SKU xác thực, UI ghi rõ rằng chưa xác định riêng, không tự đoán.
5. Sản lượng nhập ghi tay theo ngày được tách thành mục riêng vì bản ghi không có mã vận đơn/đơn để mở danh sách tương ứng.
6. Tiền công trong bộ đếm chỉ là quy đổi để hiển thị báo cáo, phân bổ tổng tiền công thực của đơn theo tỷ trọng tiền công các dòng; không ghi ngược hay thay đổi công thức/giá trị tiền công chính.
7. Danh sách chi tiết dùng lazy rendering, giảm lượng DOM dựng sẵn; không thêm truy vấn Firebase hay cập nhật cloud khi bấm bộ đếm.

## Phạm vi không thay đổi

Không sửa `MainActivity.java`, `firestore.rules`, schema Firestore, barcode scanner, PDF parser/matcher, transaction ghi đơn, kho, hoặc công thức tính tiền công hiện hành. Thay đổi logic giao diện chỉ nằm trong `app/src/main/assets/index.html`; phần version/preflight/workflow và test metadata được tăng đồng bộ.

## Kiểm thử

- Preflight: PASS.
- JavaScript regression tests: 88/88 PASS.
- Cú pháp JavaScript inline: 6/6 khối PASS; `tiktok-label-import.js` PASS.
- Bộ kiểm thử riêng nhóm cây: 5 đơn/5 cây Cẩm tú mai C7 và 4 đơn/4 cây Cẩm tú mai C9 được giữ thành 2 nhóm tách biệt; nhiều dòng cùng nhóm trong một đơn chỉ đếm một đơn; mở nhóm hiển thị đúng số đơn; mở dòng đơn tải đúng chi tiết; SKU chỉ hiển thị quan hệ khi có mapping.
- ZIP đầu ra đã vượt qua `zip -T` và `unzip -t`; SHA-256 được cung cấp trong tệp sidecar `.sha256`.

## Giới hạn xác minh

Không có Gradle/Android SDK cục bộ trong môi trường này, vì vậy chưa thể xác nhận build APK. Chưa chạy GitHub Actions, và chưa kiểm tra trên thiết bị Android/Firebase thật. Kết quả test không thay thế xác minh thực tế sau khi build/cài đặt.
