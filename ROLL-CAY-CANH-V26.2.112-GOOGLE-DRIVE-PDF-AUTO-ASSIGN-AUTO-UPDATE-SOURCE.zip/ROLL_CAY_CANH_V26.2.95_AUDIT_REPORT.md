# ROLL CÂY CẢNH V26.2.95 — Audit báo cáo đơn/SKU theo nhân viên

## Nguyên nhân

`renderReport()` chỉ gom báo cáo hoàn tất theo tên nhân viên, số đơn, số cây và tiền công. Danh sách từng đơn không được render khi bấm tên; phần `Sản lượng theo cây/kích thước` gộp số cây theo dòng danh mục. Bản ghi quét PDF (`reportDraft`) lưu `items` đã chuẩn hóa theo danh mục nhưng không lưu ảnh chụp Product Name/SKU/Seller SKU và cây được ánh xạ từ từng SKU. Dữ liệu sản phẩm gốc còn ở hàng nhãn PDF/`dailyShipmentOrders`, nhưng báo cáo không nối nó vào màn hình chi tiết.

## Sửa tối thiểu

- Thêm `dailyShipmentProductReportSnapshot(row)`, lấy nhãn gốc theo tracking và ghi snapshot Product Name, SKU, Seller SKU, Qty nhãn cùng dòng cây được ánh xạ tại thời điểm quét.
- Gắn `sourceProducts` vào báo cáo trước giao dịch `recordDailyShipmentScan`; không thay đổi công thức tính `laborPay`, `items`, hoặc logic tồn kho.
- Thêm `reportProductSourceRows`, `reportRecordedPlantLines`, `reportCompletedOrderDetailHtml`, và chuyển từng nhân viên thành `<details>` có thể mở để tra các đơn đã hoàn tất.
- SKU-to-plant mapping chỉ được trình bày như quan hệ chính xác nếu nằm trong snapshot lúc ghi nhận. Bản ghi cũ thiếu snapshot dùng dữ liệu PDF còn lưu và hiển thị cảnh báo trung lập rằng cây ghi nhận không được ghép ngược bằng quy tắc hiện tại.
- Thu gọn phần tổng hợp sản lượng theo cây/kích thước thành phần tham khảo để không nhầm tổng hợp cây với bằng chứng từng đơn.
- Tăng versionName từ 26.2.94 lên 26.2.95, versionCode 146 lên 147; đồng bộ các test version-pinned và thêm test mới.

## Phạm vi bảo vệ

Không sửa nhận diện PDF, barcode, phân công, chống trùng, tiền công, tồn kho, bảng giá, schema collection hay Firestore Rules. Bổ sung một trường báo cáo tùy chọn `sourceProducts`; không tạo collection/index mới.

## Kiểm thử

- `tools/preflight.py`: PASS.
- `tools/v2695_report_employee_order_details_test.js`: PASS; kiểm thử snapshot SKU, mapping cây theo SKU, xử lý override ở cấp toàn đơn, danh sách đơn và fallback bản ghi cũ.
- Toàn bộ `tools/*_test.js`: 87/87 PASS.
- JS syntax: 6 khối inline và `tiktok-label-import.js` PASS.
- ZIP: integrity test PASS.
- Chưa có Gradle wrapper hoặc Android SDK trong môi trường hiện tại, nên chưa build APK tại đây. Chưa test trên thiết bị/Firebase thật.
