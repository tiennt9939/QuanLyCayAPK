# V26.2.92 — Fix employee daily payroll attribution for PDF labels

### What was wrong
Admin-delegated PDF/daily-shipment records can carry the intended worker's UID in `adminDelegateAssignedUid`. The employee report filter did not consider that field, so the Admin report could include a wage while the employee's own report omitted the same row.

### What changed
The employee report now recognizes `adminDelegateAssignedUid` as an ownership key. A PDF record appears in a worker's report only when the saved delegated UID matches that worker's logged-in UID. The shared PDF import and outside-order flow are unchanged.

### Install/build
Upload this source ZIP to the repository root on `main` to trigger the existing GitHub Actions source build. Install the resulting APK and test one completed PDF label captured by Admin for an assigned employee, plus one outside order. Compare both employee and Admin reports for the same date.

### Important
This patch fixes report attribution, not the underlying recorded amount. Records with `wageRecorded: false` are intentionally excluded (e.g. an Admin no-wage scan). Audit those before making any retroactive payroll changes. Source tests are not proof of live Firebase/Drive behavior; APK build and device verification remain outstanding.
