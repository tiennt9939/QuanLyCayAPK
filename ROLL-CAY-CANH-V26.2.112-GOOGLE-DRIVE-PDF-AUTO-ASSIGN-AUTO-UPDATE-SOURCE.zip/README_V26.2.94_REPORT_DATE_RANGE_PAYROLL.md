# V26.2.94 — Báo cáo tiền công theo khoảng ngày

- Nền source: V26.2.93, versionCode 145.
- Bản mới: V26.2.94, versionCode 146.
- Hiện các bộ chọn **Từ ngày / Đến ngày** ngay trong tab Báo cáo; trước đây chúng nằm trong panel bị CSS ẩn nên người dùng không thể chọn khoảng ngày tại giao diện.
- Đổi một trong hai ngày sẽ tính lại báo cáo. Tổng hợp, tiền công theo từng nhân viên, chi tiết từng ngày, đơn hoàn tất và CSV tiếp tục dùng cùng khoảng ngày đã chọn.
- Không thay đổi schema Firestore, danh mục cây, giá, công thức tiền công, tồn kho hoặc dữ liệu đơn hàng.

## Kiểm tra
- `tools/v2694_report_date_range_payroll_test.js`: đạt.
- 86 bài test JavaScript hồi quy: đạt 86/86.
- `tools/preflight.py`: đạt.
- Cú pháp JavaScript: đạt 6 khối inline + bộ đọc PDF.
- Chưa build APK bằng GitHub Actions và chưa kiểm thử trên thiết bị/Firebase thật.
