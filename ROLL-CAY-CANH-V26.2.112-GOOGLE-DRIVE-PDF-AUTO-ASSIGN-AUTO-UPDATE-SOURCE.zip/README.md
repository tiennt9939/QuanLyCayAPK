# ROLL CÂY CẢNH V26.2.104 — Safe PDF import date recovery (versionCode 156)

Bản kế thừa V26.2.103: sửa lỗi nhập PDF bị bỏ qua khi mã vận đơn đã có trong hàng đợi ở một ngày cũ nhưng chưa giao/chưa ghi nhận. Chỉ chuyển ngày với nhãn staging chưa giao và không có bằng chứng quét/tiền công; các đơn đã giao, đã quét, liên kết hoặc thuộc nhân viên khác được giữ nguyên. Giữ phần sửa nhận diện khoảng trắng mã vận đơn của V26.2.103.

Mở `ROLL_CAY_CANH_V26.2.104_AUDIT_REPORT.md` để xem phạm vi, kiểm thử và giới hạn xác minh.
