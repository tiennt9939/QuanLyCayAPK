# ROLL CÂY CẢNH V26.2.110 — PDF import and assignment recovery

## Evidence from the latest screenshot and supplied JSON
The latest import summary says the PDF was read but `added 0 / updated 0`; employee-specific import reports one cross-date label while recorded/assigned/other-employee/missing counters are zero. This is different from a parser failure. The current source used `assignmentRequired === true` as a hard protection condition even when no actual assigned employee, scan report, photo, recorded wage, or linked packing order existed. The employee marking step also rejected `assignmentRequired` by itself.

The supplied JSON contains genuinely recorded rows with report IDs, scan timestamps, photos, and wage data. Those must not be reopened or re-counted merely to make the UI show an assignable order.

## Fix
- Treat `assignmentRequired=true` as a requirement flag, not proof that assignment actually happened.
- Rebase only an old-date `pdf_label` staging row that has no actual report, scan, photo, wage, completion, assignment, packing-order link, existing-order link, or assignment-history evidence.
- After safe rebase, allow the employee-PDF flow to mark it for the requested worker.
- Keep rows with actual recorded/scan/photo/wage data and active assignments protected; do not duplicate payroll or inventory effects.
- Employee import now classifies actual recorded/assigned state before falling back to generic cross-date/missing buckets.
- UI feedback separates recorded/scanned and assigned rows from other cross-date cases.
- Added `daily_shipment_pdf_assignment_recovery_test.js` covering the regression and safety boundaries.

## Preserved
Product-name recognition/mapping rules, combinations and quantities, payroll formulas, inventory, Firestore schema/rules, Google Drive photo persistence, barcode/OCR, assignment history, and idempotent completed-order accounting are unchanged. No records are deleted and no completed report is reopened.

## Validation
- `python3 tools/preflight.py`: PASS
- JavaScript regression suite: 99/99 PASS
- Inline/external JavaScript syntax: PASS
- ZIP integrity: PASS

This environment does not have Gradle installed. The archive is source only; GitHub Actions must still confirm Android compilation, APK signature, and release publication. Real-device PDF import and assignment validation remains necessary before claiming the issue fully resolved.
