# V26.2.101 — JSON export native bridge fix

## Root cause
`AndroidBridge.saveFile(...)` was declared as a public Java method but lacked `@JavascriptInterface`. Android WebView therefore did not expose it to JavaScript. The JSON export code fell back to a browser Blob download, which does not reliably save files in this app's WebView.

## Fix
- Expose `saveFile` with `@JavascriptInterface`, keeping the existing MediaStore destination `Download/ROLL CAY CANH`.
- Increment Android metadata to V26.2.101 / versionCode 153 so it can be installed over V26.2.100.
- Add a regression assertion to ensure the native bridge annotation remains present.
- No Firestore schema, payroll, inventory, PDF recognition, scan flow, or Drive image logic changed.
