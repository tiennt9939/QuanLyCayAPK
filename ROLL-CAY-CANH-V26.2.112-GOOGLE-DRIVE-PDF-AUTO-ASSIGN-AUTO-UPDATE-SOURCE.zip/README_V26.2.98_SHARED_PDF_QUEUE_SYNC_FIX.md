# ROLL CÂY CẢNH V26.2.98 — Đồng bộ hàng chờ PDF giữa các thiết bị

- Android `versionName`: `26.2.98`
- Android `versionCode`: `150`
- Gói ứng dụng: `com.quanlycay.apk`
- Nền phát triển: V26.2.97

## Sự cố được xử lý

Khi cùng một tài khoản Admin nhập PDF trên điện thoại chính, điện thoại thứ hai có thể vẫn hiển thị bộ đếm `Đơn/ngày`, `Đối chiếu cây` và `Chia việc` bằng 0. Source trước đó đọc tài liệu `/apps/roll-cay-canh` trong lần reconcile nhưng không theo dõi thay đổi tài liệu đó theo thời gian thực. Thêm vào đó, thao tác đồng bộ ghi lại toàn bộ snapshot ứng dụng, nên một thiết bị có hàng chờ PDF cũ/rỗng có nguy cơ đẩy snapshot lỗi thời.

## Thay đổi

1. Admin theo dõi tài liệu `apps/roll-cay-canh` qua Firestore `onSnapshot`; hàng chờ PDF/“Chia việc” được cập nhật khi thiết bị khác lưu thay đổi.
2. Hợp nhất hàng chờ theo mã vận đơn đã chuẩn hóa, có ID dự phòng; không tạo bản ghi trùng khi cùng đơn xuất hiện ở local và Cloud.
3. Bản ghi đã quét/đã ghi là bằng chứng nghiệp vụ; snapshot cũ không được hạ trạng thái đơn đã ghi về `imported` hay xóa dữ liệu tiền công/ảnh.
4. Trước khi ghi snapshot toàn ứng dụng lên Cloud, đọc snapshot mới nhất và hợp nhất hàng chờ/tombstone trước, giảm nguy cơ thiết bị stale ghi đè hàng chờ từ máy chính.
5. Hợp nhất dấu xóa/reset theo timestamp lớn nhất để một marker cũ từ Cloud không xóa mất marker mới hơn trên máy.
6. Không tạo collection Firestore mới; giữ nguyên document dùng chung và schema hiện có.

## Phạm vi không đổi

Không chỉnh sửa `MainActivity.java`, `ShippingBarcodeScannerActivity.java`, luồng camera/quét mã, ghi nhận đơn, công thức tiền công, tồn kho hoặc quy tắc nhận dạng PDF. Thay đổi chính trong `app/src/main/assets/index.html` là đồng bộ và hợp nhất hàng chờ dùng chung; các thay đổi khác cập nhật version, workflow và test hồi quy.

## Cách cập nhật an toàn sau khi build

1. Trên điện thoại chính đang còn thấy các đơn đã import, cài APK V26.2.98 sau khi GitHub Actions build thành công và mở app để đồng bộ.
2. Cài cùng APK V26.2.98 trên điện thoại phụ, đăng nhập cùng tài khoản Admin và giữ kết nối mạng; hàng chờ sẽ được tải qua Cloud/listener.
3. Không import lại cùng PDF để tránh đơn trùng. Trước khi xử lý công việc, xác nhận bộ đếm của máy phụ khớp với máy chính.

Nếu dữ liệu trên máy chính chưa từng được đẩy lên Cloud, lần đồng bộ từ máy chính là bước đưa hàng chờ đang còn trên máy lên Cloud. Không bấm đồng bộ trên máy phụ đang có bộ nhớ cục bộ rỗng/cũ trước khi máy chính đã đồng bộ.

## Trạng thái xác minh

Kiểm thử hồi quy và cú pháp source đạt trong môi trường kiểm tra. Chưa kiểm thử trực tiếp trên Firebase thật/hai điện thoại và chưa xác nhận APK build trong GitHub Actions từ gói này.
