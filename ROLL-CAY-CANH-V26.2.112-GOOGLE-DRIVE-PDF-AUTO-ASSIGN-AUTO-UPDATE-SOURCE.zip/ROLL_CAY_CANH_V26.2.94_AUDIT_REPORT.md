# Audit V26.2.94 — Chọn khoảng ngày để cộng tiền công

## Nguyên nhân
`rFrom` và `rTo` đã tồn tại trong `legacyGeneralReportPanel`, nhưng panel bị ẩn bởi selector CSS `#legacyGeneralReportPanel{display:none!important}` trong danh sách các panel ẩn. Do đó người dùng ở tab Báo cáo chỉ thấy tổng hợp một ngày mặc định, không có bộ chọn ngày hiển thị.

## Sửa
- Bỏ `#legacyGeneralReportPanel` khỏi selector ẩn; giữ nguyên các phần tử và ID hiện có để tránh tạo ID trùng.
- Gắn `onReportFromChange()` và `onReportToChange()` trực tiếp vào hai input ngày. Handler đã có sẵn và giới hạn ngày theo `START`/`END`, sau đó gọi `renderReport()`.
- Cả báo cáo admin và nhân viên dùng cùng bộ lọc `from`/`to` hiện hữu; tiền công vẫn được tính và phân nhóm theo logic sẵn có.
- VersionName 26.2.94 / versionCode 146 để cập nhật từ bản trước.

## Kết quả kiểm tra
- Test mới: đạt.
- Node regression tests: 86/86 đạt.
- Preflight: đạt.
- JavaScript syntax: đạt 6 khối inline và parser.
- ZIP integrity: cần xác minh ở bước đóng gói.
- Chưa có xác minh APK build hoặc thiết bị/Firebase thật.
