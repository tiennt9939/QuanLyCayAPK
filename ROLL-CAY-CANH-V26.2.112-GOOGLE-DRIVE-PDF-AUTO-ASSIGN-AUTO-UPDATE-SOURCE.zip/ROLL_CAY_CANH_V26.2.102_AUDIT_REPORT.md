# ROLL CÂY CẢNH V26.2.102 — Audit an toàn cache và Firestore push

Ngày: 24/10/2026
Baseline: source ZIP V26.2.101 (versionCode 153), giữ nguyên schema Firestore và nghiệp vụ.
Bản mới: V26.2.102, versionCode 154.

## Kết quả audit có căn cứ

1. `localSaveOnly()` serialize gần như toàn bộ `D` vào `localStorage` key `quanlycay`. Khi vượt quota, code giữ cache cũ và đánh dấu dirty, nhưng không có số liệu chẩn đoán key nào chiếm dung lượng lớn nhất.
2. `dailyShipmentPersistLocalBackup()` lưu thêm `dailyShipmentOrders` và `dailyShipmentReports` vào `roll_cay_daily_shipment_state_backup_v1`, tạo khả năng trùng dữ liệu với key chính.
3. `CloudSync.pushNow()` trước bản sửa không có khóa single-flight; `schedulePush()`, thao tác người dùng và các luồng nghiệp vụ đều có thể gọi push. Đây là lỗi concurrency đã thấy trực tiếp trong source. Nó là một nguyên nhân có thể góp phần gây lỗi SDK `Unexpected state`, nhưng không thể khẳng định là nguyên nhân duy nhất nếu chưa có log Firebase/thiết bị.
4. Luồng push hiện đọc/merge dữ liệu chung rồi ghi nguyên tài liệu. Cơ chế đọc-merge-ghi đa thiết bị không phải transaction nguyên tử; bản này không thay schema hay tự tuyên bố đã giải quyết mọi race giữa hai máy.

## Thay đổi trong V26.2.102

- Serialize `pushNow()` trong một WebView; các thay đổi phát sinh trong lúc ghi sẽ yêu cầu lượt push tiếp theo (tối đa 3 lượt trong chu kỳ hiện tại). Nếu còn thay đổi chưa đẩy được, giữ cờ `quanlycay_dirty`.
- Log giai đoạn lỗi (`read-latest`, `normalize-drive-references`, `firestore-write`, `post-write-local-cache`) cùng code/tên/message lỗi, không log JSON, dữ liệu người dùng hay ảnh.
- Thêm `window.rollCayStorageDiagnostics()` để trả về tổng byte/character và danh sách key theo dung lượng, cùng số ảnh Base64 nhúng trong các key nghiệp vụ; không hiển thị giá trị nội dung.
- Chỉ bỏ `dailyShipmentOrders`/`dailyShipmentReports` khỏi bản cache chính khi bản sao riêng parse được và hai mảng khớp chính xác. Nếu thiếu/hỏng/lệch, giữ nguyên dữ liệu trong cache chính. Không xóa key backup.
- Giữ nguyên collection/document `/apps/roll-cay-canh`, các collection đơn hàng hiện hữu, nghiệp vụ tồn kho/tiền công, nhận diện PDF, queue ảnh pending, chống trùng và luồng quét.
- Tăng version Android lên `26.2.102` / `154`; thêm bài test hồi quy riêng cho backup guard và push serialization.

## Kiểm chứng source

- `python3 tools/preflight.py`: PASS.
- `node --test tools/*_test.js`: 93/93 PASS.
- 4 khối inline JavaScript trong `index.html`: `node --check` PASS.
- `unzip -t` trên ZIP đầu ra: PASS (đã thực hiện sau khi đóng gói).
- Build Gradle cục bộ: KHÔNG THỰC HIỆN ĐƯỢC vì source ZIP không chứa Gradle Wrapper và môi trường hiện tại không cài `gradle`.
- GitHub Actions build APK: CHƯA CHẠY trong lần bàn giao này; source ZIP chưa được commit vào repository/nhánh `main` từ môi trường này.
- Firebase live/two-device test và cài APK trên điện thoại thật: CHƯA XÁC MINH. Không tuyên bố lỗi `INTERNAL ASSERTION FAILED` đã được xác nhận hết.

## Bước xác minh tiếp theo

1. Giữ file JSON backup mới nhất và một bản sao độc lập. Không gỡ app/clear storage/xóa key hoặc import lại PDF để xử lý lỗi.
2. Đưa ZIP này vào repository `tiennt9939/QuanLyCayAPK` trên `main`, bảo đảm workflow chọn đúng file kết thúc `AUTO-UPDATE-SOURCE.zip`, rồi chạy GitHub Actions.
3. Sau khi APK build thành công, kiểm tra trên một máy Admin: xem chẩn đoán bằng `rollCayStorageDiagnostics()` trong WebView devtools nếu có; nếu không có devtools, cần bổ sung UI chẩn đoán có chủ đích trước khi yêu cầu người dùng thao tác.
4. Đồng bộ một lần và lưu log lỗi theo stage nếu còn lỗi; kiểm thử hai Admin, hàng đợi PDF, ảnh Drive, đơn đã quét, tồn kho và tiền công trước khi tối ưu cache thêm.

## Giới hạn

Không có quyền truy cập trực tiếp vào localStorage/Firestore đang chạy trên điện thoại của người dùng trong phiên này. Do đó không thể đo dung lượng key thực tế, xác nhận dữ liệu Cloud live, hoặc kết luận root cause duy nhất của lỗi SDK chỉ từ source.
