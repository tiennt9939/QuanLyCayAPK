# ROLL CÂY CẢNH V26.2.106 — PDF image OCR fallback audit

## Evidence
The latest phone screenshot shows the import callback reached the parser with `pageCount=1`, then returned zero recognized tracking IDs. The most recent supplied Seller Center PDF in the conversation is seven pages and parses correctly using a text-layout extraction tool; therefore that file does not reproduce the one-page symptom. A single-page PDF with a raster/image barcode or missing text glyphs can still open in PDFBox while the text stripper returns no tracking ID.

## Root cause class addressed
Before this change, the native importer returned only PDFBox's visual/layout/standard text representations. If the shipping code existed only as a raster image or was omitted from the PDF text layer, no on-device OCR fallback was run; the JS callback then correctly stopped the import because it had zero tracking IDs.

## V26.2.106 change
- Keep the existing fast text-first PDF extraction unchanged.
- When all three text representations lack a supported GHN/J&T tracking-code pattern, render just that page to a temporary bitmap (170 DPI) and run the already-installed ML Kit text recognizer.
- Bound each OCR task to 18 seconds, recycle its bitmap immediately, and close the recognizer after the PDF loop.
- Send OCR text as a separate `ocrText` field and let the existing parser use it only as an additional fallback representation. If OCR recovers a tracking code while native text contains product lines, clear only the stale missing-tracking warning; retain all other review warnings.
- If OCR still cannot recognize a code, the existing safe stop remains: no rows are imported and business data is not changed.

## Preserved
No edits to product matching rules, catalog, wage/payroll formulas, inventory deductions, assignment/scan/photo/Drive workflows, Firestore schema/rules, or the storage recovery change from V26.2.105. No data reset or destructive migration.

## Checks and limits
- Offline JS parser regressions, including OCR-only J&T/GHN cases, are run with the complete test suite and preflight.
- The full APK build and ML Kit OCR on the user's physical Android phone must still be confirmed by the repository GitHub Actions build and installation; the container does not have Gradle/Android SDK and cannot claim an APK/device test.
