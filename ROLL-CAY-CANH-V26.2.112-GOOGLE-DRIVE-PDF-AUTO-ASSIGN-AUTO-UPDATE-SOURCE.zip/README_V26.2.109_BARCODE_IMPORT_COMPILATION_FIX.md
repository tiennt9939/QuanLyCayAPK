# ROLL CÂY CẢNH V26.2.110 — ML Kit Barcode compile fix

## Root cause verified from GitHub Actions
V26.2.108 failed at `:app:compileDebugJavaWithJavac` with 12 `cannot find symbol` errors for `Barcode`. MainActivity imported `com.google.mlkit.vision.barcode.Barcode`, but the ML Kit API class is `com.google.mlkit.vision.barcode.common.Barcode`. BarcodeScanner, BarcodeScannerOptions, and BarcodeScanning stay under `com.google.mlkit.vision.barcode`.

## Fix
- Corrected only the `Barcode` class import.
- Added a regression assertion that verifies the correct package and rejects the old import.
- Bumped versionName to 26.2.110 and versionCode to 161 for an in-place Android update.

## Preservation
No changes to business logic, PDF text/OCR/barcode flow, product matching, payroll formulas, inventory, orders, Firestore schema/rules, sync, Drive, or assignment behavior.

## Verification
Run `python3 tools/preflight.py`, every `tools/*_test.js`, and JavaScript syntax checks using the existing GitHub Actions workflow. This working environment has no Gradle executable/wrapper, so the Android APK build must be confirmed by GitHub Actions; do not treat source tests as an APK-build result.
