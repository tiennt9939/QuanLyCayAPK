# V26.2.90 — Đơn ngoài: Admin chụp ảnh, nhân viên xem đơn và báo cáo ngày

## Admin chụp ảnh thay nhân viên
1. Đảm bảo đơn có loại `ĐN`, đã được giao cho một nhân viên cụ thể và không nằm trong `open_pool`.
2. Mở khu vực Đơn ngoài hoặc bảng giao việc, nhấn **📷 ADMIN CHỤP ẢNH & HOÀN TẤT**.
3. Chụp/chọn một ảnh, chờ tải ảnh qua luồng Google Drive hiện có hoàn tất rồi xác nhận.
4. Bản ghi hoàn tất giữ nhân viên đã được giao làm người hưởng tiền công; Admin chỉ là người ghi nhận thao tác.
5. Đơn chưa được giao, đã hoàn tất, hoặc không thuộc loại `ĐN` không đủ điều kiện cho thao tác này.

## Nhân viên xem đơn ngoài
- Trong tab **Theo ngày**, nhân viên đăng nhập thấy danh sách đơn đã giao cho đúng UID của mình.
- Dùng bộ lọc **🌱 Đơn ngoài** để chỉ xem đơn ĐN. Danh sách hợp nhất theo ID giữa nguồn dữ liệu đơn đã giao và thông báo đơn; bản cache chỉ được dùng khi không có dữ liệu trực tiếp, nhằm tránh hồi sinh đơn cũ đã bị xóa.
- Đơn chưa giao hoặc đơn của nhân viên khác không hiển thị như đơn của mình.

## Báo cáo cây và tiền công theo ngày
- Tab **Theo ngày** và **Báo cáo** dùng các bản ghi hoàn tất của tài khoản nhân viên hiện tại.
- Hiển thị tổng số cây, tổng tiền công/ngày, số đơn và chi tiết số cây theo tên cây/kích thước.
- Tổng tiền công dùng hàm tính hiện có `packerPay` để giữ điều chỉnh/snapshot hợp lệ. Tổng chi tiết cây dùng số lượng và tiền công cơ sở của các dòng sản phẩm; nếu có phần lệch do điều chỉnh/snapshot thì hiển thị riêng, không âm thầm thay đổi tổng công chuẩn.

## Tính tương thích
- Luồng **NHẬP PDF NHÃN ĐƠN CHUNG** không bị thay thế.
- Không đổi Firestore Rules, schema dữ liệu, quy tắc nhận diện, công thức tiền công hoặc tồn kho.
- Đây là source đã qua test mã nguồn, chưa phải APK đã build và chưa được xác minh trên Firebase/Drive thật. Build qua GitHub Actions và kiểm tra trên điện thoại trước khi triển khai.
