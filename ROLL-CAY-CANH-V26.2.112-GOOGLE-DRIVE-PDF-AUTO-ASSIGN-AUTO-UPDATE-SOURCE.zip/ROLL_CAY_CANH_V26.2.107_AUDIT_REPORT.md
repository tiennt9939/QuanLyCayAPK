# ROLL CÂY CẢNH V26.2.107 — PDF tracking recognition root fix

## Root cause in V26.2.106 source
The native Java preflight detector and the JavaScript tracking parser used different whitespace rules. Java's detector accepted `\\s` (including CR/LF) between tracking characters and therefore could skip OCR. JavaScript only accepted spaces/tabs/hyphens, so a PDFBox layout that placed glyphs on separate lines could still produce zero tracking candidates in the import callback.

There was a second safety issue in treating variable-length VNGH/GHVN patterns as newline-tolerant: line breaks can also separate the end of a tracking string from text on the next line. A fully permissive `\\s` gap could absorb adjacent text and generate a false longer code.

## V26.2.107 changes
- Align Java and JS tracking detection: fixed-length J&T formats can span whitespace/newlines; current VNGH labels can span line breaks for the known 11-digit numeric suffix.
- Keep variable-length VNGH/GHVN patterns horizontal-layout-only to avoid swallowing neighboring text. If an unfamiliar GHVN or VNGH layout cannot be confidently parsed, native detection does not suppress the OCR fallback.
- Narrow VNGH suffix matching to digits, consistent with the existing `carrierFor()` validation. Supported prefixes and expected lengths remain guarded.
- When no tracking code is found, the UI shows only sanitized counters (native text characters, OCR text characters, candidate count). It does not show or log recipient names, phones, addresses, or raw label text.
- Preserve the V26.2.106 OCR fallback, V26.2.105 cache/storage recovery, date reconciliation protections and assignment-first daily shipping workflow.

## Regression evidence
- New `tools/tiktok_tracking_whitespace_root_fix_test.js`: tests VNGH and J&T tracking numbers where glyphs are split by LF/CRLF/nonbreaking spaces, and guards against accidentally extending a VNGH code into the next line.
- The supplied `TikTokSeller_1792928941021(1).pdf` is 7 pages and contains seven supported tracking codes. Its extracted text still produces exactly those seven IDs in the current parser. The code in the user's earlier screenshot is from a different one-page PDF; that exact file is not present as a separate PDF in the available workspace, so the exact screenshot PDF cannot be reproduced offline.
- Native Java tracking detector patterns compiled and passed a small parity check for fixed-length newline-separated codes and OCR handoff behavior for variable-length GHVN codes split across lines.

## Preserved business behavior
No changes to Firestore schema/rules, catalog, plant-size matching, combo quantities, payroll/wage formulas, inventory deductions, assignments, barcode/photo completion, Drive image storage or order statuses. No data resets, no deletion of canonical orders/reports, and no changes to records already marked recorded.

## Validation
- `python3 tools/preflight.py`: PASS.
- All `tools/*_test.js`: 97/97 PASS.
- Inline JavaScript syntax: all 4 non-empty inline blocks PASS.
- `app/src/main/assets/tiktok-label-import.js` syntax: PASS.
- Actual supplied 7-page PDF text regression: 7/7 IDs matched exactly.
- Source ZIP integrity: PASS.

## Limits
- This environment does not build/install Android APKs. The repository's GitHub Actions build and real-phone verification of V26.2.107 must still run before claiming this fix is confirmed on the device.
