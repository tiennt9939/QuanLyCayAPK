# V26.2.103 — PDF tracking whitespace fix

## Lỗi quan sát được
Khi nhập PDF vận chuyển, giao diện có thể báo nhập xong nhưng `thêm 0, cập nhật 0` và không có nhãn nào được đưa vào luồng chia việc. PDF mẫu có 7 nhãn hợp lệ: 6 mã J&T bắt đầu bằng `862` và 1 mã GHN bắt đầu bằng `VNGH`.

## Nguyên nhân trong source
`tiktok-label-import.js` trước đây chỉ chấp nhận tối đa một dấu cách/tab/gạch giữa từng ký tự mã vận đơn. Bộ trích xuất PDF dùng tọa độ glyph có thể chèn nhiều dấu cách giữa các số, khiến regex không nhận ra mã dù văn bản vẫn có số vận đơn. Việc đó làm dòng parser thiếu `trackingNo`; luồng nhập bỏ qua những dòng không có mã và có thể tạo thông báo 0 nhãn.

## Sửa đổi
- Nới pattern chính xác của J&T Express, J&T Cargo, GHN để chấp nhận chuỗi khoảng trắng/gạch có độ dài bất kỳ giữa ký tự rồi chuẩn hóa mã.
- Tổng hợp mã nhận diện từ các biểu diễn văn bản PDF hiện có. Nếu các biểu diễn bất đồng về mã, không tự đoán mã.
- Dừng nhập và báo lỗi rõ nếu cả PDF không có mã vận đơn dùng được; không ghi danh sách rỗng và không hiện thông báo thành công giả.
- Tăng versionName lên `26.2.103`, versionCode lên `155` để có thể cài cập nhật.
- Cập nhật regression assertions và preflight để bám version hiện hành.

## Phạm vi không thay đổi
Không thay schema Firestore, danh mục cây, các quy tắc nhận diện cây/size/combo, phân công nhân viên, tính lương, tồn kho, quét barcode, luồng ảnh Drive, hay cấu trúc dữ liệu nghiệp vụ. Không xóa dữ liệu hiện có.

## Kiểm chứng
- Parser test và barcode-flow test: PASS.
- PDF layout / coordinate cells / multi-product / continuation / combo / completed-order reconciliation tests: PASS.
- `tools/preflight.py`: PASS.
- 93/93 bài `tools/*_test.js`: PASS.
- PDF người dùng gửi đọc thử bằng `pdftotext -layout`: 7 trang → 7 nhãn, 7/7 có tracking; các mã quan sát được là `862631586442`, `862693306442`, `862600576452`, `862656546442`, `VNGH80799520620`, `862665876452`, `862683066452`.
- Đã thêm test tái hiện nhiều dấu cách giữa mỗi ký tự của mã tracking.
- Chưa build APK trong container (không có Gradle wrapper hoặc Gradle cài sẵn), chưa chạy GitHub Actions và chưa xác minh trên thiết bị Android thật.
