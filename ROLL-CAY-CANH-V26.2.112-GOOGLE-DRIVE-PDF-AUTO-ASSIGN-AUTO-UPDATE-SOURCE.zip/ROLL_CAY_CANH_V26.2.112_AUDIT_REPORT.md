# ROLL CÂY CẢNH V26.2.112 — Audit báo cáo

## Kết quả

- Baseline: `ROLL-CAY-CANH-V26.2.111-PDF-IMPORT-DATE-ROLLOVER-AUTO-UPDATE-SOURCE.zip`.
- Android package: `com.quanlycay.apk`.
- Version: `26.2.112`; versionCode: `164`.
- Thêm 3 native bridge methods: tạo thư mục PDF nhân viên, liệt kê PDF trong hộp thư Drive và tải/parse PDF từ Drive bằng pipeline hiện tại.
- Thêm thư mục gốc `ROLL_CAY_CANH_IMPORT` cùng các thư mục con theo ID/tên nhân viên.
- Tạo thư mục cho tài khoản `packer` khi cấp tài khoản nếu Drive đã kết nối; rà soát lại các nhân viên `packer` hoạt động sau khi kết nối và theo chu kỳ thử lại.
- Poll Drive mỗi 60 giây chỉ khi app đang ở foreground, khi app hiện lại và khi kết nối mạng khôi phục.
- Auto-assign chỉ được bật với luồng Drive và chỉ phân công các nhãn đã đối chiếu đủ cây. Luồng import thủ công giữ nguyên hộp xác nhận.
- Dùng key gồm file ID + modifiedTime + size + md5Checksum để phát hiện file được thay nội dung trong cùng ID; việc nhập lại vẫn được bảo vệ bởi logic mã vận đơn/đơn hiện có.
- Thay đổi quyền Drive bổ sung `https://www.googleapis.com/auth/drive.readonly` để có thể duyệt những PDF tải lên từ app Drive trên iPad; scope này là restricted theo tài liệu Google.

## Kiểm thử đã thực hiện trong môi trường hiện tại

- `python3 tools/preflight.py`: PASS.
- Cú pháp các khối script JavaScript trong `index.html`: PASS (4 khối script inline).
- `node tools/drive_pdf_employee_auto_sync_test.js`: PASS.
- Toàn bộ `tools/*_test.js`: PASS (101 tests).
- ZIP và APK: source package được đóng gói riêng; chưa chạy được Android Gradle build trong môi trường tạo artifact vì không có lệnh `gradle`, Gradle wrapper hoặc Android SDK đã cài. Do đó không tuyên bố APK đã được biên dịch hoặc thử nghiệm trên thiết bị.

## Rủi ro/điều kiện chưa xác nhận

- Chưa thể xác minh từ môi trường cục bộ việc cấp `drive.readonly` trên OAuth project của người dùng. Google xếp scope này vào nhóm restricted; việc chạy thật phụ thuộc cấu hình consent screen/verification hoặc user test được cấp quyền.
- Cần kiểm thử thực tế với cùng tài khoản Drive trên iPad và thiết bị Android Admin, đặc biệt file TikTok PDF thật, quyền Drive, nhãn chưa đủ mapping và nhãn đã có trạng thái.
- Tự đồng bộ là foreground polling; nó không chạy khi app bị đóng hẳn. App kiểm tra lại khi mở trở lại.

## Những phần không thay đổi

- Firebase Authentication / Firestore schema và quyền user hiện tại.
- Nhận diện PDF TikTok, OCR/barcode fallback, catalog matching/rules, mapping queue.
- Logic ID vận đơn chống trùng, bảo vệ đơn đã ghi nhận/đã giao/đã hoàn thành.
- Công thức tiền công, tồn kho, ảnh bằng chứng và luồng quét mã hoàn tất.
