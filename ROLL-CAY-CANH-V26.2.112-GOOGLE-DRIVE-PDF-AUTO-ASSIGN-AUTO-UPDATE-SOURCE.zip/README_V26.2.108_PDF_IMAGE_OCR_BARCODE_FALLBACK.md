# ROLL CÂY CẢNH V26.2.108 — PDF image/OCR/barcode fallback

## Purpose
Fix the import failure where the app opened a PDF page but reported zero supported tracking IDs. The existing PDFBox text extraction, visual-coordinate text, and ML Kit OCR can all fail on scanned/image-only labels or fail to read one of the tracking characters.

## What changed
- Kept PDFBox text extraction as the fast primary path.
- For a page where none of the three native text representations contains a supported tracking pattern, render that page at 220 DPI, run bundled ML Kit Text Recognition, then decode supported linear shipping barcodes if OCR still has no supported tracking pattern.
- Barcode fallback accepts only known shipping-code patterns (J&T `862…`, J&T Cargo `530…`, GHN `VNGH…` or `GHVN…`); it does not use arbitrary QR/product codes as an order identity.
- Pass barcode detections independently to the JavaScript parser, so tracking recovery does not overwrite OCR product/Order ID evidence.
- Recycle the bitmap after each page and close ML Kit recognizers/scanners at the end of the import.
- When no code can be detected, show sanitized counters for native text, OCR, barcode output, and page-level OCR/barcode errors. No raw recipient text is displayed in the diagnostic.

## Preserved
- Firestore schema/rules, catalog entries, recognition rules, wage formulas, inventory accounting, order statuses, assignment requirements, photo evidence, Google Drive references, and duplicate-tracking safety.
- No orders are created, marked complete, or assigned merely because OCR/barcode fallback finds a code.
- No existing data is reset or deleted.

## Version
- `versionName`: `26.2.108`
- `versionCode`: `160`
- Android package: `com.quanlycay.apk`

## Validation limits
- Source tests exercise barcode-only recovery, line-break-separated tracking IDs, and preservation of OCR Order ID/product rows.
- The previously provided seven-page text-based PDF parses as 7/7 tracking IDs in the local parser regression.
- The one-page PDF that produced the latest phone error was not attached as a PDF in that turn, so direct reproduction against that exact one-page file and real-device ML Kit validation remain unverified. The new diagnostic now shows whether native text, OCR, or barcode fallback produced anything if the same file still fails.
- APK build and phone install must be verified by the repository's GitHub Actions workflow; this environment does not have a configured Android signing key/Gradle build environment.
