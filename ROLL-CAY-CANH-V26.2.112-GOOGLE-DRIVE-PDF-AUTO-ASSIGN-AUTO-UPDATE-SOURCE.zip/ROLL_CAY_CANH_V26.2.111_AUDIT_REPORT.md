# ROLL CÂY CẢNH V26.2.111 — PDF import date rollover audit

## Evidence and scope
The current export contains 985 daily shipment rows through 2026-10-25 and none for 2026-10-26. The visible app screenshot taken on the morning of 2026-10-26 still shows the selected date as 25/10/2026. The PDF importer uses the selected `dDate` as the business date, so an app left open across midnight can continue importing a new day's file into yesterday's view/date.

The only PDF attached to the available workspace is the seven-page `TikTokSeller_1792928941021(1).pdf`, created on 2026-10-25. Its seven tracking IDs already exist in the supplied JSON as recorded rows. It is not a sample of today's new labels, so it cannot verify their exact parser output.

## Fix
- Add `dailyShipmentPreparePdfImportDate()` at the common Android PDF-picker entry point, covering common, employee-specific and legacy direct PDF import buttons.
- When a stale date is carried over midnight without being deliberately selected on the current day, automatically roll the import date to today and request a refresh of today's cloud scan records.
- Preserve an intentional historical date selected by the user during the current day; this avoids breaking historical re-import workflows.
- Include the actual target date in the import-result notification, so the date used for each import is visible.
- Add a regression test for stale-date rollover, deliberate historical selection, and a historical selection becoming stale after midnight.

## Preserved
No change to tracking-code regex, PDF parser, plant recognition rules, plant catalog, payroll calculation, inventory, assignment ownership, Firestore schema/rules, Drive photo handling or completed-order idempotency. Previously recorded labels are not reopened or re-counted.

## Validation boundaries
The source is still subject to the repository's Android build workflow and real-device verification. The latest attached PDF is dated 2026-10-25; no new 2026-10-26 PDF was available in this workspace, so this audit does not claim a physical-device pass on today's exact label format.
