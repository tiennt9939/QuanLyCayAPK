# ROLL CÂY CẢNH V26.2.103 — Audit khẩn luồng nhập PDF nhãn

## Kết luận
Đã xác định được nguyên nhân kỹ thuật phù hợp với triệu chứng nhập PDF không thêm nhãn: parser chỉ cho phép tối đa một khoảng trắng/tab/dấu gạch giữa mỗi ký tự của mã tracking. Bộ tái dựng tọa độ glyph của PDFBox có thể tạo nhiều khoảng trắng giữa các chữ số, vì vậy `extractTracking()` trả về rỗng dù trang PDF vẫn có mã vận đơn rõ ràng. Khi toàn bộ mã bị bỏ, luồng nhập có thể hiển thị `0 nhãn` do các dòng không có `trackingNo` bị bỏ qua.

## Dấu hiệu đối chiếu với PDF được gửi
PDF có 7 trang và chứa 7 mã vận đơn đọc được:
- J&T Express: `862631586442`, `862693306442`, `862600576452`, `862656546442`, `862665876452`, `862683066452`.
- GHN: `VNGH80799520620`.

Dùng `pdftotext -layout` để chạy parser cục bộ cho kết quả 7/7 nhãn có tracking và trạng thái `ready`. Bài hồi quy mới mô phỏng khoảng trắng kép/nhiều giữa từng glyph, đây là dạng mà parser cũ không nhận ra.

## Những sửa đổi
1. `tiktok-label-import.js`: regex tracking chấp nhận khoảng trắng/tab/dấu gạch lặp lại giữa ký tự, vẫn giữ tiền tố và độ dài chính xác của định dạng để tránh nhầm Order ID. Tracking được đối chiếu qua các kiểu trích xuất PDF có sẵn; nếu bất đồng, mã không được đoán.
2. `index.html`: nếu PDF đã mở nhưng parser không nhận ra bất kỳ mã vận đơn nào, dừng trước khi ghi queue, báo nguyên nhân rõ và không hiện thông báo thành công 0 nhãn.
3. Version nâng lên `26.2.103` / versionCode `155`, cập nhật preflight và các bài kiểm tra yêu cầu metadata hiện hành.
4. Giữ nguyên schema Firestore, nhận diện cây/size/combo, hàng tồn, tiền công, logic chia việc, quét barcode và lưu ảnh Drive.

## Kết quả kiểm thử
- `python3 tools/preflight.py`: PASS.
- `tools/*_test.js`: 93/93 PASS.
- JavaScript: 6 khối script nhúng và `tiktok-label-import.js` đều PASS cú pháp.
- Android XML: `AndroidManifest.xml` và `styles.xml` PASS.
- PDF parser / barcode flow / real-layout / coordinate cells / continuation / multi-product / combo / completed-order reconciliation: PASS.
- PDF người dùng gửi, mô phỏng parser trên kết quả trích xuất layout: 7/7 nhãn tracking được nhận.

## Giới hạn chưa được xác minh
Không có Gradle executable hoặc Gradle Wrapper trong môi trường hiện tại, nên chưa build APK ở đây. Chưa chạy GitHub Actions và chưa kiểm tra trên điện thoại/Firebase/Drive thật. Cần để workflow của repository build APK từ source V26.2.103, sau đó thử import lại chính PDF 7 trang và xác minh cả hàng đợi chia việc. Không xóa dữ liệu ứng dụng, không reset ngày và không nhập lại JSON để thử sửa lỗi này.
