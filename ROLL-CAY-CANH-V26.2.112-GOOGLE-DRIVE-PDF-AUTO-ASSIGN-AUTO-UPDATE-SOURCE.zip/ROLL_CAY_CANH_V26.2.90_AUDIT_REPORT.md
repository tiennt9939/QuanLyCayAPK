# ROLL CÂY CẢNH V26.2.90 — Audit report

## Phạm vi
- Source base: V26.2.89.
- Tăng versionName lên `26.2.90`, versionCode lên `142`.
- Giữ nguyên luồng nhập PDF chung và schema Firestore.
- Thêm luồng Admin chụp ảnh thay cho nhân viên đối với đơn ngoài loại `ĐN` đã giao.
- Nhân viên có bộ lọc riêng `🌱 Đơn ngoài`; danh sách giao việc hợp nhất theo ID để tránh bỏ sót đơn từ một nguồn dữ liệu.
- Báo cáo nhân viên giới hạn dữ liệu theo UID hiện tại, trình bày tổng cây/tổng tiền công/ngày và phân tích theo cây/kích thước.

## An toàn nghiệp vụ
- Không cho Admin hoàn tất ảnh thay trên đơn chưa giao hoặc loại đơn không phải `ĐN`.
- Khi Admin chụp thay, bản ghi hoàn tất vẫn ghi công cho nhân viên được giao; Admin là người thực hiện thao tác.
- Chỉ một ảnh bằng luồng hiện có, tải Drive xong mới xác nhận.
- Không tự ghi công, trừ kho hoặc tạo đơn mới chỉ vì mở thao tác/chọn ảnh.
- Không thay Firestore Rules, schema, công thức tiền công, tồn kho, parser PDF hoặc luồng import chung.
- Báo cáo dùng tổng tiền công chuẩn (`packerPay`) và cho hiển thị riêng phần điều chỉnh/snapshot chênh lệch thay vì làm sai tổng.

## Kiểm thử
- `tools/preflight.py`: PASS.
- Tất cả `tools/*_test.js`: 82 bài, 0 lỗi.
- Kiểm thử mới `admin_outside_order_photo_completion_test.js`: PASS.
- Kiểm thử mới `employee_outside_order_and_daily_plant_report_test.js`: PASS.
- JavaScript parser và các block nhúng: PASS.
- Android manifest và styles XML: PASS.
- ZIP integrity: PASS (xác minh sau khi đóng gói).

## Giới hạn xác minh
- Chưa chạy Gradle/GitHub Actions build; không tuyên bố APK đã được tạo.
- Chưa cài lên điện thoại và chưa kiểm tra live Firebase/Google Drive.
- Do đó cần build từ ZIP và kiểm tra trên thiết bị trước khi dùng thật.
