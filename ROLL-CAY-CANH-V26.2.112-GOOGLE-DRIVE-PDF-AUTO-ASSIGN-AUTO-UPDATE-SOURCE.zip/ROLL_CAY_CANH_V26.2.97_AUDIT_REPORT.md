# ROLL CÂY CẢNH V26.2.97 — Audit bộ đếm nhân viên theo cây + SKU

## Baseline và phạm vi
- Baseline: V26.2.96, versionCode 148 (`com.quanlycay.apk`).
- Candidate: V26.2.97, versionCode 149.
- Sửa phạm vi báo cáo: trong thẻ “Đơn phân công đã hoàn tất theo nhân viên”, luồng mở chi tiết đổi thành **nhân viên → bộ đếm cây/kích thước/SKU → danh sách đơn của bộ đếm → chi tiết đơn**.

## Hành vi mới
- Các đơn chỉ gom chung khi tên cây, kích thước và SKU giống nhau. SKU là khóa chính; khi SKU không có thì dùng Seller SKU nếu có.
- Khi bấm vào tên nhân viên mới dựng các bộ đếm của nhân viên đó. Khi bấm bộ đếm mới dựng danh sách đơn; chi tiết đơn chỉ được dựng khi mở từng đơn.
- Mỗi đơn trong danh sách hiển thị mã vận đơn, ngày, số cây trong bộ đếm, SKU và tiền công phân bổ theo dữ liệu đã ghi nhận.
- Với dữ liệu cũ không lưu SKU liên kết cây, UI giữ nhóm “SKU chưa lưu trong bản ghi”. Không chạy lại quy tắc nhận diện hiện tại để phỏng đoán lịch sử.
- Nếu nhiều SKU cùng ánh xạ tới một dòng cây nhưng tổng số lượng snapshot không khớp số cây ghi nhận, không tự chia SKU; dòng được đưa vào nhóm SKU chưa xác định.

## Hạn chế ảnh hưởng nghiệp vụ
- Đây là thay đổi đọc/hiển thị trong `app/src/main/assets/index.html`.
- Không thay đổi `MainActivity.java`, scanner Java, giao dịch Firestore, schema Firestore, quy tắc nhận diện PDF, quy trình quét, đánh dấu hoàn tất, chống ghi trùng, công thức tiền công hay tồn kho.
- Các thay đổi trong test cũ chỉ cập nhật các kỳ vọng versionName/versionCode của build hiện tại hoặc chuyển kỳ vọng UI sang luồng mở theo bộ đếm.

## Kết quả kiểm tra thực tế
- Preflight: PASS.
- Test JavaScript hồi quy: 89/89 PASS.
- Cú pháp JavaScript: 6 khối script inline + `tiktok-label-import.js` PASS.
- ZIP sau khi đóng gói: kiểm tra CRC và kiểm tra source sau giải nén.
- Chưa chạy Gradle/GitHub Actions build APK và chưa kiểm thử trên điện thoại/Firebase thật. Vì vậy không khẳng định đã xác minh độ mượt trên thiết bị thật.
