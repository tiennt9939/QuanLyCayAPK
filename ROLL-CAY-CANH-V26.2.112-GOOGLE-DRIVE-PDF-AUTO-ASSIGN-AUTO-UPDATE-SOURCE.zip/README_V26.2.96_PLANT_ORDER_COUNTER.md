# V26.2.96 — Bộ đếm đơn hàng theo tên cây + kích thước

- Phiên bản Android: `26.2.96` — `versionCode 148`.
- Nền source: V26.2.95; giữ nguyên mã gói `com.quanlycay.apk`.
- Trong tab Báo cáo, thay bảng chỉ đếm cây bằng các bộ đếm nhóm theo tên cây và kích thước. Mỗi bộ đếm hiển thị số đơn riêng, số cây và tiền công được phân bổ để xem báo cáo.
- Bấm bộ đếm để mở danh sách những đơn có cây/kích thước đó; mỗi đơn có mã vận đơn, ngày, số cây trong nhóm và bằng chứng tên sản phẩm/SKU nếu dữ liệu gốc có sẵn.
- Bấm từng đơn để mở chi tiết sản phẩm/SKU và dòng cây đã ghi nhận.
- Danh sách đơn và chi tiết đơn được tạo khi mở (lazy rendering), không dựng chi tiết của toàn bộ đơn ngay khi mở Báo cáo.
- Sản lượng nhập ghi tay trong Theo ngày được hiển thị riêng, không được giả làm đơn hàng vì không có mã đơn để truy ngược.
- Không thêm trường Firestore, không thay đổi dữ liệu đã lưu. Không chỉnh luồng quét mã, hoàn tất đơn, nhận diện PDF, công thức tiền công hoặc tồn kho.

Bản này đã chạy preflight, test hồi quy, và kiểm tra cú pháp JavaScript trong source. Chưa build APK/GitHub Actions và chưa kiểm thử trên thiết bị/Firebase thật.
