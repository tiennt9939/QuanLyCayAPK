# ROLL CÂY CẢNH V26.2.105 — Audit phục hồi import PDF khi bộ nhớ WebView gần đầy

## Triệu chứng và bằng chứng
- Người dùng xác nhận nhập PDF hoạt động trước khoảng 18:00 ngày 25/10/2026 và sau đó không thể nhập thêm đơn hợp lệ; V26.2.104 vẫn tái hiện.
- Bản sao lưu ứng dụng mới nhất có 985 `dailyShipmentOrders` (944 `recorded`, 39 `imported`, 2 `legacy_linked`) và 286 báo cáo đã ghi. Danh sách vận chuyển theo ngày đang chọn là dữ liệu nghiệp vụ lớn và có bản backup riêng trong LocalStorage.
- Source trước đây giữ cache phụ `roll_tiktok_label_queue_v1` riêng cho parser PDF. Cơ chế dọn cũ chủ yếu xác định nhãn đã xử lý thông qua `packingOrders`; nhãn của luồng vận chuyển hằng ngày được ghi ở `dailyShipmentOrders` / `dailyShipmentReports`, nên bản sao parser có thể còn lại dù bản ghi chính đã được ghi nhận.
- Thứ tự lưu trước đây trong `importParsedLabelsIntoDailyShipments()` gọi `save()` trước `dailyShipmentPersistLocalBackup()`. Nếu backup chưa trùng với snapshot mới, `localSaveOnly()` tạm cố ghi cả `dailyShipmentOrders` và `dailyShipmentReports` vào cache chính rồi mới ghi bản backup tách biệt. Khi danh sách lớn, bước này làm tăng mạnh dung lượng cần ghi và có thể chạm giới hạn LocalStorage/WebView.

## Sửa ở V26.2.105 / versionCode 157
1. Thêm `compactTikTokStagingQueueFromDailyShipmentState()`: đối chiếu tracking trong cache parser với đơn/báo cáo vận chuyển chính; chỉ loại bản sao cache của nhãn đã recorded, assigned, linked hoặc completed.
2. Giữ nguyên `D.dailyShipmentOrders`, `D.dailyShipmentReports`, bằng chứng ảnh, product maps, quy tắc nhận diện và tombstone quy tắc; không xóa đơn, báo cáo, tiền công hoặc tồn kho.
3. Trước khi ghi dữ liệu vận chuyển mới, compact và lưu cache PDF trước; ghi `dailyShipmentPersistLocalBackup()` trước `save()`. Khi backup đã khớp snapshot, `localSaveOnly()` có thể loại các mảng lớn khỏi cache chính mà không mất dữ liệu vì bản backup canonical đã tồn tại.
4. Sau khi ghi nhận quét thành công, dọn bản sao cache staging tương ứng để tránh tăng dần qua nhiều ngày.
5. Nếu không ghi được cache phụ hoặc bản backup vì quota, không âm thầm dừng luồng mapping; hiện cảnh báo rõ, giữ dữ liệu trong phiên và yêu cầu đồng bộ Cloud.

## Những gì không thay đổi
- Firestore schema/rules, catalog, giá, quy tắc nhận diện cây/size/combo.
- Công thức tiền công, tồn kho, ghi nhận báo cáo, phân công, quét mã, ảnh và Drive.
- Nhãn đã ghi nhận không bị nhập lại, tính công hoặc trừ tồn lần hai.
- Không xóa dữ liệu người dùng hay reset ngày.

## Kiểm tra
- `python3 tools/preflight.py`: PASS.
- Toàn bộ `tools/*_test.js`: 95/95 PASS.
- Cú pháp inline JavaScript: 4 khối có nội dung đều PASS; hai khối rỗng được bỏ qua. `tiktok-label-import.js`: PASS.
- `tools/tiktok_pdf_storage_recovery_test.js`: PASS. Mô phỏng quota hẹp xác nhận các bản sao nhãn đã xử lý được dọn, hai nhãn pending/review còn nguyên, product maps/quy tắc vẫn nguyên, đơn/báo cáo chính không đổi; sau đó ghi snapshot mở rộng thành công.
- Regression `tools/daily_shipment_cross_date_import_fix_test.js`: PASS.
- Parser regression hiện có cho PDF nhiều trang, mã tracking, SKU/Qty, nhãn nối trang và combo: PASS trong bộ test.
- ZIP integrity: kiểm tra sau khi đóng gói.

## Giới hạn xác minh
- Không có quyền đọc trực tiếp LocalStorage của điện thoại nên không thể đo chính xác số byte/quota trên thiết bị của người dùng. Nguyên nhân được xác lập từ đường đi ghi dữ liệu và dung lượng queue tích lũy; kiểm thử tái hiện tình huống quota hẹp ở mức helper/persistence.
- APK phải được build bằng GitHub Actions rồi thử trên điện thoại thật. Không tuyên bố đã xác minh Firebase/Drive hay cài đặt thực tế của V26.2.105 cho đến khi có kết quả build và thiết bị.
