# V26.2.97 — Bộ đếm đơn nhân viên theo cây + SKU

- Android version: `26.2.97`; `versionCode 149`. Baseline: V26.2.96.
- Trong Báo cáo, mở nhân viên để xem bộ đếm theo tên cây + kích thước + SKU (ưu tiên SKU; dùng Seller SKU khi thiếu SKU).
- Bấm bộ đếm để mở danh sách những đơn đã ghi nhận thuộc đúng nhóm; bấm một đơn để xem chi tiết gốc.
- Các nhóm được tính từ dòng cây đã ghi nhận và bằng chứng SKU được lưu tại thời điểm quét. Không chạy lại quy tắc nhận dạng hiện tại để suy diễn lịch sử. Trường hợp nhiều SKU cùng map về một dòng cây nhưng số lượng snapshot không khớp sẽ được đưa vào nhóm `SKU chưa lưu/không xác định`, tránh gán sai.
- Chi tiết là lazy-render ở ba cấp (nhân viên → bộ đếm → đơn) để không dựng toàn bộ DOM khi mở Báo cáo.
- Không đổi luồng quét, ghi nhận, chống trùng, công thức tiền công, tồn kho, cấu trúc Firestore hoặc logic nhận dạng PDF.
- Chạy test hồi quy/cú pháp và preflight trước khi build. Chưa xác nhận trên điện thoại/Firebase thật cho đến khi build và cài thử.
