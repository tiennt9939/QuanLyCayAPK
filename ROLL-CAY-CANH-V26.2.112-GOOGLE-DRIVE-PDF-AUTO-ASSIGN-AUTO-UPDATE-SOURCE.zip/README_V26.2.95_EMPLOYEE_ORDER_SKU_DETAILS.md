# V26.2.95 — Chi tiết đơn hàng / SKU theo nhân viên

- Nền source: V26.2.94, versionCode 146.
- Bản mới: V26.2.95, versionCode 147.

## Thay đổi

1. Trong **Báo cáo → Đơn phân công đã hoàn tất theo nhân viên**, bấm vào dòng/tên nhân viên để mở danh sách từng đơn trong khoảng ngày đang chọn.
2. Mỗi đơn hiển thị mã vận đơn, Order ID, ngày ghi nhận, tiền công, tên sản phẩm trên nhãn, SKU, Seller SKU và cây/kích thước/số lượng thực tế đã ghi nhận.
3. Tại thời điểm quét PDF, báo cáo chụp lại thông tin sản phẩm gốc và dòng cây đã ánh xạ vào trường tùy chọn `sourceProducts`. Đây là bằng chứng hiển thị theo từng đơn, không dùng để tính lại tiền công hoặc tồn kho.
4. Đơn cũ chưa có `sourceProducts` thử đọc thông tin SKU từ nhãn PDF/queue đã lưu. Nếu không có ảnh chụp ánh xạ lịch sử, UI nói rõ và chỉ hiển thị cây đã ghi nhận từ báo cáo; không áp quy tắc nhận dạng hiện tại ngược về quá khứ.
5. Tổng hợp sản lượng theo cây/kích thước được thu gọn thành phần tham khảo; danh sách đơn/SKU theo từng nhân viên là trọng tâm.

## Không thay đổi

- Công thức tiền công và giá snapshot.
- Cơ chế chống ghi trùng, trừ tồn kho và ghi nhận hoàn tất.
- Quy tắc nhận diện PDF/SKU, danh mục cây và bảng giá.
- Không thêm collection hoặc index Firestore mới. `sourceProducts` là trường tùy chọn trong báo cáo hiện có, tương thích với các bản ghi cũ.

## Kiểm thử

- Preflight đạt.
- 87/87 bài test JavaScript hồi quy đạt.
- Cú pháp JavaScript: 6/6 khối inline + bộ đọc PDF đạt.
- ZIP source kiểm tra hợp lệ.
- Chưa build APK Gradle/GitHub Actions và chưa xác minh trực tiếp trên thiết bị/Firebase thật.
