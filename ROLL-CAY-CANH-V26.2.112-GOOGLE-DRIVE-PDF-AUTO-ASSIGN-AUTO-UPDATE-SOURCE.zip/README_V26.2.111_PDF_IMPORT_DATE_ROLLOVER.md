# V26.2.111 PDF import date rollover

The app can keep the previous selected date if it is left open across midnight. The import path now detects a stale date and rolls it to today unless the Admin deliberately selected a historical date during the current local day. The final import message displays the target date.
