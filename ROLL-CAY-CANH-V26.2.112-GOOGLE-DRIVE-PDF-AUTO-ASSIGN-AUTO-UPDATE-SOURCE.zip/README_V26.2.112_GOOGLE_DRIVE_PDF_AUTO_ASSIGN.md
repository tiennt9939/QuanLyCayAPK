# ROLL CÂY CẢNH V26.2.112 — Google Drive PDF tự đồng bộ và tự phân công

## Tính năng thêm

- Tự tạo thư mục gốc `ROLL_CAY_CANH_IMPORT` ngay trong cấp cao nhất của “Drive của tôi”.
- Khi Admin kết nối Google Drive, ứng dụng rà soát các tài khoản có vai trò `packer` đang hoạt động và tạo/kiểm tra thư mục riêng `NV_<mã nhân viên>__<tên nhân viên>`.
- Khi Admin tạo tài khoản đóng hàng mới trong lúc Drive đã kết nối, ứng dụng cố gắng tạo thư mục nhân viên ngay sau khi hồ sơ Firebase được lưu. Nếu Drive chưa kết nối hoặc tạo thư mục tạm lỗi, lần kết nối/đồng bộ tiếp theo sẽ thử lại.
- Khi ứng dụng đang mở ở màn hình Admin, app dò thư mục nhân viên khoảng mỗi 60 giây, đồng thời kiểm tra lại khi app trở về foreground hoặc có mạng.
- PDF được tải từ Drive đi qua đúng bộ đọc PDF/OCR/barcode và bộ nhận diện TikTok đang có. Nhãn có mã vận đơn hợp lệ và cây được đối chiếu đầy đủ mới tự phân công cho nhân viên theo thư mục. Nhãn chưa ghép đủ cây không tự giao mà vẫn chờ Admin đối chiếu.
- Nhận diện phiên bản file dựa trên ID, thời điểm sửa, kích thước và checksum khi Drive cung cấp. Cơ chế nhập đơn cũ và ID vận đơn xác định vẫn là hàng rào chống trùng; không thay đổi công thức tiền công, tồn kho hoặc schema Firestore.
- Nhập PDF thủ công vẫn giữ hành vi xác nhận phân công cũ; chỉ luồng tự đồng bộ Drive mới bỏ bước xác nhận cho các nhãn đã đủ điều kiện.

## Cách sử dụng

1. Cài APK của bản này rồi đăng nhập tài khoản Admin.
2. Mở mục nhập PDF nhãn đơn và bấm **KẾT NỐI GOOGLE DRIVE / KIỂM TRA ẢNH**. Chấp nhận các quyền Google yêu cầu.
3. Trong Drive, mở `ROLL_CAY_CANH_IMPORT`; bên trong có thư mục `NV_<mã>__<tên>` cho mỗi nhân viên đóng hàng đã có tài khoản.
4. Trên iPad, tại màn hình tải PDF của TikTok Shop như ảnh hướng dẫn, chọn thư mục đích `ROLL_CAY_CANH_IMPORT` → thư mục đúng nhân viên → bấm **TẢI LÊN**. Không tải vào thẳng `Drive của tôi` hay `QuanLyCayAPK_Images`, vì hai nơi đó không phải hộp thư PDF của nhân viên.
5. Giữ app ROLL CÂY CẢNH đang mở trên thiết bị Admin. Tối đa khoảng 60 giây sau, app sẽ phát hiện và xử lý PDF mới; cũng có thể bấm **ĐỒNG BỘ PDF DRIVE NGAY**.
6. Lần đầu bật theo dõi, app hỏi có nhập các PDF đã có trong thư mục không. Chọn OK chỉ khi đó là lô mới cần nhập; chọn Hủy để ghi nhận các file có sẵn là file cũ. Sau bước khởi tạo, PDF mới được đồng bộ tự động.
7. Kiểm tra danh sách nhãn chờ đối chiếu. Nhãn chưa xác định đủ loại cây/kích thước vẫn cần xử lý thủ công; app không đoán cây để tự giao.

## Điều kiện và giới hạn cần biết

- App phải chạy trên thiết bị Admin và ở foreground để polling 60 giây hoạt động; khi app đóng hẳn, bản này không chạy job nền hoặc máy chủ độc lập. Khi mở lại app, nó tiếp tục đồng bộ.
- Thiết bị Admin phải kết nối đúng tài khoản Google Drive mà iPad dùng để tải PDF lên.
- Để tự dò mọi file trong các thư mục, bản này yêu cầu scope `drive.readonly` ngoài quyền `drive.file` hiện tại. Google phân loại `drive.readonly` là restricted scope; tùy cấu hình OAuth consent screen của dự án, Google có thể yêu cầu thêm thiết lập/xác minh hoặc chỉ cho tài khoản thử nghiệm cấp quyền. Nếu màn hình kết nối báo OAuth/permission error, cần cấu hình dự án OAuth Google Cloud tương ứng; không phải lỗi nhận diện PDF.
- Thư mục tự tạo chỉ áp dụng cho tài khoản có vai trò `packer` và có liên kết đúng với nhân viên trong hồ sơ `/users` của Firebase.
- Các bài kiểm tra source không thể thay cho kiểm thử thực tế với tài khoản Google Drive/TikTok của cửa hàng. Trước khi dùng trên đơn thật, hãy thử 1 PDF mới trong thư mục test của một nhân viên và xác nhận tên cây, mã vận đơn, nhân viên được giao.

## Giữ nguyên từ bản nền

Nguồn được phát triển từ ZIP V26.2.111. Không tái tạo ứng dụng từ đầu; giữ Android WebView + Java, Firebase Authentication/Firestore, bộ nhận diện TikTok PDF, lưu ảnh Drive, nghiệp vụ phân công/scan/ảnh hoàn tất, chống trùng vận đơn, tiền công và tồn kho.
