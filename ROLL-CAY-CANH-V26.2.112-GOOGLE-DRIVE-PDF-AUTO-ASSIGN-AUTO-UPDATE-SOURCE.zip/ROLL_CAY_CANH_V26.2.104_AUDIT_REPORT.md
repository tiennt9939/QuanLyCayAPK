# ROLL CÂY CẢNH V26.2.104 — Audit sửa lỗi nhập PDF nhãn vận chuyển

## Triệu chứng đã xác nhận
Ảnh lỗi cho thấy lần nhập PDF báo `thêm 0, cập nhật 0, tổng 114 nhãn`; luồng nhập riêng cho Huy báo `đã đánh dấu 0` và `6 nhãn bỏ qua vì đã giao/ghi nhận, khác ngày hoặc đang thuộc người khác`.

PDF người dùng gửi có 7 trang. Chạy parser hiện tại trên kết quả `pdftotext -layout` nhận đủ 7/7 mã vận đơn, trạng thái `ready` và có Order ID. Vì vậy, thông báo mới không chỉ là lỗi nhận diện ký tự: luồng lưu hàng đợi theo ngày/phân công cũng cần xử lý.

## Nguyên nhân trong source
`importParsedLabelsIntoDailyShipments()` trước đây lập map theo mã vận đơn trên toàn bộ lịch sử nhưng không xét ngày ở bước kiểm tra trùng. Nếu mã đã có trong `dailyShipmentOrders` từ ngày khác, hàm `continue` mà không chuyển staging row chưa xử lý sang ngày đang chọn. Sau đó `markDailyShipmentLabelsRequestedForEmployee()` chỉ tìm nhãn trong ngày đang chọn; không tìm thấy thì tăng bộ đếm conflict và nhãn không được đánh dấu cho nhân viên. Điều này khớp với thông báo `khác ngày` và không tăng số nhãn của ngày hiện tại.

## Sửa ở V26.2.104 / versionCode 156
1. Tìm tất cả bản ghi theo mã vận đơn, ưu tiên bản ghi thuộc ngày đang chọn.
2. Nếu mã chỉ tồn tại trong ngày cũ, chỉ chuyển ngày của **staging row từ PDF chưa được giao/chưa ghi nhận** khi `source=pdf_label`, không có báo cáo quét/tiền công, không có nhân viên được giao, không có cờ yêu cầu phân công, không liên kết packing order và không có lịch sử phân công. Dữ liệu sản phẩm được cập nhật từ lần đọc PDF mới.
3. Không chuyển tự động bản ghi đã ghi nhận, đã quét, đã giao, đã liên kết đơn, có lịch sử phân công hoặc đang được yêu cầu cho nhân viên khác. Giữ cơ chế chống tính công/trừ kho lặp.
4. Thông báo kết quả chi tiết hơn: số nhãn được chuyển từ ngày cũ và số xung đột do khác ngày, đã ghi nhận, đã giao/đang giao, thuộc người khác hoặc không tìm thấy.
5. Kế thừa sửa nhận diện khoảng trắng bất thường trong mã vận đơn từ V26.2.103.

## Giữ nguyên
- Schema Firestore và cơ chế đồng bộ.
- Danh mục cây, giá, công thức tiền công, tồn kho, quy tắc nhận diện cây/size/combo.
- Quy trình quét, ảnh, Drive và chống ghi công/trừ kho trùng.
- Các nhãn đã giao hoặc đã ghi nhận không bị tự động chuyển ngày hay phân công lại.

## Kiểm thử
- `python3 tools/preflight.py`: PASS.
- 94/94 bài kiểm thử JavaScript trong `tools/*_test.js`: PASS.
- Cú pháp JavaScript: 6 khối script trong `index.html` và `tiktok-label-import.js`: PASS.
- `tools/daily_shipment_cross_date_import_fix_test.js`: PASS cho ba trường hợp (staging cũ chưa giao được chuyển ngày; nhãn đã giao được giữ nguyên; mã mới được thêm).
- PDF người dùng: 7 trang, 7 mã vận đơn và 7 Order ID được parser nhận diện.

## Giới hạn xác minh
Không có Gradle executable hoặc Gradle Wrapper trong môi trường này, nên chưa build APK tại đây; cũng chưa chạy GitHub Actions hoặc thử trên thiết bị/Firebase/Drive thật. Cần build từ source này và thử lại PDF thực tế. Nếu thông báo mới vẫn cho thấy các nhãn đều `đã giao/đã ghi nhận/thuộc người khác`, app cố ý giữ chúng nguyên trạng để bảo vệ tiền công/tồn kho; khi đó cần dùng luồng phân công lại có xác nhận, không import lặp để ép tạo đơn mới.
