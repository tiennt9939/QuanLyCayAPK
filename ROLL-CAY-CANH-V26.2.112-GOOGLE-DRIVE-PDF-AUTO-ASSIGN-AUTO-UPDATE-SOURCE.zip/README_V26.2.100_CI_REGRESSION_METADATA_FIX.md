# ROLL CÂY CẢNH V26.2.100 — CI Regression Metadata Fix

- App version: `26.2.100`
- Android `versionCode`: `152`
- Package: `com.quanlycay.apk`
- Baseline: the supplied `QuanLyCayAPK-V26.2.100-ANDROID-JSON-EXPORT-FIX-AUTO-UPDATE-SOURCE.zip`.

## Root cause
The GitHub Actions run stopped in the test step before Gradle build. Multiple existing regression tests still asserted that the current Android app must be `26.2.99` / code `151`; the supplied source had correctly moved to `26.2.100` / code `152`. The first surfaced failure was `tools/admin_outside_order_photo_completion_test.js`, but fixing only that test would have exposed many more stale version pins.

## Changes
- Updated version-pinned regression assertions in the test suite to expect the current `26.2.100` / `152` metadata. Assertions about behavior were kept intact.
- Updated the preflight failure text to name `V26.2.100` correctly.
- Updated the shared Cloud `appVersion` label to `V26.2.100-ANDROID-JSON-EXPORT-FIX` so new writes are not mislabeled as V26.2.99.
- No scanner Java code, PDF recognition rules, payroll formulas, inventory logic, Firestore schema, or security rules were changed.

## Validation
- Preflight: PASS.
- JavaScript regression tests: 92 passed, 0 failed.
- JavaScript syntax: 6 inline script blocks + `tiktok-label-import.js` parser PASS.
- `AndroidManifest.xml` and `styles.xml` parse: PASS.
- ZIP integrity: PASS after repackaging.

## Not verified
- A local Android APK build was not run because this environment has no Gradle executable or Android SDK configured.
- GitHub Actions build and real-phone JSON export have not yet been rerun/verified.
