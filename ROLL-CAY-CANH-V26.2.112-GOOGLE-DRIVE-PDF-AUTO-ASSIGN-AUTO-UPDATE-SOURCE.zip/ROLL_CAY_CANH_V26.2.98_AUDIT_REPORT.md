# ROLL CÂY CẢNH V26.2.98 — Báo cáo audit đồng bộ PDF liên thiết bị

## Tóm tắt

Đã nâng từ source V26.2.97 lên V26.2.98 / versionCode 150 để khắc phục tình huống hai điện thoại dùng cùng tài khoản Admin nhưng một máy có hàng chờ nhãn PDF còn máy kia vẫn hiển thị số lượng 0.

## Nguyên nhân gốc được tìm thấy trong source

- Hàng chờ PDF được lưu trong `D.dailyShipmentOrders`, là một phần của dữ liệu `data` trong document Firestore `apps/roll-cay-canh`.
- `reconcile()` thực hiện đọc document tại thời điểm reconcile nhưng không có listener `onSnapshot` để cập nhật hàng chờ trên một màn hình đang mở khi điện thoại khác import PDF.
- `pushNow()` ghi snapshot toàn ứng dụng. Nếu thiết bị thứ hai giữ snapshot lỗi thời, chỉ đọc/ghi toàn bộ mà không hợp nhất hàng chờ mới nhất có thể làm mất dữ liệu hàng chờ đã import trên thiết bị chính.

Đây là kết luận từ code. Không thể chỉ từ hai ảnh xác nhận được dữ liệu Firestore thật đã/ chưa có 23 nhãn; bản vá xử lý cả việc phân phối realtime lẫn guard khi ghi.

## Sửa đổi

1. Thêm Admin-only Firestore document listener cho `apps/roll-cay-canh`; listener merge dữ liệu vào hàng chờ local và render lại tab Theo ngày khi đang mở.
2. Thêm hàm hợp nhất hàng chờ theo tracking number đã chuẩn hóa, dùng row ID dự phòng, không nhân đôi nhãn trùng.
3. Bảo toàn trạng thái `recorded`, bằng chứng quét/tiền công/ảnh và thông tin phân công có revision mới hơn; không cho snapshot cũ làm đơn đã ghi quay về trạng thái nhập.
4. Trước khi `pushNow()` ghi snapshot toàn ứng dụng, đọc Cloud snapshot mới nhất và merge queue/tombstones.
5. Hợp nhất marker reset/xóa theo timestamp lớn nhất; áp dụng reset/tombstone hiện hành sau khi hợp nhất.
6. Thêm test hồi quy `tools/shared_daily_shipment_cloud_sync_test.js`, bổ sung kiểm tra cho giữ hàng chờ local khi Cloud đọc cũ/rỗng và giữ marker reset mới hơn.
7. Tăng `versionName` lên 26.2.98, `versionCode` lên 150; cập nhật workflow title và các assertion version liên quan.

## Ranh giới thay đổi

- Logic ứng dụng cốt lõi: `app/src/main/assets/index.html`.
- Phiên bản Android: `app/build.gradle.kts`.
- Tên workflow build: `.github/workflows/build-apk.yml` (trigger và bước build được giữ nguyên).
- `MainActivity.java` và `ShippingBarcodeScannerActivity.java` không bị sửa.
- Không thêm Firestore collection/schema mới.
- Các tệp trong `tools/` sửa assertion version/kiểm thử và thêm test riêng.

## Kiểm thử thực hiện

- `python3 tools/preflight.py`: PASS.
- Tất cả `tools/*_test.js`: 90/90 PASS.
- `node --check` cho 6 inline JavaScript blocks trong `index.html`: PASS.
- `node --check app/src/main/assets/tiktok-label-import.js`: PASS.
- Kiểm tra APK/build, Firebase production, và đồng bộ trực tiếp giữa hai điện thoại: chưa thực hiện.

## Cảnh báo vận hành trước khi cập nhật

Không nhập lại PDF đang còn đơn trên điện thoại chính. Cập nhật và sync điện thoại chính trước, rồi cập nhật điện thoại phụ. Nếu Cloud trước đó chưa nhận 23 nhãn, chính thao tác sync trên máy còn đủ 23 nhãn mới sẽ đẩy chúng lên; sau đó máy phụ lấy về qua listener. Đợi bộ đếm ở hai máy bằng nhau trước khi quét/ghi nhận tiếp.
