# ROLL CÂY CẢNH V26.2.107 — PDF tracking whitespace root fix

## Root cause
The native Java detector and JavaScript parser did not use the same whitespace rule. MainActivity's detector accepted newline-separated tracking characters (`\s`), so it could conclude a page already contained a supported code and skip image OCR. The JavaScript extractor only accepted spaces/tabs/hyphens, so a PDFBox representation with line breaks between glyphs still produced zero tracking codes.

## Fix
- Use `\s` plus hyphens between characters in the JavaScript tracking patterns, matching the native detector and tolerating CR/LF/non-breaking whitespace.
- Preserve strict supported carrier prefixes and exact code lengths; `normalize()` removes layout characters after matching.
- If a PDF still yields no tracking code, show sanitized diagnostic counts for native text, OCR text and candidate codes, without showing or logging recipient information.
- Keep the V26.2.106 OCR fallback, storage recovery, daily import safeguards, assignment, report, payroll and inventory behavior.

## Validation
- New regression covers GHN/J&T tracking strings split by line breaks and Unicode spaces.
- Full existing JavaScript regression suite and preflight must pass.
- Tested against the attached seven-page Seller Center PDF's extracted text: all 7 tracking identifiers are present and recognized by the current parser.

## Limits
The specific one-page PDF from the screenshot is not available as a separate file in the current local workspace; the supplied PDF is seven pages. Therefore the pattern mismatch is grounded in the source and covered by a regression, but that exact one-page case still requires confirmation in the installed APK.
