# ROLL CÂY CẢNH V26.2.99 — Audit report

- Baseline: V26.2.98, versionCode 150.
- Output: V26.2.99, versionCode 151.
- Focus: shared PDF label recognition and scan-readiness on a secondary Admin device.

## Root cause in source
`D.dailyShipmentOrders` can contain shared PDF rows from the primary device, while each device's `tiktokLabelQueue` and `tiktokProductMaps` are local storage. The earlier `tiktokUniqueProducts()` path relied on the local staging queue, so a secondary device without that local queue could not rebuild a product mapping from a row it had already received from Firestore. In addition, the Admin assignment-board readiness path did not refresh `loadTikTokRecognitionRulesFromCloud(true)` and rebuild mappings before computing the `CẦN KIỂM TRA CÂY`/scan guard. Therefore, a row could appear as shared and assigned but remain `0 cây` on the secondary device.

## Changes
1. `app/src/main/assets/index.html`: include selected-date shared Firestore rows in the unique-product mapping source; preserve local parser detail when available; normalize missing/legacy stable map keys; conditionally refresh shared Admin recognition rules and invoke existing auto-mapping before readiness is calculated. Repair is gated to Admin sessions with unresolved rows and is throttled by queue fingerprint to avoid repeated reads.
2. `app/build.gradle.kts`: bump versionName/versionCode to 26.2.99/151.
3. `.github/workflows/build-apk.yml`: update workflow title, keep existing auto-update source ZIP selection/build flow.
4. `tools/preflight.py` and regression test version assertions: keep build checks aligned with version 26.2.99 and include the new targeted test.
5. `tools/shared_pdf_product_mapping_cloud_repair_test.js`: focused regression coverage for a shared queue with an empty local staging queue and for avoiding repeated Cloud rule reads on an unchanged queue.

## Safety scope
- No edits to `MainActivity.java`, native barcode scanner, scan completion writes, payroll formula, inventory logic, Firestore rules, or collection/schema.
- Does not bypass mapping/readiness checks. If no applicable saved recognition rule or deterministic match exists, the order should remain blocked for manual review.
- No order records were changed by preparing this source package.

## Test results
See `ROLL_CAY_CANH_V26.2.99_VALIDATION_SUMMARY.txt`. Tests are code-level tests; they do not replace a GitHub Actions Gradle build or two-device live Firestore verification.
