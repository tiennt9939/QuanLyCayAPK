# ROLL CÂY CẢNH V26.2.91 — Admin outside-order photo completion speed

## Scope
- Base: V26.2.90 source.
- Keep the shared PDF import and employee-specific PDF import paths unchanged.
- Optimize only the post-photo completion path and its Admin UI feedback.

## Findings
The Admin completion method uploaded the proof image to Google Drive, then fetched the completed Firestore document and passed it to `DriveStorage.fromCloudValue(...)`. That helper immediately downloaded historical photo references, including the same image just uploaded. This caused an avoidable upload-then-download round trip before completion returned. The UI also awaited a full assignment-board refresh before showing completion feedback.

## Changes
- Admin completion returns the completed row using `fromCloudValueSkippingHistoryImages`, leaving the Drive reference in the local row. The photo is downloaded only when a photo viewer explicitly needs it.
- After Firestore confirms completion, the UI closes the modal, renders the local confirmed state, and shows the success toast immediately. The assignment board refresh runs in the background and logs errors without blocking the completed-order feedback.
- Existing Drive upload confirmation, Firestore completion write, assigned employee wage recipient, and duplicate-safe completion logic remain in place.
- No change to PDF import routing/parser, Firestore schema/rules, wage formulas, inventory logic, or native Drive upload contract.

## Validation
- `python3 tools/preflight.py`: PASS.
- `tools/*_test.js`: 83 tests, 0 failures.
- Embedded inline JavaScript: 4/4 syntax PASS; external TikTok PDF parser syntax PASS.
- AndroidManifest.xml and styles.xml parse: PASS.
- ZIP integrity: checked after packaging.

## Limitations
- Source-level verification only. APK build, on-device timing, and live Google Drive/Firebase timing were not executed here.
- Upload time still depends on phone camera output, network speed, and Google Drive response. This fix removes the avoidable immediate image download and blocking board refresh; it cannot guarantee a specific completion time without a device/network test.
