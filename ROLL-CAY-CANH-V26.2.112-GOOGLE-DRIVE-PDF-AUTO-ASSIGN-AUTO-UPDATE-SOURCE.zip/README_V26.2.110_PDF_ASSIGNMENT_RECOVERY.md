# V26.2.110 PDF Assignment Recovery

- Fixes cross-date imported-label rebasing when `assignmentRequired=true` is the only apparent assignment flag.
- Corrects employee-import conflict classification so recorded/assigned state is not hidden in the generic other-date count.
- Preserves actual reports, wages, photos, assignment history and inventory idempotency.
- Adds regression test for recoverable staging row, recorded row, assigned-to-other row, and new tracking.
