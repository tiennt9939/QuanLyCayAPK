# V26.2.108 Audit — PDF import still returns no tracking codes

## User-observed symptom
The phone reports “Đã mở PDF (1 trang) nhưng không nhận diện được mã vận đơn nào” and does not import or assign anything. Previous source versions had text-extraction paths and an OCR fallback, but the current report does not distinguish OCR failure from barcode decoding failure.

## Source-level change
Keep native text extraction first. If it yields no supported code, use a higher-resolution page render; attempt on-device ML Kit Text Recognition and, when OCR has no supported tracking pattern, ML Kit linear-barcode detection on the same page image. Pass barcode candidates into the same parser independently from the OCR text. Only recognized carrier patterns are eligible; unrelated QR/product codes are ignored.

The error screen now reports counters (native/OCR/barcode characters, supported-code candidate count, OCR error pages and barcode error pages) without exposing recipient names, phone numbers, or raw extracted page text.

## Data safety
No code path marks a packing order complete, records wages, changes stock, or assigns an employee as a result of detection alone. Existing duplicate checks and manual catalog mapping/assignment flow remain in place. No Firestore schema/rules or business calculations were changed.

## Verification to run
- `python3 tools/preflight.py`
- Every `tools/*_test.js` regression
- Node syntax check for inline JS and `tiktok-label-import.js`
- Source ZIP integrity check
- GitHub Actions Android compile/signature verification, followed by on-device testing with the same failing PDF

## Limits
The attached screenshot itself is not the failing PDF document. The accessible accompanying PDF (`TikTokSeller_1792928941021(1).pdf`) has 7 pages, a text layer, and parses as 7/7 known tracking IDs in the local JS parser. Therefore the exact one-page failure cannot be reproduced from that 7-page document alone. This source adds a second native recognition channel and better diagnostics, but real-device verification of the exact one-page file is still necessary before claiming the issue is definitively resolved.
