'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const preflight = fs.readFileSync(path.join(root, 'tools/preflight.py'), 'utf8');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/build-apk.yml'), 'utf8');

assert(gradle.includes('versionName = "26.2.107"') && gradle.includes('versionCode = 159'), 'V26.2.107 / code 159 metadata missing');
assert(preflight.includes('versionName = "26.2.107"') && preflight.includes('versionCode = 159'), 'preflight must enforce V26.2.107');
assert(workflow.includes('V26.2.107') && workflow.includes('*AUTO-UPDATE-SOURCE.zip'), 'build workflow must retain automatic source zip trigger');
assert(html.includes('Bộ đếm đơn hàng theo cây/kích thước'), 'plant-and-size order counter section missing');
assert(html.includes('ontoggle="renderReportPlantGroup(this)"'), 'plant counters must expand the associated order list on demand');
assert(html.includes('ontoggle="renderReportPlantOrderDetail(this)"'), 'individual order details must also be lazy-loaded');
assert(html.includes('renderManualPlantReportSummary(from,to)'), 'manual daily quantity summary must be kept separate from order counters');
assert(!html.includes('const plantTotals={};D.daily.filter'), 'old mixed tree-only counter must not be mistaken for order-specific counts');

const start = html.indexOf('function reportPlantGroupIdentity(name,size){');
const end = html.indexOf('\nfunction renderReport(){', start);
assert(start >= 0 && end > start, 'report plant grouping helper block missing');
const context = {
  Array, Map, String, Number, Math,
  D: { catalog: [{ name: 'Cẩm tú mai', size: 'C7' }, { name: 'Cẩm tú mai', size: 'C9' }] },
  orderItems: row => (row.items || []).map(item => ({ ...item, qty: Number(item.qty) || 0 })),
  orderItemRate: item => Number(item.assignedRate) || (item.size === 'C7' ? 1600 : 2000),
  packerPay: row => Number(row.payAmount) || (row.items || []).reduce((sum, item) => sum + (Number(item.qty)||0) * (Number(item.assignedRate)|| (item.size === 'C7' ? 1600 : 2000)), 0),
  reportProductSourceRows: row => Array.isArray(row.sourceProducts) ? row.sourceProducts : [],
  reportOrderTrackingNo: row => String(row.trackingNo || row.id || ''),
  completedOrderDate: row => String(row.date || ''),
  fmtDMY: date => date,
  money: value => `${Math.round(Number(value)||0)} đ`,
  esc: value => String(value ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'),
  reportCompletedOrderDetailHtml: row => `<article>FULL-ORDER-DETAIL:${row.id}</article>`,
};
vm.runInNewContext(html.slice(start, end), context, { filename: 'report-plant-group.js' });
const rows = [];
for (let i=0;i<5;i++) rows.push({ id:`C7-${i+1}`, trackingNo:`C7000000000${i+1}`, date:`2026-10-${String(22-i).padStart(2,'0')}`, payAmount:1600, items:[{ plantName:'Cẩm tú mai', size:'C7', plantIndex:0, qty:1, assignedRate:1600 }], sourceProducts:[{productName:'Cẩm tú mai C7',sku:'CAM-C7',sellerSku:'SELLER-C7',mappedPlants:[{plantName:'Cẩm tú mai',size:'C7',qty:1}]}] });
for (let i=0;i<4;i++) rows.push({ id:`C9-${i+1}`, trackingNo:`C9000000000${i+1}`, date:`2026-10-${String(22-i).padStart(2,'0')}`, payAmount:2000, items:[{ plantName:'Cẩm tú mai', size:'C9', plantIndex:1, qty:1, assignedRate:2000 }] });
const groups = context.buildReportPlantOrderGroups(rows);
assert.strictEqual(groups.length, 2, 'C7 and C9 must remain separate groups');
const c7 = groups.find(group => group.size === 'C7');
const c9 = groups.find(group => group.size === 'C9');
assert(c7 && c9, 'both plant sizes must exist');
assert.strictEqual(c7.orderCount, 5, 'C7 count must count five distinct orders');
assert.strictEqual(c7.qty, 5, 'C7 count must sum five trees');
assert.strictEqual(Math.round(c7.pay), 8000, 'C7 labor subtotal should match item wage values');
assert.strictEqual(c9.orderCount, 4, 'C9 count must count four distinct orders');
assert.strictEqual(c9.qty, 4, 'C9 count must sum four trees');
assert.strictEqual(Math.round(c9.pay), 8000, 'C9 labor subtotal should match item wage values');

const duplicateLines = [{ id:'DUP', trackingNo:'DUP0001', payAmount:3200, items:[
  {plantName:'Cẩm tú mai',size:'C7',plantIndex:0,qty:1,assignedRate:1600},
  {plantName:'Cẩm tú mai',size:'C7',plantIndex:0,qty:1,assignedRate:1600},
]}];
const duplicateGroup = context.buildReportPlantOrderGroups(duplicateLines)[0];
assert.strictEqual(duplicateGroup.orderCount, 1, 'two plant lines in the same order must count as one order');
assert.strictEqual(duplicateGroup.qty, 2, 'quantities of duplicate plant lines must be combined within that order');

const displayRows = rows.slice().reverse();
const panel = context.renderReportPlantGroupSection(displayRows);
assert(panel.includes('5 đơn · 5 cây') && panel.includes('4 đơn · 4 cây'), 'counter UI must present order count and tree count');
assert(panel.includes('renderReportPlantGroup(this)') && !panel.includes('FULL-ORDER-DETAIL:'), 'full details must not be rendered before a counter or order is opened');
const groupBody = { innerHTML: '' };
const groupDetails = { open:true, dataset:{reportPlantGroupIndex:String(groups.indexOf(c7))}, querySelector:selector=>selector==='.report-plant-group-orders'?groupBody:null };
context.reportPlantGroupRowsCache = groups;
context.renderReportPlantGroup(groupDetails);
assert.strictEqual((groupBody.innerHTML.match(/report-plant-order-accordion/g)||[]).length, 5, 'opening the C7 counter must reveal its five orders only');
assert(!groupBody.innerHTML.includes('FULL-ORDER-DETAIL:'), 'order detail body must remain lazy until an individual order is expanded');
const orderBody = { innerHTML:'' };
const orderDetails = { open:true, dataset:{reportPlantGroupIndex:String(groups.indexOf(c7)),reportPlantOrderIndex:'0'}, querySelector:selector=>selector==='.report-plant-order-detail'?orderBody:null };
context.renderReportPlantOrderDetail(orderDetails);
assert(orderBody.innerHTML.includes('FULL-ORDER-DETAIL:C7-1'), 'opening an order must load the same order shown at that sorted list position');
assert(groupBody.innerHTML.includes('SKU CAM-C7') && groupBody.innerHTML.includes('Seller SKU SELLER-C7'), 'counter order row must keep SKU evidence visible with the plant group');
assert(groupBody.innerHTML.includes('chưa xác định riêng với cây này')===false, 'known SKU-to-plant mapping should not be shown as unlinked');
console.log('V26.2.107 REPORT PLANT GROUP COUNTER TEST PASS');
