package com.quanlycay.apk;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PageRange;
import android.print.PrintDocumentInfo;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.auth.UserRecoverableAuthException;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;
import org.json.JSONObject;
import org.json.JSONArray;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONTokener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.regex.Pattern;

import android.util.Base64;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQ = 4101;
    private static final int DRIVE_SIGN_IN_REQ = 4102;
    private static final String DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.file";
    private static final String DRIVE_FOLDER_NAME = "QuanLyCayAPK_Images";
    private static final ExecutorService DRIVE_EXECUTOR = Executors.newFixedThreadPool(3);
    private String pendingDriveCallbackId = "";
    private static final long PRINT_CAPTURE_TIMEOUT_MS = 12000L;

    private WebView webView;
    private FrameLayout root;
    private WebView activePrintWebView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraOutputUri;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        root = new FrameLayout(this);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new AppChromeClient());
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AppChromeClient extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                         FileChooserParams params) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = callback;
            boolean imageOnly = false;
            String[] accepts = params.getAcceptTypes();
            if (accepts != null) {
                for (String a : accepts) {
                    if (a != null && a.toLowerCase().startsWith("image/")) imageOnly = true;
                }
            }

            if (params.isCaptureEnabled() && imageOnly) {
                launchCamera();
            } else {
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType(imageOnly ? "image/*" : "*/*");
                startActivityForResult(pick, FILE_CHOOSER_REQ);
            }
            return true;
        }
    }

    private void launchCamera() {
        try {
            Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME,
                        "ROLL_CAY_CANH_" + System.currentTimeMillis() + ".jpg");
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                values.put(MediaStore.Images.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES + "/ROLL CAY CANH");
                cameraOutputUri = getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
                camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
            startActivityForResult(camera, FILE_CHOOSER_REQ);
        } catch (Exception e) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = null;
            cameraOutputUri = null;
            Toast.makeText(this, "Không thể mở camera", Toast.LENGTH_SHORT).show();
        }
    }

    private String driveErrorJsonOuter(Exception e) {
        try { return new JSONObject().put("ok", false).put("error", e == null ? "Lỗi Google Drive" : String.valueOf(e.getMessage())).toString(); }
        catch (Exception ignored) { return "{\"ok\":false,\"error\":\"Lỗi Google Drive\"}"; }
    }
    private void deliverDriveResultOuter(String callbackId, String resultJson) {
        final String cb = callbackId != null && callbackId.matches("[A-Za-z0-9_]{1,80}") ? callbackId : "__driveBridgeInvalidCallback";
        final String payload = resultJson == null ? "{}" : resultJson;
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("if(window.__driveBridgeResponse)window.__driveBridgeResponse(" + JSONObject.quote(cb) + "," + JSONObject.quote(payload) + ");", null); });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == DRIVE_SIGN_IN_REQ) {
            String callback = pendingDriveCallbackId;
            pendingDriveCallbackId = "";
            try {
                GoogleSignInAccount account = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class);
                if (account == null) throw new Exception("Không nhận được tài khoản Google");
                DRIVE_EXECUTOR.execute(() -> {
                    try {
                        AndroidBridge driveBridge = new AndroidBridge();
                        String token = driveBridge.getDriveAccessToken(account);
                        String folderId = driveBridge.ensureDriveFolder(token, account.getEmail());
                        getSharedPreferences("drive_store", MODE_PRIVATE).edit()
                            .putString("account_email", account.getEmail() == null ? "" : account.getEmail())
                            .putString("folder_id_" + (account.getEmail() == null ? "default" : account.getEmail().toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9_-]", "_")), folderId)
                            .apply();
                        deliverDriveResultOuter(callback, new JSONObject().put("ok", true)
                            .put("email", account.getEmail() == null ? "" : account.getEmail())
                            .put("folderId", folderId).toString());
                    } catch (Exception e) {
                        deliverDriveResultOuter(callback, driveErrorJsonOuter(e));
                    }
                });
            } catch (Exception e) {
                deliverDriveResultOuter(callback, driveErrorJsonOuter(e));
            }
            return;
        }
        if (requestCode != FILE_CHOOSER_REQ || filePathCallback == null) return;

        Uri result = null;
        if (resultCode == RESULT_OK) {
            if (cameraOutputUri != null) {
                result = cameraOutputUri;
            } else if (data != null) {
                if (data.getData() != null) {
                    result = data.getData();
                } else if (data.getExtras() != null && data.getExtras().get("data") instanceof Bitmap) {
                    result = saveLegacyCameraBitmap((Bitmap) data.getExtras().get("data"));
                }
            }
        }

        filePathCallback.onReceiveValue(result == null ? null : new Uri[]{result});
        filePathCallback = null;
        if (result == null && cameraOutputUri != null) {
            try { getContentResolver().delete(cameraOutputUri, null, null); } catch (Exception ignored) {}
        }
        cameraOutputUri = null;
    }

    private Uri saveLegacyCameraBitmap(Bitmap bitmap) {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME,
                    "ROLL_CAY_CANH_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return null;
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null || !bitmap.compress(Bitmap.CompressFormat.JPEG, 88, out)) return null;
            }
            return uri;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Capture only the prepared print area + the page <head>. This avoids sending the
     * entire live WebView DOM into Android's print engine and avoids re-running the app
     * scripts in the print WebView.
     */
    private static final String CAPTURE_PRINT_HTML_JS =
            "(function(){" +
            "var ids=['orderPrintArea','quotePdfPrint'];" +
            "var el=null;" +
            "for(var i=0;i<ids.length;i++){var x=document.getElementById(ids[i]);" +
            "if(x&&x.innerHTML&&((x.getAttribute('aria-hidden')==='false')||x.classList.contains('show'))){el=x;break;}}" +
            "if(!el)return '';" +
            "function attrs(node){var s='';for(var i=0;i<node.attributes.length;i++){var a=node.attributes[i];" +
            "s+=' '+a.name+'=\\\"'+String(a.value).replace(/&/g,'&amp;').replace(/\\\"/g,'&quot;')+'\\\"';}return s;}" +
            "return '<!doctype html><html'+attrs(document.documentElement)+'><head>'+document.head.innerHTML+'</head><body'+attrs(document.body)+'>'+el.outerHTML+'</body></html>';" +
            "})()";

    private String decodeJavascriptString(String raw) throws Exception {
        Object value = new JSONTokener(raw == null ? "null" : raw).nextValue();
        if (!(value instanceof String)) return "";
        return (String) value;
    }

    private String sanitizePrintHtml(String html) {
        if (html == null) return "";
        return Pattern.compile("<script\\b[^>]*>.*?</script>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL)
                .matcher(html).replaceAll("");
    }

    private PrintAttributes buildPrintAttributes(boolean orderLabel) {
        if (orderLabel) {
            return new PrintAttributes.Builder()
                    .setMediaSize(new PrintAttributes.MediaSize(
                            "ROLL_GARDEN_65X100", "65 x 100 mm", 2559, 3937))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();
        }
        return new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build();
    }

    private void cleanupPrintWebView(WebView printView) {
        if (printView == null) return;
        try { printView.stopLoading(); } catch (Exception ignored) {}
        try { printView.setWebViewClient(null); } catch (Exception ignored) {}
        try { printView.destroy(); } catch (Exception ignored) {}
        if (root != null) {
            try { root.removeView(printView); } catch (Exception ignored) {}
        }
        if (activePrintWebView == printView) activePrintWebView = null;
    }

    private void startIsolatedPrint(String jobName, String html, PrintAttributes attributes) {
        if (html == null || html.trim().length() < 50) {
            Toast.makeText(this, "Không lấy được nội dung để in", Toast.LENGTH_SHORT).show();
            return;
        }
        if (activePrintWebView != null) {
            cleanupPrintWebView(activePrintWebView);
        }

        final WebView printView = new WebView(this);
        activePrintWebView = printView;
        printView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        WebSettings ps = printView.getSettings();
        ps.setJavaScriptEnabled(false);
        ps.setDomStorageEnabled(false);
        ps.setAllowFileAccess(true);
        ps.setAllowContentAccess(true);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(2, 2);
        lp.leftMargin = 1;
        lp.topMargin = 1;
        root.addView(printView, lp);

        final boolean[] started = {false};
        final Runnable start = () -> {
            if (started[0] || activePrintWebView != printView) return;
            started[0] = true;
            try {
                PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (printManager == null) {
                    cleanupPrintWebView(printView);
                    Toast.makeText(this, "Thiết bị không hỗ trợ in", Toast.LENGTH_SHORT).show();
                    return;
                }
                PrintDocumentAdapter delegate = printView.createPrintDocumentAdapter(jobName);
                if (delegate == null) {
                    cleanupPrintWebView(printView);
                    Toast.makeText(this, "Không thể tạo tài liệu in", Toast.LENGTH_SHORT).show();
                    return;
                }
                printManager.print(jobName, new ReleaseAfterPrintAdapter(delegate, printView), attributes);
            } catch (Throwable e) {
                cleanupPrintWebView(printView);
                Toast.makeText(this, "Không thể mở chức năng in: " + safeError(e), Toast.LENGTH_LONG).show();
            }
        };

        printView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                mainHandler.postDelayed(start, 250);
            }
        });

        printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        mainHandler.postDelayed(() -> {
            if (!started[0]) start.run();
        }, 3500);
        mainHandler.postDelayed(() -> {
            if (activePrintWebView == printView && !started[0]) {
                cleanupPrintWebView(printView);
                Toast.makeText(this, "Không thể chuẩn bị nội dung in. Vui lòng thử lại.", Toast.LENGTH_LONG).show();
            }
        }, PRINT_CAPTURE_TIMEOUT_MS);
    }

    private String safeError(Throwable e) {
        String m = e == null ? "" : e.getMessage();
        if (m == null || m.trim().isEmpty()) return e == null ? "Lỗi không xác định" : e.getClass().getSimpleName();
        return m;
    }

    private class ReleaseAfterPrintAdapter extends PrintDocumentAdapter {
        private final PrintDocumentAdapter delegate;
        private final WebView printView;
        ReleaseAfterPrintAdapter(PrintDocumentAdapter delegate, WebView printView) {
            this.delegate = delegate;
            this.printView = printView;
        }
        @Override public void onStart() { delegate.onStart(); }
        @Override public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                                       android.os.CancellationSignal cancellationSignal,
                                       LayoutResultCallback callback, Bundle extras) {
            delegate.onLayout(oldAttributes, newAttributes, cancellationSignal, callback, extras);
        }
        @Override public void onWrite(android.print.PageRange[] pages, android.os.ParcelFileDescriptor destination,
                                      android.os.CancellationSignal cancellationSignal, WriteResultCallback callback) {
            delegate.onWrite(pages, destination, cancellationSignal, callback);
        }
        @Override public void onFinish() {
            try { delegate.onFinish(); } finally { cleanupPrintWebView(printView); }
        }
    }

    private void startPdfExport(String jobName, String html) {
        if (html == null || html.trim().length() < 50) {
            Toast.makeText(this, "Không lấy được nội dung báo giá", Toast.LENGTH_SHORT).show();
            return;
        }

        // Android PrintDocumentAdapter.LayoutResultCallback and WriteResultCallback
        // constructors are package-private. We must NOT instantiate them directly.
        // Use Android's public PrintManager pipeline instead; the system print UI
        // can then save the prepared A4 document as PDF.
        startIsolatedPrint(jobName, html, buildPrintAttributes(false));
    }

    private void savePdfToDownloads(String jobName, File tmp) throws Exception {
        String name=(jobName==null||jobName.trim().isEmpty()?"Bao-gia-ROLL-GARDEN":jobName).replaceAll("[^a-zA-Z0-9._-]","_");
        if(!name.toLowerCase().endsWith(".pdf"))name+=".pdf";
        if(Build.VERSION.SDK_INT>=29){
            ContentValues values=new ContentValues(); values.put(MediaStore.Downloads.DISPLAY_NAME,name); values.put(MediaStore.Downloads.MIME_TYPE,"application/pdf"); values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/ROLL CAY CANH"); values.put(MediaStore.Downloads.IS_PENDING,1);
            Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values); if(uri==null)throw new Exception("Không tạo được file trong Tải xuống");
            try(InputStream in=new FileInputStream(tmp); OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception("Không mở được file đích"); byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)out.write(buf,0,n);}
            ContentValues done=new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING,0); getContentResolver().update(uri,done,null,null);
        } else {File dir=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);if(!dir.exists()&&!dir.mkdirs())throw new Exception("Không tạo được thư mục Tải xuống");try(FileInputStream in=new FileInputStream(tmp);FileOutputStream out=new FileOutputStream(new File(dir,name))){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}}
        Toast.makeText(this,"✅ Đã xuất PDF: Tải xuống / ROLL CAY CANH / "+name,Toast.LENGTH_LONG).show();
        if(webView!=null)webView.evaluateJavascript("window.finishQuotePdfExport&&window.finishQuotePdfExport(true)",null);
    }
    public class AndroidBridge {
        @JavascriptInterface
        public boolean isDriveConnected() {
            GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(MainActivity.this);
            if (account == null || account.getEmail() == null) return false;
            return GoogleSignIn.hasPermissions(account, new Scope(DRIVE_SCOPE));
        }

        @JavascriptInterface
        public void connectGoogleDrive(String callbackId) {
            final String cb = safeCallbackId(callbackId);
            runOnUiThread(() -> {
                try {
                    pendingDriveCallbackId = cb;
                    GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestEmail().requestScopes(new Scope(DRIVE_SCOPE)).build();
                    GoogleSignInClient client = GoogleSignIn.getClient(MainActivity.this, options);
                    startActivityForResult(client.getSignInIntent(), DRIVE_SIGN_IN_REQ);
                } catch (Exception e) {
                    deliverDriveResult(cb, driveErrorJson(e));
                }
            });
        }

        @JavascriptInterface
        public void uploadDriveImage(String dataUrl, String fileName, String callbackId) {
            final String cb = safeCallbackId(callbackId);
            DRIVE_EXECUTOR.execute(() -> {
                try {
                    GoogleSignInAccount account = requireDriveAccount();
                    String token = getDriveAccessToken(account);
                    String folder = ensureDriveFolder(token, account.getEmail());
                    String raw = dataUrl == null ? "" : dataUrl.trim();
                    int comma = raw.indexOf(',');
                    String mime = "image/jpeg";
                    if (raw.startsWith("data:")) {
                        int semi = raw.indexOf(';');
                        if (semi > 5) mime = raw.substring(5, semi);
                    }
                    if (comma >= 0) raw = raw.substring(comma + 1);
                    if (raw.isEmpty()) throw new Exception("Dữ liệu ảnh trống");
                    byte[] bytes = Base64.decode(raw, Base64.DEFAULT);
                    String name = (fileName == null || fileName.trim().isEmpty() ? "image.jpg" : fileName.trim())
                        .replaceAll("[^a-zA-Z0-9._-]", "_");
                    JSONObject meta = new JSONObject();
                    meta.put("name", name); meta.put("mimeType", mime);
                    meta.put("parents", new JSONArray().put(folder));
                    String boundary = "QuanLyCayAPK_" + System.currentTimeMillis();
                    URL url = new URL("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType");
                    HttpURLConnection c = (HttpURLConnection) url.openConnection();
                    c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(20000); c.setReadTimeout(30000);
                    c.setRequestProperty("Authorization", "Bearer " + token);
                    c.setRequestProperty("Content-Type", "multipart/related; boundary=" + boundary);
                    try (OutputStream out = c.getOutputStream()) {
                        out.write(("--" + boundary + "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" + meta.toString() + "\r\n").getBytes(StandardCharsets.UTF_8));
                        out.write(("--" + boundary + "\r\nContent-Type: " + mime + "\r\n\r\n").getBytes(StandardCharsets.UTF_8));
                        out.write(bytes);
                        out.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
                    }
                    String response = readHttpResponse(c);
                    JSONObject result = new JSONObject(response);
                    if (c.getResponseCode() < 200 || c.getResponseCode() >= 300 || !result.has("id")) throw new Exception("Drive không lưu được ảnh: " + response);
                    deliverDriveResult(cb, new JSONObject().put("ok", true).put("id", result.getString("id")).put("name", result.optString("name", name)).toString());
                } catch (Exception e) { deliverDriveResult(cb, driveErrorJson(e)); }
            });
        }

        @JavascriptInterface
        public void downloadDriveImage(String fileId, String callbackId) {
            final String cb = safeCallbackId(callbackId);
            DRIVE_EXECUTOR.execute(() -> {
                try {
                    if (fileId == null || !fileId.matches("[A-Za-z0-9_-]{10,}")) throw new Exception("Mã ảnh Drive không hợp lệ");
                    GoogleSignInAccount account = requireDriveAccount();
                    String token = getDriveAccessToken(account);
                    URL url = new URL("https://www.googleapis.com/drive/v3/files/" + URLEncoder.encode(fileId, "UTF-8") + "?alt=media");
                    HttpURLConnection c = (HttpURLConnection) url.openConnection();
                    c.setRequestMethod("GET"); c.setConnectTimeout(20000); c.setReadTimeout(30000);
                    c.setRequestProperty("Authorization", "Bearer " + token);
                    int code = c.getResponseCode();
                    if (code < 200 || code >= 300) throw new Exception("Không đọc được ảnh Drive (HTTP " + code + "): " + readHttpResponse(c));
                    String mime = c.getContentType();
                    if (mime == null || !mime.toLowerCase(java.util.Locale.ROOT).startsWith("image/")) mime = "image/jpeg";
                    int mimeSemi = mime.indexOf(';'); if (mimeSemi > 0) mime = mime.substring(0, mimeSemi).trim();
                    byte[] bytes;
                    try (InputStream in = c.getInputStream(); java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
                        byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n); bytes = out.toByteArray();
                    }
                    String dataUrl = "data:" + mime + ";base64," + Base64.encodeToString(bytes, Base64.NO_WRAP);
                    deliverDriveResult(cb, new JSONObject().put("ok", true).put("dataUrl", dataUrl).toString());
                } catch (Exception e) { deliverDriveResult(cb, driveErrorJson(e)); }
            });
        }

        private GoogleSignInAccount requireDriveAccount() throws Exception {
            GoogleSignInAccount a = GoogleSignIn.getLastSignedInAccount(MainActivity.this);
            if (a == null || !GoogleSignIn.hasPermissions(a, new Scope(DRIVE_SCOPE))) throw new Exception("Chưa kết nối Google Drive. Hãy bấm KẾT NỐI GOOGLE DRIVE trước.");
            return a;
        }

        private String getDriveAccessToken(GoogleSignInAccount account) throws Exception {
            String scopes = "oauth2:" + DRIVE_SCOPE;
            try { return GoogleAuthUtil.getToken(MainActivity.this, account.getAccount(), scopes); }
            catch (UserRecoverableAuthException e) { throw new Exception("Google cần cấp lại quyền Drive. Hãy kết nối Google Drive và chấp nhận quyền truy cập.", e); }
        }

        private String ensureDriveFolder(String token, String email) throws Exception {
            String key = "folder_id_" + safePreferenceKey(email);
            String saved = getSharedPreferences("drive_store", MODE_PRIVATE).getString(key, "");
            if (!saved.isEmpty()) return saved;
            String q = "name='" + DRIVE_FOLDER_NAME + "' and mimeType='application/vnd.google-apps.folder' and trashed=false";
            URL listUrl = new URL("https://www.googleapis.com/drive/v3/files?q=" + URLEncoder.encode(q, "UTF-8") + "&pageSize=10&fields=files(id,name,mimeType)");
            HttpURLConnection list = (HttpURLConnection) listUrl.openConnection();
            list.setRequestMethod("GET"); list.setConnectTimeout(15000); list.setReadTimeout(20000); list.setRequestProperty("Authorization", "Bearer " + token);
            int code = list.getResponseCode();
            if (code >= 200 && code < 300) {
                JSONObject json = new JSONObject(readHttpResponse(list)); JSONArray files = json.optJSONArray("files");
                if (files != null && files.length() > 0) return files.getJSONObject(0).getString("id");
            }
            JSONObject meta = new JSONObject().put("name", DRIVE_FOLDER_NAME).put("mimeType", "application/vnd.google-apps.folder");
            URL createUrl = new URL("https://www.googleapis.com/drive/v3/files?fields=id,name");
            HttpURLConnection create = (HttpURLConnection) createUrl.openConnection();
            create.setRequestMethod("POST"); create.setDoOutput(true); create.setConnectTimeout(15000); create.setReadTimeout(20000);
            create.setRequestProperty("Authorization", "Bearer " + token); create.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            try (OutputStream out = create.getOutputStream()) { out.write(meta.toString().getBytes(StandardCharsets.UTF_8)); }
            String response = readHttpResponse(create);
            JSONObject result = new JSONObject(response);
            if (create.getResponseCode() < 200 || create.getResponseCode() >= 300 || !result.has("id")) throw new Exception("Không tạo được thư mục Drive: " + response);
            String id = result.getString("id");
            getSharedPreferences("drive_store", MODE_PRIVATE).edit().putString(key, id).apply();
            return id;
        }

        private String readHttpResponse(HttpURLConnection c) throws Exception {
            InputStream in = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null) return "";
            try (InputStream stream = in; java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
                byte[] b = new byte[4096]; int n; while ((n = stream.read(b)) > 0) out.write(b, 0, n);
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            }
        }

        private String safePreferenceKey(String value) { return (value == null ? "default" : value.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9_-]", "_")); }
        private String safeCallbackId(String value) { return value != null && value.matches("[A-Za-z0-9_]{1,80}") ? value : "__driveBridgeInvalidCallback"; }
        private String driveErrorJson(Exception e) { try { return new JSONObject().put("ok", false).put("error", e == null ? "Lỗi Google Drive" : String.valueOf(e.getMessage())).toString(); } catch (Exception ignored) { return "{\"ok\":false,\"error\":\"Lỗi Google Drive\"}"; } }
        private void deliverDriveResult(String callbackId, String resultJson) {
            final String cb = safeCallbackId(callbackId); final String payload = resultJson == null ? "{}" : resultJson;
            runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("if(window.__driveBridgeResponse)window.__driveBridgeResponse(" + JSONObject.quote(cb) + "," + JSONObject.quote(payload) + ");", null); });
        }

        @JavascriptInterface
        public void ocrShippingImage(String dataUrl, String callback) {
            // Keep this signature in sync with index.html:
            // AndroidBridge.ocrShippingImage(dataUrl, "__callbackName")
            final String cb = (callback == null
                    || !callback.matches("[A-Za-z_$][A-Za-z0-9_$]*"))
                    ? "__shippingOcrResult" : callback;

            try {
                String raw = dataUrl == null ? "" : dataUrl.trim();
                int comma = raw.indexOf(',');
                if (comma >= 0) raw = raw.substring(comma + 1);
                if (raw.isEmpty()) throw new IllegalArgumentException("Ảnh OCR rỗng");

                byte[] bytes = Base64.decode(raw, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bitmap == null) throw new IllegalArgumentException("Không giải mã được ảnh");

                InputImage image = InputImage.fromBitmap(bitmap, 0);
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    .process(image)
                    .addOnSuccessListener(result -> {
                        String recognized = result == null || result.getText() == null
                                ? "" : result.getText();
                        deliverOcrResult(cb, recognized);
                        bitmap.recycle();
                    })
                    .addOnFailureListener(error -> {
                        deliverOcrResult(cb, "");
                        bitmap.recycle();
                        runOnUiThread(() -> Toast.makeText(
                                MainActivity.this,
                                "OCR không đọc được ảnh. Hãy thử chụp rõ nhãn hơn.",
                                Toast.LENGTH_LONG
                        ).show());
                    });
            } catch (Exception error) {
                deliverOcrResult(cb, "");
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "Không xử lý được ảnh OCR. Hãy chọn/chụp lại ảnh.",
                        Toast.LENGTH_LONG
                ).show());
            }
        }

        private void deliverOcrResult(String callbackName, String recognizedText) {
            String safeCallback = (callbackName != null
                    && callbackName.matches("[A-Za-z_$][A-Za-z0-9_$]*"))
                    ? callbackName : "__shippingOcrResult";
            String quotedCallback = org.json.JSONObject.quote(safeCallback);
            String js = "if(window[" + quotedCallback + "])window[" + quotedCallback + "]("
                    + org.json.JSONObject.quote(recognizedText == null ? "" : recognizedText)
                    + ");";
            runOnUiThread(() -> {
                if (webView != null) webView.evaluateJavascript(js, null);
            });
        }

        @JavascriptInterface
        public void sendToFlashLabel(String jobName) {
            final String safeName = (jobName == null || jobName.trim().isEmpty() ? "ROLL-CAY-CANH-LABEL" : jobName).replaceAll("[^a-zA-Z0-9._-]", "_");
            runOnUiThread(() -> {
                if (webView == null) return;
                webView.evaluateJavascript("(function(){var e=document.getElementById('orderPrintArea');return e?e.outerHTML:''})()", htmlRaw -> {
                    try {
                        String html = sanitizePrintHtml(decodeJavascriptString(htmlRaw));
                        if (html == null || html.trim().length() < 20) throw new Exception("Không có nội dung nhãn");
                        WebView pv = new WebView(MainActivity.this);
                        pv.setBackgroundColor(Color.WHITE);
                        pv.getSettings().setJavaScriptEnabled(false);
                        pv.setVisibility(View.INVISIBLE);
                        root.addView(pv, new FrameLayout.LayoutParams(780, 1200));
                        pv.setWebViewClient(new WebViewClient(){ @Override public void onPageFinished(WebView v,String u){
                            v.postDelayed(() -> {
                                try {
                                    Bitmap bm=Bitmap.createBitmap(780,1200,Bitmap.Config.ARGB_8888);
                                    v.draw(new android.graphics.Canvas(bm));
                                    shareBitmapToFlashLabel(bm,safeName);
                                } catch(Exception e){ Toast.makeText(MainActivity.this,"Không tạo được nhãn: "+safeError(e),Toast.LENGTH_LONG).show(); }
                                finally { root.removeView(v); v.destroy(); }
                            },350);
                        }});
                        pv.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
                    } catch(Exception e){ Toast.makeText(MainActivity.this,"FlashLabel lỗi: "+safeError(e),Toast.LENGTH_LONG).show(); }
                });
            });
        }

        private void shareBitmapToFlashLabel(Bitmap bm, String name) {
            try {
                ContentValues values=new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME,name+".png");
                values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");
                if(Build.VERSION.SDK_INT>=29) values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/ROLL CAY CANH");
                Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
                if(uri==null) throw new Exception("Không tạo được ảnh nhãn");
                try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception("Không mở được ảnh");bm.compress(Bitmap.CompressFormat.PNG,100,out);}
                Intent send=new Intent(Intent.ACTION_SEND); send.setType("image/png"); send.putExtra(Intent.EXTRA_STREAM,uri); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                String[] pkgs={"com.flashlabel.flashlabelpro","com.extralife.flashlabel"};
                for(String pkg:pkgs){try{if(getPackageManager().getLaunchIntentForPackage(pkg)!=null){send.setPackage(pkg);startActivity(send);return;}}catch(Exception ignored){}}
                startActivity(Intent.createChooser(send,"Chọn FlashLabel để in"));
            }catch(Exception e){Toast.makeText(MainActivity.this,"Không gửi được sang FlashLabel: "+safeError(e),Toast.LENGTH_LONG).show();}
        }

        @JavascriptInterface
        public void printA4Page(String jobName) {
            final String safeName = (jobName == null || jobName.trim().isEmpty())
                    ? "ROLL-CAY-CANH-BAO-GIA"
                    : jobName.replaceAll("[^a-zA-Z0-9._-]", "_");
            final boolean orderLabel = safeName.startsWith("ROLL-CAY-CANH-");
            runOnUiThread(() -> {
                try {
                    if (webView == null) {
                        Toast.makeText(MainActivity.this, "WebView chưa sẵn sàng", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    final PrintAttributes attributes = buildPrintAttributes(orderLabel);
                    webView.evaluateJavascript(CAPTURE_PRINT_HTML_JS, raw -> {
                        try {
                            final String html = sanitizePrintHtml(decodeJavascriptString(raw));
                            startIsolatedPrint(safeName, html, attributes);
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Không chuẩn bị được nội dung in: " + safeError(e), Toast.LENGTH_LONG).show();
                        }
                    });
                } catch (Throwable e) {
                    Toast.makeText(MainActivity.this, "Không thể mở chức năng in: " + safeError(e), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void printOrder65x100(String jobName) {
            final String safeName=(jobName==null||jobName.trim().isEmpty()?"ROLL-CAY-CANH-ORDER-65X100":jobName).replaceAll("[^a-zA-Z0-9._-]","_");
            runOnUiThread(()->{if(webView==null){Toast.makeText(MainActivity.this,"WebView chưa sẵn sàng",Toast.LENGTH_SHORT).show();return;} webView.evaluateJavascript(CAPTURE_PRINT_HTML_JS,raw->{try{startIsolatedPrint(safeName,sanitizePrintHtml(decodeJavascriptString(raw)),buildPrintAttributes(true));}catch(Exception e){Toast.makeText(MainActivity.this,"Không chuẩn bị được đơn in: "+safeError(e),Toast.LENGTH_LONG).show();}});});
        }

        @JavascriptInterface
        public void exportPdf(String jobName) {
            final String safeName=(jobName==null||jobName.trim().isEmpty()?"Bao-gia-ROLL-GARDEN":jobName).replaceAll("[^a-zA-Z0-9._-]","_");
            runOnUiThread(()->{if(webView==null){Toast.makeText(MainActivity.this,"WebView chưa sẵn sàng",Toast.LENGTH_SHORT).show();return;} webView.evaluateJavascript(CAPTURE_PRINT_HTML_JS,raw->{try{startPdfExport(safeName,sanitizePrintHtml(decodeJavascriptString(raw)));}catch(Exception e){Toast.makeText(MainActivity.this,"Không chuẩn bị được PDF: "+safeError(e),Toast.LENGTH_LONG).show();}});});
        }

        public void printCurrentPage(String jobName) {
            final String safeName = (jobName == null || jobName.trim().isEmpty())
                    ? "ROLL-CAY-CANH"
                    : jobName.replaceAll("[^a-zA-Z0-9._-]", "_");
            runOnUiThread(() -> {
                if (webView == null) {
                    Toast.makeText(MainActivity.this, "WebView chưa sẵn sàng", Toast.LENGTH_SHORT).show();
                    return;
                }
                final PrintAttributes attributes = buildPrintAttributes(false);
                webView.evaluateJavascript(CAPTURE_PRINT_HTML_JS, raw -> {
                    try {
                        final String html = sanitizePrintHtml(decodeJavascriptString(raw));
                        startIsolatedPrint(safeName, html, attributes);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Không chuẩn bị được nội dung in: " + safeError(e), Toast.LENGTH_LONG).show();
                    }
                });
            });
        }

        public boolean saveFile(String filename, String base64, String mimeType) {
            try {
                String safeName = filename == null ? "bao-cao.csv" : filename.replaceAll("[^a-zA-Z0-9._-]", "_");
                if (!safeName.toLowerCase().endsWith(".csv")) safeName = safeName + ".csv";
                final String outputName = safeName;
                byte[] bytes = Base64.decode(base64 == null ? "" : base64, Base64.DEFAULT);
                if (bytes.length == 0) throw new Exception("Nội dung file rỗng");

                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, outputName);
                    values.put(MediaStore.Downloads.MIME_TYPE,
                            mimeType == null ? "text/csv" : mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH,
                            Environment.DIRECTORY_DOWNLOADS + "/ROLL CAY CANH");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("Không tạo được file trong Tải xuống");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("Không mở được file đích");
                        out.write(bytes);
                        out.flush();
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "✅ Đã xuất file: Tải xuống / ROLL CAY CANH / " + outputName,
                            Toast.LENGTH_LONG).show());
                    return true;
                }

                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Không tạo được thư mục Tải xuống");
                File file = new File(dir, outputName);
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(bytes);
                    out.flush();
                }
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "✅ Đã lưu file trong thư mục Tải xuống / " + outputName,
                        Toast.LENGTH_LONG).show());
                return true;
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "❌ Không lưu được file: " + safeError(e), Toast.LENGTH_LONG).show());
                return false;
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        try { cleanupPrintWebView(activePrintWebView); } catch (Exception ignored) {}
        try { mainHandler.removeCallbacksAndMessages(null); } catch (Exception ignored) {}
        try { if (webView != null) webView.destroy(); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
