# Google Drive shipment-photo display fix (v26.1.1)

- The shipment-report table now resolves `drive://FILE_ID` references through `DriveStorage.fromCloudValue()` before putting a source into an `<img>` element. It shows a clear message if Drive is disconnected or an image cannot be retrieved instead of a broken-image icon.
- The direct Firestore notification refresh path now hydrates Drive references too, rather than placing `drive://...` strings directly in app state.
- The connection status explicitly names the folder this app creates/uses: `QuanLyCayAPK_Images`. The similarly named `QuanLyCayAPK_Anh` folder is not the folder currently configured in the Android bridge.
- Order data stays in Firestore collection `packingOrders`, document `{orderId}`. `completionImage` points to proof image 1; `completionImages[0]` is image 1 and `completionImages[1]` is image 2 (shipping label). When upload succeeds, these fields hold `drive://{Drive file ID}` references; binary image files are private files in the connected Google account's `QuanLyCayAPK_Images` folder.
- `pushNow()` reporting success means Firestore data/reference sync succeeded; it should not be interpreted as a separate post-upload visual verification of every image.

Validation performed: source preflight, JavaScript syntax check for all inline scripts, AndroidManifest XML parse, and ZIP consistency. An Android runtime upload/download test still depends on the user's Google account and installed APK.
