ROLL CÂY CẢNH V20.3

1. Lấy QuanLyCayAPK_project.zip bên trong và thay file ZIP cũ trên GitHub.
2. Build APK bằng GitHub Actions.
3. Firebase Console → Firestore Database → Rules: dán file firestore.rules của V20.3 và Publish.
4. Cài APK mới.
5. Đăng nhập tiennt9939@gmail.com. Admin sẽ tự được tách khỏi nhân viên nếu trước đây từng gắn SINH.
6. Tạo/cấp tài khoản nhân viên từ danh sách nhân viên có sẵn; role packer phải liên kết với nhân viên để xuất hiện trong Phân công đơn.
