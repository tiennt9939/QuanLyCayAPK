# QuanLyCayAPK V26.1.5 — Admin Direct Completion (No Photo)

## Changes

- Removed the old standalone Admin “GHI NHẬN ĐÓNG HÀNG” form and its required photo section from the top of Theo ngày → Đóng hàng.
- Consolidated Admin work in “Phân công / ghi nhận hoàn tất”.
- Kept “PHÂN CÔNG ĐƠN HÀNG” for normal assigned orders; these remain pending and the employee completion/photo/OCR workflow is unchanged.
- Added “GHI NHẬN HOÀN TẤT (ADMIN · KHÔNG ẢNH)”. It uses the same employee, plant/size, per-line quantity, and number-of-orders fields, then creates the orders directly with `status=completed`, an explicit `completionMethod=admin_no_photo`, no images, and server-confirmed completion timestamp.
- Replaced the per-order Admin photo-completion button with “ADMIN HOÀN TẤT · KHÔNG ẢNH” for pending assigned orders. It asks for confirmation, then records completed status and the wage snapshot without photos.
- The Admin-only action records the assigned employee, completion operator, date, plant lines, quantity, and wage. It does not create shipment-tracking claims or queue delivery OCR.
- Firestore Rules only permit creation of no-photo completed orders through the explicitly named Admin branch; employee rules for their normal photo flow remain in place.
- Preserved stored per-item pay rates and current Cẩm tú mai C7/C9 wage thresholds.

## Release version

- `versionName`: `26.1.5`
- `versionCode`: `47`

## Automated verification

Run from the project root:

```bash
python3 tools/preflight.py
node tools/retention_logic_test.js
node tools/packing_wage_rules_test.js
node tools/drive_image_persistence_test.js
node tools/packer_assignment_ui_test.js
node tools/admin_direct_completion_test.js
```

The GitHub Actions workflow also checks JavaScript syntax and builds the debug APK. No APK is included in this source ZIP; an APK is available after Actions reports a successful build and uploads the artifact.

## Deployment

1. Upload this ZIP to the repository root as `QuanLyCayAPK-V26.1.5-ADMIN-DIRECT-COMPLETION.zip`.
2. Copy `.github/workflows/build-apk.yml` from this project into the repository workflow path `.github/workflows/build-apk.yml`.
3. Run the workflow in GitHub Actions and install only the APK artifact from a successful run.
4. Publish the accompanying `firestore.rules` to the correct Firebase project before relying on the new Admin direct-completion path.

No historical orders, plant catalog rows, rates, reports, or Drive images are deleted by this change.
