from pathlib import Path
import hashlib, re, json, sys, xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
java=ROOT/'app/src/main/java/com/quanlycay/apk/MainActivity.java'
html=ROOT/'app/src/main/assets/index.html'
bg=ROOT/'app/src/main/assets/quote-background.jpg'
manifest=ROOT/'app/src/main/AndroidManifest.xml'
styles=ROOT/'app/src/main/res/values/styles.xml'
data=ROOT/'app/src/main/assets/data.json'
rules=ROOT/'firestore.rules'
gradle=ROOT/'app/build.gradle.kts'
drive_test=ROOT/'tools/drive_image_persistence_test.js'
packer_ui_test=ROOT/'tools/packer_assignment_ui_test.js'

for f in (java,html,bg,manifest,styles,data,rules,gradle,drive_test,packer_ui_test):
    assert f.is_file(), f

assert hashlib.sha256(bg.read_bytes()).hexdigest() == '9c3965014db664df3caa1b42a85488c9a9c5557685e3c55d8b81625729655251'

j=java.read_text(encoding='utf-8')
ann=len(re.findall(r'@JavascriptInterface',j))
assert ann==9, f'Expected five original plus four Google Drive @JavascriptInterface methods, found {ann}'
assert 'play-services-auth:21.3.0' in (ROOT/'app/build.gradle.kts').read_text(encoding='utf-8'), 'Google Sign-In dependency missing'
for token in ('connectGoogleDrive', 'uploadDriveImage', 'downloadDriveImage', 'DRIVE_SCOPE'):
    assert token in j, f'Google Drive native bridge missing: {token}'
assert 'Drive không lưu được ảnh (HTTP ' in j and 'Không kiểm tra được ảnh' not in j, 'Drive upload must return explicit upload errors'
assert 'Verify a real non-empty file exists in the target folder' in j and 'verified.optLong("size", 0) <= 0' in j, 'Drive upload must verify file existence, size, and destination folder before success'
assert 'FixedAttributesPrintAdapter' not in j, 'Legacy print adapter must stay removed'
assert 'CAPTURE_PRINT_HTML_JS' in j, 'Isolated print capture bridge missing'
assert 'MediaSize.ISO_A4' in j, 'Native ISO A4 print size missing'
assert 'ROLL_GARDEN_65X100' in j, '65x100 media size missing'
assert 'Downloads.RELATIVE_PATH' in j
assert 'ocrShippingImage' in j
assert 'public void ocrShippingImage(String dataUrl, String callback)' in j, 'OCR bridge must accept the callback used by index.html'
assert 'TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)' in j and '.process(image)' in j, 'Native ML Kit OCR processing missing'
assert 'deliverOcrResult(cb, recognized)' in j and 'deliverOcrResult(cb, "")' in j, 'OCR success/failure callback missing'
assert 'implementation("com.google.mlkit:text-recognition:16.0.1")' in (ROOT/'app/build.gradle.kts').read_text(encoding='utf-8'), 'ML Kit OCR dependency missing'
assert 'sendToFlashLabel' in j
assert 'window.' in j, 'Native file export path missing'

h=html.read_text(encoding='utf-8')
assert "AndroidBridge.ocrShippingImage(photo,'__packingShipmentOcrResult')" in h, 'Packing OCR callback wiring missing'
assert "AndroidBridge.ocrShippingImage(photo,'__adminShipmentOcrResult')" in h, 'Admin OCR callback wiring missing'
assert 'quote-background.jpg' in h
assert '.quote-pdf-bg' in h and '.quote-pdf-page' in h
assert 'function exportQuotePdf()' in h
assert 'function exportPayrollCsv()' in h
assert 'function saveSalaryAdvance()' in h
assert 'function payrollAdvanceAvailable(' in h
assert 'function refreshAssignmentCatalogUI()' in h
assert 'refreshCatalogForAssignment' in h
assert 'V26.0.0 ROOT CAUSE FIX' in h
assert 'J&T Express' in h
assert 'J&T Cargo' in h
assert 'GHN' in h
assert "/^GHVN[A-Z0-9]{4,26}$/" in h, 'GHVN tracking prefix rule missing'
assert "/^862\\d{9}$/" in h, '12-digit J&T Express tracking rule missing'
assert "/^530\\d{9}$/" in h, '12-digit J&T Cargo tracking rule missing'
assert 'Ưu tiên các mẫu mã đã quy ước' in h, 'OCR tracking prefix filter missing'
assert 'CloudSync.schedulePush()' in h
assert 'const localCatalog=Array.isArray(D.catalog)' in h
assert "catalogId:String(x.catalogId||'')" in h, 'Assignment payload must preserve catalogId'
assert "catalogId:String(x?.catalogId||'')" in h, 'Cloud order creation must preserve catalogId'
assert "const catalogId=String(r?.catalogId??'').trim()" in h, 'Reports must resolve orders by catalogId first'
assert 'function addAssignmentItem()' in h
assert 'adminDeletePackerRecord:(id)=>state().adminDeletePackerRecord(id)' in h, 'Admin completed-record delete bridge must be exposed on window.CloudSync'
assert 'adminUpdatePackerRecord:(id,changes)=>state().adminUpdatePackerRecord(id,changes)' in h, 'Admin record update bridge must be exposed on window.CloudSync'
assert 'waitUntilAuthReady:(timeout)=>state().waitUntilAuthReady(timeout)' in h, 'Auth-ready top-level bridge required by print access checks'
assert 'assignPackSize' not in h, 'Legacy combo selector must be removed; each item line owns its quantity'
assert 'completionImages' in h and 'proofReady' in h
assert 'function openPackerCompleteOrder(id)' in h, 'Packer must open the per-order completion modal immediately'
assert 'async function submitPackerCompleteOrder(id)' in h, 'Packer modal must submit through the authenticated packer completion path'
packer_render=h[h.index('function renderPackerOrders(){'):h.index('async function acceptAssignedOrder(id){')]
assert 'onclick=\"openPackerCompleteOrder(' in packer_render, 'Assigned orders must open the one-step completion modal'
assert 'acceptAssignedOrder(' not in packer_render and 'NHẬN ĐƠN' not in packer_render, 'Packer UI must not require an acceptance step'
assert 'completePackingOrder(String(id),pendingAdminOrderProof,sh)' in h, 'Packer must complete orders as the assigned employee, not as Admin'
assert 'Đơn được phân công xuất hiện ngay' in packer_render
assert 'const DriveStorage=(()=>{' in h and 'window.DriveStorage=DriveStorage' in h, 'Drive image storage bridge missing'
assert "const PREFIX='drive://'" in h, 'Firestore image reference format missing'
assert 'migrateOrderImagesToDrive' in h, 'Legacy order image migration missing'
assert 'async function renderShipments()' in h and 'openOrderPhotoGallery' in h, 'Shipment report must open private Drive image references on demand'
assert 'function rawCompletionImages(r)' in h and 'function openOrderPhotoGallery(' in h, 'Completed-order photo gallery must support up to two data URLs or private Drive references'
assert '📷 Xem ảnh (${x.photoCount})' in h and 'order-photo-gallery' in h, 'Completed order and shipment report photos must remain hidden until the user taps the gallery control'
assert 'Chưa kết nối Google Drive trên thiết bị này. Ảnh chưa được tải lên' in h, 'New evidence photos must not silently fall back to Base64 when Drive is disconnected'
assert 'DriveStorage.toCloudValue' in h and 'drive:// IDs' in h, 'Private Drive reference flow missing'
assert 'async function runRetentionCleanupInternal()' in h and 'async function runRetentionCleanup()' in h, 'Automatic 30-day cleanup is missing'
assert 'retentionArchivePayrollForDates' in h, 'Payroll snapshots before cleanup are missing'
assert 'stockBaseDate' in h and 'monthlyStockSnapshots' in h and 'D.stockBaseDate=prevEnd' in h, 'Inventory baseline/month-end rollover is missing'
assert 'warningAtByDate' in h and 'RETENTION_DAY_MS' in h and 'timeByDate+RETENTION_DAY_MS' in h, '24-hour deletion warning/grace period is missing'
assert "String(r.status||'')==='completed'&&purgeSetForOrders.has(retentionOrderDate(r))" in h, 'Unfinished orders must be preserved'
assert 'pendingPayrollRetentionDates' in h and 'orderDataDeletedAtMs' in h, 'Payroll hold must recover after interrupted sync and start after confirmed order deletion'
assert 'Number(r.orderDataDeletedAtMs||0)>0' in h and 'now>=Number(r.deleteAfterMs)' in h, 'Wage archives must be paid and at least 10 days beyond order deletion before removal'
assert 'daily:cloudDaily.length||cloudHasAuthoritativeCleanup?cloudDaily:localDaily' in h, 'Explicit cleanup must not be undone by an empty Cloud daily list on a second device'
assert 'retentionCleanupPromise' in h and 'setInterval(runAdminRetentionPass,6*60*60*1000)' in h, 'Retention cleanup must be single-flight and periodically retried in foreground'
assert 'r.deleteAfterMs=Math.max(Number(r.deleteAfterMs)||0,now+10*RETENTION_DAY_MS)' in h, 'Late payroll settlement must receive another 10-day grace period'
assert "(D.shipments||[]).forEach(x=>{const d=String(x.date||x.completedDate||'');if(retentionValidDate(d))allDates.add(d)});" in h, 'Shipment history must be included in retention warning/purge dates'
assert 'setInterval(runAdminRetentionPass,6*60*60*1000)' in h and "document.addEventListener('visibilitychange'" in h, 'Retention checks need foreground/periodic triggers'
assert 'async function markPayrollPaid' in h and 'payrollSettlements' in h, 'Unpaid payroll protection is missing'
assert 'Đã xác nhận thanh toán' in h and 'Tiền công được bảo lưu' in h, 'Admin payroll retention UI is missing'
assert 'Ảnh riêng tư chỉ xem được bằng cùng tài khoản' in h, 'Drive account guidance missing'
assert 'printA4Page' in h
assert 'print-order' in h
# Payroll DOM must have exactly one payrollBody and no stray closing wrapper between advance card and body.
assert h.count('id="payrollBody"') == 1
assert '<section id="payroll"' in h and '</section>' in h

r=rules.read_text(encoding='utf-8')
assert 'request.resource.data.packSize >= 1' in r
assert 'request.resource.data.packSize <= 100' in r
assert "request.resource.data.completionMethod == 'admin_no_photo'" in r, 'Admin direct completion must be explicitly scoped in Firestore Rules'
assert "request.resource.data.status == 'completed'" in r and "request.resource.data.completedBy == request.auth.uid" in r, 'No-photo completed order must be Admin-authenticated'
assert "request.resource.data.completionImages.size() == 0" in r, 'Admin direct-completion rules must allow zero photos only in its named method'
assert 'request.resource.data.completionImages.size() == 2' in r
assert 'request.resource.data.diff(resource.data).affectedKeys().hasOnly' in r, 'Packer updates must be limited to completion/evidence fields'
assert "get(/databases/$(database)/documents/packingOrders/$(request.resource.data.orderId)).data.orderType == 'TT'" in r, 'TT shipment claim must be scoped to the assigned employee order'
assert 'adminCreateAssignments(true)' in h and 'adminCreateAssignments(false)' in h, 'Admin assignment form must expose both pending assignment and direct completion actions'
assert 'async function adminCompleteOrderNoPhoto(id)' in h, 'Admin should be able to complete an existing assigned order without photo'
assert "completionMethod:'admin_no_photo'" in h and "shipmentOcrStatus:'admin_no_photo'" in h, 'No-photo direct completion must be explicitly recorded'
assert '<div id="adminPackEntryPanel" class="hidden"' in h, 'Legacy standalone packing record form must be hidden/removed'
assert 'GHI NHẬN HOÀN TẤT (ADMIN · KHÔNG ẢNH)' in h, 'Admin direct-completion button must be visible on assignment form'
assert 'function orderItemWageProfile(' in h and 'function orderItemRate(' in h, 'Order-specific wage rules are missing'
assert 'const assignedPayAmount=items.reduce' in h and 'item.assignedRate=assignedRates[index]' in h, 'Admin-assigned wage snapshots per item and order must be stored'
assert "'completedBy','completionRecordedBy','shipment'" in r, 'Packer update whitelist must not expose writable wage fields'
assert "current.size==='C7'&&totalSameType>=5)return 1600" in h, 'Cẩm tú mai C7 wage rule missing'
assert "current.size==='C9'&&totalSameType>=4)return 2500" in h, 'Cẩm tú mai C9 wage rule missing'

assert 'function toLocalCacheValue(value)' in h, 'localStorage must persist Drive references, not image Base64 when uploaded'
assert 'drive.toLocalCacheValue(D):D' in h and 'countEmbeddedImages(localSnapshot)' in h, 'Primary local cache must be normalized to references and refuse unresolved Base64 writes'
assert 'async function ensureImageUploadedToDrive(' in h, 'Every captured image must be uploaded before being accepted'
for image_flow in ('readPlantImage(ev)', 'readAdminPackProofImage(ev)', 'readPackProofImage(ev)', 'readDeliveryOcrImage(ev)', 'readAdminOrderProof(ev,index)', 'readShipmentImage(ev)'):
    assert image_flow in h, f'Missing image flow {image_flow}'
assert h.count('ensureImageUploadedToDrive(') >= 7, 'Capture flows must upload images to Drive before processing'
assert 'async function migrateLocalImagesToDrive(' in h, 'Legacy local Base64 images must be migrated to Drive'
assert "key.startsWith('ROLL_CAY_PACKER_ORDERS_')" in h, 'Legacy employee order photo caches must also be migrated'
assert 'const cacheRefs=await drive.toCloudValue(rows' in h and 'JSON.stringify(cacheRefs)' in h, 'Employee order cache must persist Drive references only'
assert 'async function exportData()' in h and 'countEmbeddedImages(snapshot)' in h, 'Backup export must not include unmigrated Base64 photos'
assert 'await migrateLocalImagesToDrive({notify:false,render:false})' in h, 'Drive connect/startup must migrate previous local images'
assert "if((migrated>0||orderMigrated>0)&&st?.role!=='packer'" in h, 'Successful legacy image migration must push Drive references back to shared Cloud data'
assert 'function toLocalCacheValue(value)' in h and 'cacheRows=await drive.toCloudValue(safe' in h and 'JSON.stringify(cacheRows)' in h, 'Secondary packer order cache must persist Drive references only'
assert "backup-drive-references.json" in h, 'JSON backup should export Drive references rather than image bytes'

assert 'function hasDriveReference(dataUrl)' in h, 'Image writes must be gated on a confirmed Drive reference'
assert 'const snapshot=JSON.parse(JSON.stringify(D))' in h and 'D=await drive.fromCloudValue(refs)' not in h, 'Background migration must not overwrite edits made while uploads are in flight'
assert 'function displayImageSrc(value,fallback=\'\')' in h, 'Cached Drive references must be safely resolved for UI previews'
assert 'persistPackerOrderCache' in h and 'cacheRows=await drive.toCloudValue(safe' in h, 'Secondary order cache must upload legacy images and persist Drive references only'
assert 'Deferred local cache write' in h and 'countEmbeddedImages(localSnapshot)' in h, 'Local cache must not write unresolved Base64 image payloads'
assert 'DRIVE IMAGE PERSISTENCE TEST PASS' in drive_test.read_text(encoding='utf-8'), 'Drive-only local image persistence regression test is missing'
assert 'window.__rollDriveImageMigrationPromise' in h, 'Legacy image migration must be single-flight to avoid duplicate uploads'
assert 'verifiedDriveIds.add(String(r.id))' in h and 'downloaded.set(String(r.id),dataUrl)' not in h, 'Uploads must not duplicate every photo in the transient download cache'
assert "await drive.fromCloudValue(cacheRefs)" not in h, 'Local photo migration must not immediately redownload every uploaded photo'
assert "await window.DriveStorage.fromCloudValue(snapshot)" not in h, 'Backup export must not download images after uploading them'
assert "typeof st.migrateOrderImagesToDrive==='function'" in h, 'Startup should migrate legacy Firestore packing-order images as well as local cache images'

g=gradle.read_text(encoding='utf-8')
assert 'versionName = "26.1.5"' in g
assert 'versionCode = 47' in g
assert 'create("stableDebug")' in g and 'file("debug.keystore")' in g, 'Stable debug signing config is missing'
assert 'signingConfig = signingConfigs.getByName("stableDebug")' in g, 'Debug variant must use stable signing when keystore exists'
assert 'id="catalogExportSale"' in h
assert 'id="catalogExportPurchase"' in h
assert 'function exportCatalogPriceCsv()' in h
assert 'function exportCatalogPricePdf()' in h
# Quotation page must independently select sale/purchase columns for both PDF and CSV.
assert 'id="quoteExportSale"' in h and 'id="quoteExportPurchase"' in h
assert 'function quotePriceOptions(' in h
assert 'function onQuotePriceOptionsChanged()' in h
assert 'function quotePurchasePrice(' in h
assert "if(includePurchase&&role!=='admin')" in h
assert "headers.push('Giá nhập','Thành tiền nhập')" in h
assert "headers.push('Giá bán','Thành tiền bán')" in h
assert "const label=includePurchase&&includeSale?'gia-nhap-va-gia-ban':includePurchase?'gia-nhap':'gia-ban'" in h
assert "if(includePurchase&&role!=='admin')" in h
assert 'if(!includeSale&&!includePurchase)' in h

ET.parse(manifest); ET.parse(styles); json.loads(data.read_text(encoding='utf-8'))
print('PREFLIGHT PASS')
print('Background SHA-256:', hashlib.sha256(bg.read_bytes()).hexdigest())
print('JavascriptInterface count:', ann)
print('Google Drive bridge and legacy image migration: PASS')
print('Version: 26.1.5 / code 47')
print('Packer assigned-order flow: no acceptance step; one modal for photos and completion')
print('Drive image persistence audit: captured photos upload before acceptance; all local cache paths persist Drive references')
print('Catalog price export: sale/purchase/both selectable; purchase export admin-only')
print('Quotation PDF/CSV: sale/purchase/both selectable; purchase visible/export admin-only')
print('Multi-item assignment: per-line quantities preserved; order total 1..100')
print('Payroll export: PASS')
print('Salary advance: PASS')
print('Assignment refresh: PASS')
print('Isolated print WebView: PASS')
