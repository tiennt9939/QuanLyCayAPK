ROLL CAY CANH V20.4

1. Upload/replace QuanLyCayAPK_project.zip at the root of the GitHub repository.
2. Run GitHub Actions to build the APK.
3. IMPORTANT: publish the firestore.rules from the project in Firebase Console -> Firestore Database -> Rules.

Changes:
- Restore Admin/Manager manual packing screen as before assignment.
- Move packing assignment UI into the Đóng hàng screen.
- Keep Điều khiển focused on employees, accounts, rates, catalog, opening stock, backup.
- Admin cannot be linked to an employee.
- Fix sync rules for shared app/config data for the bootstrap admin.
