# ROLL CÂY CẢNH V25.6.1 — ROOT ASSIGNMENT FIX

This release is based on V25.5.9 and contains a real code change for the newly-added-plant assignment bug.

## Root cause fixed
The assignment catalog refresh previously called `pushNow()` before reading Firestore. A failed/slow Cloud write could prevent the local catalog from reaching the assignment selector. V25.6.1 makes the local catalog authoritative for the assignment UI, merges Cloud data without overwriting local conflicts, and retains the local catalog on permission/network failure.

## Other existing V25.6.x work retained
- Stable `catalogId` assignment payloads
- Dedicated 65x100 order print bridge
- Native PDF export bridge
- Payroll and salary advance logic

## Verification
This package must be rebuilt by GitHub Actions. Do not treat the source audit as proof of runtime behavior until the V25.6.1 APK artifact is installed and tested.
