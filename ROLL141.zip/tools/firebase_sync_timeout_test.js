'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8');
assert(/versionName\s*=\s*"26\.2\.141"/.test(gradle)&&/versionCode\s*=\s*193/.test(gradle),'sync timeout patch must increment Android version to 26.2.141 / 193');
const start=html.indexOf('async function pushNowUnlocked(){');
const end=html.indexOf('  function pushNow(){',start);
assert(start>=0&&end>start,'Cloud push function boundaries missing');
const push=html.slice(start,end);
for(const token of [
  "dailyShipmentAwaitWithTimeout(ref.get(),18000,'đọc dữ liệu chung từ Firebase')",
  "dailyShipmentAwaitWithTimeout(window.DriveStorage.toCloudValue(",
  "shipmentDataDeltaUpdateArguments(currentRoot.data||{},safeData,rootPatch)",
  "dailyShipmentAwaitWithTimeout(ref.update(",
  "setStatus('Lỗi đồng bộ · '",
  "localStorage.setItem('quanlycay_dirty','1')"
]) assert(push.includes(token),'pushNow must timeout and preserve dirty data at stage: '+token);
const syncStart=html.indexOf('async function syncNow(){'),syncEnd=html.indexOf('\nfunction setEntryMode',syncStart);
assert(syncStart>=0&&syncEnd>syncStart,'manual sync function boundaries missing');
const sync=html.slice(syncStart,syncEnd);
assert(sync.includes("dailyShipmentAwaitWithTimeout(CloudSync.pushNow(),55000,'đồng bộ dữ liệu chung')"),'manual sync needs an outer timeout');
assert(!push.includes('readDailyShipmentCollections(')&&!push.includes('persistDailyShipmentCollections('),'routine full-app sync must not read/rewrite the entire historical PDF/report collections');
assert(sync.includes('finally{window.__rollManualSyncBusy=false}'),'manual sync busy guard must always clear');
assert(sync.includes('Đồng bộ chưa xác nhận:'),'manual sync must show a failure, never success on timeout');
const assignStart=html.indexOf('async function applyDailyShipmentAssignments('),assignEnd=html.indexOf('\nasync function assignPendingEmployeePdfRows',assignStart);
const assign=html.slice(assignStart,assignEnd);
assert(assign.includes("dailyShipmentAwaitWithTimeout(api.syncDailyShipmentQueueForAssignment(),queueSyncTimeoutMs,'đồng bộ lô PDF mới nhất')"),'assignment must sync the targeted PDF queue instead of blocking on full-app sync');
assert(!assign.includes('window.CloudSync.pushNow()'),'assignment must not upload the entire app snapshot as a PDF precondition');
assert(assign.includes('if(!result?.ok)throw new Error'),'assignment must require Firebase confirmation');
console.log('Firebase sync timeout regression checks: PASS');
