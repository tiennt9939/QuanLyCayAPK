# V26.2.160 — Dọn dữ liệu thử nghiệm đơn hàng/vận chuyển theo ngày

- Tiếp tục từ source V26.2.159; `versionCode` tăng từ 211 lên 212.
- Bổ sung công cụ Admin chỉ dọn dữ liệu đơn hàng/vận chuyển của ngày được chọn. Mặc định là 01/11/2026 theo yêu cầu.
- Phạm vi xóa: PDF/nhãn vận chuyển, bản ghi quét, báo cáo vận chuyển, đơn đóng hàng/đơn vận chuyển thuộc ngày, khóa vận đơn liên quan và hàng đợi ngoại tuyến cũ gắn với ngày/mã đó.
- Giữ nguyên: danh mục cây, quy cách/giá/quy tắc nhận diện, tài khoản và nhân viên, công thức và lịch sử tiền công, ứng lương, tồn kho và giao dịch nhập-xuất, dữ liệu ngày khác, ảnh gốc đã tải lên Google Drive.
- Không tạo backup/migration snapshot trong thao tác dọn dữ liệu. Thao tác chỉ chạy sau khi Admin xem trước phạm vi và nhập đúng cụm xác nhận `XOA 01/11/2026`.
- Thêm mốc reset trên máy chủ để ngăn lượt quét ngoại tuyến cũ khôi phục lại các đơn đã dọn; nhãn mới được nhập sau mốc vẫn được phép vận hành.
- Giữ nguyên schema Firestore; không đổi công thức tiền công, quy tắc tồn kho, danh mục hoặc nhận diện PDF.
