# Dọn dữ liệu thử nghiệm trước khi vận hành — V26.2.160

## Phạm vi đã cấu hình

Ngày mặc định: **01/11/2026**.

Chỉ xóa dữ liệu nghiệp vụ đơn hàng/vận chuyển có ngày 01/11/2026:
- PDF/nhãn và hàng đợi nhãn trong kho vận chuyển tách schema.
- Lượt quét Firebase, báo cáo vận chuyển và khóa vận đơn thuộc các đơn/ngày được chọn.
- Đơn hàng/đơn đóng hàng có `date`, `completedDate`, `createdAtDate` hoặc ngày lưu trữ tương ứng trùng ngày được chọn.
- Các lượt quét/ảnh còn chờ đồng bộ trên thiết bị có thể liên kết chính xác với ngày/mã vận đơn đã dọn.

Giữ nguyên danh mục/quy cách/quy tắc nhận diện/giá; tài khoản và nhân viên; tiền công, bảng lương, lịch sử, ứng lương; tồn kho và toàn bộ giao dịch nhập-xuất; các ngày khác; tệp ảnh gốc đã có trên Google Drive.

Không tạo bản sao lưu server, không tự chạy migration, không xóa ảnh gốc Drive.

## Thực hiện sau khi cài APK V26.2.160

1. Dừng quét và đồng bộ trên tất cả điện thoại đang dùng app.
2. Đăng nhập tài khoản Admin, mở **Theo ngày → Công cụ dữ liệu nâng cao → Xóa dữ liệu nghiệp vụ theo ngày**.
3. Giữ ngày `01/11/2026`, bấm **Kiểm tra đơn & báo cáo ngày đã chọn** và xem số lượng từng loại trước khi xóa.
4. Chỉ tiếp tục nếu phạm vi preview đúng ngày và đúng loại dữ liệu. Nhập chính xác `XOA 01/11/2026`, bấm nút xóa và xác nhận hộp thoại cuối.
5. Chỉ coi là hoàn tất khi ứng dụng hiện thông báo **Firebase xác nhận đã xóa dữ liệu ngày 01/11/2026** và báo số lượng xóa. Nếu app báo schema chưa đối soát, có thay đổi chưa đồng bộ, phạm vi thay đổi hoặc timeout thì không thử reset khác; lần chạy đó chưa được xác nhận.
6. Mở app trên các điện thoại khác có mạng để đồng bộ mốc reset. Các lượt quét ngoại tuyến cũ thuộc ngày/mã đã xóa bị từ chối khôi phục; nhãn mới được nhập sau thời điểm reset vẫn được phép dùng.

## Các chốt an toàn trong source

- Chỉ Admin được xem preview/thực thi.
- Trước xóa: yêu cầu dữ liệu chung sạch, không có worker quét/tải ảnh đang chạy.
- Bắt buộc preview và nhập đúng cụm xác nhận; fingerprint được tính lại trước và trong Firestore transaction.
- Chỉ chạy khi kho nhãn đã ở schema tách V2 và migration manifest đã `committed`/đối soát. Nếu phát hiện mảng legacy trong root, source dừng và không tự migrate/backup.
- Giới hạn tối đa 400 thao tác transaction. Quá giới hạn thì không xóa.
- Ghi reset tombstone để chặn outbox cũ khôi phục dữ liệu đã dọn.
- Ảnh gốc Google Drive không bị xóa; chỉ mục ảnh tạm cục bộ thuộc lượt quét đã dọn được gỡ khỏi hàng đợi sau khi server xác nhận.

**Lưu ý:** ZIP này chứa chức năng dọn dữ liệu. Việc xóa thật chỉ diễn ra sau khi APK đã được build/cài và Admin thao tác trên hệ thống Firebase production; tạo ZIP không tự kết nối hoặc xóa dữ liệu trên máy chủ.
