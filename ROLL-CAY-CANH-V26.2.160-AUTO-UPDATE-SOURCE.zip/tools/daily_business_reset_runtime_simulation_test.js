const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const must = (condition, message) => { if (!condition) throw new Error(message); };

const start = html.indexOf('function resetValidBusinessDate(value){');
const end = html.indexOf('async function loadDailyShipmentScanRecords(', start);
must(start >= 0 && end > start, 'reset implementation region missing');
let source = html.slice(start, end);
must(!source.includes('ensureDailyShipmentStorageMigrated()'), 'cleanup must not trigger migrations/backups');

const date = '2026-11-01';
const pathKey = (collection, id) => `${collection}/${id}`;
const store = new Map();
const pathCollection = (collection, rows) => {
  for (const [id, data] of Object.entries(rows)) store.set(pathKey(collection, id), structuredClone(data));
};
const mkSnap = (id, p, data) => ({ id, ref: ref(p), exists: data !== undefined, data: () => data === undefined ? undefined : structuredClone(data) });
function ref(p) {
  return {
    path: p,
    id: p.split('/').pop(),
    get: async () => mkSnap(p.split('/').pop(), p, store.get(p)),
  };
}
function query(collection, field, value) {
  return {
    get: async () => {
      const prefix = `${collection}/`;
      const docs = [];
      for (const [p, data] of store.entries()) {
        if (p.startsWith(prefix) && p.split('/').length === collection.split('/').length + 1 && String(data?.[field] ?? '') === String(value)) docs.push(mkSnap(p.split('/').pop(), p, data));
      }
      return { docs };
    }
  };
}
const collections = {
  dailyShipmentScans: { where: (f, op, v) => query('dailyShipmentScans', f, v), doc: id => ref(pathKey('dailyShipmentScans', id)) },
  shipmentTrackingClaims: { doc: id => ref(pathKey('shipmentTrackingClaims', id)) },
};
const collRef = (collection) => ({
  where: (f, op, v) => query(collection, f, v),
  doc: id => ref(pathKey(collection, id)),
  get: async () => query(collection, '__never__', '__never__').get(),
});

const rootPath = 'apps/roll-cay-canh';
const rootPayload = {
  catalog: [{ id: 'plant-1', name: 'Nguyệt quế', size: 'C7', price: 30000 }],
  employees: [{ id: 'e1', name: 'Nhân viên A' }],
  users: [{ uid: 'u1', role: 'packer', employeeId: 'e1' }],
  daily: [{ date, plant: 'Nguyệt quế', qty: 9, laborPay: 14400 }],
  salaryAdvances: [{ id: 'adv1', date, amount: 50000 }],
  packerRecords: [{ id: 'wage1', date, amount: 14400 }],
  payrollArchives: [{ id: 'pay1', date, total: 14400 }],
  payrollSettlements: { [`${date}|e1`]: { amount: 14400 } },
  stockMovements: [{ id: 'stock1', date, qty: 3 }],
  inventory: [{ plantId: 'plant-1', qty: 25 }],
  shipments: [{ id: 'shipment-old', date }, { id: 'shipment-other', date: '2026-10-31' }],
  packingOrders: [{ id: 'cache-old', date, status: 'pending' }, { id: 'cache-other', date: '2026-10-31', status: 'pending' }],
};
store.set(rootPath, { data: structuredClone(rootPayload), dailyShipmentStorageSchema: 2, dailyShipmentStorageMigrationId: 'schema_v2_20261026' });
store.set('apps/roll-cay-canh/dailyShipmentMigrations/schema_v2_20261026', { phase: 'committed', postCommitVerification: { rootSchema: 2, orders: 2, reports: 2 } });
pathCollection('dailyShipmentScans', {
  OLD001: { date, trackingNo: 'OLD001', source: 'daily_shipment_scan', report: { date, trackingNo: 'OLD001', source: 'daily_shipment_scan' } },
  KEEP001: { date: '2026-10-31', trackingNo: 'KEEP001', source: 'daily_shipment_scan' },
});
pathCollection('packingOrders', {
  order_old_pending: { date, status: 'pending', shipmentTrackingNo: 'OLD001', name: 'test order' },
  order_old_completed: { completedDate: date, status: 'completed', shipmentTrackingNo: 'OLD002', name: 'test completed' },
  order_keep: { date: '2026-10-31', status: 'pending', shipmentTrackingNo: 'KEEP001', name: 'real order' },
});
pathCollection('apps/roll-cay-canh/dailyShipmentOrders', {
  OLD001: { record: { id: 'OLD001', trackingNo: 'OLD001', date, source: 'pdf_label', importedAtMs: 100 }, date, importedAtMs: 100, recordKind: 'order' },
  KEEP001: { record: { id: 'KEEP001', trackingNo: 'KEEP001', date: '2026-10-31', source: 'pdf_label', importedAtMs: 90 }, date: '2026-10-31', importedAtMs: 90, recordKind: 'order' },
});
pathCollection('apps/roll-cay-canh/dailyShipmentReports', {
  OLD001: { record: { id: 'OLD001', trackingNo: 'OLD001', date, source: 'daily_shipment_scan', scannedAtMs: 110 }, date, scannedAtMs: 110, recordKind: 'report' },
  KEEP001: { record: { id: 'KEEP001', trackingNo: 'KEEP001', date: '2026-10-31', source: 'daily_shipment_scan', scannedAtMs: 90 }, date: '2026-10-31', scannedAtMs: 90, recordKind: 'report' },
});
pathCollection('shipmentTrackingClaims', {
  OLD001: { orderId: 'order_old_pending', source: 'packing_order' },
  OLD002: { orderId: 'order_old_completed', source: 'packing_order' },
  KEEP001: { orderId: 'order_keep', source: 'packing_order' },
});

let migrationCalls = 0;
let txDeletes = [];
const db = {
  collection: name => collections[name] || collRef(name),
  runTransaction: async fn => {
    const pendingDeletes = [], pendingSets = [];
    await fn({
      get: async r => r.get(),
      delete: r => pendingDeletes.push(r.path),
      set: (r, value, options) => pendingSets.push({ path: r.path, value: structuredClone(value), options }),
    });
    for (const p of pendingDeletes) store.delete(p);
    for (const x of pendingSets) {
      if (x.options?.merge && store.has(x.path)) store.set(x.path, { ...store.get(x.path), ...x.value });
      else store.set(x.path, x.value);
    }
    txDeletes = pendingDeletes.slice();
  }
};
const context = {
  db,
  user: { uid: 'admin-1' },
  firebase: { firestore: { FieldValue: { serverTimestamp: () => 'SERVER_TIMESTAMP' } } },
  DAILY_SHIPMENT_STORAGE_SCHEMA: 2,
  DAILY_SHIPMENT_MIGRATION_ID: 'schema_v2_20261026',
  role: () => 'admin',
  ensureActionSession: async () => ({ uid: 'admin-1' }),
  ensureDailyShipmentStorageMigrated: async () => { migrationCalls++; throw new Error('migration/backup should not run'); },
  sharedRef: () => ref(rootPath),
  dailyShipmentMigrationRef: () => ref('apps/roll-cay-canh/dailyShipmentMigrations/schema_v2_20261026'),
  ordersRef: () => collRef('packingOrders'),
  dailyShipmentOrdersRef: () => collRef('apps/roll-cay-canh/dailyShipmentOrders'),
  dailyShipmentReportsRef: () => collRef('apps/roll-cay-canh/dailyShipmentReports'),
  normalizeTracking: value => String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, ''),
  normalizeResetTracking: value => String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, ''),
  fmt: d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`,
  completedOrderDate: r => String(r?.completedDate || r?.date || ''),
  retentionOrderDate: r => String(r?.completedDate || r?.date || r?.createdAtDate || ''),
  shipmentTracking: r => String(r?.trackingNo || r?.tracking || r?.waybill || '').toUpperCase().replace(/[^A-Z0-9]/g, ''),
  shipmentRecordId: r => String(r?.trackingNo || r?.tracking || r?.waybill || r?.id || '').toUpperCase().replace(/[^A-Z0-9_-]/g, '_'),
  shipmentRowsFromSnapshot: snap => (snap?.docs || []).map(d => d.data()?.record || d.data()).filter(Boolean),
  shipmentWithoutQueueFields: data => { const out={...data}; delete out.dailyShipmentOrders; delete out.dailyShipmentReports; return out; },
  dailyShipmentMergeSharedQueueRows: (local, cloud) => {
    const map=new Map(); for(const r of [...(local||[]),...(cloud||[])]){const k=String(r.trackingNo||r.id||''); if(!map.has(k))map.set(k,{...r}); else map.set(k,{...map.get(k),...r});} return [...map.values()];
  },
  mergeShipmentReports: (...groups) => {
    const map=new Map(); for(const g of groups)for(const r of (g||[])){const k=String(r.trackingNo||r.id||''); if(!map.has(k))map.set(k,{...r}); else map.set(k,{...map.get(k),...r});} return [...map.values()];
  }
};
context.db = db;
vm.createContext(context);
vm.runInContext(source + '\nthis.preview=getDailyShipmentResetPreview; this.reset=resetDailyShipmentData;', context);

(async () => {
  const preview = await context.preview(date);
  must(preview.canExecute === true, 'preview should be executable under transaction limit');
  must(preview.orderCount >= 2, 'preview should include pending and completed orders from target day');
  must(preview.pdfCount >= 1 && preview.reportCount >= 1 && preview.scanCount === 1, 'preview should detect PDFs/reports/scans');
  const confirm = context.resetBusinessConfirmPhrase(date);
  // A schema-v2 document that unexpectedly still contains legacy root arrays must stop before
  // any write, because Firestore rules prohibit reintroducing those arrays.
  const cleanRoot = structuredClone(store.get(rootPath));
  store.set(rootPath, { ...cleanRoot, data: { ...cleanRoot.data, dailyShipmentOrders: [{ trackingNo: 'LEGACY' }] } });
  let blockedLegacy = false;
  try { await context.reset(date, preview.fingerprint, confirm); } catch (e) { blockedLegacy = /schema tách đã đối soát hoàn tất/i.test(String(e?.message || e)); }
  must(blockedLegacy && txDeletes.length === 0, 'unexpected legacy root arrays must fail closed without deleting anything');
  store.set(rootPath, cleanRoot);
  const result = await context.reset(date, preview.fingerprint, confirm);
  must(result.ok === true, 'server transaction should confirm cleanup');
  must(migrationCalls === 0, 'cleanup must not initiate migration or backup');
  must(!store.has(pathKey('dailyShipmentScans', 'OLD001')) && store.has(pathKey('dailyShipmentScans', 'KEEP001')), 'only target-day scan must be deleted');
  must(!store.has(pathKey('packingOrders', 'order_old_pending')) && !store.has(pathKey('packingOrders', 'order_old_completed')) && store.has(pathKey('packingOrders', 'order_keep')), 'all and only target-day orders must be deleted');
  must(!store.has(pathKey('apps/roll-cay-canh/dailyShipmentOrders', 'OLD001')) && store.has(pathKey('apps/roll-cay-canh/dailyShipmentOrders', 'KEEP001')), 'only target-day PDF queue document must be deleted');
  must(!store.has(pathKey('apps/roll-cay-canh/dailyShipmentReports', 'OLD001')) && store.has(pathKey('apps/roll-cay-canh/dailyShipmentReports', 'KEEP001')), 'only target-day report document must be deleted');
  must(!store.has(pathKey('shipmentTrackingClaims', 'OLD001')) && !store.has(pathKey('shipmentTrackingClaims', 'OLD002')) && store.has(pathKey('shipmentTrackingClaims', 'KEEP001')), 'only claims linked to target-day orders/reports must be deleted');
  const rootAfter = store.get(rootPath);
  const dataAfter = rootAfter.data;
  for (const key of ['catalog','employees','users','daily','salaryAdvances','packerRecords','payrollArchives','payrollSettlements','stockMovements','inventory']) {
    must(JSON.stringify(dataAfter[key]) === JSON.stringify(rootPayload[key]), `protected field ${key} must be byte-for-byte equivalent in simulation`);
  }
  must(dataAfter.shipments.length === 1 && dataAfter.shipments[0].id === 'shipment-other', 'other-date shipment must remain');
  must(dataAfter.packingOrders.length === 1 && dataAfter.packingOrders[0].id === 'cache-other', 'other-date root cached order must remain');
  must(!Object.prototype.hasOwnProperty.call(dataAfter,'dailyShipmentOrders') && !Object.prototype.hasOwnProperty.call(dataAfter,'dailyShipmentReports'), 'split schema must keep queue/report arrays out of the root document');
  must(store.has(pathKey('apps/roll-cay-canh/dailyShipmentOrders','KEEP001')) && store.has(pathKey('apps/roll-cay-canh/dailyShipmentReports','KEEP001')), 'other-date split queue and report records must remain');
  must(rootAfter.dailyShipmentResetDates[date] > 0 && rootAfter.dailyShipmentClearedTrackingNos.OLD001 > 0, 'cross-device anti-resurrection markers must be persisted');
  must(!txDeletes.some(p => /catalog|employees|users|daily\//.test(p)), 'no protected collection documents may be deleted');
  console.log('Daily reset runtime simulation PASS — selected-date orders/reports only; payroll, stock, catalog, staff and other dates retained; no migration/backup side effects');
})().catch(e => { console.error(e); process.exitCode = 1; });
