'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert'),vm=require('vm');
const root=path.resolve(__dirname,'..');
const gas=fs.readFileSync(path.join(root,'Code.gs'),'utf8');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
assert(gas.includes("marker='~ROLLB64V1~',chunkSize=30000"),'GAS writes must encode payload chunks before storing them in Sheets');
assert(gas.includes('function fsCompatJoinPayloadChunks_(chunks,path)'),'GAS reader must decode new payload chunks');
assert(gas.includes("if(marked===0)return encoded.join('')"),'legacy raw chunks must remain readable');
assert(gas.includes('fsCompatMaterializeIndex_(sheet,verifyMetadata,changes.map(function(x){return x.path;}))'),'GAS must read back writes before compacting older versions');
assert(gas.includes('function diagnoseKnownBrokenRollDocuments()'),'read-only diagnostics missing');
assert(html.includes("EXPECTED_ROLL_GAS_COMPAT_VERSION='gas-firestore-compat-phase3.3-safe-base64-payload-chunks'"),'client and GAS compatibility versions must match');
assert(html.includes('async function prepareDailyShipmentAssignmentBatch(date,trackingNos)'),'bulk assignment must prepare selected queue only once');
assert(html.includes('adminAssignDailyShipmentLabels(date,assignments,options={})'),'assignment transaction must support prevalidated queue mode');
assert(html.includes('const chunkSize=18,totalChunks=Math.ceil(assignments.length/chunkSize)'),'transaction chunks must respect the GAS getMany 100-document limit');
assert(html.includes('api.adminAssignDailyShipmentLabels(date,chunk,{prepared:true})'),'transaction chunks must not persist the same PDF batch repeatedly');
const assignStart=html.indexOf('async function applyDailyShipmentAssignments('),assignEnd=html.indexOf('\nasync function assignPendingEmployeePdfRows',assignStart);
const assign=html.slice(assignStart,assignEnd);
assert(assign.includes('api.prepareDailyShipmentAssignmentBatch(date,needsPreparation)'),'unprepared labels must be persisted once before transactions');
assert(!assign.includes('chunkSize=10'),'old ten-row repeated-write path must be removed');

// Execute the real GAS payload helpers with a minimal Utilities-compatible implementation.
const context={
  Utilities:{
    Charset:{UTF_8:'UTF-8'},
    base64EncodeWebSafe:(value)=>Buffer.from(String(value),'utf8').toString('base64'),
    base64DecodeWebSafe:(value)=>Array.from(Buffer.from(String(value),'base64')),
    newBlob:(bytes)=>({getDataAsString:()=>Buffer.from(bytes).toString('utf8')})
  },
  console, Logger:{log(){}}, Object, Array, String, Number, Math, JSON, Date, Error
};
vm.createContext(context);
vm.runInContext(gas,context,{filename:'Code.gs'});
const longJson=JSON.stringify({x:'A'.repeat(39994)+'='+ 'B'.repeat(65000),label:'Cây nguyệt quế 🌱 – Cẩm tú mai'});
assert.strictEqual(longJson.charAt(40000),'=','fixture must reproduce a raw chunk starting with equals');
const encodedChunks=context.fsCompatSplitPayload_(longJson);
assert(encodedChunks.length>1,'large payload must split into multiple cells');
assert(encodedChunks.every(c=>c.startsWith('~ROLLB64V1~')&&!c.startsWith('=')),'no persisted chunk may begin with formula marker');
assert(encodedChunks.every(c=>c.length<=30011),'encoded chunks must remain below cell size limit');
assert.strictEqual(context.fsCompatJoinPayloadChunks_(encodedChunks,'test/doc'),longJson,'encoded payload must round-trip Unicode and long JSON exactly');
const legacyChunks=[];for(let i=0;i<longJson.length;i+=40000)legacyChunks.push(longJson.slice(i,i+40000));
assert.strictEqual(context.fsCompatJoinPayloadChunks_(legacyChunks,'legacy/doc'),longJson,'legacy raw payloads must still round-trip when their cells are intact');
assert.throws(()=>context.fsCompatJoinPayloadChunks_([encodedChunks[0],legacyChunks[1]],'mixed/doc'),/Mixed legacy and encoded chunks/,'mixed chunk encoding must fail closed');
console.log('V26.2.160 GAS SAFE PAYLOAD + BULK PDF ASSIGNMENT REGRESSION: PASS');
