const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const rules = fs.readFileSync(path.join(root, 'firestore.rules'), 'utf8');
const must = (condition, message) => { if (!condition) throw new Error(message); };

must(/versionName\s*=\s*"26\.2\.160"/.test(gradle) && /versionCode\s*=\s*212/.test(gradle), 'targeted cleanup version metadata missing');
must(html.includes('id="dailyBusinessResetDate" type="date" value="2026-11-01"'), 'cleanup default date must be 2026-11-01');
must(html.includes('function previewDailyBusinessReset()') && html.includes('function executeDailyBusinessReset()'), 'Admin preview/execute UI missing');
must(html.includes("scope:'orders_and_shipment_reports_only'"), 'cleanup audit scope must be order/report-only');
must(html.includes("if(String(confirmationText||'').trim()!==expectedPhrase)"), 'date-specific destructive confirmation guard missing');
must(html.includes("db.collection('dailyShipmentScans').where('date','==',date)"), 'scan deletion must be date-scoped');
must(html.includes('pdfRecordRefs.forEach(ref=>tx.delete(ref))'), 'split PDF queue documents must actually be deleted');
must(html.includes('reportRecordRefs.forEach(ref=>tx.delete(ref))'), 'split report documents must actually be deleted');
must(html.includes('targetScans.forEach(doc=>tx.delete(doc.ref))'), 'scan documents must be deleted');
must(html.includes('targetOrders.forEach(doc=>tx.delete(doc.ref))'), 'all matching date orders must be deleted');
must(html.includes('claimsToDelete.forEach(x=>tx.delete'), 'only related tracking claims should be deleted');
must(html.includes('resetOrderCandidateForDate({id:doc.id,...(doc.data()||{})},date)'), 'order scope must include every order state on the selected date');
must(html.includes("String(r?.date||'')!==date"), 'date-scoped queue/report deletion missing');
must(html.includes('nextData.packingOrders=(Array.isArray(rootData.packingOrders)?rootData.packingOrders:[]).filter(r=>!resetOrderCandidateForDate(r,date))'), 'cached packing orders must be removed for selected date');

// Guard against regression to the old broad reset: no payroll, stock, advance or manual daily rows are deleted.
const resetStart = html.indexOf('async function resetDailyShipmentData(');
const resetEnd = html.indexOf('async function loadDailyShipmentScanRecords(', resetStart);
must(resetStart >= 0 && resetEnd > resetStart, 'targeted backend cleanup function missing');
const resetCode = html.slice(resetStart, resetEnd);
must(!resetCode.includes('ensureDailyShipmentStorageMigrated()'), 'cleanup must not trigger migration/backup side effects');
must(resetCode.includes("Object.prototype.hasOwnProperty.call(rootData,'dailyShipmentOrders')") && resetCode.includes("migrationData.phase!=='committed'") && resetCode.includes('postCommitVerification?.rootSchema'), 'legacy root queue arrays or incomplete split migration must fail closed');
must(resetCode.includes('data:shipmentWithoutQueueFields(nextData)'), 'split root write must keep queue arrays out of the shared root document');
for (const forbidden of [
  'nextData.daily=', 'nextData.salaryAdvances=', 'nextData.packerRecords=',
  'nextData.payrollArchives=', 'nextData.payrollSettlements=',
  'nextData.retentionState=', 'delete nextData.stockBaseDate',
]) must(!resetCode.includes(forbidden), `cleanup must preserve protected data: ${forbidden}`);
must(resetCode.includes('preservedPayroll:true') && resetCode.includes('preservedInventory:true'), 'audit must certify payroll/inventory preservation');
must(resetCode.includes('nextData.shipments=') && !resetCode.includes('nextData.dailyShipmentOrders=') && !resetCode.includes('nextData.dailyShipmentReports=') && resetCode.includes('pdfRecordRefs.forEach(ref=>tx.delete(ref))') && resetCode.includes('reportRecordRefs.forEach(ref=>tx.delete(ref))'), 'shipment queue/report split docs must be deleted without rewriting legacy root arrays');
must(resetCode.includes('nextData.packingOrders='), 'date orders cache should be removed');
must(resetCode.includes('dailyShipmentResetDates:resetDates') && resetCode.includes('dailyShipmentClearedTrackingNos:clearedTrackingMarkers'), 'cross-device tombstones must be persisted');
must(rules.includes('match /dailyShipmentScans/{trackingNo}') && rules.includes('allow delete: if isAdmin();'), 'Admin scan-delete rule not available');
must(rules.includes('match /packingOrders/{orderId}') && rules.includes('allow delete: if isAdmin();'), 'Admin order-delete rule not available');
must(rules.includes('match /apps/{appId}/dailyShipmentOrders/{recordId}') && rules.includes('allow delete: if appId == \'roll-cay-canh\' && isAdmin();'), 'Admin split-order-delete rule not available');
must(rules.includes('match /apps/{appId}/dailyShipmentReports/{recordId}') && rules.includes('allow delete: if appId == \'roll-cay-canh\' && isAdmin();'), 'Admin split-report-delete rule not available');
must(html.includes('RESET_DATE_INVALIDATED'), 'stale offline scan must be rejected server-side after cleanup');
must(html.includes('dailyShipmentPruneResetOfflineOutbox();'), 'each sync must prune offline entries invalidated by reset marker');
must(html.includes('GIỮ NGUYÊN: toàn bộ bảng lương/tiền công'), 'UI must explain protected records');
must(html.includes('Ảnh gốc trên Google Drive không bị xóa'), 'UI must explain Drive photos are retained');

// Verify date tombstones hide all pre-reset shipment reports/queue rows, while new work and other dates survive.
const helperStart = html.indexOf('function dailyShipmentDateWasReset(date)');
const helperEnd = html.indexOf('window.__mergeDailyShipmentSharedSnapshot=', helperStart);
must(helperStart >= 0 && helperEnd > helperStart, 'date marker helper block missing');
const sandbox = {
  normalizeTracking: value => String(value || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase(),
  D: {
    dailyShipmentResetDates: { '2026-11-01': 1000 },
    dailyShipmentClearedTrackingNos: { OLD: 1000 },
    dailyShipmentReports: [
      {id:'daily_old',trackingNo:'OLD',date:'2026-11-01',source:'daily_shipment_scan',status:'recorded',scannedAtMs:900},
      {id:'pdf_old',trackingNo:'PDFOLD',date:'2026-11-01',source:'pdf_label',status:'imported',importedAtMs:900},
      {id:'daily_new',trackingNo:'NEW',date:'2026-11-01',source:'daily_shipment_scan',status:'recorded',scannedAtMs:1100},
      {id:'daily_other',trackingNo:'OTHER',date:'2026-10-31',source:'daily_shipment_scan',status:'recorded',scannedAtMs:800}
    ],
    dailyShipmentOrders: [
      {trackingNo:'OLD',date:'2026-11-01',source:'pdf_label',status:'recorded',importedAtMs:900},
      {trackingNo:'PDFOLD',date:'2026-11-01',source:'pdf_label',status:'imported',importedAtMs:900},
      {trackingNo:'NEW',date:'2026-11-01',source:'pdf_label',status:'recorded',importedAtMs:1100},
      {trackingNo:'OTHER',date:'2026-10-31',source:'pdf_label',status:'imported',importedAtMs:800}
    ]
  },
  invalidateInventoryIndexes() {}
};
vm.runInNewContext(html.slice(helperStart, helperEnd) + `this.run=()=>{dailyShipmentApplyResetMarkers();return {reports:D.dailyShipmentReports,orders:D.dailyShipmentOrders};};`, sandbox);
const marked = sandbox.run();
must(!marked.reports.some(r => r.trackingNo === 'OLD' || r.trackingNo === 'PDFOLD'), 'old date reports must be hidden regardless of report source');
must(marked.reports.some(r => r.trackingNo === 'NEW') && marked.reports.some(r => r.trackingNo === 'OTHER'), 'fresh same-day and other-day reports must remain');
must(!marked.orders.some(r => r.trackingNo === 'OLD' || r.trackingNo === 'PDFOLD'), 'all old same-day queue rows, including recorded rows, must be hidden');
must(marked.orders.some(r => r.trackingNo === 'NEW' && r.status === 'recorded') && marked.orders.some(r => r.trackingNo === 'OTHER'), 'newly imported same-day and other-day labels must remain');

// Fingerprint contains only deletable shipment/order data. Payroll and inventory drift is intentionally irrelevant.
const signatureStart = html.indexOf('function resetPreviewSignature(');
const signatureEnd = html.indexOf('async function collectDailyBusinessResetSnapshot', signatureStart);
must(signatureStart >= 0 && signatureEnd > signatureStart, 'cleanup fingerprint function missing');
const sigSandbox = {
  resetTargetPdfRows: (rows,date) => (Array.isArray(rows)?rows:[]).filter(r=>String(r?.date||'')===String(date)),
  resetTargetShipmentReports: (rows,date) => (Array.isArray(rows)?rows:[]).filter(r=>String(r?.date||'')===String(date)),
  resetCleanForSignature: value => {
    if(Array.isArray(value))return value.map(sigSandbox.resetCleanForSignature);
    if(value&&typeof value==='object'){const out={};Object.keys(value).sort().forEach(k=>{if(['updatedAt','updatedAtMs','lastSeenAtMs','syncedAtMs'].includes(k))return;const v=value[k];if(v!==undefined)out[k]=sigSandbox.resetCleanForSignature(v)});return out}
    if(typeof value==='number'&&!Number.isFinite(value))return String(value);
    return value===undefined?null:value;
  },
  resetStableJson: value => JSON.stringify(sigSandbox.resetCleanForSignature(value))
};
vm.runInNewContext(html.slice(signatureStart, signatureEnd) + ';this.signature=resetPreviewSignature;', sigSandbox);
const date='2026-11-01';
const order={id:'p1',data:()=>({status:'pending',date,assignedUid:'a'})};
const app={dailyShipmentOrders:[{trackingNo:'T1',date}],dailyShipmentReports:[{trackingNo:'T1',date}],daily:[{date,qty:1}],payrollArchives:[{date,total:20}],stockBaseDate:'2026-10-31'};
const sig1=sigSandbox.signature(date,app,[],[],[order]);
app.daily[0].qty=77;app.payrollArchives[0].total=999;app.stockBaseDate='2026-11-01';
const sig2=sigSandbox.signature(date,app,[],[],[order]);
must(sig1===sig2, 'changes to retained payroll, stock and manual daily records must not invalidate shipment cleanup');
order.data=()=>({status:'assigned',date,assignedUid:'b'});
const sig3=sigSandbox.signature(date,app,[],[],[order]);
must(sig3!==sig2, 'changes to a date-targeted order must invalidate the preview');

// Offline test rows from a cleared date are removed from device storage, while later work stays queued.
const pruneStart = html.indexOf('function dailyShipmentPruneResetOfflineOutbox(){');
const pruneEnd = html.indexOf('async function dailyShipmentSyncOfflineOutbox', pruneStart);
must(pruneStart >= 0 && pruneEnd > pruneStart, 'offline reset queue pruning helper missing');
const deviceRows = [
  {trackingNo:'OLD',queuedAtMs:900,path:'old.jpg',report:{date:'2026-11-01',scannedAtMs:900},orderPatch:{}},
  {trackingNo:'NEW',queuedAtMs:1100,path:'new.jpg',report:{date:'2026-11-01',scannedAtMs:1100},orderPatch:{}},
  {trackingNo:'OTHER',queuedAtMs:800,path:'other.jpg',report:{date:'2026-10-31',scannedAtMs:800},orderPatch:{}}
];
const acked=[];let stored=deviceRows.slice();let pending=[{trackingNo:'OLD',path:'old.jpg'},{trackingNo:'NEW',path:'new.jpg'}];
const deviceSandbox={
  D:{dailyShipmentResetDates:{'2026-11-01':1000},dailyShipmentClearedTrackingNos:{OLD:1000}},
  DAILY_SHIPMENT_OUTBOX_NATIVE_STORE:'daily-shipment-outbox-v1',dailyShipmentOfflineOutbox:undefined,
  AndroidBridge:{listOfflineJsonRecords:()=>JSON.stringify(stored),removeOfflineJsonRecord:(store,id)=>{const t=id.replace(/^T_/,'');const n=stored.length;stored=stored.filter(x=>x.trackingNo!==t);return stored.length<n},ackDailyShipmentPhoto:path=>acked.push(path)},
  normalizeTracking:v=>String(v||'').replace(/[^A-Za-z0-9]/g,'').toUpperCase(),
  dailyShipmentOfflineOutboxRows(force){if(!Array.isArray(deviceSandbox.dailyShipmentOfflineOutbox)||force){deviceSandbox.dailyShipmentOfflineOutbox=JSON.parse(deviceSandbox.AndroidBridge.listOfflineJsonRecords()).slice()}return deviceSandbox.dailyShipmentOfflineOutbox},
  dailyShipmentOfflineOutboxRemove(t){const ok=deviceSandbox.AndroidBridge.removeOfflineJsonRecord('daily-shipment-outbox-v1','T_'+t);if(ok)deviceSandbox.dailyShipmentOfflineOutbox=deviceSandbox.dailyShipmentOfflineOutbox.filter(x=>x.trackingNo!==t);return ok},
  dailyShipmentPendingPhotos:()=>pending,
  saveDailyShipmentPendingPhotos:rows=>{pending=rows},
  renderDailyShipmentRetryPanel:()=>{}
};
vm.runInNewContext(html.slice(pruneStart, pruneEnd) + ';this.prune=dailyShipmentPruneResetOfflineOutbox;', deviceSandbox);
const removed=deviceSandbox.prune();
must(removed===1, 'only the stale offline capture should be removed');
must(stored.length===2 && stored.some(x=>x.trackingNo==='NEW') && stored.some(x=>x.trackingNo==='OTHER'), 'fresh and other-date outbox entries must be preserved');
must(acked.includes('old.jpg'), 'photo stored locally for the deleted test capture must be acknowledged');
must(!pending.some(x=>x.trackingNo==='OLD') && pending.some(x=>x.trackingNo==='NEW'), 'only the corresponding local pending photo should be removed');

console.log('Targeted order/report cleanup regression test PASS');
