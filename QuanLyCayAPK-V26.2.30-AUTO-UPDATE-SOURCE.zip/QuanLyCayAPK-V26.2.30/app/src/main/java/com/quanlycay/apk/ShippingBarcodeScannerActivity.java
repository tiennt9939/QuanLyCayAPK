package com.quanlycay.apk;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.util.Size;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.ComponentActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.MeteringPoint;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

/** Fast, on-device shipping-label scanner with continuous autofocus, torch, zoom and manual fallback. */
public final class ShippingBarcodeScannerActivity extends ComponentActivity {
    public static final String EXTRA_RAW_VALUE = "shipping_barcode_raw_value";
    public static final String EXTRA_ERROR = "shipping_barcode_error";
    private static final int CAMERA_PERMISSION_REQ = 4821;
    private static final Pattern GHN_VNGH = Pattern.compile("^VNGH\\d{8,12}$");
    private static final Pattern GHN_GHVN = Pattern.compile("^GHVN[A-Z0-9]{4,26}$");
    private static final Pattern JT_EXPRESS = Pattern.compile("^862\\d{9}$");
    private static final Pattern JT_CARGO = Pattern.compile("^530\\d{9}$");

    private final ExecutorService cameraExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean analyzingFrame = new AtomicBoolean(false);
    private PreviewView previewView;
    private TextView statusView;
    private TextView zoomView;
    private Button torchButton;
    private Button zoomOutButton;
    private Button zoomInButton;
    private EditText manualInput;
    private BarcodeScanner barcodeScanner;
    private Camera camera;
    private ProcessCameraProvider cameraProvider;
    private boolean torchEnabled = false;
    private volatile boolean finished = false;
    private long lastHintAtMs = 0L;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(20, 83, 45));
        window.setNavigationBarColor(Color.rgb(15, 23, 42));
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildUi();
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
            // Shipping barcodes are linear. Deliberately skip QR codes printed for TikTok promotions.
            .setBarcodeFormats(Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39,
                Barcode.FORMAT_CODE_93, Barcode.FORMAT_ITF, Barcode.FORMAT_CODABAR)
            .build();
        barcodeScanner = BarcodeScanning.getClient(options);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQ);
        }
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.rgb(8, 15, 24));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(16), dp(12), dp(16), dp(12));
        header.setBackgroundColor(Color.rgb(20, 83, 45));
        TextView title = text("QUÉT MÃ VẬN ĐƠN", 19, Color.WHITE, true);
        header.addView(title);
        TextView subtitle = text("Đặt mã vạch GHN/J&T nằm ngang trong khung xanh", 13, Color.rgb(220, 252, 231), false);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(-1, -2);
        subtitleParams.topMargin = dp(4);
        header.addView(subtitle, subtitleParams);
        page.addView(header, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout cameraArea = new FrameLayout(this);
        cameraArea.setBackgroundColor(Color.BLACK);
        previewView = new PreviewView(this);
        previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        cameraArea.addView(previewView, new FrameLayout.LayoutParams(-1, -1));
        ScanTargetOverlay overlay = new ScanTargetOverlay(this);
        cameraArea.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        previewView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) focusAt(event.getX(), event.getY());
            return true;
        });
        page.addView(cameraArea, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.VERTICAL);
        footer.setPadding(dp(12), dp(9), dp(12), dp(10));
        footer.setBackgroundColor(Color.rgb(248, 250, 252));
        statusView = text("Đang chuẩn bị camera…", 14, Color.rgb(30, 41, 59), true);
        statusView.setMinHeight(dp(38));
        footer.addView(statusView, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        torchButton = button("🔦 BẬT ĐÈN", Color.rgb(21, 101, 52));
        zoomOutButton = button("−", Color.rgb(51, 65, 85));
        zoomView = text("1.0×", 15, Color.rgb(15, 23, 42), true);
        zoomView.setGravity(Gravity.CENTER);
        zoomInButton = button("+", Color.rgb(51, 65, 85));
        LinearLayout.LayoutParams ctl = new LinearLayout.LayoutParams(0, dp(42), 1.4f);
        ctl.setMargins(0, dp(3), dp(6), dp(5));
        controls.addView(torchButton, ctl);
        LinearLayout.LayoutParams small = new LinearLayout.LayoutParams(0, dp(42), 0.6f);
        small.setMargins(0, dp(3), dp(5), dp(5));
        controls.addView(zoomOutButton, small);
        LinearLayout.LayoutParams zoomLabel = new LinearLayout.LayoutParams(0, dp(42), 0.65f);
        zoomLabel.setMargins(0, dp(3), dp(5), dp(5));
        controls.addView(zoomView, zoomLabel);
        LinearLayout.LayoutParams plus = new LinearLayout.LayoutParams(0, dp(42), 0.6f);
        plus.setMargins(0, dp(3), 0, dp(5));
        controls.addView(zoomInButton, plus);
        footer.addView(controls);

        torchButton.setOnClickListener(v -> toggleTorch());
        zoomOutButton.setOnClickListener(v -> adjustZoom(false));
        zoomInButton.setOnClickListener(v -> adjustZoom(true));

        LinearLayout manualRow = new LinearLayout(this);
        manualRow.setOrientation(LinearLayout.HORIZONTAL);
        manualInput = new EditText(this);
        manualInput.setSingleLine(true);
        manualInput.setTextSize(15);
        manualInput.setHint("Mã vạch khó đọc? Nhập mã vận đơn");
        manualInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        manualInput.setPadding(dp(10), 0, dp(10), 0);
        manualInput.setBackground(roundBackground(Color.WHITE, Color.rgb(203, 213, 225)));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(0, dp(46), 1f);
        inputParams.setMargins(0, dp(2), dp(7), dp(2));
        manualRow.addView(manualInput, inputParams);
        Button useManual = button("XÁC NHẬN MÃ", Color.rgb(5, 150, 105));
        manualRow.addView(useManual, new LinearLayout.LayoutParams(dp(132), dp(46)));
        useManual.setOnClickListener(v -> submitManualCode());
        footer.addView(manualRow);

        Button cancel = button("ĐÓNG MÁY QUÉT", Color.rgb(71, 85, 105));
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(-1, dp(42));
        cancelParams.topMargin = dp(6);
        footer.addView(cancel, cancelParams);
        cancel.setOnClickListener(v -> finishCancelled());
        page.addView(footer, new LinearLayout.LayoutParams(-1, -2));
        setContentView(page);
    }

    private void startCamera() {
        setStatus("Đang khởi động camera và bộ đọc mã…", Color.rgb(30, 41, 59));
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            if (finished || isFinishing()) return;
            try {
                cameraProvider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                ImageAnalysis analysis = new ImageAnalysis.Builder()
                    .setTargetResolution(new Size(1280, 720))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build();
                analysis.setAnalyzer(cameraExecutor, this::analyzeFrame);
                cameraProvider.unbindAll();
                camera = cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis);
                torchButton.setEnabled(camera.getCameraInfo().hasFlashUnit());
                if (!camera.getCameraInfo().hasFlashUnit()) torchButton.setText("KHÔNG CÓ ĐÈN");
                setStatus("Đang quét liên tục… chạm vào mã để lấy nét, dùng + để phóng to.", Color.rgb(21, 101, 52));
                updateZoomLabel();
                focusAt(previewView.getWidth() / 2f, previewView.getHeight() / 2f);
            } catch (Exception e) {
                setStatus("Không mở được camera: " + safeMessage(e), Color.rgb(185, 28, 28));
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void analyzeFrame(ImageProxy proxy) {
        if (finished || !analyzingFrame.compareAndSet(false, true)) {
            proxy.close();
            return;
        }
        android.media.Image mediaImage = proxy.getImage();
        if (mediaImage == null) {
            proxy.close();
            analyzingFrame.set(false);
            return;
        }
        InputImage input;
        try {
            input = InputImage.fromMediaImage(mediaImage, proxy.getImageInfo().getRotationDegrees());
        } catch (Exception e) {
            proxy.close();
            analyzingFrame.set(false);
            return;
        }
        barcodeScanner.process(input)
            .addOnSuccessListener(barcodes -> {
                for (Barcode barcode : barcodes) {
                    String raw = barcode == null ? "" : barcode.getRawValue();
                    String normalized = normalize(raw);
                    if (isSupportedTracking(normalized)) {
                        finishWithCode(normalized);
                        return;
                    }
                    String display = barcode == null ? "" : barcode.getDisplayValue();
                    String displayNormalized = normalize(display);
                    if (isSupportedTracking(displayNormalized)) {
                        finishWithCode(displayNormalized);
                        return;
                    }
                }
                if (!barcodes.isEmpty()) hintOtherBarcode();
            })
            .addOnFailureListener(error -> android.util.Log.w("ShippingBarcode", "Frame decode failed", error))
            .addOnCompleteListener(task -> {
                try { proxy.close(); } catch (Exception ignored) { }
                analyzingFrame.set(false);
            });
    }

    private void hintOtherBarcode() {
        long now = System.currentTimeMillis();
        if (now - lastHintAtMs < 1800 || finished) return;
        lastHintAtMs = now;
        runOnUiThread(() -> {
            if (!finished) setStatus("Đã thấy mã khác. Hãy căn mã vận đơn GHN/J&T vào khung xanh.", Color.rgb(146, 64, 14));
        });
    }

    private void focusAt(float x, float y) {
        if (camera == null || previewView == null || previewView.getWidth() <= 0 || previewView.getHeight() <= 0) return;
        try {
            MeteringPoint point = previewView.getMeteringPointFactory().createPoint(x, y);
            FocusMeteringAction action = new FocusMeteringAction.Builder(point,
                FocusMeteringAction.FLAG_AF | FocusMeteringAction.FLAG_AE)
                .setAutoCancelDuration(3, TimeUnit.SECONDS).build();
            camera.getCameraControl().startFocusAndMetering(action);
        } catch (Exception e) {
            android.util.Log.d("ShippingBarcode", "Tap focus unavailable", e);
        }
    }

    private void toggleTorch() {
        if (camera == null || !camera.getCameraInfo().hasFlashUnit()) {
            setStatus("Camera này không có đèn pin. Hãy tăng ánh sáng môi trường.", Color.rgb(146, 64, 14));
            return;
        }
        torchEnabled = !torchEnabled;
        camera.getCameraControl().enableTorch(torchEnabled).addListener(() -> runOnUiThread(() -> {
            torchButton.setText(torchEnabled ? "🔦 TẮT ĐÈN" : "🔦 BẬT ĐÈN");
            torchButton.setBackground(roundBackground(torchEnabled ? Color.rgb(180, 83, 9) : Color.rgb(21, 101, 52), Color.TRANSPARENT));
        }), ContextCompat.getMainExecutor(this));
    }

    private void adjustZoom(boolean zoomIn) {
        if (camera == null) return;
        try {
            androidx.camera.core.ZoomState state = camera.getCameraInfo().getZoomState().getValue();
            if (state == null) return;
            float current = state.getZoomRatio();
            float desired = zoomIn ? current * 1.35f : current / 1.35f;
            desired = Math.max(state.getMinZoomRatio(), Math.min(state.getMaxZoomRatio(), desired));
            camera.getCameraControl().setZoomRatio(desired).addListener(this::updateZoomLabel, ContextCompat.getMainExecutor(this));
            zoomView.setText(String.format(Locale.ROOT, "%.1f×", desired));
        } catch (Exception e) {
            setStatus("Không thể thay đổi mức zoom trên camera này.", Color.rgb(146, 64, 14));
        }
    }

    private void updateZoomLabel() {
        if (camera == null || zoomView == null) return;
        androidx.camera.core.ZoomState state = camera.getCameraInfo().getZoomState().getValue();
        if (state != null) zoomView.setText(String.format(Locale.ROOT, "%.1f×", state.getZoomRatio()));
    }

    private void submitManualCode() {
        String value = normalize(manualInput == null ? "" : manualInput.getText().toString());
        if (!isSupportedTracking(value)) {
            setStatus("Mã không đúng định dạng GHN/J&T đã hỗ trợ. Kiểm tra lại ký tự và thử quét camera.", Color.rgb(185, 28, 28));
            return;
        }
        finishWithCode(value);
    }

    private void finishWithCode(String value) {
        if (finished) return;
        String tracking = normalize(value);
        if (!isSupportedTracking(tracking)) return;
        finished = true;
        Intent result = new Intent();
        result.putExtra(EXTRA_RAW_VALUE, tracking);
        setResult(RESULT_OK, result);
        finish();
    }

    private void finishCancelled() {
        if (finished) return;
        finished = true;
        setResult(RESULT_CANCELED, new Intent());
        finish();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != CAMERA_PERMISSION_REQ) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            Intent result = new Intent();
            result.putExtra(EXTRA_ERROR, "Bạn chưa cấp quyền camera nên không thể quét mã. Hãy cấp quyền Camera cho ROLL CÂY CẢNH trong Cài đặt Android.");
            setResult(RESULT_CANCELED, result);
            finished = true;
            finish();
        }
    }

    @Override protected void onDestroy() {
        try { if (cameraProvider != null) cameraProvider.unbindAll(); } catch (Exception ignored) { }
        try { if (barcodeScanner != null) barcodeScanner.close(); } catch (Exception ignored) { }
        try { cameraExecutor.shutdown(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    private void setStatus(String text, int color) {
        runOnUiThread(() -> {
            if (statusView == null || finished) return;
            statusView.setText(text);
            statusView.setTextColor(color);
        });
    }

    private boolean isSupportedTracking(String value) {
        return GHN_VNGH.matcher(value).matches() || GHN_GHVN.matcher(value).matches()
            || JT_EXPRESS.matcher(value).matches() || JT_CARGO.matcher(value).matches();
    }

    private String normalize(String value) {
        return value == null ? "" : value.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
    }

    private String safeMessage(Exception e) {
        return e == null || e.getMessage() == null || e.getMessage().trim().isEmpty()
            ? (e == null ? "lỗi chưa rõ" : e.getClass().getSimpleName()) : e.getMessage();
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button button(String label, int color) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(13);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setPadding(dp(5), 0, dp(5), 0);
        button.setBackground(roundBackground(color, Color.TRANSPARENT));
        return button;
    }

    private GradientDrawable roundBackground(int color, int strokeColor) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(10));
        if (strokeColor != Color.TRANSPARENT) shape.setStroke(dp(1), strokeColor);
        return shape;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private final class ScanTargetOverlay extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ScanTargetOverlay(android.content.Context context) { super(context); setClickable(false); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float width = getWidth();
            float height = getHeight();
            float boxWidth = width * 0.86f;
            float boxHeight = Math.max(dp(88), Math.min(dp(136), height * 0.19f));
            float left = (width - boxWidth) / 2f;
            float top = (height - boxHeight) / 2f;
            RectF rect = new RectF(left, top, left + boxWidth, top + boxHeight);
            paint.setColor(Color.rgb(34, 197, 94));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(3));
            canvas.drawRoundRect(rect, dp(10), dp(10), paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setTextSize(dp(12));
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setColor(Color.WHITE);
            canvas.drawText("MÃ VẬN ĐƠN", left + dp(8), Math.max(dp(18), top - dp(10)), paint);
        }
    }
}
