# V26.2.30 — Faster shipping barcode scan

This source replaces the old Google Code Scanner modal with a native CameraX + bundled ML Kit scanner, with torch, zoom, touch-to-focus and manual tracking-code fallback.

Build through the repository's existing GitHub Actions workflow. The source has automated/preflight checks, but no Android APK build or physical-device scan benchmark was performed in this environment.
