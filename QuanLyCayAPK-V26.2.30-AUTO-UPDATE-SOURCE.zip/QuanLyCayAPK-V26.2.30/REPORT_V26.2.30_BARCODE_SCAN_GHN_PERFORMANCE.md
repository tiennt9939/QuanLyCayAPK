# V26.2.30 — GHN / J&T barcode scanning performance update

## Reported problem

On V26.2.29, staff reported that GHN tracking barcodes were slow or would not scan reliably. A source audit showed that the app opened the Google Code Scanner UI through `play-services-code-scanner:16.1.0`, configured for linear formats, but had no app-level controls for torch, zoom, tap-to-focus, or a persistent camera preview. The manifest also requested the `barcode_ui` module.

This audit cannot prove which device-specific factor caused the delay. The implementation below makes camera behavior controllable and avoids relying on a dynamically provisioned scanner UI.

## Changes

- Version `26.2.30`, `versionCode 82`.
- Replaced the Google Code Scanner modal with a dedicated Android `ShippingBarcodeScannerActivity` using CameraX and bundled ML Kit Barcode Scanning (`com.google.mlkit:barcode-scanning:17.3.0`).
- Configured shipping linear formats: Code 128, Code 39, Code 93, ITF and Codabar. QR codes are intentionally not enabled, so the TikTok promotional QR should not win a scan.
- Uses 1280×720 analysis frames and `STRATEGY_KEEP_ONLY_LATEST` to avoid creating an unbounded frame backlog.
- Adds continuous camera preview, touch-to-focus, zoom controls, torch control and manual tracking-code entry as a fallback.
- Accepts recognized tracking patterns currently used by the app for GHN (`VNGH…`, `GHVN…`), J&T Express (`862…`) and J&T Cargo (`530…`). Accepted code values are normalized before being returned to the existing JavaScript flow.
- Preserves the existing Firebase direct lookup, assigned-user/shared-pool checks, scanned-order match validation, duplicate-tracking protections, photo-to-Drive flow, payroll and inventory logic.
- Adds `CAMERA` runtime permission and a non-exported portrait scanner activity. Camera hardware is declared optional so devices can still install the app if they do not have a camera.
- Removes the old `play-services-code-scanner` dependency and `barcode_ui` module declaration. ML Kit's bundled model avoids having to wait for the barcode model to be dynamically downloaded the first time it is used.

## Checks performed

- `tools/preflight.py`: PASS.
- JavaScript regression tests: 35/35 PASS, including existing TikTok PDF → barcode → Firebase order verification tests and the new scanner contract test.
- JavaScript syntax checks: six inline `index.html` blocks plus `tiktok-label-import.js`: PASS.
- Android Manifest XML parse: PASS.
- ZIP integrity: checked after packaging.
- Java source was checked for parse/syntax-oriented diagnostics with `javac`; this environment has no Android SDK/classpath, so this is not an Android compilation.

## Limitations

- No Gradle Android build was run in this environment because Gradle/Android SDK are not installed here.
- No physical-device GHN barcode timing/accuracy benchmark has been performed. Device autofocus, print quality, light, camera lens and barcode size can still affect scan time.
- APK generation and on-device validation must be done through the repository's current GitHub Actions build workflow. Test on a real GHN label and also retain the manual-entry fallback if a label is damaged or low contrast.

## Source

`QuanLyCayAPK-V26.2.30-AUTO-UPDATE-SOURCE.zip`
