'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const preflight = fs.readFileSync(path.join(root, 'tools/preflight.py'), 'utf8');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/build-apk.yml'), 'utf8');

assert(gradle.includes('versionName = "26.2.106"') && gradle.includes('versionCode = 158'), 'V26.2.106 / code 158 metadata missing');
assert(preflight.includes('versionName = "26.2.106"') && preflight.includes('versionCode = 158'), 'preflight must enforce V26.2.106');
assert(workflow.includes('V26.2.106') && workflow.includes('*AUTO-UPDATE-SOURCE.zip'), 'auto-build workflow must continue watching source ZIP');
assert(html.includes('sourceProducts:dailyShipmentProductReportSnapshot(row)'), 'new scan report must persist product/SKU and mapped-plant evidence snapshot');
assert(html.includes('class="order-accordion report-employee-accordion"') && html.includes('ontoggle="renderReportEmployeeCounters(this)"'), 'employee names must open a lazy employee-specific counter list');
assert(html.includes('function renderReportEmployeeCounters(details)') && html.includes('function renderReportEmployeeSkuGroupOrders(details)'), 'employee reports must drill down via plant/SKU counters before listing orders');
assert(html.includes('Bộ đếm đơn hàng theo cây/kích thước') && html.includes('renderReportPlantGroup(this)'), 'plant breakdown must now be an interactive order counter');
assert(html.includes('Sản lượng ghi tay theo cây/kích thước'), 'manual daily quantities must remain separate from order-specific counts');

// Exercise the exact scan-time SKU-to-catalog snapshot helper.
const snapshotStart = html.indexOf('function dailyShipmentProductReportSnapshot(row){');
const snapshotEnd = html.indexOf('\nfunction dailyShipmentReadiness(row){', snapshotStart);
assert(snapshotStart >= 0 && snapshotEnd > snapshotStart, 'scan-time source product snapshot helper is missing');
let currentPdfLabel = null;
const snapshotContext = {
  Array, String, Number, Math,
  dailyShipmentLabelByTracking: () => currentPdfLabel,
  tiktokProductMappingLines: key => key === 'rose-sku' ? [{ catalogKey: 'cam-tu-mai-c7', perUnit: 2 }] : [],
  findCatalogByKey: key => key === 'cam-tu-mai-c7' ? { p: { name: 'Cẩm tú mai', size: 'C7', deleted: false } } : null,
};
vm.runInNewContext(html.slice(snapshotStart, snapshotEnd), snapshotContext, { filename: 'report-sku-snapshot.js' });
currentPdfLabel = { trackingNo: '862652114050', products: [{ productName: 'Cam Tu Mai Combo', rawProductName: 'Cam Tu Mai Combo', sku: 'SKU-C7-02', sellerSku: 'SELLER-CAM7', qty: 3, mapKey: 'rose-sku' }] };
const snapshot = snapshotContext.dailyShipmentProductReportSnapshot({ trackingNo: '862652114050', products: [{ productName: 'queue copy with no mapping key', sku: 'SKU-C7-02', qty: 3 }] });
assert.strictEqual(snapshot.length, 1);
assert.strictEqual(snapshot[0].sku, 'SKU-C7-02');
assert.strictEqual(snapshot[0].sellerSku, 'SELLER-CAM7');
assert.strictEqual(snapshot[0].soldQty, 3);
assert.strictEqual(snapshot[0].mappedPlants[0].plantName, 'Cẩm tú mai');
assert.strictEqual(snapshot[0].mappedPlants[0].qty, 6, 'recorded map snapshot should preserve per-sold-unit conversion');
currentPdfLabel = null;
const overrideSnapshot = snapshotContext.dailyShipmentProductReportSnapshot({
  manualPlantCompositionOverride: { adminConfirmed: true },
  products: [{ productName: 'Order-level override', sku: 'SKU-ORDER', qty: 1, mapKey: 'rose-sku' }],
});
assert.strictEqual(overrideSnapshot[0].mappedPlants.length, 0, 'order-level override must not falsely assign one SKU to a tree line');
assert.strictEqual(overrideSnapshot[0].compositionSharedAcrossOrder, true, 'report must distinguish whole-order composition override from an old missing snapshot');

// Exercise the same report detail renderer used by clickable employee rows.
const helperStart = html.indexOf('function reportOrderTrackingNo(row){');
const helperEnd = html.indexOf('\nfunction renderReport(){', helperStart);
assert(helperStart >= 0 && helperEnd > helperStart, 'employee order detail rendering helpers are missing');
const reportContext = {
  Array, String, Number, Math,
  normalizeTracking: value => String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, ''),
  completedOrderDate: row => row.date || '',
  orderItems: row => (row.items || []).map((x, i) => ({ ...x, itemIndex: i, plantIndex: Number(x.plantIndex), qty: Number(x.qty) || 0 })),
  D: { catalog: [{ name: 'Cẩm tú mai', size: 'C7' }] },
  dailyShipmentQueueRowQuality: row => (row.products || []).length * 10,
  D_dailyUnused: {},
  D: { catalog: [{ name: 'Cẩm tú mai', size: 'C7' }], dailyShipmentOrders: [] },
  tiktokLabelQueue: [],
  money: n => `${Number(n) || 0} đ`,
  esc: v => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;'),
  fmtDMY: v => String(v || ''),
  packerPay: () => 12000,
};
vm.runInNewContext(html.slice(helperStart, helperEnd), reportContext, { filename: 'report-employee-order-details.js' });
const detail = reportContext.reportCompletedOrderDetailHtml({
  id: 'daily_862652114050', trackingNo: '862652114050', orderId: 'TIKTOK-ORDER-99', date: '2026-10-22', employee: 'Luân nhỏ',
  sourceProducts: [{ productName: 'Nguyệt quế Thái 15–20cm', sku: 'SKU-NQ-C7', sellerSku: 'SELLER-NQ', soldQty: 2, mappedPlants: [{ plantName: 'Nguyệt quế Thái', size: 'C7', qty: 2 }] }],
  items: [{ plantName: 'Nguyệt quế Thái', size: 'C7', plantIndex: 0, qty: 2 }],
});
assert(detail.includes('862652114050') && detail.includes('TIKTOK-ORDER-99'), 'order detail must show tracking and order ID');
assert(detail.includes('Nguyệt quế Thái 15–20cm') && detail.includes('SKU-NQ-C7') && detail.includes('SELLER-NQ'), 'source product name and SKU pair must be shown together');
assert(detail.includes('Cây ghép từ SKU này') && detail.includes('Nguyệt quế Thái C7 × 2 cây'), 'detail must show the mapped catalog tree associated with the SKU snapshot');
assert(detail.includes('Cây đã ghi nhận để tính công') && detail.includes('× 2 cây'), 'detail must independently show the canonical recorded tree quantity');

// Old reports without saved SKU snapshots should use available label evidence without recalculating
// historical mapping; their canonical recorded tree lines remain authoritative.
reportContext.D.dailyShipmentOrders = [{ trackingNo: '862602696370', products: [{ productName: 'Cây Táo Thái sân bóng', sku: 'TAO-C9-01', sellerSku: 'SELLER-TAO', qty: 1, mapKey: 'untrusted-old-map' }] }];
const legacyDetail = reportContext.reportCompletedOrderDetailHtml({
  id: 'daily_862602696370', trackingNo: '862602696370', date: '2026-10-22', items: [{ plantName: 'Táo Thái', size: 'C9', plantIndex: 0, qty: 1 }],
});
assert(legacyDetail.includes('TAO-C9-01') && legacyDetail.includes('Tên sản phẩm / SKU trên nhãn'), 'legacy orders should display available original SKU evidence');
assert(legacyDetail.includes('không tự ghép SKU theo quy tắc hiện tại') && legacyDetail.includes('Táo Thái'), 'legacy order details must not pretend current mapping is historical truth');
const overrideDetail = reportContext.reportCompletedOrderDetailHtml({ id: 'daily_862652114050', trackingNo: '862652114050', sourceProducts: [{ productName: 'Combo nhiều cây', sku: 'SKU-COMBO', soldQty: 1, compositionSharedAcrossOrder: true, mappedPlants: [] }], items: [{ plantName: 'Cẩm tú mai', size: 'C7', plantIndex: 0, qty: 2 }] });
assert(overrideDetail.includes('Admin đã chốt thành phần cây chung cho toàn đơn') && !overrideDetail.includes('Cây ghép từ SKU này'), 'whole-order override must be transparent and must not create a false SKU-to-plant link');
console.log('V26.2.106 REPORT EMPLOYEE ORDER/SKU DETAILS TEST PASS');
