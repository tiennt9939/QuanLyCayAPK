const assert = require('assert');
const parser = require('../app/src/main/assets/tiktok-label-import.js');
const page = (text, pageNo = 1) => ({ page: pageNo, text });
const jntC7 = `862596581425\nNgười gửi Roll Cây Cảnh\nOrder ID: 586534686489019809\nProduct Name                                      SKU                Seller SKU                    Qty\nNguyệt quế thái siêu hoa thơm                       1 chậu C7          1000                           1\ncao 15-\n20cm\nQty Total: 1`;
const ghnC7 = `VNGH80315470213\nNgười gửi Roll Cây Cảnh\nOrder ID: 586534641275012442\nProduct Name                                      SKU                Seller SKU                    Qty\nNguyệt quế thái siêu hoa thơm                       1 chậu C7          1000                           1\ncao 15-\n20cm\nQty Total: 1`;
const combo = `862570541435\nOrder ID: 586534361301026308\nProduct Name                                      SKU                Seller SKU                    Qty\nCombo 5 cây cẩm tú mai thái C6,                    Combo 5                                          2\nC7- Cây ngoại thất, trang trí vườn,\nhoa màu độc đáo, rực rỡ\nQty Total: 2`;
let rows = parser.parsePages([page(jntC7,1), page(ghnC7,2), page(combo,3)]);
assert.strictEqual(rows.length, 3);
assert(rows.every(x => x.status === 'ready'), JSON.stringify(rows));
assert.strictEqual(rows[0].trackingNo, '862596581425');
assert.strictEqual(rows[0].carrier, 'J&T Express');
assert.strictEqual(rows[0].orderId, '586534686489019809');
assert.strictEqual(rows[0].products[0].qty, 1);
assert(rows[0].products[0].sku.includes('C7'));
assert.strictEqual(rows[1].trackingNo, 'VNGH80315470213');
assert.strictEqual(rows[1].carrier, 'GHN');
assert.strictEqual(rows[2].trackingNo, '862570541435');
assert.strictEqual(rows[2].products[0].qty, 2, 'Qty must remain sale units; combo conversion is Admin-mapped explicitly');
assert.strictEqual(parser.expectedPlantsPerSoldUnit(rows[2].products[0]), 5, 'Combo size in the product label should be used only as a mapping validation guard');
assert.strictEqual(parser.expectedPlantsPerSoldUnit({productName:'Combo 2 chậu Vàng Bạc'}), 2);
assert.strictEqual(parser.carrierFor('530123456789'), 'J&T Cargo');
assert.strictEqual(parser.extractTracking('VNGH 80315470213')[0], 'VNGH80315470213', 'PDF extraction spaces must not break GHN tracking');
assert.strictEqual(parser.extractTracking('862 519 321 425')[0], '862519321425', 'PDF extraction spaces must not break J&T tracking');
const duplicate = parser.parsePages([page(jntC7,1), page(jntC7,2)]);
assert(duplicate.every(x => x.status === 'needs_review' && x.reviewReason.includes('trùng')));
const invalid = parser.parsePage(page('No track number here\nNo Order ID\nNo product table'));
assert.strictEqual(invalid.status, 'needs_review');

// Regression: PDF generators may place the Qty value a few columns before the Qty header.
const shiftedQty = `862596581425\nOrder ID: 586534686489019809\nProduct Name                                      SKU                Seller SKU                    Qty\nNguyệt quế thái siêu hoa thơm                       1 chậu C7          1000                           1\nQty Total: 1`;
const shiftedRow = parser.parsePage(page(shiftedQty, 4));
assert.strictEqual(shiftedRow.status, 'ready', 'Shifted quantity position must not drop the product row');
assert(shiftedRow.products[0].sku.includes('C7'), 'SKU/size must stay in the SKU column when Qty shifts');
// Regression: use the alternate native extraction if it contains a complete table and the primary does not.
const alternate = parser.parsePage({page:5,text:'862570541435\nOrder ID: 586534361301026308\nProduct Name\nSeller SKU\nQty Total: 2',fallbackText:combo});
assert.strictEqual(alternate.status, 'ready', 'Alternate PDF text extraction should rescue a readable label');
assert.strictEqual(alternate.products[0].qty, 2);

console.log('TIKTOK LABEL PARSER TEST PASS');
