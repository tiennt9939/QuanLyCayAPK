# ROLL CÂY CẢNH V26.2.128 — isolate PDF assignment from full-app sync

- Android `versionName`: `26.2.128`; `versionCode`: `180`.
- Based on V26.2.127; preserves the existing data model, Firestore collections, payroll, inventory and plant-recognition logic.

## Changes
- Defers background full-app sync while a newly imported PDF batch is pending or assignment is running, avoiding simultaneous reads/writes of the full historical queue during assignment.
- The targeted PDF batch remains marked pending until every assignment chunk is confirmed. A timeout keeps the current-batch marker and dirty flags for a safe retry; it does not silently claim the operation succeeded.
- Successful completion releases the pending batch marker only after all chunks are confirmed.
- Full-app dirty state is not cleared when unrelated edits existed before the PDF import.
- Keeps targeted per-tracking assignment transactions and idempotency guards from V26.2.127.

## Verification limitations
Automated tests and static checks can validate source behavior, but do not establish live Firebase latency, Firestore Rules correctness, Android APK signing continuity, Google Drive availability, or real-device performance. Build with the repository workflow and test on a device before treating this as production-verified.

## In-app updater release prerequisites
- Configure GitHub Actions secrets `DEBUG_KEYSTORE_BASE64` and `EXPECTED_APK_CERT_SHA256` with the intended signing keystore and the exact SHA-256 certificate fingerprint.
- The source ZIP triggers the repository workflow only after it is committed to the repository root. This file has not been uploaded to GitHub by this local packaging step.
- Verify the generated APK, certificate fingerprint, and real-device Firebase assignment before production use.
