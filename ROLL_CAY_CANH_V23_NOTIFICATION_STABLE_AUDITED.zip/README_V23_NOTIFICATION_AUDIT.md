ROLL CAY CANH V23 - AUDIT / NOTIFICATION SESSION FIX

This package is based directly on the user-supplied:
ROLL_CAY_CANH_V23_NOTIFICATION_CLICK_FIXED.zip

Scope of this repair:
- Preserve the existing catalog, employees, rates, inventory, packing assignment, packer completion,
  labor adjustment, admin UI, login flow, and Firebase data model.
- Repair the order-notification click path so it never treats a transient Firebase/WebView auth
  restoration state as a logout.
- Pass the click Event explicitly instead of relying on the global `event` object in Android WebView.
- Add a short auth-session wait before notification actions.
- Expose Firebase's currentUser for reliable session detection.
- Use Firebase LOCAL auth persistence so an Android/WebView Activity/process restart does not
  unnecessarily return the user to the login gate.

Static checks performed before packaging:
- JavaScript extracted from index.html: Node.js syntax check PASSED.
- Canonical employees: 6.
- Canonical labor rates: 6.
- Canonical catalog: 99 rows.
- Required previously repaired functions are present.
- Notification functions no longer call showLoginGate() on a transient missing in-memory session.
- Both Firebase persistence calls use LOCAL.
- Android project structure and Gradle configuration inspected.
- Firestore rules were NOT changed in this repair, because the user reported the existing
  assignment/packing flow was already working.

Important test limitation:
- This environment cannot run the actual Android APK on the user's physical phone, so real-device
  click behavior cannot be claimed as physically verified here. The source was statically checked
  and the notification/auth path was repaired from the supplied source.
