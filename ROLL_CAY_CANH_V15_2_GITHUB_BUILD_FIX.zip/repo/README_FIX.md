ROLL CAY CANH – GitHub build fix

Upload/replace QuanLyCayAPK_project.zip and .github/workflows/build-apk.yml in the GitHub repository.
The Firebase Web configuration is already included inside the project at:
app/src/main/assets/firebase-config.js

The workflow now builds by cd into the detected absolute project directory instead of using a dynamic working-directory.
