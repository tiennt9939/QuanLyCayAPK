# ROLL CÂY CẢNH V26.2.144 — GAS read-lock contention fix

- Android versionName: `26.2.144`; versionCode: `197`.
- Preserves the V26.2.144 safe stale-PDF cleanup and all existing app business logic.
- Fixes GAS `ScriptLock` contention: read-only `listUsers`, `get`, `query`, `multiQuery`, and `getMany` no longer acquire the global script lock.
- Write commits remain serialized with `LockService.getScriptLock()` and retain preconditions, idempotency, authorization, and release in `finally`.
- No Firestore/Sheets data is deleted or migrated by this source change.

The screenshot diagnostics showed GAS phase3.2/cutover/writes active, while the order list and PDF queue timed out after 12 seconds. The previous server-side 10-second read locks caused these read requests to queue behind long writes/compaction. This release removes that unnecessary read-side lock while preserving serialized writes.

Deployment requirement: update the existing Apps Script Web App deployment with the `Code.gs` included in this source, preserving its current URL and Script Properties. Do not create a new deployment or run migration/cutover again.
