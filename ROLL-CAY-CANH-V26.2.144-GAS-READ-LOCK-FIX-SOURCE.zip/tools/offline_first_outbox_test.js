'use strict';
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const java = fs.readFileSync(path.join(root, 'app/src/main/java/com/quanlycay/apk/MainActivity.java'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');

assert(/versionName\s*=\s*"26\.2\.144"/.test(gradle) && /versionCode\s*=\s*196/.test(gradle), 'offline-first version must be 26.2.144 / 197');
for (const method of ['loadOfflineJsonStore','saveOfflineJsonStore','putOfflineJsonRecord','listOfflineJsonRecords','removeOfflineJsonRecord']) {
  assert(java.includes(` ${method}(`), `Android must expose durable offline queue method ${method}`);
}
assert(java.includes('getFilesDir()') && java.includes('roll-offline-queues'), 'offline JSON stores must live in app-private persistent storage');
assert(java.includes('writeSynced(tmp, json.getBytes(StandardCharsets.UTF_8))') && java.includes('replaceFile(tmp, target)'), 'offline JSON records must use fsynced atomic replacement');
assert(html.includes("const TIKTOK_LABEL_QUEUE_NATIVE_STORE='tiktok-label-queue-v1'"), 'PDF staging labels must have a native durable store');
assert(html.includes("const DAILY_SHIPMENT_OUTBOX_NATIVE_STORE='daily-shipment-outbox-v1'"), 'daily shipment reports must have a separate durable outbox');
assert(html.includes('function dailyShipmentOfflineOutboxSave(entry){') && html.includes("'T_'+tracking"), 'each offline report must be independently and durably stored by tracking number');
assert(html.includes('operationId:\'daily_\'+tracking+\'_\'+scannedAtMs'), 'offline retry needs a stable operation ID');
assert(html.includes('if(!navigator.onLine){await dailyShipmentQueueOfflineCapturedReport(offlineEntry'), 'offline capture must persist locally without waiting for Firebase');
assert(html.includes('dailyShipmentAwaitWithTimeout(refreshDailyShipmentCloudScanRecords(date,date,true),6000'), 'scan setup must fall back quickly if cloud refresh hangs');
assert(html.includes("st.checkDailyShipmentClaims(candidates.map(x=>x.tracking)),6000"), 'cloud duplicate pre-check must not block scanning for a long time');
assert(html.includes('function dailyShipmentLooksLikeConnectivityFailure(error)') && html.includes('quá \\d+ giây chờ'), 'connectivity timeouts must safely queue rather than discard scan state');
assert(html.includes("entry.status='report_committed'"), 'sync must persist server-confirmed report before uploading the photo');
assert(html.includes("String(serverReport.operationId||'')!==String(entry.report.operationId||'')"), 'retry must reject a different pre-existing report to avoid duplicate wages');
assert(html.includes("if(!String(entry.driveRef||'').startsWith('drive://'))") && html.includes('dailyShipmentReadOfflinePhoto(entry.path)'), 'photo data must be reloaded from native storage and uploaded separately');
assert(html.includes('st.attachDailyShipmentPhoto(entry.trackingNo,entry.driveRef)'), 'uploaded photo must be attached to the canonical Firestore report');
assert(html.indexOf('st.attachDailyShipmentPhoto(entry.trackingNo,entry.driveRef)') < html.indexOf('bridge.ackDailyShipmentPhoto(entry.path)'), 'photo may only be acknowledged locally after Firebase confirms attachment');
assert(html.includes("window.addEventListener('online'" ) && html.includes("document.addEventListener('visibilitychange'"), 'offline outbox must resume on reconnect and foreground');
assert(html.includes('Chưa được tính vào tiền công/tồn kho') || html.includes('Tiền công/tồn kho chỉ được tính sau khi Firebase xác nhận'), 'UI must distinguish locally queued work from confirmed wages/inventory');
console.log('OFFLINE-FIRST OUTBOX REGRESSION TEST PASS: native durable queue, PDF staging persistence, bounded cloud waits, idempotent retry and separately acknowledged Drive photos');
