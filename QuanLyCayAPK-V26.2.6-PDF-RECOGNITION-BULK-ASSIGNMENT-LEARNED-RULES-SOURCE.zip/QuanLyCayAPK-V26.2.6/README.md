# QuanLyCayAPK — V26.2.6 PDF recognition rules + bulk assignment

This release carries forward the V26.2.3 coordinate-based PDF extraction fix and adds catalog-aware product matching plus its regression tests. It does not change the existing wage/inventory/account business logic.

## Build identity
- `versionName`: `26.2.6`
- `versionCode`: `58`
- Android package: `com.quanlycay.apk`
- Build: GitHub Actions manual workflow `.github/workflows/build-apk.yml`

## Root cause and fix
The supplied 12-page TikTok Shop PDF uses visually aligned product table columns. PDFBox's ordinary text stream can interleave table column labels/values with other content, while the previous JavaScript fallback assumed contiguous blocks. That is why the app found tracking numbers and Order IDs but dropped plant/SKU/Qty. This release keeps native coordinate-based text reconstruction, selects the best of three extraction variants, then matches each product to the current app catalog. Product Name text after a dash is ignored; Combo N is plants per sale unit and Qty counts sale units. Unique name/size matches are auto-filled; unresolved ambiguity remains for Admin review except the explicit Combo 5 Cẩm tú mai C6/C7 → Cẩm tú mai C7 rule. If Admin manually confirms another valid mapping, that recognition rule is saved locally and reused for subsequent labels with the same normalized identity, Combo count and explicit size set.

## Safety boundary
The change does not edit Firestore data, Firestore Rules behavior, database schema, catalog or catalog prices, user accounts/permissions, wage formula, inventory calculations, image/Drive storage, or order completion. PDF import still stages labels only; an Admin confirms or corrects the catalog map and explicitly creates/assigns orders. The app never invents catalog entries or changes inventory just because a PDF was read.

## Verification performed
- `python3 tools/preflight.py`
- Every `tools/*_test.js` test, including `tiktok_pdf_real_layout_regression_test.js`
- JavaScript syntax checks for all inline blocks and `tiktok-label-import.js`
- Sanitized product table fragments from all 12 supplied PDF pages: 12/12 parsed with a product and positive Qty.

## Device validation still required
The Java coordinate extractor has not been compiled in GitHub Actions or exercised on a physical Android device from this environment. Run the included manual build workflow and install/test the resulting APK with the original PDF before using it for live assignments. If Gradle compilation fails, do not install the APK; inspect the workflow diagnostics first.

## GitHub mobile workflow
1. Upload `QuanLyCayAPK-V26.2.6-PDF-RECOGNITION-BULK-ASSIGNMENT-LEARNED-RULES-SOURCE.zip` to the repository root (the ZIP must be uploaded to GitHub; a file kept only on the phone is not visible to Actions).
2. Add the standalone workflow file at `.github/workflows/build-apk.yml` or replace the existing canonical workflow content with the supplied V26.2.6 workflow.
3. Open Actions, choose **Build ROLL CAY CANH V26.2.6 — PDF Recognition Rules + Bulk Assignment**, tap **Run workflow**, and keep the source_zip input at the default file name.
4. Only install the APK when the workflow completes successfully and the artifact exists.


## PDF catalog matching behavior
- Plant-name token matching ignores marketing text after a dash, while size detection still checks the complete Product Name, SKU and Seller SKU so a C9 after a dash is not discarded.
- Combo N is N plants per sold unit, and PDF Qty is the number of combos. The app computes N × Qty.
- Each imported plant must resolve to a row from the currently loaded app catalog. A unique name/size match is prefilled. Ambiguous/missing size choices remain for Admin review; no catalog row is fabricated and no order is created until Admin assigns it.
- `tools/tiktok_catalog_matcher_test.js` validates catalog matching against `app/src/main/assets/data.json`, including the agreed Combo 5 Cẩm tú mai C6/C7 → existing C7 catalog row behavior and Qty 2 → 10 plants.

## Confirmed and learned recognition rules
- `Combo 5 cây cẩm tú mai thái C6, Combo 5 C7` maps to the existing Cẩm tú mai C7 catalog row; Qty 2 means 10 plants.
- When Admin fixes a different ambiguous mapping, the app persists a normalized recognition rule locally for future equivalent labels. A C9 or different Combo/name signature will not inherit the rule.
- Rules are device-local (localStorage), not synced to other Admin devices.
