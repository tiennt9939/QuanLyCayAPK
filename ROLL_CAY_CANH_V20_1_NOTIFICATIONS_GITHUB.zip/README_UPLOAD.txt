ROLL CÂY CẢNH V20.1 – GÓI GITHUB

1. Upload/replace file QuanLyCayAPK_project.zip ở thư mục gốc repository GitHub.
2. Vào Actions và chạy workflow Build QuanLyCayAPK.
3. Sau khi build xong, tải artifact APK.
4. Firestore Rules: giữ nguyên Rules V20 hiện tại (gói này không thay đổi quyền Firestore).

V20.1 bổ sung:
- Chuông thông báo + badge đỏ số đơn chưa hoàn tất.
- Cảnh báo hình ảnh + âm thanh + rung khi số đơn chờ tăng hoặc khi mở app đang có đơn chờ (khi app đang mở).
- Admin xem số đơn chưa hoàn tất và số đơn đã hoàn tất.
- Nhân viên vẫn chỉ nhận đơn được phân công và phải chụp ảnh mới hoàn thành.
