# V26.2.41 — Continuous scan latency optimization

- Base: V26.2.40, preserving Firestore schema and business logic.
- Version: 26.2.41 / versionCode 93.
- Main change: after Drive upload confirmation and the atomic Firestore order + tracking-claim transaction succeed, the continuous-scan path no longer waits for localStorage cache persistence or full order-list rendering before returning to the scanner. Cache persistence is deferred; order lists refresh when scanning stops.
- Scanner relaunch idle delay reduced from 250 ms to 70 ms; session/in-flight guards remain.
- Safety retained: Drive reference required before Firestore completion; Firestore transaction still checks order assignment/status and tracking claim atomically; no duplicate payroll/inventory mutation is added.
- Validation required on device: time scan result → Drive confirmed → Firestore completed → next camera ready. Network/Drive latency remains variable; no claim of a measured 8-second-to-X-second improvement without device timings.
