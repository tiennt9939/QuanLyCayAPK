ROLL CÂY CẢNH – V19

1) Upload QuanLyCayAPK_project.zip to the GitHub repository root.
2) Push/save the file.
3) Open Actions -> Build QuanLyCayAPK -> Run workflow.
4) Download the generated debug APK artifact.
5) IMPORTANT: publish the firestore.rules included in this project to Firebase Console -> Firestore Database -> Rules before testing assignment/completion.

V19 adds:
- Admin assignment of plant + size + packer.
- Combo packing size 2..100 trees/combo.
- Separate packingOrders documents assigned by UID.
- Packer sees only assigned orders and cannot enter quantity.
- Mandatory direct camera completion photo.
- Only completed orders count toward pay.
