const assert = require('assert');
const fs = require('fs');
const path = require('path');
const parser = require('../app/src/main/assets/tiktok-label-import.js');
const initial = JSON.parse(fs.readFileSync(path.join(__dirname, '../app/src/main/assets/data.json'), 'utf8'));
const catalog = initial.catalog.map((p, i) => ({ ...p, _index: i, _key: `catalog-row-${i}` }));
function match(product) { return parser.matchCatalogProduct(product, catalog); }

// Ordinary items: match against the app catalog using product name plus SKU size.
const nqC9 = match({ productName: 'Nguyệt quế thái siêu hoa thơm', sku: '1 chậu C9', sellerSku: '', qty: 1 });
assert.strictEqual(nqC9.matched, true, JSON.stringify(nqC9));
assert.strictEqual(nqC9.name, 'Nguyệt quế thái');
assert.strictEqual(nqC9.size, 'C9');
assert.strictEqual(nqC9.perUnit, 1);

const nqC7 = match({ productName: 'Nguyệt quế thái siêu hoa thơm', sku: '1 chậu C7', sellerSku: '1000', qty: 1 });
assert.strictEqual(nqC7.matched, true, JSON.stringify(nqC7));
assert.strictEqual(nqC7.size, 'C7');

// User's rule: ignore advertising text after '-', Combo N means N plants per sold unit,
// Qty is combo count, and the size must resolve to an actual existing catalog row.
const combo = match({
  productName: 'Combo 5 cây cẩm tú mai thái C6, C7- Cây ngoại thất, trang trí vườn, hoa màu độc đáo, rực rỡ',
  sku: 'Combo 5',
  sellerSku: 'cây cẩm tú mai C6',
  qty: 2
});
assert.strictEqual(combo.matched, true, JSON.stringify(combo));
assert.strictEqual(combo.name, 'Cẩm tú mai');
assert.strictEqual(combo.size, 'C7');
assert.strictEqual(combo.perUnit, 5);
assert.strictEqual(2 * combo.perUnit, 10, 'Qty 2 means 10 catalog plants, not two plants');
assert.strictEqual(parser.stripProductDescription('Combo 5 cây cẩm tú mai C6,C7- Cây ngoại thất'), 'Combo 5 cây cẩm tú mai C6,C7');

// An item without a size can have multiple catalog sizes. Do not guess the wrong size.
const noSizeCombo = match({ productName: 'Combo 2 chậu Vàng Bạc ( cây trang trí phong thuỷ sân vườn)', sku: 'Mặc định', sellerSku: '', qty: 1 });
assert.strictEqual(noSizeCombo.matched, false, 'A multi-size plant with no size must remain a manual catalog choice');
assert(noSizeCombo.candidates.length > 1);

// Names without a catalog match must never create a synthetic catalog plant.
const unknown = match({ productName: 'Combo 3 cây Lan lạ chưa có trong danh mục', sku: 'Combo 3', sellerSku: '', qty: 1 });
assert.strictEqual(unknown.matched, false);
assert(/Không tìm thấy/.test(unknown.reason));

console.log('TIKTOK CATALOG MATCHER TEST PASS: exact size, combo multiplier, description stripping, ambiguity guard');
