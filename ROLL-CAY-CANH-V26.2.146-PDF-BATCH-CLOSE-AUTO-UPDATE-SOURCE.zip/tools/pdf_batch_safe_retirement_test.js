'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const snapshotStart=html.indexOf('async function readOldPdfBatchRetirementSnapshot()');
const previewStart=html.indexOf('async function previewLegacyPdfBatchClose(){',snapshotStart);
const snapshot=html.slice(snapshotStart,previewStart);
assert(snapshotStart>=0&&previewStart>snapshotStart,'safe close must have a backend verification snapshot');
assert(snapshot.includes("localStorage.getItem('roll_pdf_queue_current_batch_v1')"),'must read exact local batch index');
assert(snapshot.includes('dailyShipmentOrdersRef().doc(t)'),'must verify every tracking document in canonical backend queue');
assert(snapshot.includes("String(row.date||'')!==date"),'backend record must match the original batch date');
assert(snapshot.includes('missing.length===0&&cloud.length===trackingNos.length'),'missing or mismatched backend rows must block close');

const previewStartInner=html.indexOf('async function previewLegacyPdfBatchClose(){',previewStart);
const executeStart=html.indexOf('async function executeLegacyPdfBatchClose(',previewStartInner);
const preview=html.slice(previewStartInner,executeStart);
assert(preview.includes('readOldPdfBatchRetirementSnapshot()'),'preview must use canonical backend verification');
assert(preview.includes('if(!snapshot.ok)'),'preview must fail closed if any label is missing');
assert(preview.includes('dailyShipmentWorkerRunning>0')&&preview.includes('dailyShipmentWorkQueue.length'),'preview must stop while photo workers/queue are active');

const nextFn=html.indexOf('async function previewLegacyIncompleteOrdersCleanup()',executeStart);
const execute=html.slice(executeStart,nextFn);
assert(execute.includes('readOldPdfBatchRetirementSnapshot()'),'execute must re-read backend immediately before cleanup');
assert(execute.includes('current.fingerprint!==expectedFingerprint'),'execute must reject changed state after preview');
assert(execute.includes("String(confirmationText||'').trim()!=='KET THUC LO PDF CU'"),'execute must require explicit confirmation');
const removed=[...execute.matchAll(/localStorage\.removeItem\('([^']+)'\)/g)].map(m=>m[1]).sort();
assert.deepStrictEqual(removed.sort(),['roll_pdf_queue_current_batch_v1','roll_pdf_queue_local_pending','roll_pdf_queue_only_import_dirty_before'].sort(),'only the three PDF batch markers may be removed');
assert(!/quanlycay_dirty.*removeItem|removeItem\(['"]quanlycay_dirty/.test(execute),'unrelated dirty flag must be preserved');
assert(!/dailyShipment(?:Orders|Reports|Scans)Ref\(\)\.doc\([^)]*\)\.(?:delete|set|update)/.test(execute),'safe close must not write or delete canonical business records');
assert(execute.includes("localStorage.setItem('roll_pdf_queue_synced','1')"),'close must mark the batch gate as released');
assert(execute.includes('if(dirtyPreserved)schedulePush()'),'unrelated dirty changes must be scheduled after gate release');

const gradle=fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8');
assert(/versionName\s*=\s*"26\.2\.146"/.test(gradle)&&/versionCode\s*=\s*198/.test(gradle),'release metadata must be V26.2.146/code198');
const wrapperStart=html.indexOf('async function previewLegacyPdfBatchClose(){',html.indexOf('async function previewLegacyPdfBatchClose(){')+1);
const wrapperEnd=html.indexOf('async function previewLegacyIncompleteOrdersCleanup(){',wrapperStart);
const wrapper=html.slice(wrapperStart,wrapperEnd);
assert(wrapper.includes('api.previewLegacyPdfBatchClose()')&&wrapper.includes('api.executeLegacyPdfBatchClose(preview.fingerprint'),'UI must call the guarded CloudSync methods');
console.log('SAFE PDF BATCH RETIREMENT PASS: exact backend verification, unchanged-state fingerprint, strict confirmation, local markers only, unrelated dirty state and business records preserved');
