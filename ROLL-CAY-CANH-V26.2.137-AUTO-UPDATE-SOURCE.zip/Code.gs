/**
 * ROLL CAY CANH - Google Apps Script migration foundation (Phase 1)
 * IMPORTANT: This is a staged backend scaffold, not yet wired into index.html.
 * Deploy as a Web App only after setting Script Properties and reviewing access.
 */
const ROLL = {
 VERSION: 'gas-firestore-compat-phase2.3.1-audit-fix',
  SHEETS: {
    records: ['recordId', 'entity', 'payloadJson', 'updatedAt', 'operationId'],
    operations: ['operationId', 'entity', 'recordId', 'resultJson', 'createdAt'],
    photos: ['photoId', 'driveFileId', 'fileName', 'mimeType', 'createdAt', 'deleteAfter']
  },
  MAX_BATCH: 100,
  MAX_PAYLOAD_CHARS: 45000
};
function auditBackendSchema() {
  const ss = ss_();

  const report = Object.keys(ROLL.SHEETS).map(function (name) {
    const expected = ROLL.SHEETS[name];
    const sh = ss.getSheetByName(name);

    if (!sh) {
      return {
        sheet: name,
        exists: false,
        ok: false
      };
    }

    const lastCol = sh.getLastColumn();
    const actual = lastCol > 0
      ? sh.getRange(1, 1, 1, lastCol)
          .getDisplayValues()[0]
          .map(function (value) {
            return String(value).trim();
          })
      : [];

    const actualExpectedWidth = actual.slice(0, expected.length);

    const missing = expected.filter(function (header) {
      return actual.indexOf(header) === -1;
    });

    const orderMatches =
      JSON.stringify(actualExpectedWidth) === JSON.stringify(expected);

    return {
      sheet: name,
      exists: true,
      dataRows: Math.max(0, sh.getLastRow() - 1),
      expectedHeaders: expected,
      actualHeaders: actual,
      missingHeaders: missing,
      orderMatches: orderMatches,
      ok: missing.length === 0 && orderMatches
    };
  });

  const result = {
    ok: report.every(function (item) {
      return item.ok === true;
    }),
    spreadsheet: ss.getName(),
    sheets: report
  };

  Logger.log(JSON.stringify(result));
  return result;
}
function doGet(e) {
  try {
    const p = (e && e.parameter) || {};
    // Public health check returns non-sensitive status only; all data actions still require the API token.
    if (p.action === 'health') return json_({ ok: true, version: ROLL.VERSION, now: new Date().toISOString() });
    authorize_(p.token);
    if (p.action === 'list') return json_(listRecords_(p.entity, p.updatedAfter || ''));
    if (p.action === 'get') return json_(getRecord_(p.entity, p.recordId));
    return json_({ ok: false, error: 'Unsupported GET action' });
  } catch (err) { return json_({ ok: false, error: safeMessage_(err) }); }
}function runPhotoMaintenanceOnce() {
  const props = PropertiesService.getScriptProperties();
  const ssId = props.getProperty('ROLL_SPREADSHEET_ID');

  if (!ssId) {
    throw new Error('Thiếu ROLL_SPREADSHEET_ID');
  }

  const ss = SpreadsheetApp.openById(ssId);
  const sh = ss.getSheetByName('photos');

  if (!sh) {
    throw new Error('Không tìm thấy sheet photos');
  }

  const lastRow = sh.getLastRow();
  const lastCol = sh.getLastColumn();

  let updated = 0;
  let skipped = 0;

  if (lastCol < 1) {
    throw new Error('Sheet photos chưa có tiêu đề cột');
  }

  const headers = sh.getRange(1, 1, 1, lastCol)
    .getDisplayValues()[0]
    .map(function (h) { return String(h).trim(); });

  const createdCol = headers.indexOf('createdAt');
  const expiryCol = headers.indexOf('deleteAfter');

  if (createdCol < 0 || expiryCol < 0) {
    throw new Error('Sheet photos thiếu cột createdAt hoặc deleteAfter');
  }

  if (lastRow >= 2) {
    const rows = sh.getRange(2, 1, lastRow - 1, lastCol).getValues();

    rows.forEach(function (row, index) {
      const rawCreated = row[createdCol];

      const createdMs = rawCreated instanceof Date
        ? rawCreated.getTime()
        : Date.parse(String(rawCreated || ''));

      if (!Number.isFinite(createdMs)) {
        skipped++;
        return;
      }

      const deleteAfter = new Date(createdMs + 60 * 24 * 60 * 60 * 1000);

      sh.getRange(index + 2, expiryCol + 1)
        .setValue(deleteAfter.toISOString());

      updated++;
    });
  }

  // Tạo trigger mới trước; chỉ xóa trigger cũ sau khi tạo thành công.
  const handler = 'deleteExpiredPhotos_';

  const newTrigger = ScriptApp.newTrigger(handler)
    .timeBased()
    .everyDays(1)
    .create();

  const newTriggerId = newTrigger.getUniqueId();

  ScriptApp.getProjectTriggers().forEach(function (trigger) {
    if (
      trigger.getHandlerFunction() === handler &&
      trigger.getUniqueId() !== newTriggerId
    ) {
      ScriptApp.deleteTrigger(trigger);
    }
  });

  const result = {
    ok: true,
    retentionDays: 60,
    updated: updated,
    skipped: skipped,
    triggerHandler: handler,
    schedule: 'daily'
  };

  Logger.log(JSON.stringify(result));
  return result;
}
function testBackendIdempotencyAndListGet() {
  const entity = 'backend_audit';
  const recordId = 'AUDIT_REC_' + Utilities.getUuid();
  const operationId = 'AUDIT_OP_' + Utilities.getUuid();
  const payload = {
    audit: 'ROLL_CAY_CANH',
    runId: Utilities.getUuid()
  };

  let result = { ok: false };
  let operationsCleaned = false;
  let recordCleaned = false;

  try {
    const operations = sheet_('operations');
    const before = operations.getLastRow();

    const request = {
      operationId: operationId,
      entity: entity,
      recordId: recordId,
      payload: payload
    };

    const first = applyOperation_(request);
    const afterFirst = operations.getLastRow();

    const second = applyOperation_(request);
    const afterSecond = operations.getLastRow();

    const read = getRecord_(entity, recordId);
    const cutoff = new Date(Date.now() - 5 * 60 * 1000).toISOString();
    const listed = listRecords_(entity, cutoff);

    const foundInList = listed.records.some(function (r) {
      return r.recordId === recordId &&
        r.operationId === operationId;
    });

    result = {
      ok:
        first.ok === true &&
        first.duplicate === false &&
        afterFirst === before + 1 &&
        second.duplicate === true &&
        afterSecond === afterFirst &&
        read.found === true &&
        read.record.payload.runId === payload.runId &&
        foundInList,
      firstWrite: first,
      secondWrite: second,
      operationsBefore: before,
      operationsAfterFirst: afterFirst,
      operationsAfterSecond: afterSecond,
      getFound: read.found,
      listFound: foundInList
    };
  } catch (err) {
    result = {
      ok: false,
      error: safeMessage_(err)
    };
  } finally {
    try {
      const operations = sheet_('operations');
      const row = findExact_(operations, 1, operationId);
      if (row) operations.deleteRow(row);
      operationsCleaned = true;
    } catch (err) {
      result.cleanupOperationsError = safeMessage_(err);
    }

    try {
      const records = sheet_('records');
      const row = findCompositeRecord_(records, entity, recordId);
      if (row) records.deleteRow(row);
      recordCleaned = true;
    } catch (err) {
      result.cleanupRecordError = safeMessage_(err);
    }
  }

  result.testDataCleaned = operationsCleaned && recordCleaned;
  if (!result.testDataCleaned) result.ok = false;

  Logger.log(JSON.stringify(result));
  return result;
}
function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    // Phase 2 route: Firebase ID token is validated by the compatibility handler.
    // Keep this BEFORE the legacy ROLL_API_TOKEN check; legacy endpoints remain unchanged.
    if (body && body.action === 'fsCompat') {
      const compatResult = handleFirestoreCompatRequest_(body);
      return ContentService.createTextOutput(JSON.stringify(compatResult))
        .setMimeType(ContentService.MimeType.JSON);
    }
    authorize_(body.token);
    const action = String(body.action || '');
    if (action === 'health') return json_({ ok: true, version: ROLL.VERSION, now: new Date().toISOString() });
    if (action === 'applyBatch') {
      const ops = Array.isArray(body.operations) ? body.operations : [];
      if (!ops.length || ops.length > ROLL.MAX_BATCH) throw new Error('Batch must contain 1-' + ROLL.MAX_BATCH + ' operations');
      lock.waitLock(20000);
      try { return json_({ ok: true, results: ops.map(applyOperation_) }); }
      finally { lock.releaseLock(); }
    }
    if (action === 'upsert') {
      lock.waitLock(20000);
      try { return json_(applyOperation_(body)); }
      finally { lock.releaseLock(); }
    }
    if (action === 'uploadPhoto') return json_(uploadPhoto_(body));
    if (action === 'deleteExpiredPhotos') return json_(deleteExpiredPhotos_());
    return json_({ ok: false, error: 'Unsupported POST action' });
  } catch (err) { try { if (lock.hasLock()) lock.releaseLock(); } catch (_) {} return json_({ ok: false, error: safeMessage_(err) }); }
}

function authorize_(provided) {
  const expected = PropertiesService.getScriptProperties().getProperty('ROLL_API_TOKEN');
  if (!expected || expected.length < 32) throw new Error('Server is not configured: set ROLL_API_TOKEN (at least 32 characters) in Script Properties');
  if (!provided || !constantTimeEquals_(String(provided), expected)) throw new Error('Unauthorized');
}
function constantTimeEquals_(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0; for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
function ss_() {
  const id = PropertiesService.getScriptProperties().getProperty('ROLL_SPREADSHEET_ID');
  if (!id) throw new Error('Set ROLL_SPREADSHEET_ID in Script Properties');
  return SpreadsheetApp.openById(id);
}
function sheet_(name) {
  const ss = ss_();
  let sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    const headers = ROLL.SHEETS[name];
    if (headers) sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    sh.setFrozenRows(1);
  }
  return sh;
}
function ensureSheets() { Object.keys(ROLL.SHEETS).forEach(sheet_); return { ok: true, sheets: Object.keys(ROLL.SHEETS) }; }
function applyOperation_(op) {
  const operationId = String(op.operationId || '').trim();
  const entity = validName_(op.entity, 'entity');
  const recordId = validName_(op.recordId, 'recordId');
  if (!operationId || operationId.length > 160) throw new Error('operationId is required (max 160 chars)');
  if (typeof op.payload === 'undefined') throw new Error('payload is required');
  const serialized = JSON.stringify(op.payload);
  if (serialized.length > ROLL.MAX_PAYLOAD_CHARS) throw new Error('Payload too large; split the operation');
  const ops = sheet_('operations');
  const existing = findExact_(ops, 1, operationId);
  if (existing) return { ok: true, duplicate: true, operationId: operationId, result: safeJson_(ops.getRange(existing, 4).getValue()) };
  const records = sheet_('records');
  const recordRow = findCompositeRecord_(records, entity, recordId);
  const now = new Date().toISOString();
  const row = [recordId, entity, serialized, now, operationId];
  if (recordRow) records.getRange(recordRow, 1, 1, row.length).setValues([row]);
  else records.appendRow(row);
  const result = { ok: true, duplicate: false, entity: entity, recordId: recordId, operationId: operationId, updatedAt: now };
  ops.appendRow([operationId, entity, recordId, JSON.stringify(result), now]);
  return result;
}
function listRecords_(entity, updatedAfter) {
  entity = validName_(entity, 'entity');
  const sh = sheet_('records'); const last = sh.getLastRow();
  if (last < 2) return { ok: true, entity: entity, records: [] };
  const rows = sh.getRange(2, 1, last - 1, 5).getValues();
  const cutoff = updatedAfter ? Date.parse(updatedAfter) : 0;
  const records = [];
  rows.forEach(r => {
    if (r[1] !== entity) return;
    if (cutoff && Date.parse(r[3]) <= cutoff) return;
    records.push({ recordId: String(r[0]), entity: String(r[1]), payload: safeJson_(r[2]), updatedAt: String(r[3]), operationId: String(r[4]) });
  });
  return { ok: true, entity: entity, records: records };
}
function getRecord_(entity, recordId) {
  entity = validName_(entity, 'entity'); recordId = validName_(recordId, 'recordId');
  const sh = sheet_('records'); const row = findCompositeRecord_(sh, entity, recordId);
  if (!row) return { ok: true, found: false, entity: entity, recordId: recordId };
  const r = sh.getRange(row, 1, 1, 5).getValues()[0];
  return { ok: true, found: true, record: { recordId: String(r[0]), entity: String(r[1]), payload: safeJson_(r[2]), updatedAt: String(r[3]), operationId: String(r[4]) } };
}
function uploadPhoto_(body) {
  const name = String(body.fileName || 'roll-photo.jpg').replace(/[\\/:*?"<>|]/g, '_').slice(0, 120);
  const mime = String(body.mimeType || 'image/jpeg');
  const data = String(body.base64 || '').replace(/^data:[^,]+,/, '');
  if (!data || data.length > 7000000) throw new Error('Photo missing or too large for one request; compress/split before upload');
  const folderId = PropertiesService.getScriptProperties().getProperty('ROLL_DRIVE_FOLDER_ID');
  if (!folderId) throw new Error('Set ROLL_DRIVE_FOLDER_ID in Script Properties');
  const bytes = Utilities.base64Decode(data);
  const file = DriveApp.getFolderById(folderId).createFile(Utilities.newBlob(bytes, mime, name));
  const created = new Date(); const deleteAfter = new Date(created.getTime() + 60 * 86400000);
  sheet_('photos').appendRow([Utilities.getUuid(), file.getId(), file.getName(), mime, created.toISOString(), deleteAfter.toISOString()]);
  return { ok: true, driveFileId: file.getId(), fileName: file.getName(), createdAt: created.toISOString(), deleteAfter: deleteAfter.toISOString() };
}
function deleteExpiredPhotos_() {
  const sh = sheet_('photos');
  const lastRow = sh.getLastRow();
  const lastCol = sh.getLastColumn();

  if (lastRow < 2) {
    return { ok: true, deleted: 0, failed: 0, skipped: 0 };
  }

  const headers = sh.getRange(1, 1, 1, lastCol)
    .getDisplayValues()[0]
    .map(function (h) { return String(h).trim(); });

  const driveIdCol = headers.indexOf('driveFileId');
  const expiryCol = headers.indexOf('deleteAfter');

  if (driveIdCol < 0 || expiryCol < 0) {
    throw new Error('Sheet photos thiếu cột driveFileId hoặc deleteAfter');
  }

  const rows = sh.getRange(2, 1, lastRow - 1, lastCol).getValues();
  const now = Date.now();

  let deleted = 0;
  let failed = 0;
  let skipped = 0;

  // Giới hạn tối đa 100 lần thử xóa mỗi lượt.
  for (let i = rows.length - 1; i >= 0 && deleted + failed < 100; i--) {
    const rawExpiry = rows[i][expiryCol];

    if (rawExpiry === '' || rawExpiry == null) {
      skipped++;
      continue;
    }

    const expiryMs = rawExpiry instanceof Date
      ? rawExpiry.getTime()
      : Date.parse(String(rawExpiry));

    // Ngày không hợp lệ thì giữ nguyên metadata, không xóa.
    if (!Number.isFinite(expiryMs)) {
      skipped++;
      continue;
    }

    if (expiryMs > now) continue;

    const driveFileId = String(rows[i][driveIdCol] || '').trim();

    if (!driveFileId) {
      failed++;
      Logger.log(JSON.stringify({
        ok: false,
        row: i + 2,
        error: 'Thiếu driveFileId; giữ nguyên metadata'
      }));
      continue;
    }

    try {
      DriveApp.getFileById(driveFileId).setTrashed(true);

      // Chỉ xóa dòng metadata sau khi thao tác Drive thành công.
      sh.deleteRow(i + 2);
      deleted++;
    } catch (err) {
      // Giữ nguyên metadata để có thể kiểm tra và thử lại.
      failed++;
      Logger.log(JSON.stringify({
        ok: false,
        row: i + 2,
        error: String(err && err.message ? err.message : err).slice(0, 200)
      }));
    }
  }

  const result = {
    ok: failed === 0,
    deleted: deleted,
    failed: failed,
    skipped: skipped,
    remainingRows: Math.max(0, sh.getLastRow() - 1)
  };

  Logger.log(JSON.stringify(result));
  return result;
}
function findCompositeRecord_(sh, entity, recordId) {
  const last = sh.getLastRow(); if (last < 2) return 0;
  const rows = sh.getRange(2, 1, last - 1, 2).getValues();
  for (let i = rows.length - 1; i >= 0; i--) if (String(rows[i][0]) === recordId && String(rows[i][1]) === entity) return i + 2;
  return 0;
}
function findExact_(sh, col, value) {
  const last = sh.getLastRow(); if (last < 2) return 0;
  const found = sh.getRange(2, col, last - 1, 1).createTextFinder(value).matchEntireCell(true).findNext();
  return found ? found.getRow() : 0;
}
function validName_(value, field) {
  const s = String(value || '').trim();
  if (!s || s.length > 160 || /[\r\n]/.test(s)) throw new Error('Invalid ' + field);
  return s;
}
function safeJson_(s) { try { return JSON.parse(String(s || 'null')); } catch (_) { return null; } }
function safeMessage_(e) { return String(e && e.message ? e.message : e).slice(0, 300); }
function json_(value) { return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON); }
function testConnection() {
  const ss = ss_();
  const names = ['records', 'operations', 'photos'];

  const result = names.map(name => {
    const sh = ss.getSheetByName(name);
    return {
      sheet: name,
      exists: !!sh,
      rows: sh ? sh.getLastRow() : null
    };
  });

  Logger.log(JSON.stringify({
    ok: result.every(x => x.exists),
    spreadsheet: ss.getName(),
    sheets: result
  }));
}
function testWriteRead() {
  const testId = 'TEST_' + Utilities.getUuid();
  const operationId = 'OP_' + Utilities.getUuid();

  const testData = {
    operationId: operationId,
    entity: 'connection_test',
    recordId: testId,
    payload: {
      test: true,
      message: 'ROLL_CAY_CANH_TEST'
    }
  };

  const writeResult = applyOperation_(testData);

  const readResult = getRecord_('connection_test', testId);

  Logger.log(JSON.stringify({
    write: writeResult,
    read: readResult,
    testRecordId: testId
  }));
}
function testDriveUpload() {
  const folderId = PropertiesService.getScriptProperties()
    .getProperty('ROLL_DRIVE_FOLDER_ID');

  if (!folderId) {
    throw new Error('Thiếu ROLL_DRIVE_FOLDER_ID trong Script Properties');
  }

  const folder = DriveApp.getFolderById(folderId);
  const testName = 'ROLL_TEST_' + Utilities.getUuid() + '.txt';
  const file = folder.createFile(
    testName,
    'ROLL CAY CANH DRIVE CONNECTION TEST',
    MimeType.PLAIN_TEXT
  );

  const result = {
    ok: true,
    folderName: folder.getName(),
    fileName: file.getName(),
    fileId: file.getId()
  };

  Logger.log(JSON.stringify(result));
}
function testUploadPhoto() {
  // Ảnh PNG thử nghiệm 1x1 pixel
  const base64 =
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/S+8AAAAASUVORK5CYII=';

  const result = uploadPhoto_({
    fileName: 'ROLL_TEST_PHOTO_' + Utilities.getUuid() + '.png',
    mimeType: 'image/png',
    base64: base64
  });

  Logger.log(JSON.stringify(result));
}
function testWebAppAPI() {
  const url = 'https://script.google.com/macros/s/AKfycbyUJaEPNEb5v45Ew0Fjk9Mh17JWtZ9j8V7Ai4QaMW4xe349nSUq5C7mhjhuqRsxzhPD/exec';

  const token = PropertiesService.getScriptProperties()
    .getProperty('ROLL_API_TOKEN');

  if (!token) {
    throw new Error('Không tìm thấy ROLL_API_TOKEN trong Script Properties');
  }

  const recordId = 'API_TEST_' + Utilities.getUuid();
  const operationId = 'API_OP_' + Utilities.getUuid();

  const writeResponse = UrlFetchApp.fetch(url, {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify({
      token: token,
      action: 'upsert',
      entity: 'api_test',
      recordId: recordId,
      operationId: operationId,
      payload: {
        test: true,
        message: 'ROLL_CAY_CANH_WEB_APP_API_TEST'
      }
    }),
    muteHttpExceptions: true
  });

  const writeText = writeResponse.getContentText();
  let writeResult;

  try {
    writeResult = JSON.parse(writeText);
  } catch (e) {
    throw new Error('API ghi dữ liệu trả về phản hồi không phải JSON: ' + writeText.slice(0, 300));
  }

  if (!writeResult.ok) {
    throw new Error('API ghi dữ liệu thất bại: ' + writeText.slice(0, 300));
  }

  const readUrl = url
    + '?action=get'
    + '&entity=api_test'
    + '&recordId=' + encodeURIComponent(recordId)
    + '&token=' + encodeURIComponent(token);

  const readResponse = UrlFetchApp.fetch(readUrl, {
    method: 'get',
    muteHttpExceptions: true
  });

  let readResult;

  try {
    readResult = JSON.parse(readResponse.getContentText());
  } catch (e) {
    throw new Error('API đọc dữ liệu trả về phản hồi không phải JSON');
  }

  const success = readResult.ok === true
    && readResult.found === true
    && readResult.record.recordId === recordId
    && readResult.record.payload.message === 'ROLL_CAY_CANH_WEB_APP_API_TEST';

  Logger.log(JSON.stringify({
    success: success,
    write: writeResult,
    read: readResult
  }));

  if (!success) {
    throw new Error('Ghi được dữ liệu nhưng API đọc lại chưa đạt yêu cầu. Xem nhật ký thực thi.');
  }
}
function testTokenSecurity() {
  const url = 'https://script.google.com/macros/s/AKfycbyUJaEPNEb5v45Ew0Fjk9Mh17JWtZ9j8V7Ai4QaMW4xe349nSUq5C7mhjhuqRsxzhPD/exec';

  const tests = [
    {
      name: 'MISSING_TOKEN',
      query: '?action=get&entity=api_test&recordId=SECURITY_TEST'
    },
    {
      name: 'INVALID_TOKEN',
      query: '?action=get&entity=api_test&recordId=SECURITY_TEST&token=INVALID_TEST_TOKEN'
    }
  ];

  const results = [];

  tests.forEach(function(test) {
    const response = UrlFetchApp.fetch(url + test.query, {
      method: 'get',
      followRedirects: true,
      muteHttpExceptions: true
    });

    let body;

    try {
      body = JSON.parse(response.getContentText());
    } catch (e) {
      body = { error: 'NON_JSON_RESPONSE' };
    }

    results.push({
      test: test.name,
      rejected: body.ok === false && body.error === 'Unauthorized',
      error: body.error || null
    });
  });

  const success = results.every(function(result) {
    return result.rejected === true;
  });

  Logger.log(JSON.stringify({
    securityTestPassed: success,
    results: results
  }));

  if (!success) {
    throw new Error(
      'Chưa xác nhận được API từ chối tất cả token không hợp lệ. Hãy kiểm tra nhật ký.'
    );
  }
}
function updateExistingPhotosRetention60Days() {
  const ssId = PropertiesService.getScriptProperties()
    .getProperty('ROLL_SPREADSHEET_ID');

  if (!ssId) {
    throw new Error('Thiếu ROLL_SPREADSHEET_ID');
  }

  const sheet = SpreadsheetApp
    .openById(ssId)
    .getSheetByName('photos');

  if (!sheet) {
    throw new Error('Không tìm thấy sheet photos');
  }

  const lastRow = sheet.getLastRow();

  if (lastRow < 2) {
    Logger.log(JSON.stringify({
      ok: true,
      updated: 0,
      message: 'Không có ảnh cần cập nhật'
    }));
    return;
  }

  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn())
    .getValues()[0];

  const createdCol = headers.indexOf('createdAt');
  const deleteCol = headers.indexOf('deleteAfter');

  if (createdCol === -1 || deleteCol === -1) {
    throw new Error('Không tìm thấy cột createdAt hoặc deleteAfter');
  }

  const rows = sheet.getRange(
    2, 1, lastRow - 1, sheet.getLastColumn()
  ).getValues();

  let updated = 0;
  let skipped = 0;

  rows.forEach(function(row, index) {
    const createdAt = new Date(row[createdCol]);

    if (!row[createdCol] || isNaN(createdAt.getTime())) {
      skipped++;
      return;
    }

    const deleteAfter = new Date(
      createdAt.getTime() + 60 * 24 * 60 * 60 * 1000
    );

    sheet.getRange(index + 2, deleteCol + 1)
      .setValue(deleteAfter.toISOString());

    updated++;
  });

  Logger.log(JSON.stringify({
    ok: true,
    updated: updated,
    skipped: skipped,
    retentionDays: 60,
    filesDeleted: 0
  }));
}

function setupDailyPhotoCleanup() {
  const handler = 'deleteExpiredPhotos_';

  // Tránh tạo nhiều lịch chạy trùng nhau.
  const triggers = ScriptApp.getProjectTriggers();
  triggers.forEach(function(trigger) {
    if (trigger.getHandlerFunction() === handler) {
      ScriptApp.deleteTrigger(trigger);
    }
  });

  // Tự động kiểm tra và xóa ảnh hết hạn mỗi ngày.
  ScriptApp.newTrigger(handler)
    .timeBased()
    .everyDays(1)
    .create();

  Logger.log(JSON.stringify({
    ok: true,
    task: handler,
    schedule: 'daily'
  }));
}

/* ============================================================================
 * BEGIN MERGED PHASE 2 FIRESTORE COMPATIBILITY HANDLER
 * Original module source is preserved below; import writes are admin-only before cutover.
 * Business writes open only after full source/destination verification and finalization.
 * ============================================================================ */
/**
 * ROLL CÂY CẢNH — Firestore-compatible GAS storage adapter (Phase 2 foundation)
 * Merged into Code.gs for this deployment candidate. The doPost(e) dispatch branch
 * calls this handler before legacy token authorization. If kept as a separate file,
 * retain the same dispatch branch in Code.gs.
 *
 * IMPORTANT: migration import is admin-only before cutover; business writes fail closed until
 * the verified finalization switch is set. The module uses its own fsCompatDocs sheet and does not modify the existing records,
 * operations, or photos sheets. Document snapshots are chunked below Sheets' 50k-cell limit.
 */
var ROLL_FS_COMPAT = Object.freeze({
  VERSION: 'gas-firestore-compat-phase2.3-migration-backup',
  DOCS_SHEET: 'fsCompatDocs',
  MAX_CELL_CHARS: 40000,
  MAX_REQUEST_WRITES: 500,
  MAX_QUERY_DOCS: 5000,
  MAX_COMMIT_CHARS: 8 * 1024 * 1024,
  CACHE_SECONDS: 90,
  HEADERS: ['rowType','docPath','collectionPath','docId','payloadChunk','chunkIndex','chunkCount','version','updatedAtMs','updatedBy','deleted','operationId','resultJson']
});

function handleFirestoreCompatRequest_(body) {
  var migrationImportOnly = false; // Set only by the admin-authenticated importBatch route below.
  try {
    if (!body || body.action !== 'fsCompat') return fsCompatResult_(false, null, 'BAD_ACTION', 'Invalid adapter action');
    var identity = fsCompatAuthenticate_(String(body.idToken || ''));
    var command = String(body.command || '');
    if (command === 'health') {
      return fsCompatResult_(true, {version: ROLL_FS_COMPAT.VERSION, writesEnabled: fsCompatWritesEnabled_(), cutoverCompleted: fsCompatCutoverCompleted_(), identity: {uid: identity.uid, role: identity.role}}, null, null);
    }
    if (command === 'finalizeMigration') {
      if (!identity.isAdmin) throw fsCompatError_('PERMISSION_DENIED', 'Only an Admin may finalize the migration');
      if (fsCompatCutoverCompleted_()) return fsCompatResult_(true, {cutoverCompleted:true,writesEnabled:fsCompatWritesEnabled_(),alreadyFinalized:true}, null, null);
      var report = body.report || {};
      var total = Number(report.totalDocuments), verified = Number(report.verifiedDocuments);
      var checksum = String(report.allDocumentsChecksum || '');
      if (report.verifiedAll !== true || !Number.isSafeInteger(total) || total < 1 || verified !== total || !/^fnv32x2-[0-9a-f]{16}-docs[0-9]+-payloadBytes[0-9]+$/.test(checksum)) {
        throw fsCompatError_('FAILED_PRECONDITION', 'Migration cannot be finalized: the client did not report complete document-by-document verification');
      }
      var finalIndex = fsCompatBuildIndex_();
      var liveDocumentCount = Object.keys(finalIndex).filter(function(path){ return !finalIndex[path].deleted; }).length;
      if (liveDocumentCount !== total) throw fsCompatError_('FAILED_PRECONDITION', 'Destination document count does not match the migration report: Sheets=' + liveDocumentCount + ', verified=' + total);
      var rootDoc = finalIndex['apps/roll-cay-canh'];
      if (!rootDoc || rootDoc.deleted || !rootDoc.data || typeof rootDoc.data !== 'object') throw fsCompatError_('FAILED_PRECONDITION', 'Required app root apps/roll-cay-canh is missing in Sheets');
      if (!finalIndex['users/' + identity.uid] && !String(PropertiesService.getScriptProperties().getProperty('ROLL_ADMIN_UIDS') || '').split(',').map(function(x){return x.trim();}).filter(Boolean).includes(identity.uid)) {
        throw fsCompatError_('FAILED_PRECONDITION', 'The verified migration has no profile for the signed-in administrator');
      }
      var props = PropertiesService.getScriptProperties();
      var finalizedAt = new Date().toISOString();
      props.setProperty('ROLL_GAS_MIGRATION_REPORT', JSON.stringify({uid:identity.uid,totalDocuments:total,verifiedDocuments:verified,checksum:checksum,finalizedAt:finalizedAt,version:ROLL_FS_COMPAT.VERSION}));
      // This is the single cutover switch. It is only reached after an admin has copied and
      // read-verified every document; regular business commits stay disabled until this point.
      props.setProperty('ROLL_GAS_COMPAT_WRITES_ENABLED', 'true');
      props.setProperty('ROLL_GAS_CUTOVER_COMPLETED', 'true');
      return fsCompatResult_(true, {cutoverCompleted:true,writesEnabled:true,totalDocuments:total,verifiedDocuments:verified,checksum:checksum,finalizedAt:finalizedAt}, null, null);
    }
    var lock = LockService.getScriptLock();
    if (command === 'get' || command === 'query' || command === 'multiQuery' || command === 'getMany') {
      var readLock = LockService.getScriptLock(); readLock.waitLock(10000);
      try {
      var index = fsCompatBuildIndex_();
      if (command === 'get') {
        var path = fsCompatNormalizeDocPath_(body.path);
        var item = index[path] || null;
        if (!fsCompatCanReadPath_(identity, path, item && !item.deleted ? item.data : null, false)) throw fsCompatError_('PERMISSION_DENIED', 'Read permission denied for ' + path);
        return fsCompatResult_(true, {document: item && !item.deleted ? fsCompatPublicDoc_(item) : null, version: item ? item.version : 0}, null, null);
      }
      if (command === 'getMany') {
        if (!identity.isAdmin) throw fsCompatError_('PERMISSION_DENIED', 'Only an Admin may run bulk migration verification');
        var paths = Array.isArray(body.paths) ? body.paths : [];
        if (paths.length > 100) throw fsCompatError_('INVALID_ARGUMENT', 'getMany supports at most 100 documents per request');
        var items = paths.map(function(p){var path=fsCompatNormalizeDocPath_(p),item=index[path]||null;return item&&!item.deleted?fsCompatPublicDoc_(item):null;});
        return fsCompatResult_(true, {documents:items}, null, null);
      }
      function executeQuery_(querySpec) {
        var collectionPath = fsCompatNormalizeCollectionPath_(querySpec.collectionPath);
        var filters = Array.isArray(querySpec.filters) ? querySpec.filters : [];
        if (!fsCompatCanQueryCollection_(identity, collectionPath, filters)) throw fsCompatError_('PERMISSION_DENIED', 'Query permission denied for ' + collectionPath);
        var docs = [];
        Object.keys(index).forEach(function(path) {
          var item = index[path];
          if (item.collectionPath !== collectionPath || item.deleted) return;
          if (!fsCompatMatchesFilters_(item, filters)) return;
          // Apply rules before returning any row; unauthorized data is never serialized to the client.
          if (!fsCompatCanReadPath_(identity, path, item.data, true)) return;
          docs.push(fsCompatPublicDoc_(item));
        });
        if (docs.length > ROLL_FS_COMPAT.MAX_QUERY_DOCS) throw fsCompatError_('RESOURCE_EXHAUSTED', 'Query returned too many documents; add a filter or limit');
        return fsCompatSortAndLimit_(docs, querySpec.orderBy || [], querySpec.limit);
      }
      if (command === 'multiQuery') {
        var queries = Array.isArray(body.queries) ? body.queries : [];
        if (!queries.length || queries.length > 25) throw fsCompatError_('INVALID_ARGUMENT', 'multiQuery supports 1–25 listener queries');
        var snapshots = queries.map(function(q){var docs=executeQuery_(q);return {documents:docs,size:docs.length};});
        return fsCompatResult_(true, {snapshots:snapshots}, null, null);
      }
      var documents = executeQuery_(body);
      return fsCompatResult_(true, {documents:documents,size:documents.length}, null, null);
      } finally { readLock.releaseLock(); }
    }
    if (command === 'importBatch') {
      if (!identity.isAdmin) throw fsCompatError_('PERMISSION_DENIED', 'Only an Admin may migrate Firestore documents');
      if (fsCompatCutoverCompleted_()) throw fsCompatError_('FAILED_PRECONDITION', 'Migration import is closed after cutover');
      // Importing source-of-truth data is a separate, admin-only operation. It is allowed while
      // normal app writes remain disabled, and never bypasses the collection-root allow-list below.
      migrationImportOnly = true;
      var importDocs = Array.isArray(body.documents) ? body.documents : [];
      if (!importDocs.length || importDocs.length > 100) throw fsCompatError_('INVALID_ARGUMENT', 'Import batches must contain 1–100 documents');
      var importIndex = fsCompatBuildIndex_();
      var seenImportPaths = {};
      var importWrites = [];
      var importPreconditions = [];
      importDocs.forEach(function(item) {
        var path = fsCompatNormalizeDocPath_(item.path);
        if (seenImportPaths[path]) throw fsCompatError_('INVALID_ARGUMENT', 'Duplicate path in migration batch: ' + path);
        seenImportPaths[path] = true;
        var prior = importIndex[path] && !importIndex[path].deleted ? importIndex[path] : null;
        if (prior) {
          if (fsCompatSame_(prior.data, item.data)) return; // Idempotent replay after a network timeout.
          if (body.overwrite !== true) throw fsCompatError_('ALREADY_EXISTS', 'A different document already exists in GAS: ' + path);
          importPreconditions.push({path:path,version:prior.version});
        } else importPreconditions.push({path:path,version:0});
        importWrites.push({type:'set',path:path,data:item.data,merge:false});
      });
      if (!importWrites.length) return fsCompatResult_(true, {imported:0,skipped:importDocs.length,idempotent:true}, null, null);
      body.command = 'commit'; body.writes = importWrites; body.preconditions = importPreconditions;
      if (!body.operationId) body.operationId = 'import_' + Utilities.getUuid().replace(/-/g,'');
      // Continue through the same serialized commit path, chunking, preconditions, and idempotency marker.
      // Only this server-controlled flag bypasses ordinary live-write authorization; paths are allow-listed.
      command = 'commit';
    }
    if (command === 'commit') {
      if (!fsCompatWritesEnabled_() && !migrationImportOnly) throw fsCompatError_('FAILED_PRECONDITION', 'GAS compatibility writes are disabled until the migration has been finalized');
      var writes = Array.isArray(body.writes) ? body.writes : [];
      if (!writes.length) return fsCompatResult_(true, {committed: true, writes: 0}, null, null);
      if (writes.length > ROLL_FS_COMPAT.MAX_REQUEST_WRITES) throw fsCompatError_('INVALID_ARGUMENT', 'Too many writes in one commit');
      var serializedLength = JSON.stringify(body).length;
      if (serializedLength > ROLL_FS_COMPAT.MAX_COMMIT_CHARS) throw fsCompatError_('RESOURCE_EXHAUSTED', 'Commit payload is too large');
      var opId = String(body.operationId || '');
      if (!/^[A-Za-z0-9_-]{8,100}$/.test(opId)) throw fsCompatError_('INVALID_ARGUMENT', 'Missing or invalid operationId');
      lock.waitLock(20000);
      try {
        var sheet = fsCompatEnsureSheet_();
        var existingResult = fsCompatFindOperation_(sheet, opId);
        if (existingResult) return fsCompatResult_(true, existingResult, null, null);
        var current = fsCompatBuildIndexFromSheet_(sheet);
        fsCompatCheckPreconditions_(current, Array.isArray(body.preconditions) ? body.preconditions : []);
        var actor = identity;
        var changes = [];
        var candidates = {};
        writes.forEach(function(write) {
          var path = fsCompatNormalizeDocPath_(write.path);
          if (candidates[path] !== undefined) throw fsCompatError_('INVALID_ARGUMENT', 'Duplicate document path in one commit: ' + path);
          var before = current[path] && !current[path].deleted ? current[path].data : null;
          var applied = fsCompatApplyWrite_(before, write, Date.now());
          candidates[path] = applied.deleted ? null : applied.data;
          changes.push({path:path, write:write, before:before, after:applied.deleted ? null : applied.data, deleted:applied.deleted});
        });
        var finalDocs = {};
        Object.keys(current).forEach(function(k){ if (!current[k].deleted) finalDocs[k] = current[k].data; });
        changes.forEach(function(change){ if(change.deleted) delete finalDocs[change.path]; else finalDocs[change.path] = change.after; });
        changes.forEach(function(change) {
          if (migrationImportOnly) {
            if (!fsCompatAllowedImportPath_(change.path)) throw fsCompatError_('PERMISSION_DENIED', 'Migration path is outside the approved app collections: ' + change.path);
          } else if (!fsCompatCanWritePath_(actor, change.path, change.write, change.before, change.after, finalDocs, changes)) {
            throw fsCompatError_('PERMISSION_DENIED', 'Write permission denied for ' + change.path);
          }
        });
        // During admin migration, preserve every different pre-existing GAS document before
        // replacing it with the Firestore source-of-truth snapshot. If backup fails, abort the
        // import before any destination document rows are changed.
        if (migrationImportOnly) {
          changes.forEach(function(change) {
            if (change.before && !change.deleted && !fsCompatSame_(change.before, change.after)) {
              fsCompatBackupMigrationConflict_(change.path, change.before, current[change.path], identity, opId);
            }
          });
        }
        var now = Date.now();
        var rows = [];
        changes.forEach(function(change) {
          var prior = current[change.path];
          var version = prior ? Number(prior.version || 0) + 1 : 1;
          var parts = change.deleted ? [''] : fsCompatSplitPayload_(JSON.stringify(change.after));
          var collectionPath = change.path.split('/').slice(0, -1).join('/');
          var docId = change.path.split('/').pop();
          for (var i=0;i<parts.length;i++) {
            rows.push(['doc',change.path,collectionPath,docId,parts[i],i,parts.length,version,now,identity.uid,change.deleted?'TRUE':'FALSE',opId,'']);
          }
        });
        var result = {committed:true,writes:changes.length,operationId:opId,committedAtMs:now,versions:{}};
        changes.forEach(function(change){ result.versions[change.path] = (current[change.path] ? Number(current[change.path].version||0) : 0) + 1; });
        // The operation marker shares the same single Sheet range write as all changed documents.
        // A retry after a response timeout therefore detects the operation and cannot double-apply it.
        rows.push(['op','','','','',0,1,0,now,identity.uid,'FALSE',opId,JSON.stringify(result)]);
        var lastRow = sheet.getLastRow();
        sheet.getRange(lastRow + 1, 1, rows.length, ROLL_FS_COMPAT.HEADERS.length).setValues(rows);
        // Compaction occurs only after the append committed. If cleanup fails, the highest document
        // version remains authoritative and the next call can still read it safely.
        try { fsCompatCompactPaths_(sheet, changes.map(function(x){return x.path;})); } catch (compactError) { console.warn('fsCompat compaction deferred', compactError); }
        return fsCompatResult_(true, result, null, null);
      } finally { lock.releaseLock(); }
    }
    throw fsCompatError_('INVALID_ARGUMENT', 'Unsupported adapter command: ' + command);
  } catch (error) {
    var code = String(error && error.code || 'INTERNAL');
    var message = String(error && error.message || error || 'Unknown error');
    console.warn('FirestoreCompat request failed', code, message);
    return fsCompatResult_(false, null, code, message);
  }
}

function fsCompatResult_(ok, data, code, message) { return {ok:!!ok,data:data == null ? null : data,error:code ? {code:code,message:String(message||code)} : null,version:ROLL_FS_COMPAT.VERSION}; }
function fsCompatError_(code, message) { var e = new Error(message); e.code = code; return e; }
function fsCompatWritesEnabled_() { return String(PropertiesService.getScriptProperties().getProperty('ROLL_GAS_COMPAT_WRITES_ENABLED') || '').toLowerCase() === 'true'; }
function fsCompatCutoverCompleted_() { return String(PropertiesService.getScriptProperties().getProperty('ROLL_GAS_CUTOVER_COMPLETED') || '').toLowerCase() === 'true'; }
function fsCompatAllowedImportPath_(path) {
  var p = String(path || '').split('/');
  var roots = ['apps','config','packingOrders','users','dailyShipmentScans','shipmentTrackingClaims','notifications','inventory','inventoryLogs','payroll','salaryAdvances','reports','quotes','quotation','shipmentOcr','auditLogs','syncState','appState','payrollSettings','salarySettings','priceSettings','categories','plantCategories','sizes','employees','packerRecords'];
  if (p.length < 2 || p.length % 2 !== 0 || roots.indexOf(p[0]) < 0) return false;
  if (p.some(function(part){ return !part || part === '.' || part === '..'; })) return false;
  return true;
}

function fsCompatAuthenticate_(idToken) {
  if (!idToken || idToken.length < 100 || idToken.length > 10000) throw fsCompatError_('UNAUTHENTICATED', 'Missing or invalid Firebase ID token');
  var apiKey = String(PropertiesService.getScriptProperties().getProperty('ROLL_FIREBASE_API_KEY') || '');
  if (!apiKey) throw fsCompatError_('FAILED_PRECONDITION', 'Set Script Property ROLL_FIREBASE_API_KEY before enabling this backend');
  var cache = CacheService.getScriptCache();
  var tokenHash = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, idToken, Utilities.Charset.UTF_8).map(function(b){return ('0'+((b+256)%256).toString(16)).slice(-2);}).join('');
  var key = 'fscompat_auth_' + tokenHash.substring(0, 48);
  var cached = cache.get(key);
  var firebaseUser = null;
  if (cached) { try { firebaseUser = JSON.parse(cached); } catch (_) {} }
  if (!firebaseUser) {
    var response = UrlFetchApp.fetch('https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=' + encodeURIComponent(apiKey), {
      method:'post', contentType:'application/json', payload:JSON.stringify({idToken:idToken}), muteHttpExceptions:true
    });
    if (response.getResponseCode() !== 200) throw fsCompatError_('UNAUTHENTICATED', 'Firebase rejected the login token');
    var parsed = JSON.parse(response.getContentText() || '{}');
    if (!parsed.users || !parsed.users.length || !parsed.users[0].localId) throw fsCompatError_('UNAUTHENTICATED', 'Firebase token has no valid user');
    firebaseUser = {uid:String(parsed.users[0].localId),email:String(parsed.users[0].email||'').toLowerCase()};
    cache.put(key, JSON.stringify(firebaseUser), ROLL_FS_COMPAT.CACHE_SECONDS);
  }
  var uid = String(firebaseUser.uid || '');
  var email = String(firebaseUser.email || '').toLowerCase();
  if (!uid) throw fsCompatError_('UNAUTHENTICATED', 'Invalid Firebase user');
  var adminUids = String(PropertiesService.getScriptProperties().getProperty('ROLL_ADMIN_UIDS') || '').split(',').map(function(x){return x.trim();}).filter(Boolean);
  var isBootstrap = adminUids.indexOf(uid) >= 0; // Explicit allowlist only; never grant admin by hard-coded email.
  var profileItem = fsCompatReadCurrentDoc_('users/' + uid);
  var profile = profileItem && !profileItem.deleted ? profileItem.data : null;
  if (!isBootstrap && !profile) throw fsCompatError_('PERMISSION_DENIED', 'This account has no migrated users/{uid} profile');
  if (profile && profile.active === false && !isBootstrap) throw fsCompatError_('PERMISSION_DENIED', 'This account is disabled');
  var role = isBootstrap ? 'admin' : String(profile && profile.role || 'viewer').toLowerCase();
  return {uid:uid,email:email,role:role,active:!!isBootstrap || !profile || profile.active !== false,profile:profile||{},isAdmin:isBootstrap||role==='admin',isProcurement:['procurement','purchaser','purchasing','purchasing_staff','procurement_staff','thu_mua','nhan_vien_thu_mua'].indexOf(role)>=0};
}

// Non-destructive archive of pre-existing GAS data replaced by a verified Firestore migration.
// Each JSON snapshot is chunked below Sheets' per-cell character limit. Backups are deduplicated
// by import operation + Firestore document path; no existing backup or source row is deleted.
var ROLL_FS_MIGRATION_BACKUP = Object.freeze({
  SHEET: 'fsCompatMigrationBackup',
  MAX_CHARS: 30000,
  HEADERS: ['backupId','capturedAt','adminUid','docPath','priorVersion','chunkIndex','chunkCount','payloadChunk','importOperationId']
});
function fsCompatMigrationBackupSheet_() {
  var ssId = PropertiesService.getScriptProperties().getProperty('ROLL_SPREADSHEET_ID');
  if (!ssId) throw fsCompatError_('FAILED_PRECONDITION', 'Missing ROLL_SPREADSHEET_ID');
  var ss = SpreadsheetApp.openById(ssId);
  var sheet = ss.getSheetByName(ROLL_FS_MIGRATION_BACKUP.SHEET);
  if (!sheet) {
    sheet = ss.insertSheet(ROLL_FS_MIGRATION_BACKUP.SHEET);
    sheet.getRange(1,1,1,ROLL_FS_MIGRATION_BACKUP.HEADERS.length).setValues([ROLL_FS_MIGRATION_BACKUP.HEADERS]);
    sheet.setFrozenRows(1);
    return sheet;
  }
  var headers = sheet.getRange(1,1,1,ROLL_FS_MIGRATION_BACKUP.HEADERS.length).getDisplayValues()[0];
  if (ROLL_FS_MIGRATION_BACKUP.HEADERS.some(function(name,i){return String(headers[i]||'')!==name;})) {
    throw fsCompatError_('FAILED_PRECONDITION', 'Unexpected migration backup schema; refusing to overwrite existing backup sheet');
  }
  return sheet;
}
function fsCompatBackupMigrationConflict_(path, data, prior, identity, operationId) {
  var sheet = fsCompatMigrationBackupSheet_();
  var backupId = String(operationId) + '|' + String(path);
  var last = sheet.getLastRow();
  if (last >= 2) {
    var existing = sheet.getRange(2,1,last-1,1).createTextFinder(backupId).matchEntireCell(true).findNext();
    if (existing) return {ok:true,duplicate:true,backupId:backupId};
  }
  var serialized = JSON.stringify(data);
  if (typeof serialized !== 'string') throw fsCompatError_('DATA_LOSS', 'Could not serialize pre-existing GAS document: ' + path);
  var chunks = [], start = 0;
  while (start < serialized.length) {
    var end = Math.min(serialized.length, start + ROLL_FS_MIGRATION_BACKUP.MAX_CHARS);
    if (end < serialized.length && end > start) {
      var code = serialized.charCodeAt(end - 1);
      if (code >= 0xD800 && code <= 0xDBFF) end--;
    }
    chunks.push(serialized.slice(start,end));
    start = end;
  }
  if (!chunks.length) chunks.push('null');
  var now = new Date().toISOString();
  var rows = chunks.map(function(chunk,i){
    return [backupId,now,String(identity.uid||''),String(path),Number(prior&&prior.version||0),i,chunks.length,chunk,String(operationId)];
  });
  // Chunk large snapshots into moderate range writes to stay within Apps Script request limits.
  for (var i=0; i<rows.length; i+=400) {
    var slice = rows.slice(i,i+400);
    sheet.getRange(sheet.getLastRow()+1,1,slice.length,ROLL_FS_MIGRATION_BACKUP.HEADERS.length).setValues(slice);
  }
  return {ok:true,backupId:backupId,chunks:chunks.length,priorVersion:Number(prior&&prior.version||0)};
}

function fsCompatEnsureSheet_() {
  var ssId = PropertiesService.getScriptProperties().getProperty('ROLL_SPREADSHEET_ID');
  if (!ssId) throw fsCompatError_('FAILED_PRECONDITION', 'Missing ROLL_SPREADSHEET_ID');
  var ss = SpreadsheetApp.openById(ssId);
  var sheet = ss.getSheetByName(ROLL_FS_COMPAT.DOCS_SHEET);
  if (!sheet) { sheet = ss.insertSheet(ROLL_FS_COMPAT.DOCS_SHEET); sheet.getRange(1,1,1,ROLL_FS_COMPAT.HEADERS.length).setValues([ROLL_FS_COMPAT.HEADERS]); sheet.setFrozenRows(1); return sheet; }
  var header = sheet.getRange(1,1,1,ROLL_FS_COMPAT.HEADERS.length).getDisplayValues()[0];
  if (ROLL_FS_COMPAT.HEADERS.some(function(name,i){return String(header[i]||'')!==name;})) throw fsCompatError_('FAILED_PRECONDITION', 'Unexpected fsCompatDocs schema; refusing to overwrite the sheet');
  return sheet;
}
function fsCompatSheet_() { return fsCompatEnsureSheet_(); }
function fsCompatBuildIndex_() { return fsCompatBuildIndexFromSheet_(fsCompatSheet_()); }
function fsCompatBuildIndexFromSheet_(sheet) {
  var out = {};
  var last = sheet.getLastRow();
  if (last < 2) return out;
  // Index reconstruction only needs document columns A:K. Column M contains potentially
  // large idempotency result JSON; reading it for every query made the backend progressively slower.
  var values = sheet.getRange(2,1,last-1,11).getValues();
  var byPath = {};
  values.forEach(function(row) {
    if (String(row[0]) !== 'doc') return;
    var path = String(row[1]||''), version = Number(row[7]||0), chunkCount = Math.max(1,Number(row[6]||1)), chunkIndex = Number(row[5]||0);
    if (!path || !version) return;
    var current = byPath[path];
    if (!current || version > current.version) byPath[path] = {path:path,collectionPath:String(row[2]||''),id:String(row[3]||''),version:version,chunkCount:chunkCount,chunks:{},updatedAtMs:Number(row[8]||0),updatedBy:String(row[9]||''),deleted:String(row[10]).toUpperCase()==='TRUE'};
    current = byPath[path];
    if (version === current.version) { current.chunks[chunkIndex] = String(row[4]||''); current.deleted = String(row[10]).toUpperCase()==='TRUE'; current.collectionPath=String(row[2]||current.collectionPath); current.id=String(row[3]||current.id); current.chunkCount=chunkCount; current.updatedAtMs=Number(row[8]||current.updatedAtMs); current.updatedBy=String(row[9]||current.updatedBy); }
  });
  Object.keys(byPath).forEach(function(path) {
    var row = byPath[path];
    if (row.deleted) { out[path] = {path:path,collectionPath:row.collectionPath,id:row.id,version:row.version,deleted:true,data:null,updatedAtMs:row.updatedAtMs,updatedBy:row.updatedBy}; return; }
    var parts = [];
    for (var i=0;i<row.chunkCount;i++) { if (row.chunks[i] === undefined) throw fsCompatError_('DATA_LOSS','Incomplete chunk set for ' + path + ' v' + row.version); parts.push(row.chunks[i]); }
    var payload = parts.join('');
    var data;
    try { data = JSON.parse(payload); } catch (e) { throw fsCompatError_('DATA_LOSS','Invalid document JSON at ' + path); }
    out[path] = {path:path,collectionPath:row.collectionPath,id:row.id,version:row.version,deleted:false,data:data,updatedAtMs:row.updatedAtMs,updatedBy:row.updatedBy};
  });
  return out;
}
function fsCompatReadCurrentDoc_(path) { var index = fsCompatBuildIndex_(); return index[path] || null; }
function fsCompatFindOperation_(sheet, opId) {
  var last=sheet.getLastRow(); if(last<2)return null;
  // Operation IDs live in column L. Search that single column instead of loading every
  // document payload and every result JSON into Apps Script memory on each retry.
  var matches=sheet.getRange(2,12,last-1,1).createTextFinder(String(opId)).matchEntireCell(true).findAll();
  for(var i=matches.length-1;i>=0;i--){
    var rowNo=matches[i].getRow();
    if(String(sheet.getRange(rowNo,1).getValue())!=='op')continue;
    try{return JSON.parse(String(sheet.getRange(rowNo,13).getValue()||'{}'));}
    catch(_){throw fsCompatError_('DATA_LOSS','Invalid operation marker '+opId);}
  }
  return null;
}
function fsCompatCheckPreconditions_(current, preconditions) {
  preconditions.forEach(function(p){var path=fsCompatNormalizeDocPath_(p.path),actual=current[path]?Number(current[path].version||0):0,expected=Number(p.version||0);if(actual!==expected)throw fsCompatError_('ABORTED','Transaction conflict at '+path);});
}
function fsCompatNormalizeDocPath_(path) {
  var p=String(path||'').replace(/^\/+|\/+$/g,''); var parts=p.split('/');
  if(!p||parts.some(function(x){return !x;})||parts.length%2!==0||p.length>1500)throw fsCompatError_('INVALID_ARGUMENT','Invalid document path');
  return p;
}
function fsCompatNormalizeCollectionPath_(path) {
  var p=String(path||'').replace(/^\/+|\/+$/g,''); var parts=p.split('/');
  if(!p||parts.some(function(x){return !x;})||parts.length%2!==1||p.length>1500)throw fsCompatError_('INVALID_ARGUMENT','Invalid collection path');
  return p;
}
function fsCompatPublicDoc_(item) { return {id:item.id,path:item.path,data:item.data,version:Number(item.version||0),updatedAtMs:Number(item.updatedAtMs||0)}; }
function fsCompatSplitPayload_(payload) { var parts=[]; for(var i=0;i<payload.length;i+=ROLL_FS_COMPAT.MAX_CELL_CHARS)parts.push(payload.slice(i,i+ROLL_FS_COMPAT.MAX_CELL_CHARS)); return parts.length?parts:['']; }
function fsCompatApplyWrite_(before, write, now) {
  var type=String(write.type||'set');
  if(type==='delete')return {deleted:true,data:null};
  if(type==='update' && (!before || typeof before!=='object')) throw fsCompatError_('NOT_FOUND','Cannot update missing document '+write.path);
  if(type==='update'){
    var updated=fsCompatDeepClone_(before);
    (Array.isArray(write.patches)?write.patches:[]).forEach(function(patch){var parts=Array.isArray(patch.fieldPath)?patch.fieldPath:String(patch.fieldPath||'').split('.');fsCompatSetAtPath_(updated,parts,fsCompatResolveValue_(patch.value,now),true);});
    return {deleted:false,data:updated};
  }
  var data=fsCompatResolveValue_(write.data,now);
  if(!data||typeof data!=='object'||Array.isArray(data))throw fsCompatError_('INVALID_ARGUMENT','Document data must be an object');
  var merge=!!write.merge;
  return {deleted:false,data:merge&&before?fsCompatMergeMaps_(fsCompatDeepClone_(before),data):fsCompatApplyDeletes_(data)};
}
function fsCompatResolveValue_(value, now) {
  if(value && typeof value==='object' && !Array.isArray(value)) {
    if(value.__gasFieldOp==='serverTimestamp')return {__gasTimestampMs:now};
    if(value.__gasFieldOp==='delete')return value;
    var out={}; Object.keys(value).forEach(function(k){if(value[k]!==undefined)out[k]=fsCompatResolveValue_(value[k],now);}); return out;
  }
  if(Array.isArray(value))return value.map(function(x){return fsCompatResolveValue_(x,now)});
  return value;
}
function fsCompatApplyDeletes_(value) {
  if(Array.isArray(value))return value.map(fsCompatApplyDeletes_);
  if(value&&typeof value==='object'){var out={};Object.keys(value).forEach(function(k){if(!(value[k]&&value[k].__gasFieldOp==='delete'))out[k]=fsCompatApplyDeletes_(value[k]);});return out;}
  return value;
}
function fsCompatMergeMaps_(base, patch) {
  Object.keys(patch||{}).forEach(function(k){var v=patch[k];if(v&&v.__gasFieldOp==='delete'){delete base[k];return;}if(v&&typeof v==='object'&&!Array.isArray(v)&&!(v.__gasTimestampMs!==undefined)){var prior=base[k];base[k]=fsCompatMergeMaps_(prior&&typeof prior==='object'&&!Array.isArray(prior)?prior:{},v);}else base[k]=v;});
  return base;
}
function fsCompatSetAtPath_(obj, path, value, remove) {
  path=(Array.isArray(path)?path:[String(path)]).map(String); if(!path.length||path.some(function(p){return !p;}))throw fsCompatError_('INVALID_ARGUMENT','Invalid field path');
  var cur=obj;for(var i=0;i<path.length-1;i++){if(!cur[path[i]]||typeof cur[path[i]]!=='object'||Array.isArray(cur[path[i]]))cur[path[i]]={};cur=cur[path[i]];}
  var key=path[path.length-1];if(value&&value.__gasFieldOp==='delete'){delete cur[key];}else cur[key]=value;
}
function fsCompatDeepClone_(obj){return obj==null?obj:JSON.parse(JSON.stringify(obj));}
function fsCompatGetField_(data, fieldPath, id) {
  if (fieldPath === '__name__' || (Array.isArray(fieldPath)&&fieldPath.length===1&&fieldPath[0]==='__name__')) return id;
  var parts=Array.isArray(fieldPath)?fieldPath:String(fieldPath||'').split('.'); var v=data;
  for(var i=0;i<parts.length;i++){if(v==null)return undefined;v=v[String(parts[i])];}return v;
}
function fsCompatMatchesFilters_(item, filters) {
  return filters.every(function(f){var left=fsCompatGetField_(item.data,f.fieldPath,item.id),right=f.value,op=String(f.op||'==');
    if(right&&typeof right==='object'&&right.__gasTimestampMs!==undefined)right=Number(right.__gasTimestampMs);
    if(left&&typeof left==='object'&&left.__gasTimestampMs!==undefined)left=Number(left.__gasTimestampMs);
    if(op==='==')return fsCompatEqual_(left,right);if(op==='!=')return !fsCompatEqual_(left,right);
    if(op==='in')return Array.isArray(right)&&right.some(function(v){return fsCompatEqual_(left,v);});
    if(op==='not-in')return Array.isArray(right)&&!right.some(function(v){return fsCompatEqual_(left,v);});
    if(op==='array-contains')return Array.isArray(left)&&left.some(function(v){return fsCompatEqual_(v,right);});
    if(op==='array-contains-any')return Array.isArray(left)&&Array.isArray(right)&&left.some(function(v){return right.some(function(r){return fsCompatEqual_(v,r);});});
    if(left===undefined||right===undefined)return false;
    if(op==='<')return left<right;if(op==='<=')return left<=right;if(op==='>')return left>right;if(op==='>=')return left>=right;
    throw fsCompatError_('INVALID_ARGUMENT','Unsupported filter operator '+op);
  });
}
function fsCompatEqual_(a,b){if(a===b)return true;if(a===undefined||b===undefined)return false;try{return JSON.stringify(a)===JSON.stringify(b);}catch(_){return false;}}
function fsCompatSortAndLimit_(docs, orderBy, limit) {
  var out=docs.slice();
  if(Array.isArray(orderBy)&&orderBy.length)out.sort(function(a,b){for(var i=0;i<orderBy.length;i++){var o=orderBy[i],av=fsCompatGetField_(a.data,o.fieldPath,a.id),bv=fsCompatGetField_(b.data,o.fieldPath,b.id);if(av<bv)return String(o.direction||'asc').toLowerCase()==='desc'?1:-1;if(av>bv)return String(o.direction||'asc').toLowerCase()==='desc'?-1:1;}return a.id.localeCompare(b.id);});
  if(Number.isInteger(Number(limit))&&Number(limit)>=0)out=out.slice(0,Number(limit));
  return out;
}
function fsCompatCompactPaths_(sheet, paths) {
  var target={};paths.forEach(function(p){target[p]=true;});
  var last=sheet.getLastRow();if(last<2)return;
  // Only columns A:H are needed for compaction; avoid reading payload/result JSON.
  var rows=sheet.getRange(2,1,last-1,8).getValues(),latest={};
  rows.forEach(function(row,index){if(String(row[0])!=='doc')return;var path=String(row[1]||'');if(!target[path])return;var v=Number(row[7]||0);if(latest[path]===undefined||v>latest[path])latest[path]=v;});
  // Remove older document versions bottom-up. Operation markers are retained for idempotency.
  var remove=[];rows.forEach(function(row,index){if(String(row[0])!=='doc')return;var path=String(row[1]||'');if(target[path]&&Number(row[7]||0)<latest[path])remove.push(index+2);});
  for(var i=remove.length-1;i>=0;i--)sheet.deleteRow(remove[i]);
}

function fsCompatHasFilter_(filters, field, op, expected) {
  return (filters||[]).some(function(f){
    var p=Array.isArray(f.fieldPath)?f.fieldPath:String(f.fieldPath||'').split('.');
    if(p.length!==1||p[0]!==field||String(f.op||'')!==op)return false;
    return expected===undefined || fsCompatSame_(f.value,expected);
  });
}
function fsCompatCanQueryCollection_(actor, collectionPath, filters) {
  var p=collectionPath.split('/'), c=p[0];
  if(c==='users') {
    if(p.length===1)return actor.isAdmin;
    if(p.length===3&&p[2]==='apps')return actor.isAdmin&&p[1]===actor.uid;
    return false;
  }
  if(c==='packerRecords'&&p.length===3&&p[2]==='entries')return actor.active&&(actor.isAdmin||(actor.role==='packer'&&p[1]===actor.uid));
  if(c==='apps'&&p.length===1)return actor.active;
  if(c==='apps'&&p.length===3&&p[2]==='dailyShipmentOrders')return actor.active&&(actor.role!=='packer'||fsCompatHasFilter_(filters,'assignedUid','==',actor.uid));
  if(c==='apps'&&p.length===3&&p[2]==='dailyShipmentReports')return actor.active&&(actor.role!=='packer'||fsCompatHasFilter_(filters,'employeeId','==',String(actor.profile.employeeId||'')));
  if(c==='apps'&&p.length>=3&&(p[2]==='dailyShipmentMigrations'||p[2]==='dailyShipmentMigrationBackups'))return actor.isAdmin;
  if(c==='config'&&p.length===1)return actor.active;
  if(c==='config'&&p.length===3&&p[2]==='plants')return actor.active;
  if(c==='packingOrders') {
    if(actor.isAdmin)return true;
    if(!actor.active||actor.role!=='packer')return false;
    return fsCompatHasFilter_(filters,'assignedUid','==',actor.uid) || (fsCompatHasFilter_(filters,'orderType','==','ĐD') && fsCompatHasFilter_(filters,'status','==','completed'));
  }
  if(c==='shipmentTrackingClaims'||c==='dailyShipmentScans')return actor.active;
  if(c==='notifications')return actor.isAdmin||fsCompatHasFilter_(filters,'userId','==',actor.uid);
  if(c==='payroll'||c==='salaryAdvances'||c==='reports')return actor.isAdmin||(actor.active&&actor.role==='packer'&&fsCompatHasFilter_(filters,'employeeUid','==',actor.uid));
  if(c==='inventory'||c==='inventoryLogs'||c==='shipmentOcr'||c==='auditLogs')return actor.isAdmin;
  if(c==='quotes'||c==='quotation')return actor.isAdmin||actor.isProcurement;
  if(c==='syncState'||c==='appState'||c==='payrollSettings'||c==='salarySettings'||c==='priceSettings'||c==='categories'||c==='plantCategories'||c==='sizes'||c==='employees')return actor.active;
  return false;
}

function fsCompatCanReadPath_(actor, path, data, isQuery) {
  var p=path.split('/'), c=p[0];
  if(c==='users') { if(p.length===2)return actor.isAdmin || (!isQuery && p[1]===actor.uid); if(p.length>=4&&p[2]==='apps')return actor.isAdmin&&p[1]===actor.uid; return false; }
  if(c==='packerRecords'&&p.length===4&&p[2]==='entries')return actor.isAdmin||(actor.active&&actor.role==='packer'&&p[1]===actor.uid);
  if(c==='apps'&&p.length===2)return actor.active;
  if(c==='apps'&&p.length>=4&&p[2]==='dailyShipmentOrders')return actor.active&&(actor.role!=='packer'||String(data&&data.assignedUid||'')===actor.uid);
  if(c==='apps'&&p.length>=4&&p[2]==='dailyShipmentReports')return actor.active&&(actor.role!=='packer'||String(data&&data.employeeId||'')===String(actor.profile.employeeId||''));
  if(c==='apps'&&p.length>=4&&(p[2]==='dailyShipmentMigrations'||p[2]==='dailyShipmentMigrationBackups'))return actor.isAdmin;
  if(c==='config'||c==='categories'||c==='plantCategories'||c==='sizes'||c==='employees'||c==='priceSettings'||c==='payrollSettings'||c==='salarySettings'||c==='syncState'||c==='appState')return actor.active;
  if(c==='packingOrders')return actor.isAdmin||(actor.active&&actor.role==='packer'&&(String(data&&data.assignedUid||'')===actor.uid||(String(data&&data.orderType||'')==='ĐD'&&String(data&&data.status||'')==='completed')));
  if(c==='shipmentTrackingClaims'||c==='dailyShipmentScans')return actor.active;
  if(c==='notifications')return actor.isAdmin||(String(data&&data.userId||'')===actor.uid);
  if(c==='payroll'||c==='salaryAdvances'||c==='reports')return actor.isAdmin||(actor.active&&actor.role==='packer'&&String(data&&data.employeeUid||'')===actor.uid);
  if(c==='inventory'||c==='inventoryLogs'||c==='shipmentOcr')return actor.isAdmin;
  if(c==='quotes'||c==='quotation')return actor.isAdmin||actor.isProcurement;
  if(c==='auditLogs')return actor.isAdmin;
  return false;
}
function fsCompatCanWritePath_(actor,path,write,before,after,finalDocs,changes) {
  var p=path.split('/'),c=p[0],type=String(write.type||'set');
  if(c==='users'&&p.length===2){if(actor.isAdmin)return fsCompatValidateUserProfile_(after);return p[1]===actor.uid&&!before&&after&&String(after.role||'')==='viewer'&&after.employeeId===undefined&&after.employeeName===undefined;}
  if(c==='users'&&p.length>=4&&p[2]==='apps')return actor.isAdmin&&p[1]===actor.uid;
  if(c==='packerRecords'&&p.length===4&&p[2]==='entries')return actor.isAdmin||(actor.active&&actor.role==='packer'&&p[1]===actor.uid);
  if(c==='apps'&&p.length===2)return actor.active&&['admin','manager','warehouse'].indexOf(actor.role)>=0||actor.active&&actor.isProcurement;
  if(c==='apps'&&p.length>=4&&p[2]==='dailyShipmentOrders'){
    if(actor.active&&(['admin','manager','warehouse'].indexOf(actor.role)>=0||actor.isProcurement))return true;
    return actor.active&&actor.role==='packer'&&after&&String(after.recordKind||'')==='order'&&String(after.assignedUid||'')===actor.uid&&String(after.trackingNo||'')===String(p[p.length-1])&&after.record&&String(after.record.trackingNo||'')===String(p[p.length-1])&&fsCompatDailyScanMatches_(actor,String(p[p.length-1]),finalDocs);
  }
  if(c==='apps'&&p.length>=4&&p[2]==='dailyShipmentReports'){
    if(actor.active&&(['admin','manager','warehouse'].indexOf(actor.role)>=0||actor.isProcurement))return true;
    return actor.active&&actor.role==='packer'&&after&&String(after.recordKind||'')==='report'&&String(after.trackingNo||'')===String(p[p.length-1])&&after.record&&String(after.record.status||'')==='recorded'&&String(after.employeeId||'')===String(actor.profile.employeeId||'')&&String(after.record.employeeId||'')===String(actor.profile.employeeId||'')&&fsCompatDailyScanMatches_(actor,String(p[p.length-1]),finalDocs);
  }
  if(c==='apps'&&p.length>=4&&(p[2]==='dailyShipmentMigrations'||p[2]==='dailyShipmentMigrationBackups'))return actor.isAdmin;
  if(c==='config'&&(p.length===2||(p.length===4&&p[2]==='plants')))return actor.isAdmin||actor.isProcurement;
  if(c==='packingOrders'){
    if(actor.isAdmin)return true;
    if(!actor.active||actor.role!=='packer'||!before||!after||String(before.assignedUid||'')!==actor.uid)return false;
    if(String(before.status||'')==='completed'&&String(before.orderType||'')==='ĐD'&&before.shipmentOcrPending===true){
      var allowedOcr=['completionImage','completionImages','completedBy','shipment','shipmentTrackingNo','shipmentCarrier','shipmentCustomerName','shipmentOcrText','shipmentOcrPending','shipmentOcrStatus','shipmentOcrCompletedAtMs','shipmentOcrCompletedBy'];
      return fsCompatOnlyChangedKeys_(before,after,allowedOcr)&&String(after.completedBy||'')===String(before.completedBy||'')&&Array.isArray(after.completionImages)&&after.completionImages.length===2&&!!after.completionImages[0]&&!!after.completionImages[1]&&fsCompatValidTracking_(String(after.shipmentTrackingNo||''))&&fsCompatClaimMatchesOrder_(String(after.shipmentTrackingNo||''),p[1],finalDocs);
    }
    var allowed=['status','completionImage','completionImages','completedAtMs','completedDate','completedAt','completedBy','completionRecordedBy','shipment','shipmentTrackingNo','shipmentCarrier','shipmentCustomerName','shipmentOcrText','shipmentOcrPending','shipmentOcrStatus'];
    if(!fsCompatOnlyChangedKeys_(before,after,allowed)||String(before.status||'')!=='pending'||String(after.status||'')!=='completed'||!String(after.completionImage||'')||!Array.isArray(after.completionImages)||after.completionImages.length!==1||!String(after.completionImages[0]||'')||String(after.completedBy||'')!==actor.uid)return false;
    if(String(before.orderType||'')==='ĐD')return after.shipmentOcrPending===true;
    if(String(before.orderType||'')==='ĐN')return after.shipmentOcrPending===false;
    if(String(before.orderType||'')==='TT')return fsCompatValidTracking_(String(after.shipmentTrackingNo||''))&&!!after.shipmentCarrier&&!!after.shipmentOcrText&&after.shipmentOcrPending===false&&fsCompatClaimMatchesOrder_(String(after.shipmentTrackingNo||''),p[1],finalDocs);
    return false;
  }
  if(c==='shipmentTrackingClaims'){
    if(actor.isAdmin)return true;
    if(!actor.active||actor.role!=='packer'||!after)return false;
    var tracking=String(p[1]||''),existing=before;
    if(!fsCompatValidTracking_(tracking)||String(after.trackingNo||'')!==tracking)return false;
    if(existing&&String(existing.orderId||'')!==String(after.orderId||''))return false;
    if(String(after.source||'')==='daily_shipment_scan')return fsCompatDailyScanMatches_(actor,tracking,finalDocs)&&String(after.orderId||'')==='daily_'+tracking&&String(after.status||'')==='recorded'&&String(after.employeeId||'')===String(actor.profile.employeeId||'')&&after.wageRecorded===true;
    var order=finalDocs['packingOrders/'+String(after.orderId||'')];
    if(!order||String(after.completedBy||'')!==actor.uid)return false;
    return (String(order.orderType||'')==='ĐD'&&String(order.status||'')==='completed'&&order.shipmentOcrPending===true)||(String(order.orderType||'')==='TT'&&String(order.assignedUid||'')===actor.uid&&String(order.status||'')==='pending');
  }
  if(c==='dailyShipmentScans'){
    if(actor.isAdmin)return true;
    if(!actor.active||actor.role!=='packer'||!after||!fsCompatValidTracking_(p[1]))return false;
    if(!before){var report=after.report||{};return String(after.trackingNo||'')===p[1]&&String(after.actorUid||'')===actor.uid&&String(after.employee||'')===String(actor.profile.employeeName||'')&&String(after.employeeId||'')===String(actor.profile.employeeId||'')&&String(report.trackingNo||'')===p[1]&&String(report.status||'')==='recorded'&&String(report.employee||'')===String(actor.profile.employeeName||'')&&String(report.employeeId||'')===String(actor.profile.employeeId||'')&&report.wageRecorded===true&&typeof report.laborPay==='number'&&report.laborPay>=0&&Array.isArray(report.items)&&report.items.length>0&&String(after.status||'')==='recorded'&&String(after.source||'')==='daily_shipment_scan'&&Number(after.schemaVersion)===1&&fsCompatDailyScanMatches_(actor,p[1],finalDocs);}
    if(String(before.actorUid||'')!==actor.uid)return false;
    if(String(before.status||'')==='voided'&&String(after.status||'')==='recorded')return fsCompatDailyScanMatches_(actor,p[1],finalDocs);
    var oldReport=before.report||{},newReport=after.report||{},oldPatch=before.orderPatch||{},newPatch=after.orderPatch||{};
    return String(before.status||'')==='recorded'&&String(after.status||'')==='recorded'&&fsCompatSame_(before.actorUid,after.actorUid)&&fsCompatOnlyChangedKeys_(oldReport,newReport,['photoRef','photoUploadedAtMs'])&&fsCompatOnlyChangedKeys_(oldPatch,newPatch,['photoRef','photoUploadedAtMs'])&&fsCompatOnlyChangedKeys_(before,after,['report','orderPatch','updatedAtMs']);
  }
  if(c==='notifications')return actor.isAdmin||String(before&&before.userId||after&&after.userId||'')===actor.uid;
  if(c==='inventory'||c==='inventoryLogs'||c==='payroll'||c==='salaryAdvances'||c==='shipmentOcr')return actor.isAdmin;
  if(c==='reports')return actor.isAdmin;
  if(c==='quotes'||c==='quotation')return actor.isAdmin||actor.isProcurement;
  if(c==='auditLogs')return type==='delete'||!!after?actor.isAdmin||(!before&&actor.active):actor.isAdmin;
  if(c==='syncState'||c==='appState'||c==='payrollSettings'||c==='salarySettings'||c==='priceSettings')return actor.isAdmin;
  if(c==='categories'||c==='plantCategories'||c==='sizes')return actor.isAdmin||actor.isProcurement;
  if(c==='employees')return actor.isAdmin;
  return false;
}
function fsCompatValidateUserProfile_(data){if(!data)return true;var roles=['admin','manager','packer','warehouse','procurement','purchaser','purchasing','purchasing_staff','procurement_staff','thu_mua','nhan_vien_thu_mua','viewer'];if(roles.indexOf(String(data.role||''))<0)return false;if(data.role==='admin'&&(data.employeeId!==undefined||data.employeeName!==undefined))return false;var employeeRoles=['packer','procurement','purchaser','purchasing','purchasing_staff','procurement_staff','thu_mua','nhan_vien_thu_mua'];if(employeeRoles.indexOf(String(data.role||''))>=0&&(!(typeof data.employeeId==='string'&&data.employeeId)||!(typeof data.employeeName==='string'&&data.employeeName)))return false;return true;}
function fsCompatOnlyChangedKeys_(before,after,allowed){var keys={};Object.keys(before||{}).concat(Object.keys(after||{})).forEach(function(k){keys[k]=true;});return Object.keys(keys).every(function(k){if(fsCompatSame_((before||{})[k],(after||{})[k]))return true;return allowed.indexOf(k)>=0;});}
function fsCompatStableValue_(v){if(v===undefined)return 'undefined';if(v===null||typeof v!=='object')return JSON.stringify(v);if(Array.isArray(v))return '['+v.map(fsCompatStableValue_).join(',')+']';return '{'+Object.keys(v).sort().map(function(k){return JSON.stringify(k)+':'+fsCompatStableValue_(v[k]);}).join(',')+'}';}
function fsCompatSame_(a,b){return fsCompatStableValue_(a)===fsCompatStableValue_(b);}
function fsCompatValidTracking_(t){return /^(GHVN[A-Z0-9]{4,26}|VNGH[0-9]{8,12}|862[0-9]{9}|530[0-9]{9})$/.test(String(t||''));}
function fsCompatClaimMatchesOrder_(tracking,orderId,finalDocs){var claim=finalDocs['shipmentTrackingClaims/'+tracking];return !!claim&&String(claim.orderId||'')===String(orderId||'');}
function fsCompatDailyScanMatches_(actor,tracking,finalDocs){var scan=finalDocs['dailyShipmentScans/'+tracking],report=scan&&scan.report;return !!scan&&String(scan.trackingNo||'')===tracking&&String(scan.status||'')==='recorded'&&String(scan.actorUid||'')===actor.uid&&String(report&&report.trackingNo||'')===tracking&&String(report&&report.status||'')==='recorded'&&String(report&&report.employeeId||'')===String(actor.profile.employeeId||'')&&report.wageRecorded===true;}

/* END MERGED PHASE 2 FIRESTORE COMPATIBILITY HANDLER */
