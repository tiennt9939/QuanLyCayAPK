'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm'), assert = require('assert');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const java = fs.readFileSync(path.join(root, 'app/src/main/java/com/quanlycay/apk/MainActivity.java'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const preflight = fs.readFileSync(path.join(root, 'tools/preflight.py'), 'utf8');
assert(/versionName\s*=\s*"26\.2\.136"/.test(gradle) && /versionCode\s*=\s*188/.test(gradle), 'V26.2.137 release metadata missing');
assert((java.match(/@JavascriptInterface/g)||[]).length===32, 'native bridge count must include durable state APIs and GAS transport');
for (const token of ['loadLocalAppState','saveLocalAppState','getLocalAppStateSavedAtMs','"state-" + slot + ".json"','"active-state.txt"','SHA-256','readVerifiedAppStateSlot']) assert(java.includes(token), `native rotating storage is missing ${token}`);
assert(html.includes('function persistNativeAppState(serialized,options={}){'), 'verified native persistence helper missing');
assert(html.includes("const bridge=window.AndroidBridge;"), 'native storage must use the existing Android bridge');
assert(html.includes("const x=JSON.parse(localStorage.getItem('quanlycay')||'null')")===false, 'legacy-only load path must be replaced by native-first loading');
assert(html.includes('First launch on the native store migrates the legacy JSON'), 'legacy migration must be documented in source');
assert(html.includes('preserveLocalTimestamp:!!legacyRaw'), 'legacy migration must preserve its last successful-save timestamp');
assert(html.includes('The native snapshot now contains the complete canonical queue'), 'large queue cache must migrate to durable native state before being released');
assert(html.includes('if(!snap.exists||localTs>cloudTs)'), 'dirty local state must not overwrite a newer Cloud snapshot');
assert(html.includes('Cloud is newer than the last verified local save'), 'stale local dirty state must reconcile from Cloud');
assert(preflight.includes('assert ann==32'), 'preflight must check new bridge surface');

// Test durable-first write in a simulated Android bridge while localStorage is over quota.
const data = { catalog: [{name:'Vàng bạc'}], daily: [], dailyShipmentOrders: [{trackingNo:'A1',status:'recorded'}],
  payload: 'x'.repeat(7000) };
const store = new Map([['quanlycay', JSON.stringify({legacy:'x'.repeat(8000)})], ['roll_cay_daily_shipment_state_backup_v1','KEEP-BACKUP']]);
const native = { state: null, savedAt: 0, saveLocalAppState(raw) { this.state=String(raw); this.savedAt=Date.now(); return true; }, loadLocalAppState() { return this.state; }, getLocalAppStateSavedAtMs(){ return this.savedAt; } };
const localStorage = { getItem:k=>store.has(k)?store.get(k):null, setItem:(k,v)=>store.set(k,String(v)), removeItem:k=>store.delete(k), get length(){return store.size}, key:i=>[...store.keys()][i]||null };
const context = { window:{AndroidBridge:native,DriveStorage:{toLocalCacheValue:v=>v,connected:()=>true}}, localStorage, D:data,
  invalidateInventoryIndexes(){}, isCompletedOrderOlderThanCacheWindow(){return false}, dailyShipmentBackupMatchesSnapshot(){return false},
  countEmbeddedImages(v){let n=0;const walk=x=>{if(typeof x==='string'){if(/^data:image\//.test(x))n++;}else if(Array.isArray(x))x.forEach(walk);else if(x&&typeof x==='object')Object.values(x).forEach(walk)};walk(v);return n;},
  toast(){}, console, Date, JSON, String, Number, Array, Object, Promise, setTimeout, clearTimeout, document:{visibilityState:'visible'} };
vm.createContext(context);
const helperStart=html.indexOf('function persistNativeAppState(serialized,options={}){');
const saveStart=html.indexOf('function localSaveOnly(){', helperStart);
const saveEnd=html.indexOf('\nfunction isEmbeddedImageData', saveStart);
assert(helperStart>=0&&saveStart>helperStart&&saveEnd>saveStart,'storage function extraction boundaries invalid');
vm.runInContext(html.slice(helperStart,saveEnd)+';this.runSave=localSaveOnly;', context, {filename:'durable-storage.js'});
assert.strictEqual(context.runSave(), true, 'native storage should succeed independently of WebView quota');
assert.strictEqual(native.state, JSON.stringify(data), 'native store should contain complete state');
assert.strictEqual(store.has('quanlycay'), false, 'oversized legacy localStorage snapshot must only be removed after verified native write');
assert.strictEqual(store.get('roll_cay_daily_shipment_state_backup_v1'), 'KEEP-BACKUP', 'unverified canonical queue recovery backup must remain untouched');

// A queue backup may be removed only after the complete matching queue is stored durably.
const queued = {catalog:[],daily:[],dailyShipmentOrders:[{trackingNo:'Q1',status:'recorded'}],dailyShipmentReports:[{trackingNo:'Q1',status:'recorded'}]};
const qStore = new Map([['roll_cay_daily_shipment_state_backup_v1', JSON.stringify({orders:queued.dailyShipmentOrders,reports:queued.dailyShipmentReports})]]);
const qNative = {state:null,saveLocalAppState(raw){this.state=String(raw);return true},loadLocalAppState(){return this.state},getLocalAppStateSavedAtMs(){return Date.now()}};
const qStorage={getItem:k=>qStore.has(k)?qStore.get(k):null,setItem:(k,v)=>qStore.set(k,String(v)),removeItem:k=>qStore.delete(k),get length(){return qStore.size},key:i=>[...qStore.keys()][i]||null};
const qctx={window:{AndroidBridge:qNative,DriveStorage:{toLocalCacheValue:v=>v,connected:()=>true}},localStorage:qStorage,D:queued, invalidateInventoryIndexes(){},isCompletedOrderOlderThanCacheWindow(){return false},dailyShipmentBackupMatchesSnapshot(){return true},countEmbeddedImages(){return 0},toast(){},console,Date,JSON,String,Number,Array,Object,Promise,setTimeout,clearTimeout,document:{visibilityState:'visible'}};
vm.createContext(qctx);vm.runInContext(html.slice(helperStart,saveEnd)+';this.runSave=localSaveOnly;',qctx);
assert.strictEqual(qctx.runSave(),true,'durable queue snapshot should save');
assert.strictEqual(JSON.parse(qNative.state).dailyShipmentOrders.length,1,'native main state must retain canonical queue arrays');
assert.strictEqual(qStore.has('roll_cay_daily_shipment_state_backup_v1'),false,'a verified duplicate queue backup can be removed after durable commit');

// Failed native write must retain the legacy snapshot and report failure instead of deleting it.
const failContext = {...context, localStorageDiagnostics:()=>({keys:[]}), window:{AndroidBridge:{saveLocalAppState(){return false},loadLocalAppState(){return null},getLocalAppStateSavedAtMs(){return 0}},DriveStorage:{toLocalCacheValue:v=>v,connected:()=>false}}, localStorage:{getItem:k=>k==='quanlycay'?'OLD-SAFE-SNAPSHOT':null, setItem(){const e=new Error('quota');e.name='QuotaExceededError';throw e}, removeItem(){throw new Error('should not remove legacy state')}, get length(){return 1}, key(){return 'quanlycay'}}};
vm.createContext(failContext);
vm.runInContext(html.slice(helperStart,saveEnd)+';this.runSave=localSaveOnly;', failContext, {filename:'durable-storage-fallback.js'});
assert.strictEqual(failContext.runSave(), false, 'if native and browser stores fail, report unsaved state');
assert(failContext.localStorage.getItem('quanlycay')==='OLD-SAFE-SNAPSHOT', 'failed migration must retain last known-good local snapshot');

// Native-first boot and old localStorage migration are covered through isolated load() tests.
const loadStart=html.indexOf('function load(){');
const loadEnd=html.indexOf('\nfunction activeCatalog()', loadStart);
assert(loadStart>=0&&loadEnd>loadStart,'load function boundaries invalid');
const bridgeState = JSON.stringify({catalog:[{name:'Native'}],daily:[],employees:['A'],rates:[],opening:{}});
const bootStore = new Map([['quanlycay', JSON.stringify({catalog:[{name:'Stale local'}],daily:[]})]]);
const bootStorage = {getItem:k=>bootStore.has(k)?bootStore.get(k):null,setItem:(k,v)=>bootStore.set(k,String(v)),removeItem:k=>bootStore.delete(k)};
const boot = {window:{AndroidBridge:{loadLocalAppState:()=>bridgeState,saveLocalAppState:()=>true,getLocalAppStateSavedAtMs:()=>Date.now()+1000}},localStorage:bootStorage,JSON,structuredClone,DEFAULT_DATA:{catalog:[],rates:[],employees:[],opening:{},daily:[]},repairCanonicalConfig(){},persistNativeAppState(){bootStore.delete('quanlycay');return true},console};
vm.createContext(boot);vm.runInContext(html.slice(loadStart,loadEnd)+';this.runLoad=load;',boot);
boot.runLoad();
assert.strictEqual(boot.D.catalog[0].name,'Native','verified native snapshot must be preferred over stale localStorage');
assert.strictEqual(bootStore.has('quanlycay'),false,'stale duplicate localStorage should be removed only after native snapshot parsed');
const legacyData = JSON.stringify({catalog:[{name:'Legacy'}],daily:[],employees:['B'],rates:[],opening:{}});
const legacyStore = new Map([['quanlycay', legacyData]]);
const legacyStorage = {getItem:k=>legacyStore.has(k)?legacyStore.get(k):null,setItem:(k,v)=>legacyStore.set(k,String(v)),removeItem:k=>legacyStore.delete(k)};
let migratedState='';
const legacyCtx={window:{AndroidBridge:{loadLocalAppState:()=>null,saveLocalAppState:()=>true,getLocalAppStateSavedAtMs:()=>Date.now()}},localStorage:legacyStorage,JSON,structuredClone,DEFAULT_DATA:{catalog:[],rates:[],employees:[],opening:{},daily:[]},repairCanonicalConfig(){},persistNativeAppState(raw){migratedState=String(raw);legacyStore.delete('quanlycay');return true},console};
vm.createContext(legacyCtx);vm.runInContext(html.slice(loadStart,loadEnd)+';this.runLoad=load;',legacyCtx);legacyCtx.runLoad();
assert.strictEqual(legacyCtx.D.catalog[0].name,'Legacy','first-run migration must preserve legacy state');
assert.strictEqual(JSON.parse(migratedState).catalog[0].name,'Legacy','legacy state must be written to native storage before cleanup');
assert.strictEqual(legacyStore.has('quanlycay'),false,'legacy browser snapshot is removable after verified migration');
console.log('DURABLE NATIVE STATE PASS: rotating snapshots, native-first recovery, legacy migration, quota independence, queue preservation and safe fallback');
