'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8');
const preflight=fs.readFileSync(path.join(root,'tools/preflight.py'),'utf8');
assert(/versionName\s*=\s*"[0-9]+(?:\.[0-9]+)+"/.test(gradle)&&/versionCode\s*=\s*\d+/.test(gradle),'shared PDF queue sync fix version metadata must be current');
assert(preflight.includes('shared_daily_shipment_cloud_sync_test.js'),'preflight must require this cross-device queue regression test');
assert(html.includes('sharedRef().onSnapshot(snap=>'),'Admin must watch the shared app document for live PDF queue updates');
assert(html.includes("if(r==='admin')startSharedAppWatch();"),'shared queue listener must be restricted to Admin sessions');
assert(html.includes("window.__mergeDailyShipmentSharedSnapshot({...rootSnapshot,__dailyShipmentOrders:shipmentSnapshot.orders,__dailyShipmentReports:shipmentSnapshot.reports},{render:false,source:'reconcile-read'})"),'startup reconciliation must hydrate split Cloud queues before a possible local-dirty push');
const pushStart=html.indexOf('async function pushNowUnlocked(){');
const pushEnd=html.indexOf('  function pushNow(){',pushStart);
assert(pushStart>=0&&pushEnd>pushStart,'serialized Firestore push implementation missing');
assert(html.includes('let pushInFlight=null,pushAgain=false;')&&html.includes('while(pushAgain&&passes<3'), 'concurrent pushes must be serialized and edits during writes must trigger a follow-up pass');
const pushBody=html.slice(pushStart,pushEnd);
assert(!pushBody.includes('const latest=await ref.get()'),'whole-app push must avoid redundant root fetch');
assert(pushBody.includes('const currentRootSnap=await dailyShipmentAwaitWithTimeout(ref.get(),18000,')&&pushBody.includes('shipmentDataDeltaUpdateArguments(currentRoot.data||{},safeData,rootPatch)'),'push must read root once and update only changed app fields');
assert(!pushBody.includes('readDailyShipmentCollections(')&&!pushBody.includes('persistDailyShipmentCollections')&&pushBody.includes('delete appSnapshot.dailyShipmentOrders'),'routine sync must not scan or rewrite the split PDF queue/report history');
assert(html.includes('dailyShipmentMergeMarkerMaps(D.dailyShipmentClearedTrackingNos,cloudData.dailyShipmentClearedTrackingNos,root.dailyShipmentClearedTrackingNos)'),'shared queue hydration must merge deletion tombstones by newest marker timestamp');
assert(html.includes('dailyShipmentApplyResetMarkers();'),'shared queue hydration must still honor date-reset and clear markers');
assert(html.includes("sharedRef().collection('dailyShipmentOrders')")&&html.includes("sharedRef().collection('dailyShipmentReports')"),'unbounded PDF queues and reports must be split into dedicated per-record collections');
assert(html.includes('dailyShipmentStorageSchema:DAILY_SHIPMENT_STORAGE_SCHEMA'),'the app root must carry a migration schema marker');
assert(html.includes("dailyShipmentAwaitWithTimeout(ensureDailyShipmentStorageMigrated(),16000,'chuẩn bị kho dữ liệu chung')"),'Admin must verify migration with a bounded timeout before writing split queue data');
assert(html.includes('if(estimate.estimatedDocumentBytes>estimate.writeSafetyLimitBytes)'),'root writes need a safety-size preflight below Firestore 1 MiB');


const markerStart=html.indexOf('function dailyShipmentMergeMarkerMaps(');
const markerEnd=html.indexOf('function dailyShipmentMergeSharedQueueRows(',markerStart);
assert(markerStart>=0&&markerEnd>markerStart,'marker merge helper is missing');
const markerSandbox={};
vm.runInNewContext(html.slice(markerStart,markerEnd)+';this.mergeMarkers=dailyShipmentMergeMarkerMaps;',markerSandbox);
const markerMerge=markerSandbox.mergeMarkers;
assert.strictEqual(markerMerge({'2026-10-22':300},{'2026-10-22':200})['2026-10-22'],300,'newer local reset tombstones must not be replaced by an older Cloud marker');
assert.strictEqual(markerMerge({}, {'862652114050':100})['862652114050'],100,'Cloud clear tombstones must reach the secondary device');

const helperStart=html.indexOf('function dailyShipmentMergeSharedQueueRows(');
const helperEnd=html.indexOf('function dailyShipmentApplyResetMarkers(',helperStart);
assert(helperStart>=0&&helperEnd>helperStart,'pure shared queue merge helper is missing');
const sandbox={normalizeTracking(v){return String(v||'').replace(/[^A-Za-z0-9]/g,'').toUpperCase()}};
vm.runInNewContext(html.slice(helperStart,helperEnd)+';this.mergeQueue=dailyShipmentMergeSharedQueueRows;',sandbox);
const merge=sandbox.mergeQueue;
const cloudRows=[
 {trackingNo:'862652114050',date:'2026-10-22',importedAtMs:100,products:[{productName:'Nguyệt quế Thái',sku:'NQT-C9',qty:1}],status:'imported',assignmentRevision:0},
 {trackingNo:'862602696370',date:'2026-10-22',importedAtMs:101,products:[{productName:'Táo Thái sân bóng',sku:'TAO-C9',qty:1}],status:'imported',assignmentRevision:0}
];
let merged=merge([],cloudRows);
assert.strictEqual(merged.length,2,'empty second device must hydrate every cloud PDF label');
assert.strictEqual(merged[0].products[0].sku,'NQT-C9','product/SKU evidence must be preserved from Cloud');
merged=merge([{...cloudRows[0],assignedUid:'luan-uid',assignedEmployeeName:'Luân nhỏ',assignmentRequired:true,assignmentRevision:2,assignedAtMs:200}],cloudRows);
assert.strictEqual(merged.length,2,'merge must not duplicate rows by tracking number');
assert.strictEqual(merged.find(x=>x.trackingNo==='862652114050').assignedUid,'luan-uid','newer cloud/local assignment fields must survive merge');
merged=merge([{...cloudRows[0],status:'recorded',employee:'Luân nhỏ',laborPay:4000,assignmentRevision:1}],cloudRows);
const recorded=merged.find(x=>x.trackingNo==='862652114050');
assert.strictEqual(recorded.status,'recorded','a stale imported snapshot must never downgrade an already recorded label');
assert.strictEqual(recorded.laborPay,4000,'recorded payroll evidence must survive a stale queue snapshot');
merged=merge(cloudRows,[]);
assert.strictEqual(merged.length,2,'a stale/empty cloud read must not erase rows already imported locally before a successful push');
merged=merge(cloudRows,[{...cloudRows[0],assignedUid:'luan-uid',assignedEmployeeName:'Luân nhỏ',assignmentRequired:true,assignmentRevision:1,assignedAtMs:200}]);
assert.strictEqual(merged.length,2,'merging same local/remote IDs must stay idempotent');
assert.strictEqual(merged[0].assignedUid,'luan-uid','new server assignment must appear on second device');
console.log('SHARED DAILY SHIPMENT CLOUD SYNC TEST PASS');
