/* One-time, additive Firestore -> GAS/Sheets copy. Does not delete or modify source Firestore. */
(function (global) {
  'use strict';
  const ROOT_COLLECTIONS = [
    'apps','config','packingOrders','users','dailyShipmentScans','shipmentTrackingClaims',
    'notifications','inventory','inventoryLogs','payroll','salaryAdvances','reports','quotes',
    'quotation','shipmentOcr','auditLogs','syncState','appState','payrollSettings','salarySettings',
    'priceSettings','categories','plantCategories','sizes','employees','packerRecords'
  ];
  const PAGE_SIZE = 150;
  const MAX_BATCH_DOCS = 40;
  const MAX_BATCH_CHARS = 2 * 1024 * 1024;
  const KNOWN_NESTED = {
    users: ['apps'],
    config: ['plants'],
    packerRecords: ['entries'],
    appsRoot: ['dailyShipmentOrders','dailyShipmentReports','dailyShipmentMigrations','dailyShipmentMigrationBackups'],
    migrationBackup: ['snapshots','orders','reports','legacyPackingOrders'],
    migrationSnapshot: ['orders','reports','legacyPackingOrders']
  };

  function utf8Length(text) {
    try { return new TextEncoder().encode(text).length; }
    catch (_) { return unescape(encodeURIComponent(text)).length; }
  }
  function toGasValue(value, seen) {
    if (value === null || value === undefined) return value === undefined ? undefined : null;
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') return value;
    if (value instanceof Date) return { __gasTimestampMs: value.getTime() };
    if (typeof value.toMillis === 'function' && typeof value.toDate === 'function') return { __gasTimestampMs: value.toMillis() };
    if (typeof value.latitude === 'number' && typeof value.longitude === 'number' && Object.keys(value).length === 0) return { latitude:value.latitude, longitude:value.longitude };
    if (Array.isArray(value)) return value.map(v => toGasValue(v, seen));
    if (typeof value === 'object') {
      if (seen && seen.has(value)) throw new Error('Circular Firestore value cannot be migrated');
      const stack = seen || new Set(); stack.add(value);
      if (typeof value.path === 'string' && value.firestore) { stack.delete(value); return { __gasDocumentPath:value.path }; }
      const out = {};
      Object.keys(value).forEach(key => { const v=toGasValue(value[key],stack); if(v!==undefined)out[key]=v; });
      stack.delete(value); return out;
    }
    throw new Error('Unsupported Firestore value type: ' + typeof value);
  }
  function stable(value) {
    if (value && typeof value.toMillis === 'function') return 'T' + value.toMillis();
    if (value && typeof value === 'object' && Object.prototype.hasOwnProperty.call(value,'__gasTimestampMs')) return 'T' + Number(value.__gasTimestampMs);
    if (Array.isArray(value)) return '['+value.map(stable).join(',')+']';
    if (value && typeof value === 'object') return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+stable(value[k])).join(',')+'}';
    return JSON.stringify(value);
  }
  function checksum(rows) {
    let a=0x811c9dc5,b=0x9e3779b9,totalBytes=0;
    // Retain only a small digest per document; never keep every plant/order payload in WebView memory.
    const sorted=rows.slice().sort((x,y)=>x.path.localeCompare(y.path));
    for(const row of sorted){const text=row.path+'\n'+row.digest+'\n'+row.bytes+'\n';totalBytes+=Number(row.bytes||0);for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);a=Math.imul(a^c,0x01000193);b=Math.imul(b^(c+i),0x85ebca6b);}}
    return 'fnv32x2-'+(a>>>0).toString(16).padStart(8,'0')+(b>>>0).toString(16).padStart(8,'0')+'-docs'+sorted.length+'-payloadBytes'+totalBytes;
  }
  function hashText(text) { let a=0x811c9dc5,b=0x9e3779b9;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);a=Math.imul(a^c,0x01000193);b=Math.imul(b^(c+i),0x85ebca6b);}return (a>>>0).toString(16).padStart(8,'0')+(b>>>0).toString(16).padStart(8,'0'); }
  function sleepYield() { return new Promise(resolve => setTimeout(resolve, 0)); }

  function childCollectionsForDocument(docPath) {
    const p=docPath.split('/');
    if(p.length===2&&p[0]==='users')return KNOWN_NESTED.users;
    if(p.length===2&&p[0]==='config')return KNOWN_NESTED.config;
    if(p.length===2&&p[0]==='packerRecords')return KNOWN_NESTED.packerRecords;
    if(p.length===2&&p[0]==='apps'&&p[1]==='roll-cay-canh')return KNOWN_NESTED.appsRoot;
    if(p.length===4&&p[0]==='apps'&&(p[2]==='dailyShipmentMigrations'||p[2]==='dailyShipmentMigrationBackups'))return KNOWN_NESTED.migrationBackup;
    if(p.length===6&&p[0]==='apps'&&p[2]==='dailyShipmentMigrationBackups'&&p[4]==='snapshots')return KNOWN_NESTED.migrationSnapshot;
    return [];
  }

  async function readCollectionPages(collectionRef, nativeFieldPath, onPage) {
    let last=null, total=0;
    while(true) {
      let query=collectionRef.orderBy(nativeFieldPath.documentId()).limit(PAGE_SIZE);
      if(last)query=query.startAfter(last);
      const snapshot=await query.get();
      if(!snapshot.docs.length)break;
      total+=snapshot.docs.length;
      await onPage(snapshot.docs);
      last=snapshot.docs[snapshot.docs.length-1];
      if(snapshot.docs.length<PAGE_SIZE)break;
      await sleepYield();
    }
    return total;
  }

  async function migrateFirestoreToGas(sourceDb, gasDb, nativeFieldPath, options) {
    options=options||{};
    if(!sourceDb||!gasDb||gasDb._gasCompat!==true)throw new Error('The source Firestore and GAS adapter instances are both required');
    if(!nativeFieldPath||typeof nativeFieldPath.documentId!=='function')throw new Error('Original Firebase FieldPath must be captured before creating the GAS adapter');
    const summary={startedAt:new Date().toISOString(),finishedAt:null,source:'Firestore',destination:'Apps Script + Google Sheets',deletedFromSource:false,collections:{},totalDocuments:0,totalBytes:0,allDocumentsChecksum:'',verifiedDocuments:0,batches:0};
    const seenPaths=new Set(), allSummaryRows=[];
    let staging=[];let stagingChars=0;
    async function flushBatch() {
      if(!staging.length)return;
      const batch=staging;staging=[];stagingChars=0;
      const opId='mig_'+hashText(batch.map(x=>x.path+'\n'+stable(x.data)).join('\n'));
      const response=await gasDb._importLegacyBatch(batch,opId,options.overwrite===true);
      summary.batches++;
      const verified=await gasDb._getManyCompat(batch.map(x=>x.path));
      if(verified.length!==batch.length)throw new Error('Migration verification count mismatch in '+opId);
      for(let i=0;i<batch.length;i++) {
        const source=batch[i], target=verified[i];
        if(!target||target.path!==source.path||stable(target.data)!==stable(source.data))throw new Error('Checksum/data mismatch after copy: '+source.path+'. Firestore source has been kept unchanged.');
        summary.verifiedDocuments++;
      }
      if(typeof options.onProgress==='function')options.onProgress({phase:'verified-batch',documents:summary.totalDocuments,verified:summary.verifiedDocuments,batches:summary.batches,lastOperation:opId,serverResult:response});
      await sleepYield();
    }
    async function stageDoc(doc) {
      const path=String(doc.ref.path);
      if(seenPaths.has(path))return;
      seenPaths.add(path);
      const item={path:path,data:toGasValue(doc.data())};
      const raw=JSON.stringify(item);
      const size=utf8Length(raw);
      if(size>4*1024*1024)throw new Error('Single document is too large for one GAS import request: '+path);
      if(staging.length&&(staging.length>=MAX_BATCH_DOCS||stagingChars+size>MAX_BATCH_CHARS))await flushBatch();
      staging.push(item);stagingChars+=size;
      summary.totalDocuments++;summary.totalBytes+=size;allSummaryRows.push({path:path,digest:hashText(path+'\n'+stable(item.data)),bytes:size});
      const parent=path.split('/').slice(0,-1).join('/');
      if(!summary.collections[parent])summary.collections[parent]={documents:0,bytes:0};
      summary.collections[parent].documents++;summary.collections[parent].bytes+=size;
    }
    async function walkCollection(collectionRef, depth) {
      if(depth>8)throw new Error('Nested collection depth limit exceeded at '+collectionRef.path);
      await readCollectionPages(collectionRef,nativeFieldPath,async docs=>{
        for(const doc of docs)await stageDoc(doc);
        // Enumerate only known subcollections used by this app; the Web SDK cannot list arbitrary subcollection IDs.
        for(const doc of docs) {
          for(const childName of childCollectionsForDocument(doc.ref.path)) {
            await walkCollection(doc.ref.collection(childName),depth+1);
          }
        }
        if(typeof options.onProgress==='function')options.onProgress({phase:'read-source',collection:collectionRef.path,documents:summary.totalDocuments,verified:summary.verifiedDocuments,batches:summary.batches});
      });
    }
    for(const rootName of ROOT_COLLECTIONS) {
      await walkCollection(sourceDb.collection(rootName),0);
      await flushBatch();
      if(typeof options.onProgress==='function')options.onProgress({phase:'collection-complete',collection:rootName,documents:summary.totalDocuments,verified:summary.verifiedDocuments,batches:summary.batches});
    }
    summary.allDocumentsChecksum=checksum(allSummaryRows);
    summary.finishedAt=new Date().toISOString();
    summary.verifiedAll=summary.totalDocuments===summary.verifiedDocuments;
    if(!summary.verifiedAll)throw new Error('Final verification incomplete: '+summary.verifiedDocuments+'/'+summary.totalDocuments);
    return summary;
  }

  global.migrateFirestoreToGas = migrateFirestoreToGas;
  global.runRollGasFirestoreMigration = async function(options) {
    if(!global.firebase||!global.firebase.apps||!global.firebase.apps.length)throw new Error('Open the ROLL CÂY CẢNH app and sign in before starting migration');
    const firebase=global.firebase, auth=firebase.auth(), user=auth.currentUser;
    if(!user)throw new Error('Please sign in first');
    const nativeFactory=firebase.firestore;
    const sourceDb=nativeFactory.call(firebase);
    const nativeFieldPath=nativeFactory.FieldPath;
    const gasDb=global.createRollGasFirestoreCompat(firebase,auth,{endpoint:'https://script.google.com/macros/s/AKfycbyUJaEPNEb5v45Ew0Fjk9Mh17JWtZ9j8V7Ai4QaMW4xe349nSUq5C7mhjhuqRsxzhPD/exec',snapshotPollMs:3500});
    // Restore the native SDK namespace immediately. sourceDb remains connected to Firestore;
    // the temporary gasDb keeps its own methods and only uses Firebase Auth for ID tokens.
    firebase.firestore=nativeFactory;
    try {
      const result=await migrateFirestoreToGas(sourceDb,gasDb,nativeFieldPath,options||{});
      // Server-side cutover happens only after every staged Firestore document was read back
      // from Sheets and matched against its source value. Import/commit idempotency makes retry safe.
      if (!result.verifiedAll || result.totalDocuments !== result.verifiedDocuments) throw new Error('Không đủ điều kiện chuyển backend: dữ liệu chưa được đối chiếu đầy đủ.');
      const finalized=await gasDb._finalizeMigration(result);
      if (!finalized || finalized.cutoverCompleted !== true || finalized.writesEnabled !== true) throw new Error('Dữ liệu đã được sao chép nhưng máy chủ chưa xác nhận chuyển backend. Không tự chuyển app.');
      result.cutoverCompleted=true;
      result.cutoverFinalizedAt=finalized.finalizedAt||new Date().toISOString();
      global.__rollGasMigrationResult=result;
      if(typeof global.alert==='function')global.alert('Đã sao chép và đối chiếu '+result.totalDocuments+' tài liệu. Backend GAS đã được bật; app sẽ dùng Google Sheets/Drive ở lần tải tiếp theo. Firestore gốc vẫn giữ nguyên làm bản dự phòng.\nMã kiểm tra: '+result.allDocumentsChecksum);
      return result;
    } catch(error) {
      global.__rollGasMigrationError={message:String(error&&error.message||error),at:new Date().toISOString()};
      if(typeof global.alert==='function')global.alert('Chuyển dữ liệu chưa hoàn tất: '+String(error&&error.message||error)+'\nFirestore gốc vẫn được giữ nguyên; chưa được chuyển app sang GAS.');
      throw error;
    }
  };
})(window);
