# QuanLyCayAPK V26.1.10 — Fix camera Samsung J7 Prime

## Mục tiêu bản sửa

Bản này tiếp nối mã nguồn V26.1.9, giữ nguyên nghiệp vụ đơn hàng, tiền công, tồn kho, Drive và báo cáo lợi nhuận. Thay đổi tập trung vào đường chụp ảnh trên WebView Android đời cũ, đặc biệt là Samsung Galaxy J7 Prime.

## Đã sửa

- Camera luôn nhận `EXTRA_OUTPUT` qua `FileProvider` trên cả Android cũ và mới; không còn phụ thuộc vào camera trả ảnh thumbnail trong `Intent`.
- Cấp quyền đọc/ghi URI qua `ClipData` và kiểm tra tệp ảnh camera thực sự có dữ liệu trước khi chuyển sang WebView.
- Ảnh lớn được xử lý/thu nhỏ ở tầng Android về tối đa khoảng 1600 px, sau đó app nén ảnh xem trước trước khi tải lên Drive. Cách này giúp giảm đỉnh bộ nhớ trên thiết bị đời cũ.
- Giữ đọc được hướng ảnh EXIF thông thường (xoay 90/180/270 độ).
- Nếu camera không trả ảnh, WebView không đọc được ảnh, hoặc Drive chưa lưu ảnh, ứng dụng hiện thông báo cụ thể thay vì chỉ để vùng ảnh trống.
- Vẫn yêu cầu lưu ảnh lên Google Drive thành công trước khi chấp nhận ảnh hoàn tất. Yêu cầu OCR ảnh nhãn của đơn TT và quy tắc số ảnh theo loại đơn không đổi.
- Thêm kiểm thử hồi quy `tools/camera_compatibility_test.js`.

## Phiên bản

- Version name: **26.1.10**
- Version code: **52**
- Không đổi Firestore rules/indexes; không cần thao tác xóa dữ liệu cũ.

## Kiểm tra

Đã chạy thành công preflight, các kiểm thử tồn kho/tiền công/Drive/phân công/hoàn tất đơn/báo cáo lợi nhuận, kiểm thử tương thích camera mới, kiểm tra cú pháp JavaScript, XML và workflow YAML.

**Giới hạn kiểm tra:** môi trường làm việc hiện tại không có Gradle hoặc Android SDK nên chưa tự tạo được APK tại đây, và không có thiết bị Samsung J7 Prime thật để kiểm thử chụp ảnh trực tiếp. Hãy build trên GitHub Actions và thử cả 2 ảnh trên chính điện thoại nhân viên trước khi đưa vào sử dụng hằng ngày.

## Build bằng điện thoại qua GitHub Actions

1. Tải `QuanLyCayAPK-V26.1.10-SAMSUNG-CAMERA-COMPAT.zip` lên thư mục gốc repository `tiennt9939/QuanLyCayAPK`.
2. Thay nội dung `.github/workflows/build-apk.yml` bằng file workflow kèm theo có tên `build-apk-v26.1.10-samsung-camera-compat.yml`.
3. Mở **Actions** → **Build ROLL CAY CANH V26.1.10 — Samsung Camera Compatibility** → **Run workflow**.
4. Chỉ cài APK khi lần chạy có trạng thái **Success**. Tải artifact `QuanLyCayAPK-V26.1.10-SAMSUNG-CAMERA-COMPAT-debug`.

## Cách thử trên Samsung J7 Prime

1. Mở app và kiểm tra thiết bị đã kết nối đúng tài khoản Google Drive dùng lưu ảnh.
2. Nhận một đơn thử nghiệm chưa hoàn tất, chụp ảnh 1 và chờ đến khi ảnh hiện trong khung xem trước/hiện thông báo đã lưu Drive.
3. Chụp ảnh 2; với đơn TT, chờ OCR xong rồi mới xác nhận hoàn tất.
4. Nếu vẫn lỗi, chụp màn hình thông báo mới hiện ra và gửi lại. Không cần xóa đơn hoặc xóa dữ liệu app.
