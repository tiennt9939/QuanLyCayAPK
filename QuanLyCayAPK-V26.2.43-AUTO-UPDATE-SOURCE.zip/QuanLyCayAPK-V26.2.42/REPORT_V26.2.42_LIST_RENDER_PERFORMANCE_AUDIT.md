# ROLL CÂY CẢNH V26.2.42 — Employee order-list rendering audit

## Base and scope
- Incremental source based on V26.2.41 / versionCode 93.
- V26.2.42 / versionCode 94.
- No intended changes to Firestore schema/rules, wage formulas, inventory formulas, access permissions, TikTok Product Name recognition, combo arithmetic, duplicate-tracking claims, or Google Drive photo-completion requirements.

## Findings
1. Employee order list built the HTML for all completed orders even when the completed accordion was collapsed. The browser therefore paid the card-generation and DOM-insertion cost during ordinary list refreshes.
2. Employee list and pending-count de-duplication used `filter(...findIndex(...))`, which repeatedly scanned the same array and has quadratic worst-case behavior for large lists.

## Changes
- Keep completed-order count and type breakdown visible, but build completed order cards only while the completed accordion is expanded. Opening/closing the section uses a guarded toggle handler to rerender with the selected state.
- Add `uniqueOrderRowsById()` based on a `Set`, preserving first-occurrence behavior and replacing the two quadratic de-duplication passes in the employee list/count paths.
- Version advanced to 26.2.42 / code 94, and hard-coded current-version test guards were updated.

## Validation
- `tools/preflight.py` and all Node.js regression tests must pass after this change.
- Inline script and external PDF parser syntax must pass.
- Android SDK/Gradle build and physical-device timing are separate checks; do not infer real-device speed improvement from static tests alone.
