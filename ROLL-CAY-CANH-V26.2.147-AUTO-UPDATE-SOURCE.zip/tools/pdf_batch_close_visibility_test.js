const fs = require('fs');
const assert = require('assert');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
assert(html.includes('id="legacyPdfBatchCloseCard" data-shipment-view="admin-maintenance"'));
assert(html.includes("const resetCard=$('dailyShipmentAdminResetCard'),cleanupCard=$('legacyIncompleteCleanupCard'),pdfBatchCloseCard=$('legacyPdfBatchCloseCard');"));
assert(html.includes("if(pdfBatchCloseCard)pdfBatchCloseCard.classList.toggle('hidden',!isAdmin);"));
assert(html.includes("if(cleanupCard)cleanupCard.classList.toggle('hidden',!isAdmin);"));
console.log('PDF BATCH CLOSE VISIBILITY TEST PASS');
