# ROLL CÂY CẢNH V26.2.147 — PDF batch date-mismatch recovery

- Base: V26.2.146 (versionCode 198).
- Android version: 26.2.147 (versionCode 199).
- Root cause: the old PDF batch retirement gate treated a canonical backend tracking document with a different `date` as if the document were missing. This trapped the local `roll_pdf_queue_local_pending` flag and prevented full-app sync.
- Fix: identify the canonical queue document by normalized tracking number (document ID). If it exists, capture and show its actual backend date as a warning; a date mismatch no longer blocks retirement of the *local PDF batch markers*. A genuinely absent backend tracking document still blocks the action.
- Safety: preview and execute both read the canonical backend documents; execute re-reads and checks the fingerprint. The action removes only `roll_pdf_queue_local_pending`, `roll_pdf_queue_current_batch_v1`, and `roll_pdf_queue_only_import_dirty_before`, then releases the full-sync guard. It does not delete or update Firestore/GAS records, orders, scan reports, claims, photos, payroll, inventory, catalog, staff, or Drive files.
- Dirty-state handling: `quanlycay_dirty` is preserved. After the PDF-only gate is released, the normal full-app sync is scheduled so unrelated unsynced data can be uploaded rather than discarded.
- Tests: 132/132 JavaScript regression tests PASS; 132/132 JS syntax checks PASS; `tools/preflight.py` returns PASS. The preflight emits a non-blocking spreadsheet-runtime warmup diagnostic in this environment.
- Not built or deployed. No live backend or user data was modified during this work.
