# ROLL CÂY CẢNH V26.2.146 — PDF batch close visibility fix

- Base: V26.2.145 (versionCode 197).
- Android version: 26.2.146 (versionCode 198).
- Fix: Admin maintenance navigation now explicitly unhides `legacyPdfBatchCloseCard` after Admin authentication. Previously the card carried the permanent `hidden` class and was never unhidden, so users only saw the broad legacy cleanup card.
- Safety: The PDF batch close tool remains separate from `Dọn đơn cũ chưa hoàn tất`. It verifies every tracking number against the canonical backend queue and matching batch date, re-reads the backend immediately before release, and removes only the three local PDF batch markers. It does not delete or modify backend orders, scan reports, claims, photos, payroll, stock, catalog, or employee records.
- Existing full-app sync guard remains unchanged: a pending PDF batch still blocks full sync until the Admin close tool successfully verifies and releases that batch.
- Tests: 131/131 JavaScript regression tests PASS; `tools/preflight.py` PASS.
- Not yet built or deployed. Live backend data was not changed.
