# QuanLyCayAPK V26.1.6 — Admin Completion Permission Fix

## Lý do sửa
V26.1.5 tạo trực tiếp tài liệu `/packingOrders/{id}` với `status: completed`. Nếu Firestore Rules đang triển khai trên Firebase vẫn là bản cũ chỉ cho phép tạo đơn `pending`, thao tác bị từ chối với `Missing or insufficient permissions`.

## Sửa đổi
- Với thao tác **GHI NHẬN HOÀN TẤT (ADMIN · KHÔNG ẢNH)**, ứng dụng tạo đúng một đơn qua đường `status: pending` vốn được dùng bởi chức năng phân công.
- Sau khi tạo thành công, Admin cập nhật chính tài liệu đó sang `status: completed`, với `completionMethod: admin_no_photo`, không ảnh, thời điểm hoàn tất, nhân viên được ghi nhận và snapshot tiền công.
- Đọc lại tài liệu từ Firestore để xác nhận trạng thái `completed` trước khi báo thành công.
- Nếu bước cập nhật bị Rules từ chối, ứng dụng cố gắng xóa tài liệu tạm. Thông báo sẽ nêu rõ liệu bản nháp đã được gỡ hay cần tải lại danh sách để tránh tạo trùng.
- Giữ nguyên luồng nhân viên đóng hàng có ảnh/OCR; giữ nguyên công thức tiền công Cẩm tú mai C7/C9 và các trường dữ liệu/đơn hàng khác.
- Nút Admin hoàn tất không ảnh cho đơn đã phân công vẫn cập nhật chính đơn đang chờ, không tạo một đơn mới.

## Phiên bản
- `versionName`: `26.1.6`
- `versionCode`: `48`

## Kiểm tra
Chạy tại thư mục gốc:

```bash
python3 tools/preflight.py
node tools/retention_logic_test.js
node tools/packing_wage_rules_test.js
node tools/drive_image_persistence_test.js
node tools/packer_assignment_ui_test.js
node tools/admin_direct_completion_test.js
```

Workflow kiểm tra cú pháp JavaScript và biên dịch APK bằng Java 17 / Android SDK 35 / Gradle 8.13. Không báo APK thành công cho đến khi GitHub Actions hoàn tất và upload artifact.

## Lưu ý Firebase
Cách ghi hai bước này được thiết kế để tương thích với Rules cũ vốn cho Admin tạo `pending` và cập nhật đơn của Admin. Nếu thao tác tạo `pending` vẫn bị từ chối, cần kiểm tra tài khoản Admin, hồ sơ nhân viên đích trong `users/{uid}` và Firebase project mà APK đang dùng. Rules trong gói cần được Publish nếu muốn bật nhánh create completed trực tiếp ở các client khác; luồng ứng dụng hiện dùng pending-create + Admin-update.
