# ROLL CÂY CẢNH V26.2.117 — Tối ưu đồng bộ Firestore và nhận diện PDF

**Nền source:** V26.2.114, tiếp tục dự án hiện có. **Android versionName:** `26.2.117`; **versionCode:** `169`.

Bản này tập trung giảm thời gian đồng bộ dữ liệu nhãn PDF/báo cáo và nhận diện sản phẩm. Không dựng lại dự án; không đổi schema kinh doanh, catalog, giá, tồn kho, công thức tiền công, quyền Firebase Auth hay quy tắc nhận diện cây/size.

## Thay đổi chính

- Dùng lại snapshot nhãn/báo cáo đã được Admin listener xác nhận từ server trong các lần đồng bộ tiếp theo, thay vì tải toàn bộ hai collection lặp lại mỗi lần. Khi có nhãn thay đổi, chỉ kiểm tra lại các ID thay đổi với server; bản ghi đã mất khỏi Cloud sẽ làm đồng bộ dừng an toàn thay vì tự hồi sinh bản cũ.
- Chỉ ghi các nhãn/báo cáo thực sự thay đổi và chỉ đọc đối soát lại những document đã ghi. Loại bỏ lần chuyển Drive reference lặp lại và lần kiểm tra migration lặp trong cùng một lượt push.
- Tái sử dụng cache quy tắc nhận diện trong 30 giây; sau khi hết hạn, app tải quy tắc mới từ Cloud. Các lần lưu quy tắc từ Admin cập nhật mốc cache.
- Tiền xử lý token danh mục một lần cho mỗi fingerprint danh mục; cache tự làm mới khi tên, size, khóa, trạng thái xóa hoặc chỉ số danh mục thay đổi, kể cả khi đối tượng được sửa tại chỗ.
- Với trang PDF có đủ bằng chứng chữ native, tracking, Order ID, tiêu đề bảng và dòng sản phẩm có cấu trúc, bỏ qua lượt PDFBox text-extraction thứ ba. Trang thiếu bằng chứng vẫn dùng fallback hiện có; OCR và quét barcode không bị loại bỏ.
- Thêm log giai đoạn xử lý PDF và thời gian đọc PDF/nhận diện để có thể đo trên thiết bị.

## Kiểm thử cục bộ

- `python tools/preflight.py`: PASS.
- `104/104` bài test `tools/*test.js`: PASS.
- Cú pháp JavaScript: 4 khối script nội tuyến trong `index.html`, `tiktok-label-import.js` và bài test hiệu năng: PASS.
- Benchmark Node.js riêng: 150 sản phẩm mẫu × 99 dòng catalog, median 7 lượt. Source gốc: `197.43 ms`; source đã tối ưu: `17.06 ms`; nhanh hơn `11.57×`; kết quả so khớp trả về giống hệt nhau. Đây là benchmark trong môi trường kiểm thử, **không phải** số đo điện thoại hay Firestore thật.

## Giới hạn xác minh

Môi trường hiện tại không có Gradle wrapper, lệnh Gradle hoặc `ANDROID_HOME`, nên chưa biên dịch APK và chưa xác minh build GitHub Actions. Không có credential/Emulator của Firebase project, nên chưa đo thời gian sync trên Cloud thật. Lượt đầu tiên hoặc khi listener chưa nhận được snapshot server vẫn cần tải collection để khởi tạo; các lượt sau mới có thể dùng cache đã xác nhận.

## Files liên quan

- `ROLL_CAY_CANH_V26.2.117_PERFORMANCE_AUDIT.md`: audit, thiết kế và giới hạn.
- `ROLL_CAY_CANH_V26.2.117_VALIDATION_SUMMARY.txt`: tóm tắt test.
- `ROLL_CAY_CANH_V26.2.117_TEST_RESULTS.txt`: danh sách 103 test.
- `tools/performance_optimization_v26115_test.js`: kiểm tra hiệu năng và hợp đồng luồng nguồn.

Build APK chỉ được xác nhận khi GitHub Actions thực sự hoàn tất xanh và có artifact APK.


## Đóng gói source và tự build/cập nhật

- Tên ZIP source chính xác: `ROLL-CAY-CANH-V26.2.117-AUTO-UPDATE-SOURCE.zip`.
- ZIP chứa trực tiếp root project (`settings.gradle.kts`, `app/`, `tools/`, `.github/`), không lồng thêm thư mục project hoặc thư mục audit.
- Khi ZIP được tải lên/commit ở thư mục gốc branch `main`, `.github/workflows/build-apk.yml` tự chạy theo pattern `*AUTO-UPDATE-SOURCE.zip`.
- App tự kiểm tra cập nhật qua GitHub Releases. Để workflow tạo Release (không chỉ Artifact), repository phải có `DEBUG_KEYSTORE_BASE64` và `EXPECTED_APK_CERT_SHA256` đúng với chữ ký APK đã phát hành. Nếu thiếu, workflow chủ động bỏ qua Release để không phát hành APK không tương thích chữ ký.
- `app/build.gradle.kts` là nguồn metadata versionName/versionCode mà workflow dùng để đặt tên APK/Release. Các regression tests kiểm tra định dạng phiên bản động; preflight buộc versionCode lớn hơn bản stable đã biết (167).
