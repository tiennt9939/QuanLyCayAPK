plugins { id("com.android.application") }

// Google Play services / ML Kit currently bring different Kotlin stdlib variants
// transitively. Keep the stdlib family aligned to avoid duplicate class failures
// during :app:checkDebugDuplicateClasses.
configurations.configureEach {
    resolutionStrategy.eachDependency {
        if (requested.group == "org.jetbrains.kotlin" && requested.name in setOf(
                "kotlin-stdlib", "kotlin-stdlib-jdk7", "kotlin-stdlib-jdk8", "kotlin-stdlib-common"
            )) {
            useVersion("1.8.22")
            because("Align Kotlin stdlib variants to avoid duplicate class definitions")
        }
    }
}

android {
    namespace = "com.quanlycay.apk"
    buildFeatures {
        buildConfig = true
    }
    compileSdk = 35

    // Stable DEBUG-only signing. The private keystore is supplied by GitHub Actions secret,
    // never stored in this source archive or committed to the public repository.
    signingConfigs {
        create("stableDebug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            // If the Actions secret is not configured yet, keep the standard debug build working.
            // Once present, subsequent debug APKs use the same stable certificate.
            if (file("debug.keystore").exists()) {
                signingConfig = signingConfigs.getByName("stableDebug")
            }
        }
    }

    defaultConfig {
        applicationId = "com.quanlycay.apk"
        minSdk = 23
        targetSdk = 35
        versionCode = 140
        versionName = "26.2.88"
    }
}


dependencies {
    implementation("androidx.core:core:1.13.1")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    // Bundled ML Kit model: avoids first-use waiting for the barcode model download.
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
    // CameraX gives the shipping scanner manual zoom/torch controls and a continuous preview.
    implementation("androidx.camera:camera-camera2:1.4.2")
    implementation("androidx.camera:camera-lifecycle:1.4.2")
    implementation("androidx.camera:camera-view:1.4.2")
    implementation("androidx.activity:activity:1.10.1")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    implementation("com.google.android.gms:play-services-auth:21.3.0")
}
