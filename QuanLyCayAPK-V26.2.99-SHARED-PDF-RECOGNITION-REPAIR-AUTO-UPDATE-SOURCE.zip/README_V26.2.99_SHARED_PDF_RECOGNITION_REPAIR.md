# V26.2.99 — Shared PDF recognition repair (versionCode 151)

## Problem addressed
When two Android devices use the same Admin account, the secondary device can show imported PDF labels from the shared Firestore queue but still show `CẦN KIỂM TRA CÂY` / `0 cây`. The assignment board was evaluating per-product mappings from a device-local cache and did not refresh the shared recognition rules before deciding scan readiness.

## Fix
- Treat shared `dailyShipmentOrders` rows for the selected date as input to `tiktokUniqueProducts()`, even when this device has no local PDF staging queue.
- Normalize legacy or missing `mapKey` values to the stable product key without changing mapping rules, product count, wage, inventory, or scan state.
- Before the Admin assignment board computes readiness, refresh the existing shared recognition rules only if the selected queue has an unresolved product mapping; then run the existing safe auto-map routine.
- Cache the repair attempt by queue fingerprint for 60 seconds to avoid repeated Cloud reads on repeated renders.
- No new Firestore collection/schema and no changes to the native scanner/record-completion implementation.

## Operator notes
Do not re-import the PDF merely because the secondary device shows a recognition warning. Update the app on both devices, sign in as the same Admin, open **Theo ngày → Chia việc**, and wait for the shared rules and selected-day labels to load. If a product remains unresolved, leave it blocked and confirm that the primary device actually saved the mapping rule to Cloud; do not bypass the scan guard.

## Verification limits
The included JavaScript regression tests and preflight do not prove live Firestore behavior or device performance. Build with GitHub Actions and validate the same existing label on both devices before considering this release verified in production.
