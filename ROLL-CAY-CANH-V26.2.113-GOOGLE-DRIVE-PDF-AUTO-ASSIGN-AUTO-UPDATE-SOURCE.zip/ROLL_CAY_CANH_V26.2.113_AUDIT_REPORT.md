# ROLL CÂY CẢNH V26.2.113 — Audit báo cáo

## Phạm vi bản phát hành

- Android package: `com.quanlycay.apk`.
- `versionName`: `26.2.113`.
- `versionCode`: `165` (tăng từ 164 để Android nhận đây là bản nâng cấp).
- Kế thừa logic và tính năng từ source V26.2.112, gồm Google Drive PDF inbox theo nhân viên và tự phân công có điều kiện.
- Bản này sửa lỗi metadata của gói trước đó: phiên bản trong tên ZIP trước đây là V26.2.113 nhưng Gradle vẫn đặt V26.2.112/code 164. Đồng bộ lại Gradle, workflow title, app-version marker, preflight và các kiểm tra hồi quy đang khóa phiên bản hiện hành.
- Không thay đổi schema/quyền Firestore, nhận diện cây/PDF, chống trùng mã vận đơn, công thức tiền công, tồn kho hoặc quy trình quét/chụp ảnh hoàn tất.

## Kiểm tra đã chạy trong môi trường tạo source

- `python3 tools/preflight.py`: PASS; báo `Version: 26.2.113 / code 165`.
- Tất cả `tools/*_test.js`: PASS, 101/101 bài kiểm tra.
- Cú pháp JavaScript: PASS cho 6 khối script inline của `index.html` và `app/src/main/assets/tiktok-label-import.js`.
- Kiểm tra metadata bằng tìm kiếm: Gradle dùng versionName 26.2.113/code 165; workflow mang tên V26.2.113; app-version marker đã chuyển sang V26.2.113.
- ZIP đã được đóng gói lại; mở archive, kiểm tra CRC toàn bộ và đọc trực tiếp `app/build.gradle.kts` bên trong: PASS; archive chứa 318 file.

## Giới hạn xác minh — cần đọc kỹ

- Chưa biên dịch APK trong môi trường đóng gói hiện tại: môi trường không có lệnh `gradle`, Gradle wrapper hoặc Android SDK phù hợp. Vì vậy đây là source ZIP đã qua test source, không phải APK đã build thành công.
- Workflow GitHub Actions trong source có bước build APK, nhưng cần được chạy trong repository. Workflow yêu cầu secret `DEBUG_KEYSTORE_BASE64`; việc phát hành GitHub Release tự động còn phụ thuộc `EXPECTED_APK_CERT_SHA256` được cấu hình đúng. Nếu thiếu secret, workflow sẽ dừng trước bước build hoặc bỏ qua Release theo logic workflow.
- Chưa xác minh quyền `drive.readonly` với OAuth project thực tế của cửa hàng. Google có thể yêu cầu cấu hình consent screen/quyền restricted phù hợp.
- Trước khi xử lý đơn thật, cần thử một PDF mới trong thư mục nhân viên trên cùng tài khoản Drive với thiết bị Admin, kiểm tra mã vận đơn, loại cây/kích thước và nhân viên nhận đơn. Auto-poll chỉ chạy khi app Admin đang foreground; mở lại app để tiếp tục đồng bộ nếu app bị đóng.

## Kết luận

Metadata và bộ kiểm tra source đã được đồng bộ về V26.2.113/code 165; các bài test source hiện có đều PASS. Không khẳng định APK build thành công hoặc tích hợp Google Drive thực tế đã được xác minh cho tới khi GitHub Actions và thử nghiệm trên thiết bị chạy thành công.
