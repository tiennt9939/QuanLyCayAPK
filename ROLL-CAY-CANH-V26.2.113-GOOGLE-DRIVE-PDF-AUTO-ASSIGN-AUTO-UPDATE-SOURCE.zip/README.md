# ROLL CÂY CẢNH V26.2.113 — Google Drive PDF tự đồng bộ và tự phân công (versionCode 165)

Bản đóng gói đúng phiên bản kế tiếp từ source V26.2.112: giữ nguyên chức năng Drive PDF tự đồng bộ/tự phân công, chỉ đồng bộ metadata phát hành thành `versionName = 26.2.113`, `versionCode = 165` và cập nhật các kiểm tra hồi quy để khóa đúng metadata mới. Không thay schema Firestore, công thức tiền công, tồn kho hoặc quy tắc nhận diện PDF.

Đọc `README_V26.2.113_GOOGLE_DRIVE_PDF_AUTO_ASSIGN.md` để xem cách sử dụng và các điều kiện cần kiểm tra khi kết nối Google Drive thật. Đọc `ROLL_CAY_CANH_V26.2.113_AUDIT_REPORT.md` để xem kiểm thử và giới hạn xác minh.
