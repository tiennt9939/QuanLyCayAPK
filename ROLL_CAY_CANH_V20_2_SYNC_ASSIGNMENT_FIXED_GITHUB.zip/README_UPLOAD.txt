ROLL CÂY CẢNH V20.2 – FIX ĐỒNG BỘ + PHÂN CÔNG

1. Lấy file QuanLyCayAPK_project.zip trong gói này.
2. Đưa file đó lên GitHub repository, thay bản cũ.
3. GitHub Actions -> Build QuanLyCayAPK -> Run workflow.
4. Firebase -> Firestore Database -> Rules: thay bằng firestore.rules trong source V20.2 và Publish.
5. Cài APK mới.

V20.2 tách catalog thành từng document để tránh lỗi kích thước Firestore khi có nhiều ảnh.
