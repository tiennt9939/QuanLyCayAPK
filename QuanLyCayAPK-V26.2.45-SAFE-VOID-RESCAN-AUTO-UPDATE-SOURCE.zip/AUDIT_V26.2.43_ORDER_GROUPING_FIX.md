# V26.2.43 — Order grouping and continuation-page fix

## Root cause
The parser deleted `qtyTotal` inside `parsePage()` before `parsePages()` grouped pages. A continuation page with only `Qty Total` and the repeated Order ID could therefore lose the evidence needed to identify it as a footer-only continuation. Grouping was also conditional on one of the pages having no products, so a false product inferred from a continuation page could block the merge.

## Fix
- Preserve `qtyTotal` as internal parser evidence until after page grouping.
- Mark pages with an Order ID + `Qty Total` but no tracking barcode as `continuationOnly`.
- Clear any inferred product rows from such footer-only pages.
- Group same-Order-ID pages into the same shipment, guarded against conflicting tracking/order identifiers.
- Remove internal flags and `qtyTotal` before returning shipment rows.
- Bumped versionName to 26.2.43 and versionCode to 95.

## Required regression
PDF `TikTokSeller_1792217963994.pdf`: page 3 contains two product rows under tracking `862542794508`, Order ID `586634608115811400`; page 4 contains only `Qty Total: 2` and the same Order ID. Expected one shipment, two product lines: Cẩm tú mai C9 combo 4 Qty 1; Trầu Bà Thanh Xuân C9 Qty 1; 5 physical plants total.

## Validation limits
JavaScript regression tests and preflight are run on source. No Android Gradle build/device verification is claimed unless separately performed.
