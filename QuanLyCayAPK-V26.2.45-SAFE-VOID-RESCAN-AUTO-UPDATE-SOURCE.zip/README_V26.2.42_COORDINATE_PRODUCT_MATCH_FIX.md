# ROLL CÂY CẢNH V26.2.42 — Coordinate-based TikTok product matching fix

- Android version: `26.2.42`, versionCode `94`.
- Based on the V26.2.41 source; original V26.2.35 remains a separate backup.
- Preserves the existing Android WebView + Java, Firebase, inventory, shipment report, quote, and catalog architecture.

## Root cause addressed

The TikTok PDF uses proportional fonts. Slicing a reconstructed visual text line by character offsets can put part of `Cây Trầu Bà Thanh Xuân` into the SKU cell and continuation text into the next product's identity. That made one product appear to map to both Trầu Bà Thanh Xuân and Cẩm tú mai.

The native PDF reader now extracts table cells from actual glyph X coordinates. The heading positions define the Product Name, SKU, Seller SKU, and Qty column boundaries. Each Qty anchor starts one product row; wrapped lines are appended to that row until the next Qty anchor. `Qty Total` and the footer Order ID stop the table and cannot become plant rows.

The JavaScript parser consumes these structured cells first, trims known SEO/botanical description from the plant identity, and repairs wrapped Seller SKU text such as `1 Cây` + `Thanh Xuân C9`. The old text-based parser remains as a compatibility fallback for non-Android/test inputs.

## Expected result for the supplied TikTok PDF, pages 3–4

Order ID `586634608115811400`, tracking `862542794508`:

1. `Combo 4 chậu cẩm tú mai C9 (cây sẵn hoa + cao 25-35cm)`; SKU `Mặc định`; Qty 1 → Cẩm tú mai C9, 4 physical plants.
2. `Cây Trầu Bà Thanh Xuân`; SKU `1 Cây`; Seller SKU `Thanh Xuân C9`; Qty 1 → Trầu Bà Thanh Xuân C9, 1 physical plant.

Page 4 only has `Qty Total: 2` and the same Order ID. It is merged as continuation, not another shipment or product. Expected total: one order, two product lines, five physical plants.

## Validation

- Node JavaScript regression tests: 44/44 pass.
- `tools/preflight.py`: PASS.
- ZIP integrity and XML/JavaScript syntax checks: performed before release.
- Android Gradle/APK build and physical-device import test: not run in this environment; validate the new coordinate extraction in GitHub Actions and on-device before operational use.
