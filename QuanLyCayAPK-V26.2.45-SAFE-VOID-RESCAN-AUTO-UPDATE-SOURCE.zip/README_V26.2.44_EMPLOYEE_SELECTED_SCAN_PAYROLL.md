# V26.2.44 — Chọn nhân viên quét và ghi nhận tiền công

Dựa trên source V26.2.43; không khởi tạo dự án mới, không thay schema Firestore, không thay bộ nhận dạng PDF hoặc công thức đơn giá hiện có.

## Luồng vận hành

1. Admin nhập PDF nhãn vận chuyển như trước. Các đơn vẫn nằm trong danh sách theo ngày và chỉ những nhãn đã đối chiếu đủ danh mục cây mới được quét.
2. Trước khi bắt đầu, bấm **CHỌN NHÂN VIÊN QUÉT**, chọn một nhân viên đã có trong danh mục và xác nhận. Lựa chọn được lưu trên thiết bị. Trong phiên quét và khi ảnh còn đang xử lý, nút lựa chọn bị khóa để không gán nhầm nhân viên.
3. Khi máy quét đọc được nhãn và ảnh đã được lưu vào hàng đợi ảnh gốc trên điện thoại, app dùng các mặt hàng đã được map và `orderItemRate()` hiện có để tính công theo số cây thực tế (combo vẫn dùng kết quả nhận dạng hiện tại).
4. Firebase transaction ghi đồng thời khóa mã vận đơn duy nhất, báo cáo, nhân viên và ảnh chờ; tiền công chỉ coi là đã chốt sau khi transaction thành công. Nếu Firebase thất bại, app chưa chốt lương và ảnh vẫn chờ để thử lại.
5. Chỉ sau transaction Firebase thành công, app mới tải ảnh lên Google Drive ở nền và gắn `drive://` vào báo cáo. Chỉ xóa ảnh gốc khỏi hàng đợi sau khi Firebase xác nhận tham chiếu Drive. Nếu Drive lỗi, báo cáo tiền công vẫn được giữ và ảnh được giữ trên máy để thử lại.
6. Quét trùng bị khóa tại bước kiểm tra trước khi quét và bằng Firestore claim transaction. Cùng một mã đã ghi nhận không tạo lương thứ hai, không trừ tồn lần hai, không đổi người nhận công khi retry.

## Tiền công và tồn kho

- Dùng `orderItemRate(item, items)` đang có, gồm các quy tắc đặc biệt theo cây/kích thước/số lượng. Không sửa bảng giá công hoặc rule combo.
- Báo cáo `dailyShipmentReports` có thêm `employee`, `employeeId`, `laborPay`, `payAmount`, `wageRecorded`, `photoRef` và thời điểm tải ảnh; tiếp tục lưu trong cấu trúc dữ liệu chung hiện tại.
- Lương quét vận chuyển được đưa vào `completedOrderRecords()`/`payrollEntries()` theo nhân viên đã chọn. Những dòng này được loại khỏi nhánh tính tồn dựa trên đơn đã đóng để tránh đếm trùng; tồn vận chuyển tiếp tục lấy từ `dailyShipmentReports` như trước.
- Các báo cáo cũ chưa có `wageRecorded:true` không tự động tạo lương hồi tố hoặc tự gán cho nhân viên hiện đang được chọn.

## Phiên bản

- Android `versionName`: `26.2.44`
- Android `versionCode`: `96`
- APK package: `com.quanlycay.apk`
- Dựa trên V26.2.43 với tốc độ quét đã được cải thiện.

## Kiểm tra

- `python tools/preflight.py`
- `node tools/daily_shipment_workflow_test.js`
- `node tools/v2644_employee_selected_scan_payroll_test.js`
- Toàn bộ `tools/*_test.js`
- Đã kiểm tra cú pháp cả 6 inline JavaScript blocks trong `index.html` bằng `node --check`.

Build APK thực tế vẫn cần chạy workflow GitHub Actions `Build ROLL CAY CANH V26.2.44 — Employee Scan Payroll + Stable Auto Update` với ZIP source này; môi trường chỉnh sửa hiện tại không có Gradle wrapper/Gradle executable để xác nhận APK được compile.
