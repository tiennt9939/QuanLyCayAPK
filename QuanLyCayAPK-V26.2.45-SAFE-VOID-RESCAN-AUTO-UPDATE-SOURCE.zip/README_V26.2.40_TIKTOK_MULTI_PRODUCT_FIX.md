# ROLL CÂY CẢNH V26.2.40 — TikTok multi-product label fix

## Fixed matching rules (reusable for future label layouts)

1. **One tracking number + one Order ID = one shipment/order.** Do not turn a continuation page into a second order just because it carries `Qty Total` and footer text.
2. **Each real Product Name / SKU / Seller SKU / Qty row is a separate product line inside that same order.** A product's name, SKU and seller SKU may wrap onto following baselines; continuation lines stay with the product whose Qty anchor they follow, not the next product.
3. **`Qty` means sold units for that product line.** It is not the number of free plants. `Qty Total` is a PDF table footer, not a product row and not the count of physical plants.
4. **Combo counts determine physical plant count per sold unit.** For example `Combo 4` with Qty 1 means 4 Cẩm tú mai; a separate Trầu Bà Thanh Xuân line with Qty 1 means one more plant. The shipment is one order with two product lines and 5 physical plants total.
5. **Trim marketing/SEO/botanical descriptions for catalog identity matching** (for example “Philodendron bipinnatifidum”, “Ánh sáng gián tiếp”, “Độ ẩm cao”, “Phun sương”, “Tránh gió lùa”), but keep the printed/original text available on the imported label record for review.
6. **Preserve size evidence from Product Name, SKU and Seller SKU.** Explicit C9 stays C9; the established C7 default only applies when the label has no usable size evidence. Conflicts or ambiguous catalog matches must remain “Cần kiểm tra”, not be guessed.
7. These are generic parser/matcher rules and are covered by `tools/tiktok_pdf_multi_product_same_order_regression_test.js`; future fixes should extend that regression test rather than introduce a one-label special case.

## Changes in V26.2.40

- Fixed row grouping so wrapped text after a Qty anchor stays in the current product line instead of being prepended to the next product.
- Improved `stripProductDescription()` so numeric size/height ranges such as `25-35cm` are not treated as marketing separators; added commonly observed plant-description markers.
- Added regression for J&T tracking `862542794508`, with two product lines under one Order ID plus a continuation page containing only `Qty Total`/footer.
- Version: `26.2.40`, versionCode `92`.

## Build

Use the repository workflow **Build ROLL CAY CANH** and choose this exact file as `source_zip`:

`QuanLyCayAPK-V26.2.40-TIKTOK-MULTI-PRODUCT-FIX-AUTO-UPDATE-SOURCE.zip`

The source audit and JavaScript test suite pass. The original exported PDF was not attached in this conversation, so the new regression is reconstructed from the provided screenshots/text layout; a device import with the original PDF remains the final real-PDF verification.
