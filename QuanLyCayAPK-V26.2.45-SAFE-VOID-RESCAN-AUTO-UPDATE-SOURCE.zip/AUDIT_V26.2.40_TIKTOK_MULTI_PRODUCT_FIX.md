# Audit — ROLL CÂY CẢNH V26.2.40

Date: 2026-10-17
Baseline: V26.2.39 source supplied in this conversation.
VersionName: 26.2.40
VersionCode: 92

## Root cause

For TikTok label tables where Qty is printed on the first baseline of a product and the product name/description wraps below it, the previous parser grouped subsequent wrapped baselines with the *next* Qty candidate. On the reported J&T sample, the ending of the Cẩm tú mai description could be prepended to the next Trầu Bà product, and the long botanical/SEO description could pollute catalog tokens. The continuation page containing only `Qty Total` must stay attached to the Order ID already parsed.

## Fixes

- `parseProductRows`: start subsequent product groups at their own Qty anchor; continuation baselines remain with that row until the next true Qty anchor. The first row still supports text preceding a detached Qty anchor.
- `stripProductDescription`: protect height ranges like `25-35cm`, remove known SEO/botanical phrases for matching, including `Philodendron`, indirect light, humidity, misting and drafts.
- Added `tools/tiktok_pdf_multi_product_same_order_regression_test.js` that checks one shipment, two product lines, clean catalog names, explicit C9 mapping, combo physical-plant math and continuation footer merge.
- Preserved the original full project/data schema; only source, regression/version test contracts and docs changed.

## Validation results

- `python3 tools/preflight.py`: PASS
- Every `tools/*_test.js` regression test: PASS, including the new `TIKTOK MULTI-PRODUCT SAME-ORDER REGRESSION`.
- JavaScript syntax checks for inline application script blocks and `tiktok-label-import.js`: PASS.
- Android manifest XML parse: PASS.
- ZIP archive integrity check: PASS.

## Test fixture and limitation

The screenshot-reconstructed fixture uses the reported shipment's two rows:

- `Combo 4 chậu cẩm tú mai C9`, Qty 1 → one sold unit, four physical plants.
- `Cây Trầu Bà Thanh Xuân`, C9 from SKU/Seller SKU, Qty 1 → one physical plant.

Expected result: **one order, two product lines, Qty Total 2, five physical plants**. A following page with the same Order ID and only `Qty Total` does not create a new shipment.

The original binary PDF was not attached; test evidence is a reproducible, coordinate-aligned text fixture transcribed from the screenshots, not a direct import of the PDF itself. GitHub Actions/Gradle build and on-device PDF import were not executed in this audit.
