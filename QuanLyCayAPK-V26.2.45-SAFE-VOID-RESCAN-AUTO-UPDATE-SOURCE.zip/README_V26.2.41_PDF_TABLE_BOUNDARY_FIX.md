# ROLL CÂY CẢNH V26.2.41 — TikTok PDF table-boundary and catalog matching fix

## Baseline
- Built from the existing V26.2.40 source package; no project rebuild from scratch.
- Android package remains `com.quanlycay.apk`.
- Android version: `26.2.41`, versionCode `93`.
- Original V26.2.35 source should be retained separately as the restoration baseline.

## Root cause reproduced from the uploaded TikTokSeller PDF
- The product table on page 3 has two genuine product rows, each with Qty 1.
- Page 3 does not contain a `Qty Total` line; the table ends at its footer `Order ID`.
- The next page (page 4) contains only the repeated table header, `Qty Total: 2`, and the same Order ID.
- The previous parser used the end of the page as the table boundary when `Qty Total` was absent, so it appended the footer Order ID to the final product's Seller SKU.
- In the PDF, the second product's Seller SKU continuation (`Thanh`, `Xuân C9`) is positioned at the same x-coordinate as the SKU column. The parser now preserves the first unit SKU (`1 Cây`) and moves the wrapped continuation into Seller SKU only when it is a unit-like SKU followed by an explicit C/T size.

## Fixes
1. Bound product rows at the first footer Order ID after the product-table header when the page has no `Qty Total`.
2. Keep the continuation page with only `Qty Total` merged into the prior shipment by exact Order ID; it cannot create a third product or a second shipment.
3. Clean SEO/botanical description from the product identity before showing/matching it, while retaining `rawProductName` for audit and explicit size/combo evidence.
4. Correct the normalized description marker for `cây sẵn hoa` and cut the Cẩm tú mai product at that description, preserving C9.
5. Recover the shifted Seller SKU continuation for the documented unit-SKU layout without discarding the primary SKU.
6. Keep `Qty` as sold units. Combo count is still calculated separately from `Qty`; e.g. `Combo 4 tặng 1`, Qty 2 => 10 plants.

## Expected output for the actual PDF's page 3/4
One shipment, one Order ID, two product rows:
- `Combo 4 chậu cẩm tú mai C9`, SKU `Mặc định`, Qty 1 -> catalog `Cẩm tú mai C9`, 4 physical plants per sold unit.
- `Cây Trầu Bà Thanh Xuân`, SKU `1 Cây`, Seller SKU `Thanh Xuân C9`, Qty 1 -> catalog `Trầu bà thanh xuân C9`, 1 physical plant.
- Page 4 `Qty Total: 2` is a footer only.
- Total sold units: 2; total physical plants: 5.

## Validation
- 43/43 JavaScript tests pass.
- `tools/preflight.py` passes.
- Parser was also run locally against text extracted from the user's actual PDF pages 3 and 4. It returned one shipment, two separate product rows, clean product names, `1 Cây` as SKU, `Thanh Xuân C9` as Seller SKU, and successful catalog matches for both C9 plants.
- A full Android Gradle build and on-device import were not run in this environment; do not treat source tests as proof that an APK was built.
