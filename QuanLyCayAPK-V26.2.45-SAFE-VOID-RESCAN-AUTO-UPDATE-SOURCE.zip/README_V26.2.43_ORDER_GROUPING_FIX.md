# ROLL CÂY CẢNH V26.2.43 — Fix gom trang thành một đơn

Bản này sửa logic gom trang theo Order ID, đặc biệt trang tiếp nối chỉ có `Qty Total`.

Kết quả mong đợi với nhãn J&T đã cung cấp:
- Một đơn: tracking `862542794508`, Order ID `586634608115811400`.
- Dòng 1: Combo 4 chậu Cẩm tú mai C9, Qty 1 = 4 cây.
- Dòng 2: Trầu Bà Thanh Xuân C9, Qty 1 = 1 cây.
- Trang tiếp nối chỉ có `Qty Total: 2` không tạo đơn hoặc dòng cây mới.
- Tổng: một đơn, hai dòng sản phẩm, năm cây vật lý.

Giữ nguyên schema và các tính năng còn lại. Build APK/device verification chưa được khẳng định trong tài liệu này.
