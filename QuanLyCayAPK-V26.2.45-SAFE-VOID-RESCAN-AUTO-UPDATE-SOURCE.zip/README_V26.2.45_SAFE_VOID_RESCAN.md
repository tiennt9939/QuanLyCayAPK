# V26.2.45 — Hủy quét nhầm và quét lại an toàn

Dựa trực tiếp trên source V26.2.44, giữ nguyên parser PDF, quy tắc nhận dạng cây, công thức `orderItemRate()`, kho, tiền công và Firebase schema hiện tại. Không tạo thêm truy vấn hay transaction cho luồng quét bình thường ngoài phần kiểm tra claim/report vốn đã có. Chức năng điều chỉnh chỉ chạy khi Admin chủ động bấm.

## Luồng điều chỉnh

1. Trong danh sách vận chuyển, Admin bấm **HỦY GHI NHẬN / CHO PHÉP QUÉT LẠI** trên đúng mã đã ghi.
2. Admin nhập lý do và xác nhận mã, nhân viên, tiền công sẽ bị hủy.
3. Một Firestore transaction đọc report + claim, xác minh mã và trạng thái, rồi đánh dấu report `status: voided`, `wageRecorded: false`, claim `status: voided`, và hàng chờ `status: pending`. Lịch sử lần quét cũ, người nhận công, tiền công, ảnh, thời điểm và lý do vẫn được giữ. Không xóa lịch sử hoặc tự đổi nhân viên.
4. Tiền công và lượng cây của lần đã hủy tự rời khỏi phép tính payroll/tồn kho vì các phép tính hiện hữu chỉ dùng report `status: recorded`. Bộ nhớ cache kho được vô hiệu hóa sau khi Firebase xác nhận.
5. Mã chỉ có thể quét lại khi cả claim và report cũ được xác nhận `voided` và cùng khớp mã vận đơn. Giao dịch mới ghi công theo nhân viên được chọn trong phiên mới; trường `scanRevision` tăng và `voidHistory` được giữ. Retry ảnh cũ không được dùng để tạo tiền công lần hai.
6. Nếu kỳ tiền công đã được ghi vào bản lưu bảo lưu, thao tác hủy tự động bị chặn để không sửa sai kỳ lương đã chốt.

## Tối ưu hiệu năng

- Không thực hiện hủy trong đường xử lý scan/photo bình thường.
- Không render lại toàn bộ UI trong mỗi lần quét; chỉ làm mới sau khi Admin xác nhận điều chỉnh.
- Không xóa record, không xóa claim; dùng trạng thái và nhật ký để đối chiếu.
- Lỗi hoặc mất kết nối trước khi transaction thành công không cập nhật giao diện thành công.

## Phiên bản và kiểm thử

- Android `versionName`: `26.2.45`
- Android `versionCode`: `97`
- Package: `com.quanlycay.apk`
- Kiểm thử: `python tools/preflight.py`, toàn bộ `tools/*_test.js`, và cú pháp 6 khối JavaScript nhúng.

Cần chạy workflow GitHub Actions để xác nhận APK build; môi trường chỉnh sửa hiện tại không có Gradle executable/gradlew nên chưa xác nhận compile APK hay thử trên thiết bị.
