# Audit — V26.2.42 coordinate-based TikTok product matching

## Changes
- Bumped Android metadata to versionName `26.2.42`, versionCode `94`.
- Added native `tableRows` to the PDF import payload. Rows are derived from PDF glyph X coordinates, not character offsets in a proportional-font string.
- Added parser preference for structured `tableRows`, with wrapped SKU/Seller SKU repair and description trimming.
- Added `tools/tiktok_pdf_coordinate_cells_regression_test.js` for the supplied real PDF's known page-3/page-4 structure.
- Preserved the previous text parser as fallback.

## Regression target
- Tracking: `862542794508`
- Order ID: `586634608115811400`
- Product lines: Cẩm tú mai C9 combo 4 Qty 1; Trầu Bà Thanh Xuân C9 Qty 1.
- Page 4 Qty Total only must not add another line/order.
- Expected: 1 shipment, 2 product lines, 5 physical plants.

## Checks
- 44/44 Node tests pass.
- `tools/preflight.py` passes.
- ZIP integrity verified.
- Limitation: this environment did not run an Android Gradle build or the actual PDFBox extractor on an Android device. Do not treat the source tests as proof that the APK was built or device-verified.
