# QuanLyCayAPK V26.2.14 — Admin grouped orders and PDF staging compaction

- Version: `26.2.14`, versionCode `66`, applicationId `com.quanlycay.apk`.
- Base: V26.2.13 source. Auto updater, PDF parsing/matching, barcode scan, Drive storage, one-photo completion, and Firestore schema retained.

## Changes

1. Processed TikTok PDF labels (already linked to an order, assigned, or found live in Firestore) are pruned from the local staging queue. They are no longer rendered as old card rows; their Firestore orders remain intact. New ready labels and labels requiring review remain visible.
2. Admin pending shared orders are displayed as a group summary with a count. Order cards render when the group is expanded, and are removed from the DOM when it is collapsed.
3. Pending private orders are grouped by employee display name with counts. Cards only render when an employee group is expanded.
4. Completed orders are grouped by employee name and count inside the existing collapsed completed-orders section. Details render lazily on expansion and clear on collapse.
5. Admin can reassign an unclaimed shared TikTok PDF order from the shared-order card. It uses the existing `adminAssignOpenPoolOrder` transaction and validates that the live order remains pending/shared/unclaimed. This replaces the queue-row-only entry point, allowing assigned labels to be hidden from staging.

## Preservation

- No changes to Firestore schema/rules, wage formulas, inventory calculations, order item quantities, PDF product matcher, or Drive image upload flow.
- Firestore remains the source of truth; compacting only affects the local PDF staging queue and rendered UI.

## Verification performed

- `python3 tools/preflight.py`: PASS.
- All 21 `tools/*_test.js`: PASS.
- Inline JavaScript syntax: PASS for 6 inline script blocks; external `tiktok-label-import.js`: PASS.
- Workflow YAML syntax: PASS.
- The Android APK for V26.2.14 has not yet been built in this session; use GitHub Actions workflow to build the actual APK artifact.
