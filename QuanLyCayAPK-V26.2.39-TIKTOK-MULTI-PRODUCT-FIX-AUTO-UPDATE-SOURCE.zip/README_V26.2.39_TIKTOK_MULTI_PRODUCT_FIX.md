# ROLL CÂY CẢNH V26.2.39 — Sửa ghép nhãn nhiều sản phẩm

## Vấn đề
Một nhãn TikTok Shop có thể chứa nhiều dòng cây và có trang PDF tiếp nối chỉ còn `Order ID`/`Qty Total`. Parser cũ có thể kéo dòng Qty của sản phẩm trước sang sản phẩm kế tiếp; trang tiếp nối có thể bị coi là một nhãn/đơn khác. Mô tả SEO dài cũng có thể lấn sang cột SKU trong dữ liệu trích xuất.

## Thay đổi
- Mỗi dòng sản phẩm bắt đầu sau dòng Qty của sản phẩm trước, không lấy lại chính dòng Qty đó làm phần đầu dòng kế tiếp.
- Các trang tiếp nối chỉ được ghép khi cùng Order ID (hoặc cùng mã vận đơn nếu thiếu Order ID) và ít nhất một phía không có dòng sản phẩm; nhãn đầy đủ bị lặp vẫn được báo trùng để tránh ghi nhận kép.
- Giữ nguyên mã vận đơn, Order ID và các dòng sản phẩm đã tách; không biến mô tả quảng cáo thành cây mới.
- Thêm hồi quy kiểm tra nhãn J&T `862542794508`, Order ID `586634608115811400`: hai dòng `Combo 4 chậu cẩm tú mai C9` và `Cây Trầu Bà Thanh Xuân...`, Qty 1 + 1; trang tiếp nối có `Qty Total: 2` phải được ghép về cùng một nhãn.
- Không thay đổi Firestore schema hoặc công thức tồn kho.

## Build
ZIP: `QuanLyCayAPK-V26.2.39-TIKTOK-MULTI-PRODUCT-FIX-AUTO-UPDATE-SOURCE.zip`
GitHub Actions workflow: `Build ROLL CAY CANH`; input `source_zip` phải trùng chính xác tên ZIP trên.

## Kiểm thử
`python tools/preflight.py` và toàn bộ `tools/*_test.js` chạy đạt trong môi trường kiểm thử mã nguồn. Chưa build APK Gradle hoặc kiểm tra PDF gốc trên thiết bị thật trong lần này.
