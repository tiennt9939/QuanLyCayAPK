# V26.2.38 — Performance follow-up

## What changed
- `renderAll()` updates only the active tab instead of rendering daily entry, stock, reports, quote, controls and legacy panels on every action. Other tabs refresh when the user opens them.
- Successful daily-shipment captures update only the scanned row and visible count; they no longer rebuild the whole report/list or synchronously serialize the entire app cache per parcel.
- Local app-cache persistence is coalesced until the camera session and the background photo/report workers finish; report and duplicate-claim transaction remain authoritative in Firebase. Pending photo state remains persisted separately and the local photo is only acknowledged after the cloud report succeeds.
- Lite shipping mode stops automatically refreshing the hidden legacy assignment/PDF UI and removes the redundant full shared-data upload on every Admin login. Existing schema, stock formulas and legacy source functions remain present.
- All-order historic hydration is cached after a successful fetch and, when necessary, deferred until the app is idle/visible outside the scan tab. Retention cleanup is deferred too; neither task blocks authentication's initial UI setup.

## Not claimed
- No real device profile/Gradle APK build is performed in this environment. This is a source-level performance correction, not proof that all actions meet a timing SLA. Firebase reads/writes, first-ever history hydration and the stock calculation itself may still be expensive when the stored history is very large. Measure on-device with the shop's real account/data.

## Follow-up optimization included in this archive
- Admin Firestore order snapshots no longer redraw hidden assignment controls and the legacy PDF queue while daily-shipment lite mode is active. In lite mode they refresh only the stock, report, or home KPI view when that visible view depends on updated completed-order inventory.
- First hydration of all historical orders is not part of sign-in/startup. It is requested only when Admin opens Stock or Reports, so a first read can still take time if Firestore contains a very large history; the on-screen view renders from available cache first.
- The source retains all legacy assignment/payroll functions and the original Firestore schema for restoration. No payroll/assignment source was deleted.
