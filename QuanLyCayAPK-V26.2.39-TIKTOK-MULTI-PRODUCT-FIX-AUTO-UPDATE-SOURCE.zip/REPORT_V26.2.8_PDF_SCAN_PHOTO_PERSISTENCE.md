# Audit report — QuanLyCayAPK V26.2.9 PDF recognition + bulk assignment

## Source baseline
- Derived from the original handover source archive `QuanLyCayAPK-V26.2.4-TIKTOK-PDF-CATALOG-MATCH-FIX.zip`.
- Android application ID: `com.quanlycay.apk`.
- The output release is `26.2.9` / versionCode `59`, based on source V26.2.4. V26.2.5 was not used as source.
- No V26.2.5 source was used.

## Implemented
1. Catalog matcher extracts size tokens from the complete Product Name, SKU and Seller SKU, including a size token after a dash.
2. Explicit disagreement or multiple sizes normally requires Admin review, except the confirmed business rule for Combo 5 Cẩm tú mai with exactly C6/C7 evidence, which maps to Cẩm tú mai C7.
3. No explicit size defaults to C7 only when a matching C7 catalog row exists. If duplicate C7 rows exist, Admin must choose the right one.
4. Combo N is retained as plants per sold unit; PDF Qty remains sold units and is multiplied exactly once when mapping the order items.
5. The PDF queue now has per-label checkboxes and “select all eligible labels”; Admin may create selected draft labels directly into the shared pool or assign them directly to one active packer. Existing unclaimed shared PDF orders selected from the queue move atomically to the chosen employee. This corrects the prior V26.2.6 gap where bulk controls existed only in the lower general order list, not in the PDF queue shown in the screenshot.
6. Admin can tick one or multiple unclaimed shared orders, select one active packer, and transfer them in one action. Each transfer uses a Firestore transaction and checks the order is still pending, still shared, and not already claimed. This prevents racing a packer who claims the order first.
7. The existing barcode verification and photo completion flow is unchanged.

## Important catalog finding
The bundled seed catalog has two `Táo thái` rows with blank size and no explicit `Táo thái C9` row. The provided TikTok label explicitly says C9 in Product Name and SKU. The matcher therefore leaves it for Admin review instead of silently mapping C9 to a blank-size row. Add/confirm the correct C9 row in the live catalog before expecting automatic matching.

## Regression results
- `python3 tools/preflight.py`: PASS.
- All 15 `tools/*_test.js` tests: PASS, including `tiktok_pdf_bulk_assignment_test.js`.
- Inline JavaScript syntax check: PASS.
- Real PDF layout regression: 12/12 existing fixture pages include product rows and positive Qty.

## APK build status
This environment has Java 21 but no Android SDK, Gradle installation, Android platform packages, or network DNS access to download them. Therefore no APK was built or signed in this environment, and no APK artifact is claimed. The GitHub Actions workflow was updated to include the new regression test and retains the build/sign/verify/artifact steps. Run the workflow manually in GitHub Actions to produce the actual APK artifact.

## Recognition memory behavior
- The exact product + SKU + Seller SKU mapping continues to persist locally. In addition, manually editing a product map to a valid selection now records a reusable recognition rule keyed by normalized product-name tokens, Combo size and the union of explicitly detected sizes.
- A subsequent label with the same signature is auto-mapped to the saved catalog row(s). Different size signatures, Combo counts, or names do not reuse that learned rule.
- Rules live in localStorage on the Admin device and do not sync to other devices or survive clearing app storage.

## Preserved
No changes were made to payroll formulas, inventory equations, wage rules, Firestore schema, Firestore rules, Google Drive image persistence, or completion photo requirements.


## Khắc phục sau phản hồi — quy tắc nhận diện được xác nhận
- Quy tắc cố định: `Combo 5 Cẩm tú mai` có tín hiệu kích thước đúng bộ `{C6, C7}` sẽ khớp dòng Cẩm tú mai C7. Qty được quy đổi bằng 5 cây/đơn vị × Qty. Quy tắc không áp dụng cho cây khác, Combo khác, hoặc nếu có thêm kích thước C9/C10/C11.
- Khi Admin sửa mapping và chọn đúng cây/số cây, app lưu quy tắc nhận diện ở localStorage. Các nhãn sau được tự ghép nếu chữ đã chuẩn hóa, số cây/combo và bộ kích thước khớp. Quy tắc cục bộ chỉ dùng trên cùng thiết bị/app; không đồng bộ sang thiết bị khác.
- Parser exposes `recognitionSignature` and `applyRecognitionRule`; regression tests verify learned reuse and reject signature mismatch.
- Release metadata: V26.2.9 / versionCode 61 (based on V26.2.4; V26.2.5 was not used as source).


## PDF queue bulk selection patch — V26.2.9
- Added visible checkbox per selectable PDF label and select-all for eligible labels in the actual TikTok PDF queue, not only the separate lower-level order list.
- Added target selector for shared pool versus a specific active packer.
- New selected labels are created directly in the target mode. An already-created, still-unclaimed shared order may be moved to an employee via the existing transaction-backed Firestore method.
- Added a single-flight guard to block duplicate taps while a multi-order assignment is running. Orders already completed, already privately assigned to another employee, unverified, unmapped, or otherwise ineligible are blocked rather than silently reassigned.
- Release metadata: V26.2.9 / versionCode 61.

## V26.2.9 — Fix PDF scan-to-photo flow

- Assigned TikTok PDF order cards launch barcode scanning for the selected order instead of opening a photo form without a scanned code.
- Unclaimed shared-pool TikTok PDF cards also launch the scanner. A fresh barcode lookup permits a pending, unassigned `open_pool` PDF order; a Firestore transaction then atomically claims it and opens the proof-photo form using the same verified code. Other users' assigned orders remain inaccessible.
- If the barcode scanned from a specific order card belongs to a different order, the app refuses to open or complete it.
- The proof form asks for photo 1 (package overview) and photo 2 (shipping label / another package view). Each photo uploads to Drive before submission. Successful completion writes Drive references into `completionImage` and `completionImages` in the Firestore order document.
- Barcode scanning itself reads the barcode and does not take a photo; a successful scan now leads directly to the two-photo form. Photos are attached to the order only after Firebase confirms completion.
- Added regression test `tools/tiktok_pdf_scan_photo_capture_test.js`.
- Release metadata: V26.2.9 / versionCode 61, based on V26.2.4; V26.2.5 was not used.
- Android APK compilation and device testing still require the GitHub Actions workflow. Not claimed complete.
