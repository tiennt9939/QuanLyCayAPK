# V26.2.16 — Persistent, shared TikTok PDF recognition rules

## Root cause addressed

Admin-confirmed TikTok label recognition rules were written only to `localStorage`. They therefore did not reliably survive cleared WebView/app-local data or transfer to another Admin device. The UI also described them as device-local.

## Fix

- Load recognition rules from the existing dedicated Firestore config document `/config/roll-cay-canh` before auto-mapping PDF labels, including a fresh read before each new PDF import. Save operations have a conservative document-size guard.
- Save only dedicated top-level fields (`tiktokRecognitionRules`, `tiktokRecognitionRulesUpdatedAtMs`, and `tiktokRecognitionRulesUpdatedByUid`) using `mergeFields`; this avoids growing the large business snapshot and does not replace catalog subcollections or packing orders.
- Existing local-only rules migrate once per Admin UID/device, while Cloud values win same-signature conflicts.
- Persist deletion tombstones locally so a deliberately invalidated old rule cannot silently return if Cloud writes are temporarily unavailable. Tombstones are cleared only after the Cloud save succeeds.
- Invalidate the previous rule before accepting a new manual mapping. Save its replacement only when the mapping is complete, valid for the current catalog, and its plant count matches the sold unit.
- Preserve explicit size protection: a currently visible C9 in Product Name/SKU/Seller SKU remains stronger than an old C7 learned mapping. C7 and C9 signatures remain distinct.
- Display an in-panel warning if Cloud recognition rules could not be loaded, rather than stating incorrectly that a local-only rule is shared.

## Firestore access

This implementation uses the existing `/config/{configId}` permission block and the document `/config/roll-cay-canh`. The Rules shown in the user's Firebase screenshots permit active users to read and Admin/procurement to write this config document. No new collection or broader rule is introduced. If the deployed Rules have changed since then, an Admin read/write to `/config/roll-cay-canh` is still required.

## Verification performed

- `python tools/preflight.py` — PASS.
- All `tools/*_test.js` regression tests — PASS, including `tiktok_recognition_cloud_persistence_test.js`.
- JavaScript syntax — PASS for 6 inline script blocks and `tiktok-label-import.js`.
- Existing catalog matcher regression continues to enforce explicit C9 priority, stale C7 rejection, and the confirmed Combo 5 Cẩm tú mai C7 exception.

## Not yet verified

No live Firestore write test or physical Android test was performed in this environment. GitHub Actions must build the APK; then test a manual Admin mapping, import a similar label after closing/reopening the app, and test the same mapping on a second Admin device. Do not claim cross-device persistence until this live test succeeds.
