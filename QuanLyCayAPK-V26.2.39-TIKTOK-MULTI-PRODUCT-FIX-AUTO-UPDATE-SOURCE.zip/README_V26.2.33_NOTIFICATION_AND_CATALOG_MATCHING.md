# ROLL CÂY CẢNH V26.2.33 — Notification count only + direct catalog matching

## Notification behavior
- The bell retains its realtime numeric badge (including `99+`).
- Automatic pending-order count changes no longer open the order-list modal, toast, play sound, or vibrate.
- Tapping the bell does not fetch pending orders or rebuild the list. Staff/admin can continue to manage orders in the existing `Theo ngày` workflow.
- This change does not alter Firestore order statuses, assignment, completion, payroll, inventory, or security rules.

## TikTok PDF plant mapping
- If the parser reports multiple candidates (for example, duplicate Hàm Hương C7 catalog lines), the app deliberately does not silently select one.
- The UI now displays direct one-tap buttons for the candidate rows. Choosing a candidate sets the expected plant count per sold unit, refreshes the local mapping immediately, and schedules the shared recognition rule save in the background.
- The regular “Thêm dòng cây / kích thước” path remains available for multi-line/manual combo mappings.
- The full catalog options inside an existing selector are generated on focus, not for every product card during initial render.
- Mapping add/edit/remove renders locally first instead of waiting on a full PDF panel render and cloud refresh.

## Verification performed
- 38 JavaScript regression test files passed.
- `tools/preflight.py` passed.
- All inline JavaScript blocks and `tiktok-label-import.js` passed `node --check`.
- This is a source package; it has not been built with GitHub Actions or benchmarked on the user's phone in this environment.
