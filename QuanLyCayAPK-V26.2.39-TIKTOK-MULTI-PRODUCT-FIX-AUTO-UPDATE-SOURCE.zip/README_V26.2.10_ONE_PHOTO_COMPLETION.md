# V26.2.10 — Hoàn tất đơn bằng một ảnh

- Tất cả đơn đóng hàng chỉ cần **1 ảnh** để hoàn tất lần đầu, gồm đơn riêng, đơn chung, TT, ĐN và đơn TikTok nhập từ PDF.
- Ảnh nên thấy rõ kiện hàng và nhãn vận đơn trong cùng khung hình.
- Đơn TT thông thường sẽ OCR mã vận đơn từ ảnh duy nhất. Đơn PDF đã xác minh bằng quét mã giữ nguyên kết quả xác minh và không OCR ghi đè.
- Ảnh phải tải lên Google Drive thành công; đơn chỉ hoàn tất sau khi Firestore xác nhận ghi thành công.
- Với ĐD, luồng bổ sung nhãn/OCR sau đó vẫn được giữ.
- Không đổi công thức tiền công, tồn kho, phân công, schema Firestore, PDF import, barcode scan hoặc quy tắc nhận dạng cây.

## Quan trọng
Trước khi cài APK, hãy publish `firestore.rules` đi kèm source này vào đúng Firebase project. Nếu chỉ cập nhật APK mà không cập nhật rules, Firebase có thể vẫn từ chối hoàn tất đơn bằng một ảnh.
