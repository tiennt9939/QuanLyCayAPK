# ROLL CÂY CẢNH V26.2.27 — Fix tách sai dòng PDF và Combo N tặng M

## Vấn đề tái hiện từ nhãn thực tế

Nhãn TikTok/GHN có một sản phẩm duy nhất:
- Product Name bị xuống dòng: `Cây Ruby Đỏ - Nắng màu đỏ rực phù hợp mọi không gian`
- SKU bị xuống dòng: `Combo 4 tặng 1`
- Qty trên nhãn: `1`

Bản cũ có thể hiểu phần cuối `tặng 1` là Qty thứ hai và tách mô tả sản phẩm thành hai dòng, làm một dòng không tìm được cây trong danh mục. Đồng thời bộ đếm combo chỉ hiểu `Combo 4` là 4 cây, bỏ qua cây tặng.

## Sửa trong V26.2.27

- Bộ phân tích ưu tiên văn bản dựng theo tọa độ PDF và yêu cầu số lượng của dòng sản phẩm phải nằm trong vùng cột Qty; số nằm cuối dòng nối của SKU như `tặng 1` không được xem là Qty mới.
- Khi chấm điểm các phiên bản văn bản PDF, ưu tiên dòng sản phẩm có đủ tên/SKU/Qty; tránh chọn kết quả lỗi đã tách một sản phẩm thành nhiều đoạn không có SKU.
- Giữ toàn bộ Product Name và SKU qua các dòng xuống hàng trong cùng một hàng sản phẩm.
- Quy tắc số cây: `Combo N tặng M` = `N + M` cây cho mỗi đơn vị bán. Ví dụ `Combo 4 tặng 1` = 5 cây; Qty trên nhãn vẫn là 1 đơn vị bán, không phải 5 đơn vị bán.
- Nếu cùng nhãn đã được import vào hàng đợi tạm từ bản cũ, nhập lại chính PDF sau khi cập nhật sẽ làm mới bản ghi tạm chưa phân công bằng kết quả phân tích mới. Không ghi đè đơn đã gắn với đơn thật/đã phân công trên Firebase. Bộ ánh xạ Admin duy nhất của dòng cũ được chuyển sang sản phẩm đã ghép và số cây mỗi đơn vị được chuẩn hóa theo Combo N tặng M.
- Không thay đổi tồn kho, tiền công, lương, mã vận đơn, schema Firestore hay quy tắc ghép nhãn ĐD. Số cây thực tế được lấy từ Qty bán × số cây mỗi đơn vị theo ánh xạ danh mục.

## Phiên bản và kiểm thử

- `versionName`: `26.2.27`
- `versionCode`: `79`
- `tools/tiktok_pdf_combo_gift_regression_test.js`: tái hiện nhãn Combo 4 tặng 1 và xác nhận chỉ có một dòng sản phẩm, SKU đầy đủ, Qty = 1, số cây/đơn vị = 5.
- `tools/tiktok_pdf_queue_reparse_upgrade_test.js`: xác nhận import lại cùng PDF sẽ sửa hàng đợi cũ bị tách sai, giữ lựa chọn nhân viên/ngày quét, giữ ánh xạ danh mục phù hợp, và không sửa đơn đã liên kết.
- Tất cả 34 bài kiểm thử JavaScript đạt.
- `tools/preflight.py` đạt.
- Kiểm tra cú pháp JavaScript và phân tích AndroidManifest XML đạt.
- ZIP được kiểm tra tính toàn vẹn sau khi đóng gói.

## Giới hạn

Đây là mã nguồn đã qua kiểm tra tự động; chưa build APK thật bằng GitHub Actions và chưa cài thử trên thiết bị có PDF gốc. Sau khi build/cài, cần import lại đúng PDF để xác nhận kết quả thực tế trên Android/PDFBox.
