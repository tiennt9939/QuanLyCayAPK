# V26.2.23 — Admin-completed PDF queue cleanup

## Root cause from the reported workflow
The PDF labels are a local staging queue (`roll_tiktok_label_queue_v1`), separate from the Firestore packing orders. Admin's “complete without photo” action updates the real packing order to `status: completed` and records payroll, but a legacy PDF label that has no reliable tracking/document ID relation can remain `ready` in the local queue. Tracking-only reconciliation cannot safely infer which unrelated historical order corresponds to such a label.

## Changes
- Added a clearly labeled Admin-only action: **DỌN N NHÃN PDF TẠM ĐÃ XỬ LÝ**.
- The action requires confirmation and clears only `tiktokLabelQueue` and the queue's bulk selections on this device.
- It does not delete or mutate Firestore packing orders, completion records, photos on Drive, inventory, payroll, recognition rules, plant catalog, or pricing.
- After Admin marks an order complete without a photo, the app refreshes its authoritative orders cache and immediately reconciles/prunes labels with a reliable ID/tracking link, then refreshes the PDF panel.
- An explicit caution explains to only use the cleanup action after confirming all remaining temporary labels are already processed or should no longer be assigned.
- Version 26.2.23, versionCode 75. Core business logic and Firestore schema remain unchanged.

## Verification
- `python3 tools/preflight.py`: PASS.
- All 29 JavaScript test files: PASS.
- JavaScript syntax: 4 inline script blocks and `tiktok-label-import.js`: PASS.
- Android Manifest XML parse: PASS.
- ZIP integrity check: PASS.
- No real-device test or GitHub Actions APK build was performed in this environment.
