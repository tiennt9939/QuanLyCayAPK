# V26.2.4 — TikTok PDF + catalog-matching fix

## Root cause confirmed from supplied 12-page PDF
The previous fallback parser assumed that Product Name / SKU / Seller SKU / Qty labels were followed by their values in nearby contiguous text lines. This assumption fails for PDFBox output when the PDF content stream interleaves table columns with delivery information. The existing tests used hand-written text samples and did not test all 12 real visual table layouts, so they passed while the phone import could still show `Không tách được dòng sản phẩm/SKU/Qty`.

## Fix
- Added `VisualLayoutPdfTextStripper`, which collects PDF glyph coordinates per page, groups them by visual baseline, sorts each row by X coordinate, and reconstructs spacing so columns remain aligned.
- Android now returns this `visualText` representation alongside the previous two text representations; the original inputs are retained as fallbacks.
- JavaScript now scores the visual, layout-preserving, and standard PDFBox text candidates and uses the candidate containing the most complete product information.
- Added a sanitized regression fixture built from product-table fragments across all 12 pages of the supplied PDF. It includes real product-name wrapping / SKU column patterns but excludes recipient, address, phone, live tracking IDs, and live Order IDs.
- Version is V26.2.4 / versionCode 56 so Android can receive the build as a normal app update.

## Data/business safety
- No Firestore collection/schema, Firestore Rules, catalog, catalog prices, employee access, wage calculation, inventory logic, Drive image handling, or order-completion behavior is changed by this fix.
- PDF import remains a staging workflow. The Admin reviews the product-to-catalog mapping and resolves ambiguous matches before assigning the label. Unique catalog matches are prefilled but still remain behind the assignment validation gate.
- The fix does not create an order, alter inventory, or calculate wages simply by importing a PDF.

## Tests
- `node tools/tiktok_label_import_test.js`
- `node tools/tiktok_pdf_real_layout_regression_test.js` (all 12 sanitized table layouts)
- all existing `tools/*_test.js` checks
- `python3 tools/preflight.py`
- JavaScript syntax checks

## Build/device validation limitation
The Android PDFBox coordinate extractor must still be compiled in GitHub Actions and exercised on the phone with `TikTokSeller.pdf`. Source-level tests validate the JavaScript side and the known visual table layouts, not the Android runtime itself. If the native coordinate extractor fails to compile, do not install the APK; use the workflow diagnostics to correct it first.


## Catalog matching rule (updated 2026-10-11)
- Every parsed Product Name is compared against the currently loaded app catalog; new catalog entries are never synthesized from PDF text.
- Marketing copy after the first hyphen/en dash/em dash is ignored for catalog matching.
- Combo N means N plants per sold unit; PDF Qty is the number of sold units. Effective plant quantity is N × Qty.
- A unique exact catalog name/size match is prefilled automatically. If size is absent, multiple catalog sizes exist, duplicate catalog rows exist, or the label conflicts with available sizes, Admin must explicitly choose a catalog row before assignment.
- The Admin mapping step is still required as a safety gate; automatic matching only fills a unique candidate and never creates or assigns an order itself.
