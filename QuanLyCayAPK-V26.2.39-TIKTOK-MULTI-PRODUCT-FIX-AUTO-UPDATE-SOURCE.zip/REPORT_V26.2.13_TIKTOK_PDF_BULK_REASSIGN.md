# QuanLyCayAPK V26.2.13 — PDF bulk assignment state fix

## Release identity
- Android package: `com.quanlycay.apk`
- `versionName`: `26.2.13`
- `versionCode`: `65`
- Base: V26.2.12 auto-update and storage optimized source.

## Fixes
1. Before calculating the PDF queue bulk-select count, reconcile local staged labels against the loaded Firestore order rows using the normalized tracking number or linked order id. Stale local `ready` entries become linked/assigned UI entries when the order already exists.
2. Bulk PDF selection now allows only mapped, new, unlinked `ready` labels. Existing orders—including pending unclaimed shared-pool orders—cannot be selected or moved by the bulk operation. If another device creates an order after a label was selected, the bulk handler rejects it safely instead of reassigning it.
3. Each existing pending, unclaimed shared order in the PDF queue gets its own employee selector and `CHIA LẠI RIÊNG` action. The action refreshes the Admin order list, validates the order, asks for confirmation, then uses `adminAssignOpenPoolOrder` which performs a Firestore transaction that rechecks pending/open_pool/empty assignedUid.
4. Orders that are claimed, completed, or already private cannot be moved by this control. The queue's stale checkbox selection is cleared on reconcile.

## Preserved
- TikTok PDF extraction, tracking matching, SKU/catalog mapping, learned rules, quantity/combo math, barcode/photo flow, Drive references, Firestore schema/rules, wage calculation, and inventory calculations.
- Reassigning a shared order changes only assignment fields; it does not create a new order, complete an order, deduct stock, or recompute wages.

## Verification needed
Run `python3 tools/preflight.py`, all `tools/*_test.js`, JavaScript syntax checks, and the included GitHub Actions build workflow. This source archive has not itself been compiled into an APK in this editing environment. Verify the rendered PDF screen with the real imported queue on Android after a successful Actions build.
