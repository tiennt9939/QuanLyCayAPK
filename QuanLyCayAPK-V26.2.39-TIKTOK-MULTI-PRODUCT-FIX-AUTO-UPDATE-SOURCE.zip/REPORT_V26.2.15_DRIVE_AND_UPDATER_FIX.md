# V26.2.15 — Drive OAuth diagnostics and stable updater signing migration

## Confirmed issues
- The installed V26.2.14 APK was taken from successful Actions run `38352179346` and its certificate was inspected directly: SHA-1 `86:56:08:0C:EB:29:7B:4F:72:FC:98:70:7E:63:4D:74:69:6A:28:C8`; SHA-256 `4E:27:5A:0B:C3:01:76:64:A5:42:8E:E5:12:CD:5B:1C:C5:DA:AB:1F:B6:EF:56:C0:65:50:88:EE:DA:0C:8B:4A`. Register these fingerprints against Android application ID `com.quanlycay.apk` in Firebase / Google Cloud OAuth to fix Drive error 10 for this current APK.
- The latest GitHub Actions run `38352179346` succeeded, but GitHub Releases endpoint returned no releases. The workflow log shows `DEBUG_KEYSTORE_BASE64` exists while `EXPECTED_APK_CERT_SHA256` is empty, so the stable-keystore path is not enabled and release publication is skipped.
- V26.2.11 and V26.2.14 Actions artifacts were signed by different debug certificates, proving that ephemeral runner signing is not stable. Current V26.2.14 cannot be silently updated to a different signing certificate. A one-time manual migration is required.

## Changes in source
- Bump version to `26.2.15`, versionCode `67`.
- Map GoogleSignIn `ApiException` status 10 to a clear Vietnamese message identifying OAuth/package/SHA fingerprint configuration.
- GitHub Releases 404 status explains that Actions Artifacts are not the public updater feed and that Release publication is blocked until stable signing is configured.
- The companion workflow decodes `DEBUG_KEYSTORE_BASE64` when present, always uses it for the APK build, and prints certificate SHA-1/SHA-256 without exposing the private keystore. It only publishes a Release if `EXPECTED_APK_CERT_SHA256` is set and matches the APK signature. Missing expected fingerprint produces artifact-only output for one-time migration.

## Safe migration procedure
1. On the current V26.2.14 app, sync cloud data and make an admin backup of any local-only data before reinstalling.
2. Add the current V26.2.14 fingerprints above in Firebase / Google Cloud OAuth so the current install can connect Drive now.
3. Upload this source ZIP and the companion workflow, then run the workflow with `EXPECTED_APK_CERT_SHA256` blank. The log prints the stable keystore SHA-1/SHA-256 and the run uploads a stable-signed APK artifact.
4. Add the printed stable SHA-1/SHA-256 to the same Firebase Android app / Google OAuth Android client. Download the artifact APK. Because the signature changes from the old ephemeral key, do not use in-app install; after verified cloud sync/backups, one-time uninstall/reinstall may be required. Reconnect Drive afterward.
5. Set GitHub Actions secret `EXPECTED_APK_CERT_SHA256` to the stable keystore SHA-256 printed by the workflow and rerun the workflow to publish the matching Release. Future version builds use the same key; never change the key.

## Preserved
- PDF import/matching, barcode scan, order assignment/grouping, one-photo completion, existing Firestore data schema/rules, payroll formulas and inventory logic.

## Verification status
- `python3 tools/preflight.py`: PASS.
- All JavaScript regression tests: PASS, including new Drive OAuth code-10 diagnostic test.
- All inline JavaScript blocks and external PDF parser syntax checks: PASS.
- YAML parsed successfully and the modified workflow shell blocks were syntax-checked.
- The Android APK must still be built by GitHub Actions; no local APK build is claimed.
