# QuanLyCayAPK V26.2.34 — Tích hợp quét mã và chụp ảnh kiện hàng

## Mục tiêu
Giảm thao tác và thời gian chờ khi nhân viên hoàn tất đơn TT được giao qua mã vận đơn GHN/J&T, đồng thời không bỏ yêu cầu ảnh bằng chứng và xác minh Firebase.

## Luồng sử dụng
1. Mở quét mã của đơn được phân công.
2. Máy quét dùng camera liên tục để nhận mã vận đơn trong cùng Activity CameraX.
3. Sau khi khóa được mã hợp lệ, màn hình camera chuyển sang chụp ảnh; nhân viên đưa toàn bộ kiện hàng và nhãn vào khung rồi bấm **CHỤP ẢNH KIỆN HÀNG + NHÃN**. Có thể bấm quét lại nếu nhận nhầm mã.
4. App đối chiếu đúng đơn trên Firebase. Nếu đơn khớp, ảnh đã nén được tải lên Google Drive ở nền và modal hoàn tất hiện ra.
5. Nút xác nhận chuyển xanh ngay khi đã có ảnh và mã hợp lệ, kể cả trong lúc Drive đang tải. Nếu nhân viên bấm xác nhận, app đợi promise tải Drive hoàn tất thành công rồi mới ghi hoàn tất vào Firestore.

## Tối ưu ghi nhận
- Ảnh JPEG được giảm kích thước tối đa khoảng 1280 px, mục tiêu dưới 450 KB để giảm thời gian chuyển qua cầu Java/WebView.
- CameraX dùng `CAPTURE_MODE_MINIMIZE_LATENCY`.
- Đọc dữ liệu đơn và `shipmentTrackingClaims` song song trong transaction khi có mã cần claim; cập nhật đơn/claim vẫn ở cùng transaction để giữ chống trùng.
- Không tải ảnh Drive vừa tải lên về ngay sau khi ghi đơn và không thực hiện lượt đọc đơn thừa sau transaction.

## Giữ nguyên bảo vệ
- Bắt buộc mã vạch khớp đúng đơn đang chọn.
- Kiểm tra đơn mới nhất trên Firebase, tài khoản và người được phân công.
- Ảnh phải có tham chiếu Drive được xác nhận trước khi ghi hoàn tất.
- Chống trùng mã vận đơn giữ nguyên bằng `shipmentTrackingClaims` và transaction.
- Nếu mã không khớp, camera bị hủy, ảnh lưu thất bại hoặc Firebase chưa xác nhận, đơn vẫn chưa hoàn tất.

## Cách kiểm thử trên điện thoại
- Build V26.2.34 bằng workflow hiện hữu.
- Thử đơn PDF GHN dạng `VNGH...` và một nhãn J&T.
- Xác nhận ảnh chụp có cả kiện hàng và nhãn, ảnh Drive tồn tại, đơn đúng người/đúng tracking, chỉ ghi công một lần.
- Thử hủy máy quét hoặc để upload Drive thất bại; đơn phải vẫn ở trạng thái chưa hoàn tất.

## Giới hạn đã biết
Bộ kiểm thử tự động xác minh mã nguồn và điều kiện kiểm soát nhưng không thay thế một lượt Gradle build hay đo benchmark trên điện thoại. Thời gian thực tế còn phụ thuộc mạng, Drive, Firebase và thiết bị.
