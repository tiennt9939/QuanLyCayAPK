# ROLL CÂY CẢNH — V26.2.28

## Phạm vi sửa lỗi

### 1. Nhãn TikTok Shop “Combo 4 tặng 1”
- Sửa trường hợp PDF tách sai thành tên sản phẩm kết thúc bằng `tặng` và trường SKU chỉ có số `1`.
- Chuẩn hóa về một sản phẩm: tên `Cây Ruby Đỏ - Nắng màu đỏ rực phù hợp mọi không gian`, SKU `Combo 4 tặng 1`, Qty PDF `1`.
- `expectedPlantsPerSoldUnit` trả về 5. Khi Admin ghép một mục danh mục duy nhất với `perUnit = 5`, mapping được xác nhận và đơn tạo ra có 5 cây thực tế (Qty 1 × 5), không tạo dòng sản phẩm giả.
- Không suy diễn các SKU số khác: sửa chỉ áp dụng khi tên có `Combo N`, tên kết thúc bằng `tặng`/`tang`, và ô SKU chỉ chứa số quà.
- Giữ nguyên logic combo còn lại: Combo 4 không có quà = 4 cây; Combo 4 tặng 2 = 6 cây.

### 2. Tiền công Táo Thái C9
- Thêm ngoại lệ đơn giá đóng gói 5.000 VND/cây khi tên cây chuẩn hóa có `Táo Thái` và kích thước là `C9`.
- Chỉ áp dụng cho Táo Thái C9. Táo Thái C7 và cây khác kích thước C9 tiếp tục dùng bảng tiền công chung / quy tắc hiện hữu.
- Tôn trọng `assignedRate` đã được snapshot khi phân công, nhằm không tự ghi đè dữ liệu tiền công đã gán hoặc làm sai lệch lịch sử. Đơn phân công mới dùng quy tắc 5.000 VND/cây.

## Kiểm thử và xác minh

- 34/34 file kiểm thử tự động trong `tools/*_test.js` đã chạy đạt.
- `tools/preflight.py`: PASS.
- 4 khối JavaScript inline trong `index.html`: cú pháp PASS.
- `tiktok-label-import.js`: cú pháp PASS.
- Android Manifest XML: PASS.
- ZIP: kiểm tra nội dung bằng `unzip -t`.

## Giới hạn

Mã nguồn đã qua kiểm thử tĩnh/tự động cục bộ. APK chưa được build hoặc cài thử trên thiết bị trong bước này; vẫn cần chạy GitHub Actions rồi thử nhập lại chính nhãn PDF Ruby Đỏ. Với đơn Táo Thái C9 đã được phân công trước đây có `assignedRate` snapshot, snapshot cũ được giữ nguyên; thay đổi tự áp dụng cho các đơn được phân công sau khi cài bản mới.
