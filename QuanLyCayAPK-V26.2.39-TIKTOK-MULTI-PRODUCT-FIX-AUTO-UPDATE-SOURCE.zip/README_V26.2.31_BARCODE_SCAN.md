# V26.2.31 — Faster shipping barcode scan

This source replaces the old Google Code Scanner modal with a native CameraX + bundled ML Kit scanner, with torch, zoom, touch-to-focus and manual tracking-code fallback.

Build through the repository's existing GitHub Actions workflow. The source has automated/preflight checks, but no Android APK build or physical-device scan benchmark was performed in this environment.


## V26.2.31 build compatibility note

The barcode-scanner runtime behavior remains unchanged. AndroidX Activity and CameraX versions were aligned to releases compatible with the existing GitHub Actions SDK installation (compileSdk 35 / Android Build Tools 35.0.0), avoiding the AAR metadata mismatch introduced by using Activity 1.12.4 and CameraX 1.5.3.
