# V26.2.32 — Sửa thời gian khởi động/đăng nhập

## Nguyên nhân trong source V26.2.31
- Firebase JS SDK chỉ tải từ CDN khi khởi động; `__loadScript()` không có timeout nên một CDN bị treo có thể khiến WebView chờ lâu trước khi thử máy chủ dự phòng.
- `CloudSync.init()` chờ `auth.setPersistence()` và `db.enablePersistence()` trước khi đăng ký `onAuthStateChanged`; Firestore IndexedDB cache là tối ưu phụ nhưng có thể làm chậm khôi phục phiên.

## Sửa đổi
- Mỗi lần tải script Firebase có timeout tối đa khoảng 4.2 giây; tổng ngân sách thử CDN là 16 giây rồi báo rõ lỗi mạng.
- Dọn script lỗi/hết giờ và thử CDN dự phòng; dùng single-flight để tránh tải trùng cùng URL.
- Không chờ Firestore IndexedDB cache trước khi đăng ký auth listener; nếu cache không khả dụng app tiếp tục dùng online.
- Giữ bước đọc hồ sơ `users/{uid}` và kiểm tra active/role trước khi bỏ màn hình đăng nhập. Không hạ bảo mật, không cho phép vào app khi chưa xác minh hồ sơ.
- Đăng nhập tương tác vẫn đặt Firebase Auth persistence LOCAL trước khi thực hiện sign-in.

## Giới hạn
Bản sửa loại bỏ các điểm chờ không có giới hạn rõ ràng trong bộ nạp SDK và initialization cục bộ. Tốc độ cuối cùng vẫn phụ thuộc mạng, Firebase Auth và Firestore; cần đo thực tế trên thiết bị. Chưa khẳng định build Android thành công trong môi trường này nếu chưa chạy workflow Gradle thật.
