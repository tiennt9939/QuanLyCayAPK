# QuanLyCayAPK V26.2.9 — Sửa nhận dạng Nguyệt quế Thái C9

## Quy tắc đối chiếu đã chốt
- Chỉ mặc định C7 khi cả Product Name, SKU và Seller SKU không ghi kích thước rõ ràng.
- Nhãn mẫu `Nguyệt quế thái siêu hoa thơm` / SKU `2 chậu C9 cao 20-30cm` / Qty 1 phải ghép Nguyệt quế Thái C9 và quy đổi 2 cây.
- Kích thước ghi rõ trên nhãn luôn thắng quy tắc mặc định C7.
- Quy tắc học được không được ghi đè một kích thước đơn nhất ghi rõ trên nhãn.
- Mapping cục bộ cũ trái với kích thước rõ ràng sẽ bị vô hiệu hóa rồi đối chiếu lại; nếu không có dòng catalog khớp duy nhất thì cần Admin xác nhận, tuyệt đối không hạ xuống C7.

## Thay đổi source
- `tiktok-label-import.js`: xác thực mapping đã học trước khi áp dụng.
- `index.html`: kiểm tra mapping cũ trong local state và loại bỏ mapping trái kích thước rõ ràng.
- Test hồi quy cho SKU C9, 2 chậu, stale learned rule, và trích xuất PDF cột SKU.
- Tăng versionName lên 26.2.9, versionCode 61.

## Kiểm thử
- 16/16 test JavaScript PASS.
- Preflight PASS, version 26.2.9 / code 61.
- PDF layout regression 12/12 trang PASS.
- Chưa có APK build thực tế trong môi trường tạo source; cần chạy workflow GitHub Actions và kiểm tra artifact APK.

## Lưu ý với đơn đã tạo
Bản sửa ngăn lỗi cho mapping còn ở hàng chờ và những lần nhập sau. Đơn đã được tạo trên Firestore với cây C7 không tự sửa lịch sử khi cài APK mới, để tránh thay đổi tiền công/tồn kho ngoài ý muốn. Admin cần sửa đơn đó sang Nguyệt quế Thái C9 trước khi nhân viên hoàn tất, hoặc hủy/tạo lại theo quy trình quản trị hiện có.

Giữ nguyên PDF TikTok, phân công hàng loạt, quét mã, hai ảnh kiện hàng, Google Drive/Firestore, công thức tiền công và tồn kho.
