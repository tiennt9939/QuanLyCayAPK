# ROLL CÂY CẢNH V26.2.18 — Assignment Performance Audit

## Mục tiêu
Giảm giật/lag ở giao diện Admin khi chọn nhiều nhãn PDF và phân công đơn liên tiếp, ưu tiên thiết bị tầm trung như Xiaomi Redmi Note 11 5G. Giữ nguyên nghiệp vụ, dữ liệu và quyền hiện có.

## Nguyên nhân được xác định trong mã nguồn V26.2.17
1. Mỗi lần tích/bỏ chọn một nhãn, `renderTikTokLabelQueue()` dựng lại toàn bộ danh sách nhãn PDF.
2. Vòng lặp phân công hàng loạt cũng dựng lại toàn bộ hàng nhãn trước/sau mỗi đơn và serialize queue/map vào `localStorage` cho từng nhãn.
3. Các đơn được tạo tuần tự, gây nhiều thời gian chờ mạng theo thứ tự.
4. Trước và sau một batch, app đọc toàn bộ `/packingOrders` để dò trùng và làm mới giao diện.
5. Snapshot của Admin gọi `renderAll()`, làm dựng lại cả kho, báo cáo, bảng lương, báo giá và giao diện PDF dù chỉ đơn hàng thay đổi.
6. Listener Admin chỉ theo dõi đơn đang hoạt động và đơn hoàn tất gần đây; đặt trực tiếp tập con này vào `D.packingOrders` có nguy cơ ghi đè cache lịch sử đầy đủ đang dùng cho Admin.

## Thay đổi trong V26.2.18
- Thêm `updateTikTokBulkToolbarState()` để đổi số nhãn được chọn, ô chọn tất cả và nút phân công mà không dựng lại card list.
- Đặt `data-tiktok-tracking` trên các checkbox để cập nhật trạng thái chọn trực tiếp trong DOM.
- Bulk assign dùng tối đa 3 worker đồng thời, trong khi mỗi đơn vẫn được tạo qua `createPackingOrder()` và giao dịch Firestore deterministic ID hiện có.
- Thêm `adminFindOrdersByTrackingNos()` để dò mã đã chọn qua `shipmentTrackingNo`, trường cũ `shipment.trackingNo`, và ID xác định `tiktok_<tracking>`. Nếu truy vấn/Index bị lỗi, phương thức quay lại `adminListOrders()` để không bỏ qua bảo vệ trùng mã.
- Cho phép `createImportedTikTokLabelOrder()` hoãn việc lưu queue cục bộ khi ở batch; trạng thái queue được lưu một lần khi batch kết thúc. Đơn thật vẫn được ghi từng đơn trong Firestore bằng transaction; không đổi cơ chế chống trùng.
- Cập nhật một node tiến độ nhỏ thay vì dựng lại từng card trong vòng lặp.
- Sau batch, chỉ làm mới PDF queue và nhóm đơn Admin; loại bỏ `renderAll()` và lần đọc toàn bộ Firestore sau batch.
- Giữ cache lịch sử Admin riêng với snapshot vận hành gần đây. Khi snapshot mới đến, dữ liệu được merge; với tài khoản Admin, chỉ danh sách phân công và queue PDF đang mở được làm mới. Trong lúc bulk assignment, snapshot-driven redraw được trì hoãn đến khi hai panel đã làm mới.

## Ranh giới an toàn
- Không đổi công thức lương, quy tắc C7/C9, tồn kho, quyền vai trò, Firestore Rules, cấu trúc `packingOrders`, luồng hoàn tất một ảnh, OCR, quét barcode, Drive hoặc cơ chế cập nhật trong app.
- Duplicate detection vẫn có fallback full read khi truy vấn theo mã không khả dụng. Mỗi đơn nhập từ TikTok PDF vẫn dùng ID xác định và transaction hiện có để từ chối đơn trùng ở phía máy chủ.
- Nếu lưu cache cục bộ lỗi sau khi tạo đơn, log cảnh báo rõ; Firestore deterministic IDs vẫn ngăn tạo trùng khi nhập lại.

## Kiểm thử nguồn
- `python3 tools/preflight.py`: PASS.
- Tất cả 25 file `tools/*_test.js`: PASS.
- `tools/bulk_assignment_render_performance_test.js`: PASS.
- JavaScript syntax: 6 khối inline cộng `tiktok-label-import.js`: PASS.
- `AndroidManifest.xml` và `res/xml/file_paths.xml`: parse PASS.
- Các bài test hiện có về PDF 12 trang, mapping C7/C9, queue compaction, nhóm nhân viên, một ảnh hoàn tất, Drive, chữ ký updater, tiền công và tồn kho đều PASS.

## Chưa xác minh
- Môi trường hiện tại không có Android SDK/Gradle CLI để build APK trực tiếp.
- Chưa chạy benchmark trên Redmi Note 11 5G. Hiệu quả thực tế cần kiểm tra sau khi GitHub Actions build APK; nên thử batch 20, 40 và 100 nhãn và quan sát thời gian hoàn tất/độ phản hồi của giao diện.

## Build qua workflow đang dùng
Đưa ZIP `QuanLyCayAPK-V26.2.18-AUTO-UPDATE-SOURCE.zip` vào thư mục gốc repository. Dùng workflow hiện tại `.github/workflows/build-apk-v26.2.16-recognition-cloud.yml`; workflow này chọn ZIP cao nhất theo phiên bản có tên kết thúc bằng `-AUTO-UPDATE-SOURCE.zip`. Để trống `source_zip` hoặc nhập đúng tên ZIP ở trên. Chỉ cài APK sau khi Actions báo build thành công và xác minh được khóa ký tương thích.

## Cache consistency hardening after regression review
- Admin delete removes the order from the complete Admin history cache and resets its freshness timestamp.
- Full order reads used by Admin payroll/history populate the authoritative assignment cache.
- Notification refresh merges its partial pending-order result into the existing full Admin history rather than replacing full history with the subset.
- Retention cleanup removes purged completed orders from the complete Admin cache and refreshes its timestamp.
- Added source-regression assertions for these cache consistency paths.

## Final test pass
- All 25 `tools/*_test.js` tests passed after the cache-consistency hardening.
- `tools/preflight.py` passed.
- `node --check` passed for 6 inline JavaScript blocks and `tiktok-label-import.js`.
- Android manifest and FileProvider XML parsed successfully.
