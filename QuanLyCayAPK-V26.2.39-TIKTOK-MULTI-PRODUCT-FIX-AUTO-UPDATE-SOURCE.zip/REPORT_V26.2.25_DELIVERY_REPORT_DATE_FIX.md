# ROLL CÂY CẢNH V26.2.25 — Sửa ngày báo cáo vận chuyển theo ngày quét PDF

## Nguyên nhân

Báo cáo vận chuyển đang ưu tiên dùng `completedDate`/`date`. Với đơn ĐD đã được Admin ghi nhận hoàn tất hôm trước và tính công rồi, sau khi PDF hôm nay được ghép vào đơn đó, báo cáo vẫn phân loại theo ngày đóng hàng hôm trước.

## Thay đổi

- Lưu `shipmentReportDate` theo ngày PDF được import/quét (`importedAtMs` của nhãn).
- Lưu thêm `shipmentScannedAtMs` và `shipmentScanSource: 'tiktok_pdf'` để phân biệt ngày vận chuyển với ngày hoàn tất đóng hàng.
- Báo cáo vận chuyển lọc và hiển thị theo `shipmentReportDate`.
- Tương thích các bản ghi đã ghép ở V26.2.24: nếu chưa có `shipmentReportDate`, dùng `shipmentLinkedAtMs` làm ngày báo cáo vận chuyển.
- Không sửa `completedDate`, `date`, `completedAtMs`, người được phân công, `payAmount`/`employeePay`, số lượng cây hoặc tồn kho. Không tạo đơn đóng hàng mới và không tính công lần hai.
- Báo cáo vận chuyển các đơn khác không thuộc luồng ghép PDF vẫn giữ cách tính ngày hiện có.

## Kiểm thử

- `tools/preflight.py`: PASS.
- 31/31 bài kiểm thử JavaScript (`tools/*_test.js`): PASS, bao gồm kiểm thử mới `tiktok_pdf_delivery_report_date_test.js`.
- Cú pháp 4 khối JavaScript inline của `index.html`: PASS.
- Cú pháp `tiktok-label-import.js`: PASS.
- Android Manifest XML: PASS.
- ZIP: `unzip -t` PASS.

## Giới hạn xác minh

Mã nguồn đã qua kiểm tra tĩnh và kiểm thử tự động. Chưa build APK bằng GitHub Actions, chưa cài lên điện thoại, và chưa kiểm chứng trực tiếp trên dữ liệu Firebase của shop.
