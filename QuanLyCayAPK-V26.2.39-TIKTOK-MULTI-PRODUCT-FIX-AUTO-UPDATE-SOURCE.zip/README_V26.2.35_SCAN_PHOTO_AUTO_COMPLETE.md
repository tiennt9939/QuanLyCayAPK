# V26.2.35 — Quét + chụp ảnh + tự hoàn tất

- Sau khi nhân viên quét mã vận đơn và chụp ảnh kiện hàng + nhãn trong cùng màn hình, ứng dụng tự bắt đầu hoàn tất, không cần bấm xác nhận ở luồng thành công bình thường.
- Ảnh phải được Google Drive xác nhận lưu thành công trước khi Firestore ghi đơn hoàn tất.
- Nếu mã trùng, đơn đã hoàn tất, đơn không thuộc nhân viên, cây/kích thước không khớp hoặc danh mục mơ hồ, ứng dụng chặn tự hoàn tất.
- Giữ nguyên transaction chống trùng `shipmentTrackingClaims`, tiền công, tồn kho và schema Firestore.
- Nếu mạng/Firebase lỗi sau khi ảnh lưu, màn hình cho phép thử lại; không tạo đơn mới.

Xem `REPORT_V26.2.35_SCAN_PHOTO_AUTO_COMPLETE_SAFETY.md` để biết phạm vi kiểm thử và giới hạn xác minh.
