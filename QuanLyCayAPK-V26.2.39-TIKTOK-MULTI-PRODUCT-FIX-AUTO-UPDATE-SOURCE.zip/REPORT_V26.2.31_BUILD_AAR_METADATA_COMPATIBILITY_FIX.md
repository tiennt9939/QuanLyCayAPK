# V26.2.31 — Fix GitHub Actions AAR metadata failure

## Problem

V26.2.30 failed at `:app:checkDebugAarMetadata`. The GitHub Actions workflow in the repository installs Android platform 35 and Build Tools 35.0.0, while V26.2.30 declared newer AndroidX Activity/CameraX dependencies that may require a newer compile SDK. The screenshot shows the failing Gradle task but not the complete AAR metadata message; this fix avoids the SDK mismatch while keeping the existing workflow requirements unchanged.

## Changes

- Version changed to `26.2.31`, `versionCode = 83`.
- Keep `compileSdk = 35`, `targetSdk = 35`, and the existing workflow's installed SDK/build tools unchanged.
- Downgrade `androidx.activity:activity` from `1.12.4` to `1.10.1`.
- Downgrade CameraX artifacts `camera-camera2`, `camera-lifecycle`, and `camera-view` from `1.5.3` to `1.4.2`.
- CameraX APIs used by the custom shipping barcode scanner (`PreviewView`, `ImageAnalysis`, lifecycle binding, zoom, torch, focus metering) are retained in the selected versions.
- No changes to Firestore lookup, shipment validation, duplicate tracking checks, PDF recognition, employee payroll, inventory, image upload, or order completion logic.
- Tests and preflight assertions updated to version 26.2.31 / code 83 and the compatible CameraX dependency set.

## Validation

- `tools/preflight.py`: PASS.
- All JavaScript regression tests: PASS.
- JavaScript syntax validation: PASS.
- Android Manifest XML parse: PASS.
- ZIP integrity: PASS.
- No Android Gradle build or physical scanner test was run in this environment. Please run the existing GitHub Actions workflow to validate the build and test the barcode scanner on a real GHN label.

## Important

This repair keeps the current repository workflow's Android SDK 35 / Build Tools 35.0.0 setup intact, so there is no additional workflow edit required for this fix.
