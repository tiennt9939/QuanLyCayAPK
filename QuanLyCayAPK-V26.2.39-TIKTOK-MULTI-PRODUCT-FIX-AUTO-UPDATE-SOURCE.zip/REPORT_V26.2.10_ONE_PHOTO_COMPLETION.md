# QuanLyCayAPK V26.2.10 — One-photo order completion

## Scope
- Base: V26.2.9 source derived from the agreed V26.2.4 project line; versionName `26.2.10`, versionCode `62`.
- Reduce the first-stage order completion proof requirement to one photo for assigned orders and shared-pool orders, for TT, ĐN, and ĐD.
- Ask the worker/Admin to take one clear photo showing the parcel and shipping label together.
- For ordinary TT orders, run OCR on the single photo. For TikTok PDF orders already verified by barcode/PDF, preserve the verified tracking data and do not overwrite it with OCR.
- Upload the photo to Google Drive before accepting it and only report completion after Firestore confirms the write.
- Keep the existing ĐD second-stage label/OCR follow-up path intact; it may append the later label photo after first-stage completion.
- Keep payroll formulas, inventory logic, assignment and claim transactions, PDF import, barcode scan, catalog matching, Firestore schema, and Drive persistence logic unchanged.

## Firestore deployment requirement
The included `firestore.rules` changes the first-stage worker completion checks to accept exactly one non-empty `completionImages` reference for TT, ĐN, and ĐD. The existing second-stage ĐD OCR path still accepts two references after the later label photo is added.

**Publish the included `firestore.rules` to the same Firebase project before using this APK.** Updating the Android APK alone does not update deployed Firestore security rules. If old rules remain deployed, the app may still receive `permission-denied` when completing an order with one photo.

## Verification
- JavaScript test suite: all `tools/*_test.js` tests passed, including `single_photo_completion_test.js`.
- `tools/preflight.py`: PASS.
- Inline JavaScript syntax: PASS for all 6 inline script blocks and external PDF parser.
- PDF real-layout regression: 12/12 pages have product rows and positive Qty.
- Android APK build: **not run in this environment** because Android SDK/Gradle are unavailable here. Use the included GitHub Actions workflow to build and verify the real APK artifact.
