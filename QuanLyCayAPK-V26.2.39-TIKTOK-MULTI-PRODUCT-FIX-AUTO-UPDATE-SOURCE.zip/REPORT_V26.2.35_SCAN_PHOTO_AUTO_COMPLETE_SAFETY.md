# ROLL CÂY CẢNH V26.2.35 — Auto-complete after barcode + package photo

## Requested behavior
- Staff scans the shipment barcode and captures the parcel+label photo in the same native scanner screen.
- The app starts Drive upload and invokes the existing completion flow automatically; no confirmation tap is needed in the normal success path.
- The completion routine waits for the exact in-flight Drive upload promise before writing completion to Firestore.

## Safety guards retained/added
- The scanned tracking code must match the selected imported TikTok PDF order ID or the fresh order found by tracking.
- A stale or already-completed order is rejected before upload/completion.
- The order must belong to the logged-in packer; shared-pool orders must first be claimed with the existing first-claim-wins transaction.
- Before automatic completion, each order line must resolve to a catalog row with valid positive quantity, matching plant name/size, and no ambiguous duplicate name+size row unless a stable catalog ID identifies the exact row. Missing catalog data or ambiguous/mismatched plant mapping blocks automatic completion and asks Admin to fix mapping.
- Existing Firestore transaction continues to atomically update order completion and create/check `shipmentTrackingClaims`; duplicate tracking numbers are rejected.
- Firebase completion must return `status === completed` before local completion UI/payroll state is updated. Failed Drive uploads do not complete the order; failed Firebase writes offer a retry path without creating a new order or second payroll entry.
- Existing wage formula, item quantities, inventory logic, Firestore schema, and Drive proof-reference flow are not intentionally changed.

## Verification performed
- 40/40 Node.js tests passed, including a new regression test for no-confirm auto completion, catalog/size validation, assigned-user validation, duplicate shipment claim transaction, and retry-on-failure.
- `tools/preflight.py` passed.
- Four inline JavaScript blocks and `tiktok-label-import.js` passed Node syntax checks.
- Android XML files parsed successfully.
- ZIP integrity checked after packaging.

## Not verified
- No Android SDK/Gradle build was run in this environment.
- No physical-device timing test or live Firebase/Drive integration test was run. The APK must be built and tested on-device before claiming production success.
