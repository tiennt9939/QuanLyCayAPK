# V26.2.19 — Fast Photo Upload & Order Completion

## Mục tiêu
Giảm thời gian từ lúc chụp ảnh đến lúc nút xác nhận hoạt động và giảm thời gian chờ sau khi nhân viên bấm hoàn tất. Giữ nguyên yêu cầu: ảnh phải được Drive xác nhận và Firestore phải xác nhận giao dịch trước khi báo hoàn tất.

## Thay đổi
- Ảnh bằng chứng được nén JPEG quality 0.68 ở cạnh dài tối đa 900 px. OCR thông thường khởi chạy song song với tải ảnh; đơn PDF đã quét mã không OCR lại.
- Nút hoàn tất có thể bấm khi ảnh đang tải. Khi bấm, ứng dụng đợi đúng Promise tải ảnh; nếu Drive thất bại thì không gửi giao dịch hoàn tất. Chống bấm hai lần trong cùng một đơn.
- Cloud worker completion dùng một Firestore transaction để đọc trạng thái hiện tại và ghi nhận hoàn tất. Đối với TT, document claim và đơn được xác nhận trong cùng transaction. Bỏ lần đọc document sau commit.
- Bỏ việc tải lại ảnh từ Drive ngay sau khi vừa tải lên; hàm trả về mã tham chiếu Drive và dữ liệu đơn cục bộ.
- Với worker, bỏ lượt GET claim tách rời vì transaction đã đọc chính claim document và kiểm tra trùng nguyên tử. Không thay đổi nhánh kiểm tra lịch sử TT phía Admin.
- Android cache ID thư mục Drive đã được xác minh theo tài khoản trong vòng đời tiến trình; các lần upload tiếp theo không GET kiểm tra thư mục lặp lại. Upload request yêu cầu `id,name,mimeType,parents,size` trong response và xác minh ID/folder/size ngay từ response. Nếu response thiếu `parents` hoặc `size`, vẫn dùng GET xác minh dự phòng.

## Giữ nguyên an toàn
- Không báo hoàn tất trước khi Drive xác nhận ảnh.
- Firestore transaction tiếp tục xác minh nhân viên được giao đơn, trạng thái đơn và claim trùng mã vận đơn.
- Giữ nguyên `shipmentTrackingClaims`, công thức lương, tồn kho, schema đơn và yêu cầu một ảnh.

## Kiểm thử
- `tools/preflight.py`
- Toàn bộ `tools/*_test.js`, bao gồm `fast_order_completion_performance_test.js`
- Cú pháp 6 khối JavaScript nhúng + `tiktok-label-import.js`
- Kiểm tra cú pháp XML/YAML và cấu trúc ZIP

Đây là kiểm thử mã nguồn. Chưa có benchmark trên Redmi Note 11 5G; cần xác nhận thời gian thực sau khi build và cài APK trên thiết bị.
