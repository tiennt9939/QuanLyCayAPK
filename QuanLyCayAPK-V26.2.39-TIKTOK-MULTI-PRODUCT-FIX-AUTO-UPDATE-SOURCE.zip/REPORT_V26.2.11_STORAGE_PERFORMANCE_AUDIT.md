# QuanLyCayAPK V26.2.11 — Storage & live-order performance audit

## Base and scope
- Based on the latest available V26.2.10 source, itself continuing the agreed V26.2.4 TikTok PDF/catalog-matching line.
- Android application ID remains `com.quanlycay.apk`.
- Version: `26.2.11`, versionCode `63`.
- Kept TikTok PDF import, SKU/catalog matching, barcode verification, one-photo completion, Drive image references, wage rules, inventory logic, payroll, assignments, and Firestore schema.

## Changes made
1. **Bounded local order cache:** the main local `quanlycay` cache retains all pending orders and completed orders with no usable date, plus dated completed orders from the last 30 days. Only the serialized local snapshot is pruned; the live in-memory state and Firestore records are not deleted or modified by this cache filter.
2. **Bounded employee order cache:** employee-specific `ROLL_CAY_PACKER_ORDERS_*` caches use the same cache-window rule, reducing old completed-order payloads and image references saved on-device.
3. **Scoped Admin realtime listeners:** Admin no longer attaches one realtime listener to the entire `packingOrders` collection. It listens to all `pending` orders and records with recent `completedAtMs` values (30-day cutoff), then merges/deduplicates them. Explicit `adminListOrders()` calls remain full-history reads for existing workflows that need full records.
4. **Admin notification refresh:** tapping the notification bell fetches pending orders only instead of re-reading every historical order.
5. **Kept lazy image hydration:** historical completion/proof image fields remain Drive references in live order snapshots; full image bytes are fetched only by explicit image-viewing flows. Existing Drive persistence rules continue refusing to persist unresolved Base64 image data in new local cache writes.

## Safety boundaries
- No Firestore orders, payroll, inventory, plant catalog, prices, or image files were deleted.
- No Firestore collection/schema, security rules, wage formula, inventory equation, or PDF recognition behavior was intentionally changed.
- The 30-day setting is a **device cache/live-listener window only**, not a server-side retention/deletion policy. Firestore remains the source of historical order records.
- The new recent-completion listener queries `completedAtMs >= cutoff`; older completed records are not kept in the Admin realtime in-memory list. Existing explicit full-history methods still read the full collection. Validate historical-screen behavior in the real APK before rollout.

## Verification
- `python3 tools/preflight.py`: PASS.
- All 15 `tools/*_test.js` tests: PASS.
- Inline JavaScript syntax check: PASS (4 non-empty inline script blocks).
- PDF real-layout regression: 12/12 pages include product rows and positive Qty.
- Existing tests cover Drive image persistence, cache/lazy hydration, order grouping, payroll/wage rules, inventory retention logic, one-photo completion, barcode flow, PDF matching, and bulk assignment.

## Build status
Android APK build was **not run in this environment** because Android SDK/Gradle are unavailable here. Run `.github/workflows/build-apk.yml` manually in GitHub Actions to create the real APK artifact. This report does not claim that an APK was built or installed on a device.
