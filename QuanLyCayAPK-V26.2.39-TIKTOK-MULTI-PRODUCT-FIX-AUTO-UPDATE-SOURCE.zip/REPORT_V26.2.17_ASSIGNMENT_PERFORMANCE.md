# ROLL CÂY CẢNH V26.2.17 — Audit phân công

## Thay đổi
- Cache danh sách đơn Admin 15 giây và gộp các request đang chạy, tránh gọi adminListOrders() tải toàn bộ packingOrders mỗi lần tick checkbox hoặc đổi bộ lọc.
- Sau phân công hàng loạt, làm mới dữ liệu phân công nhưng không gọi renderAll() để dựng lại báo cáo, kho, báo giá và các bảng không liên quan.
- Giữ nguyên thao tác ghi từng đơn qua adminAssignOpenPoolOrder, không thay đổi Firestore Rules, tiền công, tồn kho hay trạng thái đơn.
- Version 26.2.17, versionCode 69.

## Giới hạn xác minh
- Đây là tối ưu nguồn cho thao tác phân công Admin; chưa có benchmark trên điện thoại thật và chưa build APK trong môi trường audit này.
- Dữ liệu mới vẫn được nạp sau tối đa 15 giây khi dùng cache; sau thao tác phân công hàng loạt có refresh bắt buộc.
