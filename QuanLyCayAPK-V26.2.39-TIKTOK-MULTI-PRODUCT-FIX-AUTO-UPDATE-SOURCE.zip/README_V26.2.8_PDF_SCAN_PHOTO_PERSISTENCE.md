# QuanLyCayAPK V26.2.9 — PDF barcode scan and package photo proof

Based on the V26.2.4 source; V26.2.5 was not used.


## V26.2.9 — Fix PDF scan-to-photo flow

- Assigned TikTok PDF order cards launch barcode scanning for the selected order instead of opening a photo form without a scanned code.
- Unclaimed shared-pool TikTok PDF cards also launch the scanner. A fresh barcode lookup permits a pending, unassigned `open_pool` PDF order; a Firestore transaction then atomically claims it and opens the proof-photo form using the same verified code. Other users' assigned orders remain inaccessible.
- If the barcode scanned from a specific order card belongs to a different order, the app refuses to open or complete it.
- The proof form asks for photo 1 (package overview) and photo 2 (shipping label / another package view). Each photo uploads to Drive before submission. Successful completion writes Drive references into `completionImage` and `completionImages` in the Firestore order document.
- Barcode scanning itself reads the barcode and does not take a photo; a successful scan now leads directly to the two-photo form. Photos are attached to the order only after Firebase confirms completion.
- Added regression test `tools/tiktok_pdf_scan_photo_capture_test.js`.
- Release metadata: V26.2.9 / versionCode 61, based on V26.2.4; V26.2.5 was not used.
- Android APK compilation and device testing still require the GitHub Actions workflow. Not claimed complete.
