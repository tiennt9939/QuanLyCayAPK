# ROLL CÂY CẢNH V26.2.38 — báo âm quét đơn và sửa nhận diện Combo Ruby Đỏ

## Bản phát hành source
- Source nền: `QuanLyCayAPK-V26.2.36-DAILY-SHIPMENT-AUTO-UPDATE-SOURCE.zip`.
- Phiên bản Android: `26.2.37`, `versionCode 90`.
- Package: `com.quanlycay.apk`.
- Giữ nguyên ứng dụng Android WebView, Firebase Authentication/Firestore, Google Drive, danh mục cây, tồn kho và báo giá. Bản nguồn V26.2.35 vẫn là bản khôi phục gốc do người dùng giữ riêng.

## Thay đổi
1. **Âm báo sau mỗi đơn:** khi mã khớp danh sách, ảnh chụp đã được nén/lưu an toàn vào hàng đợi trên máy và đã chuyển sang luồng xử lý nền, ứng dụng phát một tiếng “tít” ngắn và vẫn rung nhẹ. Âm báo không chờ upload Google Drive; lỗi chụp/ghi hàng đợi không phát tín hiệu thành công.
2. **Đọc đúng Combo 4 tặng 1:** một combo có `4 + 1 = 5` cây; `Qty 2` là 2 combo, tổng `5 × 2 = 10` cây. Qty vẫn là số combo bán ra; số cây thực tế được tính từ `Qty × số cây mỗi đơn vị` khi lập báo cáo.
3. **Lọc mô tả quảng cáo khi ghép danh mục:** cụm phía sau dấu gạch ngang như “Nắng màu đỏ rực phù hợp mọi không gian” không tham gia nhận diện tên cây. Thêm bí danh chính tả xác nhận `Ruby` ↔ `Rubi` để khớp tên cây đang có trong danh mục; quy tắc kích thước mặc định C7 hiện hữu vẫn giữ.
4. **Chống dòng sản phẩm giả do PDF:** số ở cuối phần tên/SKU như “Combo 4” hay “tặng 1” không được xem là Qty nếu nằm ngoài cột Qty. Khi Qty được xuất thành một dòng riêng, parser gom phần tên và SKU phía trên vào cùng sản phẩm. `Qty Total` được dùng để ưu tiên bản trích xuất có tổng số lượng nhất quán.

## Luồng vận hành
`Import PDF nhãn → đối chiếu mã + danh mục → quét liên tục → tự chụp ảnh → báo tít → đưa ảnh vào hàng đợi nền → Drive upload → ghi báo cáo/claim Firestore → cập nhật tồn kho một lần`.

Nếu mã chưa có trong danh sách, đã ghi nhận, hoặc sản phẩm chưa đối chiếu đủ thì không chụp/ghi nhận. Âm báo chỉ xác nhận ảnh đã được lưu an toàn và đưa vào xử lý nền, **không xác nhận Drive đã tải xong**.

## Kiểm tra đã thực hiện
- `tools/preflight.py`: PASS.
- Node regression suite: 41/41 bài PASS, bao gồm nhãn Ruby Đỏ + Combo 4 tặng 1 + Qty 2.
- Cú pháp JavaScript cho các block inline và `tiktok-label-import.js`: PASS.
- Android manifest/XML: PASS.
- Chưa chạy Gradle assemble APK hoặc thử camera/âm thanh/Drive trên thiết bị thật trong môi trường này; cần chạy GitHub Actions để build APK và thử trên máy trước khi dùng thực tế.

## Build qua GitHub Actions
Tải ZIP `QuanLyCayAPK-V26.2.38-BEEP-RUBY-COMBO-AUTO-UPDATE-SOURCE.zip` lên thư mục gốc repository, sau đó chạy workflow **Build ROLL CAY CANH** với input `source_zip` đúng tên ZIP này. Workflow hiện yêu cầu secret `DEBUG_KEYSTORE_BASE64` để ký APK ổn định.
