# Audit V26.2.39 — TikTok multi-product label fix

- Base: V26.2.38 performance source.
- Android metadata: versionName 26.2.39, versionCode 91.
- Parser fix: each product row starts after the prior row's Qty line, preventing that Qty/product content from leaking into the next row.
- Continuation pages: pages with the same Order ID (or tracking when Order ID is absent) merge only if at least one page has no product rows. Full repeated labels remain flagged as duplicates.
- Description filter: strips common TikTok SEO phrases such as "Ánh sáng gián tiếp", "độ ẩm cao", "trang trí vườn", and "nở quanh" before plant identity matching, while preserving the leading plant name.
- Regression fixture based on supplied J&T label: tracking `862542794508`, Order ID `586634608115811400`, two product rows (Cẩm tú mai C9 and Trầu Bà Thanh Xuân), Qty 1 + 1; a continuation page containing only the same Order ID and Qty Total must merge into the same label.
- `python tools/preflight.py`: PASS.
- All `tools/*_test.js`: PASS.
- ZIP integrity: checked after packaging.
- Not performed: Gradle APK build, on-device test, live Firebase/Drive test, or direct import of original PDF binary (only screenshots were supplied).
