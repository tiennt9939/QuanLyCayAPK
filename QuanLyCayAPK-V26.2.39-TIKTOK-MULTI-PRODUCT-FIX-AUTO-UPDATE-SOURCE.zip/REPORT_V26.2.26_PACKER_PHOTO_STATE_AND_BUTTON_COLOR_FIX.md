# ROLL CÂY CẢNH V26.2.26 — Fix ảnh đã chụp nhưng báo chưa chụp

## Nguyên nhân gốc đã xác minh

Trong cửa sổ hoàn tất của nhân viên, `openPackerCompleteOrder()` gắn ô chọn ảnh vào `readAdminOrderProof(event, 0)`. Hàm này lưu ảnh đã tải lên Drive vào `pendingAdminOrderProof` và cập nhật `adminOrderProofStatus`.

Tuy nhiên, `submitPackerCompleteOrder()` trước đó kiểm tra `pendingPackPhotos`, một mảng khác không được ô chọn ảnh trong cửa sổ này cập nhật. Vì thế giao diện có thể hiện `Đã có 1/1 ảnh`, nhưng khi bấm xác nhận lại báo `Phải chụp đủ 1 ảnh trước khi hoàn tất.`

Tương tự, trạng thái đỏ/vàng/xanh trước đó chỉ được cập nhật cho `packSubmitBtn`, trong khi cửa sổ đang dùng nút động `adminOrderCompleteBtn`; do đó màu trạng thái không đi theo điều kiện thực tế của cửa sổ.

## Sửa trong V26.2.26

- Version name `26.2.26`, version code `78`.
- Luồng hoàn tất của nhân viên sử dụng đúng cùng một mảng ảnh `pendingAdminOrderProof` từ lúc hiển thị số ảnh, xác minh ảnh đã được Drive xác nhận, đến khi gửi ảnh vào `completePackingOrder()`.
- Dùng cùng nguồn trạng thái `pendingAdminShipmentOcr` mà cửa sổ đang cập nhật; đơn TT chỉ được xác nhận sau khi mã vận đơn hợp lệ. ĐD/ĐN vẫn áp dụng quy tắc không yêu cầu OCR như trước.
- Khi ảnh đang tải lên Drive hoặc OCR đang chạy, nút chuyển vàng và bị khóa. Thiếu ảnh hoặc mã không hợp lệ thì nút màu đỏ. Chỉ khi đủ ảnh, Drive đã xác nhận và điều kiện vận đơn đạt thì nút chuyển xanh, có hiệu ứng viền/nhấp sáng, và mới bật để xác nhận.
- Nút cập nhật trạng thái là đúng `adminOrderCompleteBtn` trong modal này. Logic transaction, kiểm tra trùng mã vận đơn, Firebase, tiền công, tồn kho và quy tắc một ảnh không bị thay đổi.

## Kiểm tra

- `tools/preflight.py`: PASS.
- 32/32 tệp kiểm thử `tools/*_test.js`: PASS, bao gồm `packer_photo_state_regression_test.js` mới để khóa lỗi lệch giữa mảng ảnh hiển thị và mảng ảnh gửi hoàn tất.
- Kiểm tra cú pháp: 4 khối JavaScript inline và `tiktok-label-import.js`: PASS.
- Android Manifest XML parse: PASS.
- ZIP: `unzip -t` không có lỗi.

## Giới hạn xác minh

Đây là mã nguồn đã qua kiểm tra tự động; chưa build APK thật bằng GitHub Actions và chưa cài thử trên thiết bị. Cần build/cài V26.2.26 để xác nhận tương tác camera/Drive thực tế trên điện thoại.
