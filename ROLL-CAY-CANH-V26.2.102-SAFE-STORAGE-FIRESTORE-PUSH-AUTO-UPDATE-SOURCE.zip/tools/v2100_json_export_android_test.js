const fs=require('fs');const path=require('path');const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const java=fs.readFileSync(path.join(root,'app/src/main/java/com/quanlycay/apk/MainActivity.java'),'utf8');
const gradle=fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8');
const preflight=fs.readFileSync(path.join(root,'tools/preflight.py'),'utf8');
function ok(v,m){if(!v)throw new Error(m)}
ok(html.includes("AndroidBridge.saveFile('ROLL-CAY-CANH-backup-drive-references.json',b64,'application/json')"),'JSON export must call Android native saveFile');
ok(html.includes("if(!ok)throw new Error('Android không lưu được file JSON."),'must not report success when native save fails');
ok(html.includes("downloadText('ROLL-CAY-CANH-backup-drive-references.json',json,'application/json;charset=utf-8')"),'non-Android fallback should retain JSON filename and MIME');
ok(java.includes('lowerName.endsWith(".json")')&&java.includes('lowerName.endsWith(".csv")'),'native save must preserve supported extensions');
ok(/@JavascriptInterface\s+public boolean saveFile\(/.test(java),'saveFile must be exposed to Android WebView JavaScript; otherwise JSON export silently falls back to unsupported browser download');
ok(java.includes('resolvedMime = lowerName.endsWith(".json") ? "application/json"'),'native save must infer JSON MIME type');
ok(gradle.includes('versionName = "26.2.102"')&&gradle.includes('versionCode = 154'),'release metadata must be bumped');
ok(preflight.includes('versionName = "26.2.102"')&&preflight.includes('versionCode = 154'),'preflight metadata must match');
console.log('V26.2.102 ANDROID JSON EXPORT TEST PASS');
