'use strict';
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');

// Execute the production directory merge helper against a stale GAS Admin snapshot.
const start=html.indexOf('function mergeUserDirectoryRows(primaryRows,gasRows){');
const end=html.indexOf('\n  async function readUsersCollection',start);
assert(start>=0&&end>start,'production user directory merge helper exists');
const source=html.slice(start,html.indexOf('\n  }',start)+4);
const context={String,Array,Map};
vm.createContext(context);
vm.runInContext(source+'\nthis.merge=mergeUserDirectoryRows;',context);
const merged=context.merge(
  [{uid:'admin-uid',email:'baogiaroll@gmail.com',role:'admin',active:true,employeeId:'',employeeName:''}],
  [{uid:'admin-uid',email:'baogiaroll@gmail.com',role:'admin',active:true,employeeId:'0',employeeName:'Mẫn'}]
);
const admin=merged.rows.find(x=>x.uid==='admin-uid');
assert.equal(admin.role,'admin');
assert.equal(admin.employeeId,'','stale GAS employeeId must not be restored to Admin');
assert.equal(admin.employeeName,'','stale GAS employeeName must not be restored to Admin');

const createStart=html.indexOf('async function createUser(email,password,employeeId,roleValue){');
const createEnd=html.indexOf('\n  let usersListCache=',createStart);
const create=html.slice(createStart,createEnd);
assert(create.includes("String(u.role||'').trim().toLowerCase()!=='admin'"),'Admin must not block employee account creation');
const linkStart=html.indexOf('async function linkUserEmployee(uid,employeeId){');
const linkEnd=html.indexOf('\n  async function setUserRole',linkStart);
const link=html.slice(linkStart,linkEnd);
assert(link.includes("String(u.role||'').trim().toLowerCase()!=='admin'"),'Admin must not block employee relinking');
console.log('V26.11.01 ADMIN STALE EMPLOYEE LINK REGRESSION: PASS');
