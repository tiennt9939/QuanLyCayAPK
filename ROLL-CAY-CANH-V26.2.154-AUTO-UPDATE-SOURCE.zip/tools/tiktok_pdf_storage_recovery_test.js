'use strict';
const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8').replace(/\r\n/g, '\n');
const start = html.indexOf('function compactTikTokStagingQueueFromDailyShipmentState(){');
const end = html.indexOf('function isRecognitionRuleMap', start);
assert(start >= 0 && end > start, 'PDF queue storage-recovery helpers must exist');

const processed = [];
const queue = [];
for (let i = 0; i < 8; i++) {
  const trackingNo = `862600000${String(i).padStart(3, '0')}`;
  processed.push({ trackingNo, date: '2026-10-25', status: i < 4 ? 'recorded' : 'imported', assignmentStatus: i >= 4 ? 'assigned' : 'unassigned', assignedUid: i >= 4 ? 'employee-1' : '', ...(i >= 4 ? {assignedEmployeeName:'Huy'} : {}) });
  queue.push({ trackingNo, status: 'ready', products: [{ productName: 'processed staging duplicate '.repeat(350) }] });
}
const pending = [
  { trackingNo: '862699999001', date: '2026-10-25', status: 'imported', assignmentStatus: 'unassigned', assignedUid: '' },
  { trackingNo: 'VNGH80999999999', date: '2026-10-25', status: 'needs_review', assignmentStatus: 'unassigned', assignedUid: '' }
];
queue.push(...pending.map((row, i) => ({...row, status: i ? 'needs_review' : 'ready', products:[{productName:'new pending label '.repeat(90)}]})));
const reports = [{ trackingNo: processed[0].trackingNo, status: 'recorded', date: '2026-10-25' }];
const maps = { stableMappingKey: [{ catalogKey: 'catalog-c7', perUnit: 5, autoMatched: false }] };
const store = new Map([
  ['quanlycay', 'M'.repeat(300000)],
  ['roll_cay_daily_shipment_state_backup_v1', 'B'.repeat(150000)],
  ['roll_tiktok_label_queue_v1', JSON.stringify(queue)],
  ['roll_tiktok_product_maps_v1', JSON.stringify(maps)],
  ['roll_tiktok_recognition_rules_v1', '{}'],
  ['roll_tiktok_recognition_rule_deletes_v1', '[]']
]);
const quota = 600000;
const bytesNow = () => [...store.entries()].reduce((sum, [k, v]) => sum + k.length + String(v).length, 0);
const localStorage = {
  getItem(key) { return store.has(String(key)) ? store.get(String(key)) : null; },
  setItem(key, value) {
    key = String(key); value = String(value);
    const previous = store.get(key);
    const projected = bytesNow() - (previous == null ? 0 : String(previous).length) + value.length;
    if (projected > quota) { const error = new Error('QuotaExceededError'); error.name = 'QuotaExceededError'; throw error; }
    store.set(key, value);
  },
  key(i) { return [...store.keys()][i] ?? null; },
  get length() { return store.size; },
  removeItem(key) { store.delete(String(key)); }
};
const context = {
  D: { dailyShipmentOrders: processed.concat(pending), dailyShipmentReports: reports },
  tiktokLabelQueue: queue,
  tiktokProductMaps: maps,
  tiktokRecognitionRules: {rule1: {catalogKey:'catalog-c7'}},
  tiktokRecognitionRuleDeletes: new Set(['old-rule']),
  tiktokSelectedTrackingNos: new Set(queue.map(x=>x.trackingNo)),
  TIKTOK_LABEL_QUEUE_KEY: 'roll_tiktok_label_queue_v1',
  TIKTOK_PRODUCT_MAP_KEY: 'roll_tiktok_product_maps_v1',
  TIKTOK_RECOGNITION_RULES_KEY: 'roll_tiktok_recognition_rules_v1',
  TIKTOK_RECOGNITION_DELETES_KEY: 'roll_tiktok_recognition_rule_deletes_v1',
  localStorage,
  normalizeTracking: x => String(x || '').toUpperCase().replace(/[^A-Z0-9]/g, ''),
  toast: () => {},
  console
};
vm.createContext(context);
vm.runInContext(html.slice(start, end), context);
const before = bytesNow();
assert(before < quota, 'existing localStorage should be near quota but still valid');
assert.strictEqual(context.saveTikTokLocalState(), true, 'safe queue compaction must allow the staging save');
assert.strictEqual(context.tiktokLabelQueue.length, 2, 'only genuinely pending and needs-review staging rows should remain');
assert.deepStrictEqual(context.tiktokLabelQueue.map(x => x.trackingNo), pending.map(x => x.trackingNo));
assert(context.tiktokProductMaps.stableMappingKey, 'existing product mappings must be preserved');
assert(context.tiktokRecognitionRules.rule1, 'recognition rules must be preserved');
assert(context.tiktokRecognitionRuleDeletes.has('old-rule'), 'recognition tombstones must be preserved');
assert(context.D.dailyShipmentOrders.length === 10, 'canonical daily order rows must remain untouched');
assert(context.D.dailyShipmentReports.length === 1, 'canonical recorded report must remain untouched');
assert(bytesNow() < before - 50000, 'processed duplicate staging rows should materially release localStorage quota');

// Simulate the larger main snapshot that failed before the fix. After staging compaction, its
// write must fit. The updated import path also writes the separate canonical backup before save().
assert.doesNotThrow(() => localStorage.setItem('quanlycay', 'N'.repeat(380000)), 'freed space should allow the expanded main state write');
const importStart = html.indexOf('function importParsedLabelsIntoDailyShipments(');
const importEnd = html.indexOf('function startDailyShipmentPdfImport()', importStart);
const importBody = html.slice(importStart, importEnd);
assert(importBody.includes('const dailyBackupPersisted=dailyShipmentPersistLocalBackup();\n  save();'), 'canonical backup must be persisted before saving the main state');
assert(importBody.indexOf('compactTikTokStagingQueueFromDailyShipmentState();saveTikTokLocalState()') < importBody.indexOf('const dailyBackupPersisted=dailyShipmentPersistLocalBackup();'), 'staging cache must be compacted before either canonical write');
assert(importBody.includes('backupPersisted:dailyBackupPersisted'), 'import summary must retain backup persistence outcome for warnings');
console.log('PDF STORAGE RECOVERY PASS: processed staging compacted; pending labels, catalog maps, recognition rules, reports and canonical orders preserved; import persist order verified');
