# ROLL CÂY CẢNH V26.2.154 — Fix cấp tài khoản không được tự gắn lại tài khoản cũ

## Root cause đã xác định trong source V26.2.153

Hàm `createUser()` có hai nhánh nguy hiểm:
1. Nếu email đã có trong `users`, hàm tự ghi đè `employeeId`, `employeeName`, role và active của UID cũ sang nhân viên đang chọn.
2. Nếu Firebase Authentication trả `email-already-in-use` nhưng directory không có hồ sơ, hàm đăng nhập bằng mật khẩu Admin nhập rồi dùng UID cũ để ghi hồ sơ nhân viên mới.

Do đó thao tác **Cấp tài khoản** có thể chiếm/gán lại tài khoản đã tồn tại sang nhân viên mới. Đây là lỗi trực tiếp, không phải chỉ là nghi vấn về thứ tự mảng nhân viên.

## Thay đổi V26.2.154

- Cấp tài khoản gặp email đã có trong directory: dừng và báo email thuộc tài khoản cũ; không ghi bất kỳ trường nào của tài khoản đó.
- Firebase Auth trả `email-already-in-use`: dừng; không đăng nhập vào tài khoản cũ; không liên kết UID cũ với nhân viên mới.
- Việc đổi nhân viên cho tài khoản hiện hữu chỉ thực hiện qua nút **Đổi NV** trên đúng dòng tài khoản, có chủ ý riêng.
- Giữ lại bảo vệ tài khoản Auth không tự xóa khi kết quả ghi Firestore chưa rõ.
- Android versionName `26.2.154`, versionCode `206`.

## Không thay đổi

Không sửa schema Firestore, GAS Code.gs, Firestore Rules, công thức tiền công, tồn kho, báo giá, parser PDF hoặc quy tắc nhận diện cây. Không xóa hay sửa dữ liệu production.

## Kiểm thử

- `tools/user_creation_must_not_relink_existing_account_test.js`: PASS.
- `tools/user_creation_auth_orphan_safety_test.js`: PASS.
- `tools/v261101_admin_employee_link_regression_test.js`: PASS.
- `tools/v26139_employee_account_relink_test.js`: PASS (đã cập nhật kỳ vọng: relink chỉ qua thao tác Đổi NV).
- `tools/preflight.py`: PASS.
- Full JS suite and Android build status are reported separately in handover.

## Lưu ý thao tác

Nếu trước đó tài khoản bị gán nhầm, V26.2.154 ngăn lỗi tái diễn nhưng không tự ý đảo ngược liên kết cũ vì không thể suy đoán tài khoản nào thuộc nhân viên nào. Admin cần dùng **Đổi NV** trên đúng tài khoản sau khi đối chiếu email và nhân viên.
