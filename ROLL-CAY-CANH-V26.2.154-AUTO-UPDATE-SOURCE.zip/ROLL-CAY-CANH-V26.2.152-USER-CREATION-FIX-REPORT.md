# ROLL CÂY CẢNH V26.2.152 — USER CREATION FIX

## Root cause fixed
The Admin account `baogiaroll@gmail.com` could retain an obsolete employeeId/employeeName in the legacy Google Sheets (GAS) user snapshot. `mergeUserDirectoryRows()` copied those missing employee fields back onto the active Admin profile. The create-user and link-employee duplicate checks then treated that Admin profile as an employee already owning the selected employeeId, blocking creation/linking and showing the Admin email.

## Narrow changes
1. `app/src/main/assets/index.html`
   - Never restore `employeeId` or `employeeName` from the GAS backup onto an Admin profile.
   - Exclude Admin profiles from the duplicate employee-link check during account creation.
   - Exclude Admin profiles from the duplicate employee-link check when relinking an existing account.
2. `tools/v261101_admin_employee_link_regression_test.js`
   - Regression test reproduces the stale GAS Admin employee link and verifies it cannot block staff linking.

## Validation
- New regression test: PASS.
- Full JavaScript test suite: 139/139 PASS.
- `python tools/preflight.py`: PASS.
- Version metadata intentionally unchanged: versionName 26.2.152, versionCode 204.

## Safety / limits
- No Firebase or GAS production data was changed.
- No Firestore Rules, payroll formulas, inventory logic, PDF parser, or order logic was changed.
- This is a source ZIP, not an APK. No Android device/Firebase live integration test was run. Do not install this source as an APK until it is built through the project's approved workflow with a new versionCode.
