# ROLL CÂY CẢNH — V26.2.154 source audit & handover

## 1. Source baseline

- Input supplied by the user: `ROLL152_USER_CREATE_FIX.zip`.
- Source baseline: Android app `26.2.152`, `versionCode 204`, package `com.quanlycay.apk`.
- Delivered source: `26.2.154`, `versionCode 205`.
- Main application: Android WebView (HTML/CSS/JS) + Java wrapper; Firebase Auth/Firestore with GAS compatibility backend and Drive photo storage.
- This work was performed on the supplied ZIP, not on an assumed copy of the GitHub main-branch root.

## 2. Changes made in V26.2.154

1. Preserved the V26.2.152 fix for stale Admin employee links:
   - Legacy GAS snapshots cannot restore `employeeId` / `employeeName` onto Admin profiles.
   - Admin profiles do not reserve employee links during account creation or relinking.
2. Hardened account creation after ambiguous Firebase errors:
   - Firebase Auth and Firestore are separate services. A failed permission check or read-back does not prove the `/users/{uid}` write failed.
   - The account creation catch block no longer calls `createdAuthUser.delete()` automatically when the user profile has not yet been verified.
   - The UI reports the ambiguous state, asks Admin to check Authentication and `/users`, and allows retry with the same email/password after correcting the Rules/backend issue.
   - Secondary Auth session sign-out remains in place.
3. Incremented Android identity to `26.2.154` / code `205` so this source can be built as an update over code `204` using the repository's established signing/workflow.
4. Added `tools/user_creation_auth_orphan_safety_test.js` and updated historical release-identity assertions to the new version.

## 3. Audit findings by subsystem

| Subsystem | Static review result |
|---|---|
| Account creation / relinking | Admin stale-link fix retained. Existing directory is read before Auth creation. Existing email/profile relinking reuses UID. Ambiguous Auth/Firestore failure no longer triggers destructive Auth deletion. |
| User directory / GAS compatibility | Primary user docs are merged with GAS backup rows; Admin-specific stale employee properties are stripped. User-list cache and verified UID recovery paths are present. |
| Cloud sync | Single-flight `pushNow()` guard; bounded repeat pass; delta update rather than rewriting the complete app payload; document-size preflight; dirty flag retained on failure; packer account does not push the admin-wide app blob. |
| PDF import / assignment | Current PDF batch is persisted and verified before assignment. Assignment validates active packer account/employee mapping and reads exact claim/scan/order/queue/report docs transactionally. Recorded/completed evidence is protected. |
| Barcode scan / duplicate protection | Tracking number is normalized; `shipmentTrackingClaims` provides cross-device duplicate protection. Scan transaction checks the assigned UID, assignment revision and permitted Admin delegation before recording wage/report data. |
| Completion / photos | Order completion checks assignment ownership and status inside a Firestore transaction. Tracking claim and order completion are atomic. Photo upload is performed before the transaction and the returned result is converted to local-cache references rather than downloaded again. |
| Payroll | Per-item assigned wage snapshots are honored. Completed-order amount snapshots and adjustments are retained. Existing plant/size exceptions and aggregation tests pass; no wage formula was modified. |
| Inventory | Stock is derived from opening/base stock, daily input/output and completed packing quantities. Aggregate/cache helpers are present and covered by the inventory/report tests. No stock formulas or records were changed. |
| Catalog / TikTok label parser | Product Name is used for plant identity; SKU/Seller SKU determine sold-unit quantity with explicit conflict review. C7 default, explicit size detection, Nguyệt quế height mapping, combo gifts and confirmed Cẩm tú mai exception remain covered by tests. |
| Quotations | Sale/purchase price selection remains. Purchase-price output is Admin-only. Catalog `showInQuote` filtering and CSV/PDF export remain intact. No quotation schema or export behavior was changed. |
| Firestore / GAS backend | No Rules deployment, GAS script deployment, schema migration or production data mutation was performed. Existing Rules and compatibility logic were retained. |

## 4. Important remaining risk — employee ID is an array index

The account editor currently stores `employeeId` using the employee's numeric array position (`D.employees` index). `deleteEmployee(i)` removes an array element without remapping user profiles. Deleting an employee before another linked employee can shift later indexes and potentially make an existing account resolve to a different employee.

This is not safely fixed by changing the field to a string ID in a small patch: it requires a backward-compatible migration across user profiles, daily wage rows, packing orders, PDF assignment records, GAS directory snapshots and any related queries. This V26.2.154 patch intentionally does not perform that migration or change Firestore schema. Until a dedicated migration is designed, avoid deleting/reordering employees who have linked accounts. A follow-up migration should first produce a read-only mapping/preview and rollback plan.

## 5. Validation results

- `tools/preflight.py`: PASS — V26.2.154 / code 206.
- JavaScript regression suite: **140/140 PASS**.
- JavaScript syntax: **9 inline script blocks + 3 external JS assets PASS** (`node --check`).
- Source archive integrity: ZIP test PASS; root project files present; no APK or keystore bundled.
- No source writes to Firebase/GAS production were executed.
- No Android APK build or device test was executed in this environment: Java is present, but Gradle, Android SDK environment variables and `gradlew` are unavailable. The source workflow is present for the repository's GitHub Actions build.
- No live Firebase/Drive/GAS integration test was executed; the regression tests use local mocks/static assertions.

## 6. Release / deployment precautions

- Source ZIP is the deliverable; it is not an APK.
- Repository build workflow expects the exact filename `ROLL-CAY-CANH-V26.2.154-AUTO-UPDATE-SOURCE.zip` at repository root or an explicit `workflow_dispatch` source filename.
- Do not publish Firestore Rules or deploy `Code.gs` based only on this source audit. Confirm the active Firebase/GAS project and run the test project/device verification first.
- Before installing as an update, confirm the resulting APK signature matches the currently installed app's signing certificate. The workflow blocks Release publishing when the expected certificate secret is not configured or does not match.
