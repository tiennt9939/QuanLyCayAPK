# ROLL CÂY CẢNH V26.2.130 — incremental sync and targeted PDF assignment

- Android `versionName`: `26.2.130`; `versionCode`: `182`.
- Package: `com.quanlycay.apk`.
- Based on the V26.2.129 source; no project rebuild from scratch.

## Changes

1. Routine app sync no longer downloads, serializes, or rewrites the full split PDF-label/report collections. Those records remain managed by targeted import, assignment, scan, report, and migration transactions.
2. The main app document is updated by changed top-level fields only, with unchanged fields omitted from the Firestore update.
3. PDF import persistence operates on the latest batch tracking IDs in bounded chunks; historical label rows are not fetched to prepare that batch.
4. Duplicate lookup uses targeted tracking-number queries and deterministic order IDs. If those queries fail, it stops safely instead of falling back to a full order-history scan.
5. Assignment groups are reduced to 10 labels, the verified storage-schema check is not repeated within the same session, and UI status reports deferred/duplicate sync operations instead of leaving a stale spinner.

## Data safety

- The existing Firestore schema and business logic are retained.
- Assignment still validates per-tracking claim, scan, order, queue and report records; recorded/claimed rows are not silently reassigned.
- An uncertain Firebase result remains unconfirmed; the app keeps pending/dirty markers for retry.
- Failed targeted duplicate lookup stops import rather than bypassing duplicate protection.
- No old PDF labels, payroll, inventory, staff records, or Drive images are automatically deleted by these changes.

## Verification limits

Automated source/preflight/regression checks are not a live Firebase acceptance test. Android SDK/Gradle are not available in this build environment, so an APK has not been built here. Live Firebase rules/indexes, multi-device contention, Drive behavior, certificate fingerprint, and device performance still need validation after GitHub Actions builds the APK.

## GitHub Actions / APK release

Upload this source ZIP to the repository root on `main` to trigger `.github/workflows/build-apk.yml`. For an in-app update Release to be installable, repository secrets must include `DEBUG_KEYSTORE_BASE64` and `EXPECTED_APK_CERT_SHA256` matching the certificate used to sign the APK. This source package does not include signing secrets or a private keystore.
