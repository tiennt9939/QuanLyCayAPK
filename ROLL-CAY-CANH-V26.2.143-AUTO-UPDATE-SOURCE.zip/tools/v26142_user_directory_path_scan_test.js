'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const gas = fs.readFileSync(path.join(root, 'Code.gs'), 'utf8');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const adapter = fs.readFileSync(path.join(root, 'app/src/main/assets/gas-firestore-compat.js'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');

assert.match(gradle, /versionName\s*=\s*"26\.2\.143"/);
assert.match(gradle, /versionCode\s*=\s*195/);
assert.match(gas, /VERSION:\s*'gas-firestore-compat-phase3\.2-user-directory-path-scan'/);
assert.match(gas, /if\s*\(command\s*===\s*'listUsers'\)/);
assert.match(gas, /if\s*\(!identity\.isAdmin\)\s*throw fsCompatError_\('PERMISSION_DENIED'/,
  'users directory must remain Admin-only');
assert.match(gas, /rawUserUniquePathCount/);
assert.match(gas, /materializedDocumentCount/);
assert.match(gas, /returnedDocumentCount/);
assert.match(gas, /source:'users-document-path-index-admin-only'/);
assert.match(gas, /function fsCompatReadLatestMetadata_\(sheet\)[\s\S]*?String\(a\[0\]\|\|''\)\.trim\(\)\.toLowerCase\(\)!=='doc'[\s\S]*?String\(a\[1\]\|\|''\)\.trim\(\)/,
  'metadata scan must normalize row type and document path');

const helperStart = gas.indexOf('function fsCompatUserDocumentPaths_(metadata)');
const helperEnd = gas.indexOf('\n}', helperStart) + 2;
assert(helperStart >= 0 && helperEnd > helperStart, 'user path helper exists');
const ctx = { Object, String };
vm.createContext(ctx);
vm.runInContext(gas.slice(helperStart, helperEnd) + '\nthis.pick=fsCompatUserDocumentPaths_;', ctx);
const paths = ctx.pick({
  'users/u1': { deleted: false },
  'users/u2': { deleted: false },
  'users/u3/nested/doc': { deleted: false },
  'packingOrders/o1': { deleted: false },
  'users/': { deleted: false }
});
assert.deepEqual(Array.from(paths).sort(), ['users/u1', 'users/u2']);

assert.match(adapter, /async _listUsersCompat\(\)\s*\{\s*const raw=await request\('listUsers'/,
  'adapter must call the dedicated Admin users endpoint');
assert.match(html, /targetDb\._listUsersCompat\(\)/);
assert.match(html, /rawUserUniquePathCount/);
assert.match(html, /needsCollectionCrossCheck/);
assert.match(html, /collectionQueryReturned/);
assert.match(html, /async function linkUserEmployee\([\s\S]*?const refreshed=await listUsers\(true\)[\s\S]*?throw new Error\('Đã ghi liên kết nhưng danh sách users đọc lại chưa thấy nhân viên/,
  'link operation must verify the directory read-back before success');
assert.match(html, /async function refreshEmployeeAccountViews\([\s\S]*?await fillAssignOptions\(\)[\s\S]*?loadTikTokAssignees\(true\)/,
  'employee and PDF assignment selectors must refresh after account changes');

console.log('V26.2.143 Admin users path scan, raw-sheet diagnostics, and link verification: PASS');
