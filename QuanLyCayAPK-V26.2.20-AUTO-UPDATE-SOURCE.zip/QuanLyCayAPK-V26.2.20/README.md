# QuanLyCayAPK / ROLL CÂY CẢNH — V26.2.20

Bản cập nhật nhận biết rõ trạng thái hoàn tất đơn: đỏ khi chưa sẵn sàng, vàng khi OCR đang chạy, xanh khi đã đủ điều kiện xác nhận. Build version `26.2.20`, versionCode `72`.

Luồng một ảnh, lưu Google Drive trước khi ghi đơn, xác minh mã vận đơn TT, bảo vệ chống trùng vận đơn, tiền công, tồn kho, nhập PDF TikTok, Firestore schema và cập nhật ứng dụng được giữ nguyên từ V26.2.19.
