# ROLL CÂY CẢNH V17 – Tài khoản & phân quyền

Tài khoản quản trị viên gốc: `tiennt9939@gmail.com`.

## Quyền
- `admin`: toàn quyền + quản lý tài khoản.
- `manager`: đóng hàng + nhập kho + báo cáo.
- `packer`: đóng hàng.
- `warehouse`: nhập kho.
- `viewer`: chỉ xem báo cáo.

Tài khoản mới tự đăng ký được tạo mặc định là `viewer`. Quản trị viên có thể tạo user trực tiếp trong app và cấp quyền.

## Firestore
Dùng file `firestore.rules` trong thư mục project để cập nhật Rules trên Firebase Console.

Dữ liệu nghiệp vụ dùng chung nằm tại:
`apps/roll-cay-canh`

Hồ sơ quyền nằm tại:
`users/{uid}`

Dữ liệu V15/V16 cũ tại `users/{uid}/apps/roll-cay-canh` được quản trị viên tự động chuyển sang kho dùng chung lần đầu đăng nhập sau khi Rules mới được áp dụng.
