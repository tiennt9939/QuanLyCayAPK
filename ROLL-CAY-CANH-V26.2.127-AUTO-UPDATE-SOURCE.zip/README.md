# ROLL CÂY CẢNH V26.2.127 — targeted PDF queue sync and assignment transaction fix

- Android `versionName`: `26.2.127`; `versionCode`: `179`.
- Based on the existing V26.2.126 source; keeps package `com.quanlycay.apk`, app-private durable state, Firebase/Drive integration, payroll, inventory, catalog, plant-recognition rules and existing Firestore data model.
- PDF assignment now synchronizes the dedicated PDF label queue first, instead of blocking assignment on a full-app Firestore push triggered by an unrelated/stale local dirty flag.
- Queue assignment requires an explicit successful response from Firebase. A failed queue sync blocks assignment and retains local data. Existing unrelated dirty state is preserved rather than incorrectly cleared by a successful assignment.
- The PDF import path parses the selected/new PDF and builds a normalized tracking-number index for one-pass matching against existing queue rows; it does not re-run OCR/barcode extraction on historical PDFs. Existing cross-date/recorded/assigned duplicate protections remain.
- Bulk assignment remains chunked and transactional, with explicit timeout and per-chunk status. Normal assignment transactions read only the exact per-label queue, report, scan, claim and legacy-order documents; they no longer read the large shared app-root document unless an exceptional old, unrecorded duplicate actually needs cleanup. This avoids unnecessary conflict/retry with full catalog/payroll sync.
- After syncing the newest PDF, local state is updated from cached rows belonging to that file rather than iterating the full historical in-memory queue. Historical rows remain preserved.

## Verification boundaries

Automated source tests and static checks are run locally. This package is source only: no Android SDK/Gradle build environment is available here, so an APK has not been built or signed in this environment. Firebase/Google Drive live integration and real-device testing are not claimed as completed.

## GitHub Actions / signed release

To build and publish the APK, upload this source ZIP at the repository root on the configured branch and let `.github/workflows/build-apk.yml` run. The repository Actions secrets `DEBUG_KEYSTORE_BASE64` and `EXPECTED_APK_CERT_SHA256` must be configured for a signed Release/update that passes the in-app certificate check. Do not upload private signing keys into this ZIP. A successful source test is not the same as a successful Android APK build; inspect the Actions run and test the resulting APK on the shop device.
