const assert = require('assert');
const parser = require('../app/src/main/assets/tiktok-label-import.js');

// Confirmed from user-provided TikTok Shop label images (offline parser regression).
assert.strictEqual(parser.carrierFor('VNGH80722500317'), 'GHN');
assert.strictEqual(parser.carrierFor('862513534747'), 'J&T Express');

const rubyQty1 = { productName: 'Cây Ruby Đỏ – Nắng màu đỏ rực phù hợp mọi không gian', sku: 'Combo 4 tặng 1', sellerSku: '', qty: 1 };
const rubyQty2 = { productName: 'Cây Ruby Đỏ – Nắng màu đỏ rực phù hợp mọi không gian', sku: 'Combo 4 tặng 1', sellerSku: '', qty: 2 };
assert.strictEqual(parser.expectedPlantsPerSoldUnit(rubyQty1), 5);
assert.strictEqual(parser.expectedPlantsPerSoldUnit(rubyQty2), 5);
assert.strictEqual(parser.expectedPlantsPerSoldUnit(rubyQty1) * rubyQty1.qty, 5);
assert.strictEqual(parser.expectedPlantsPerSoldUnit(rubyQty2) * rubyQty2.qty, 10);

const hibiscus = parser.plantNameTokens('Combo 2 chậu Hoa Giâm Bụt nhiều màu hoa nở quanh năm + cây trang trí sân vườn');
const quynhAnh = parser.plantNameTokens('Combo 2 chậu Quỳnh Anh sân nụ hoa nở quanh năm + cây trang trí sân vườn');
assert(hibiscus.length > 0, 'Hoa Giâm Bụt name should yield catalog-match tokens');
assert(quynhAnh.length > 0, 'Quỳnh Anh name should yield catalog-match tokens');
assert.notDeepStrictEqual(hibiscus, quynhAnh, 'Distinct products must not collapse into the same name tokens');

console.log('TikTok label photo regression specification: PASS');
