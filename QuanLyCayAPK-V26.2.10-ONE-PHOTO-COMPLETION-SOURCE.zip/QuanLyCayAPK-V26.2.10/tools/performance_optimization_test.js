'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const source = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/index.html'), 'utf8');

// Live order snapshots must not download every historical completion photo.
assert(source.includes('async function fromCloudValueSkippingHistoryImages(value,key=\'\')'),
  'lazy Drive hydration helper is missing');
assert(source.includes("new Set(['completionImage','completionImages','proofImages'])"),
  'history evidence image fields are not protected from eager hydration');
assert(source.includes('window.DriveStorage.fromCloudValueSkippingHistoryImages(rawRows)'),
  'Firestore order listener must use lazy image hydration');
assert(!source.includes('window.DriveStorage.fromCloudValue(rawRows).then(rows=>'),
  'admin live listener still eagerly downloads images for every order');
assert(source.includes('scheduleLegacyOrderImageMigration(rows)'),
  'legacy Base64 migration must run through the throttled background queue');
assert(source.includes('function scheduleLegacyOrderImageMigration(rows)'),
  'bounded background migration queue is missing');
assert(source.includes('persistPackerOrderCache(safeRows,uid,{deferLegacyMigration:true})'),
  'employee live listener must not upload every legacy photo during cache writes');
assert(source.includes('function openDailyProofImage('),
  'daily proof images need an explicit lazy viewer');
assert(source.includes('let usersListCache=null,usersListCacheAt=0,usersListFetchPromise=null'),
  'Admin user list needs a time-bounded request cache');
assert(source.includes('Date.now()-usersListCacheAt<30000'),
  'Admin user list cache lifetime should avoid repeated Firestore reads during rendering');
assert(source.includes('function invalidateUserManagementUI()'),
  'explicit user-management changes must invalidate the UI cache');

// Exercise the exact lazy hydration helper in isolation with a fake Drive downloader.
const helperStart = source.indexOf("async function fromCloudValueSkippingHistoryImages(value,key='')");
const helperEnd = source.indexOf('  async function connect()', helperStart);
assert(helperStart >= 0 && helperEnd > helperStart, 'could not isolate lazy hydration helper');
const helperSource = source.slice(helperStart, helperEnd).trim();
const ctx = {
  LAZY_HISTORY_IMAGE_KEYS: new Set(['completionImage','completionImages','proofImages']),
  fromCloudValue: async value => `hydrated:${value}`,
  Promise, Set, String, Object, Array
};
vm.createContext(ctx);
vm.runInContext(`${helperSource}\nthis.lazyHydrate=fromCloudValueSkippingHistoryImages;`, ctx);
(async () => {
  const input = {
    catalog: [{ image: 'drive://plant-photo' }],
    daily: [{ proofImages: { 'Nhan Vien': 'drive://daily-proof' } }],
    orders: [{ completionImage: 'drive://order-photo', completionImages: ['drive://photo-1','drive://photo-2'], name: 'order' }]
  };
  const result = await ctx.lazyHydrate(input);
  assert.strictEqual(result.catalog[0].image, 'hydrated:drive://plant-photo',
    'catalog plant pictures should retain existing hydration behavior');
  assert.strictEqual(result.daily[0].proofImages['Nhan Vien'], 'drive://daily-proof',
    'daily proof must remain a reference until explicitly opened');
  assert.strictEqual(result.orders[0].completionImage, 'drive://order-photo',
    'order photo must remain a reference until explicitly opened');
  assert.deepStrictEqual(Array.from(result.orders[0].completionImages), ['drive://photo-1','drive://photo-2'],
    'order photo array must remain references');

  // Exercise the render coalescer: repeated listener bursts schedule only one full redraw.
  const renderStart = source.indexOf('let orderSnapshotRenderTimer=0;');
  const renderEnd = source.indexOf('\nfunction renderAll(){', renderStart);
  assert(renderStart >= 0 && renderEnd > renderStart, 'could not isolate order snapshot render coalescer');
  const timers = [];
  let renders = 0;
  const renderCtx = { setTimeout: fn => { timers.push(fn); return timers.length; }, renderAll: () => { renders++; }, console };
  vm.createContext(renderCtx);
  vm.runInContext(source.slice(renderStart, renderEnd), renderCtx);
  renderCtx.scheduleOrderSnapshotRender();
  renderCtx.scheduleOrderSnapshotRender();
  renderCtx.scheduleOrderSnapshotRender();
  assert.strictEqual(timers.length, 1, 'snapshot burst must schedule only one timer');
  timers[0]();
  assert.strictEqual(renders, 1, 'snapshot burst must produce one full redraw');
  console.log('PERFORMANCE OPTIMIZATION TEST PASS: lazy historical images, bounded legacy migration, and coalesced snapshot renders');
})().catch(err => { console.error(err); process.exitCode = 1; });
