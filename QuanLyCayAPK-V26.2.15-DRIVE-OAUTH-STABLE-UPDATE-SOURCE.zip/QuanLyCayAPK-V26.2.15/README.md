# QuanLyCayAPK — V26.2.15 tự cập nhật + phân công PDF + nhóm đơn theo nhân viên

This release is based on V26.2.13 and carries forward PDF parsing/catalog matching, one-photo completion, Google Drive image persistence, and in-app updater support. It does not change wage, inventory, Firestore schema, or security rules.

The Admin view now hides processed PDF-label cards from the temporary queue and removes their bulky payloads from local staging; those orders remain in Firestore. Pending shared orders are summarized in a lazy-open group, pending private orders are summarized by employee and count, and completed orders are grouped by employee. An unclaimed shared TikTok PDF order can still be reassigned from its order card using the existing Firestore-transaction-backed operation.

## Build identity
- `versionName`: `26.2.15`
- `versionCode`: `67`
- Android package: `com.quanlycay.apk`
- Build: GitHub Actions manual workflow `.github/workflows/build-apk.yml`

## Root cause and fix
The supplied 12-page TikTok Shop PDF uses visually aligned product table columns. PDFBox's ordinary text stream can interleave table column labels/values with other content, while the previous JavaScript fallback assumed contiguous blocks. That is why the app found tracking numbers and Order IDs but dropped plant/SKU/Qty. This release keeps native coordinate-based text reconstruction, selects the best of three extraction variants, then matches each product to the current app catalog. Product Name text after a dash is ignored; Combo N is plants per sale unit and Qty counts sale units. Unique name/size matches are auto-filled; unresolved ambiguity remains for Admin review except the explicit Combo 5 Cẩm tú mai C6/C7 → Cẩm tú mai C7 rule. If Admin manually confirms another valid mapping, that recognition rule is saved locally and reused for subsequent labels with the same normalized identity, Combo count and explicit size set.

## Safety boundary
The change does not edit Firestore data, Firestore Rules behavior, database schema, catalog or catalog prices, user accounts/permissions, wage formula, inventory calculations, image/Drive storage, or order completion. PDF import still stages labels only; an Admin confirms or corrects the catalog map and explicitly creates/assigns orders. The PDF queue itself has per-label checkboxes and select-all for new, unlinked labels only. Existing shared orders are not bulk-selectable; Admin can reassign one unclaimed shared order from its own row using the employee selector. The app never invents catalog entries or changes inventory just because a PDF was read.

## Verification performed
- `python3 tools/preflight.py`
- All 21 `tools/*_test.js` tests, including employee group counts, lazy rendering, PDF queue compaction and `tiktok_pdf_real_layout_regression_test.js`
- JavaScript syntax checks for all inline blocks and `tiktok-label-import.js`
- Sanitized product table fragments from all 12 supplied PDF pages: 12/12 parsed with a product and positive Qty.

## Device validation still required
The source-level test suite and JavaScript syntax checks passed for V26.2.15. This package has not yet been built into an APK by this session and the revised UI has not been tested on a physical device. Run the GitHub Actions workflow and test the APK with the shop’s real PDF and order data before using it for live assignments. If Gradle compilation fails, do not install the APK; inspect the workflow diagnostics first.

## GitHub mobile workflow — stable signing migration and updater

1. Upload `QuanLyCayAPK-V26.2.15-DRIVE-OAUTH-STABLE-UPDATE-SOURCE.zip` to the repository root. Replace the contents of your existing updater workflow with `build-apk-v26.2.15-drive-oauth-stable-update.yml`; avoid enabling several competing build workflows.
2. Keep the existing `DEBUG_KEYSTORE_BASE64` Actions secret. For the first migration run, leave `EXPECTED_APK_CERT_SHA256` empty. The workflow will use the stable keystore, print its public SHA-1/SHA-256 fingerprints, upload a stable-signed APK artifact, and intentionally skip GitHub Release publication.
3. Add the currently installed V26.2.14 certificate fingerprints documented in `REPORT_V26.2.15_DRIVE_AND_UPDATER_FIX.md` to the Android app `com.quanlycay.apk` in Firebase Project Settings and its corresponding Google Cloud OAuth Android client. This fixes Google Drive on the APK already installed.
4. After the migration workflow runs, add its printed stable signing SHA-1 and SHA-256 to the same Firebase/OAuth app. Ensure cloud data is synchronized and back up any local-only data before the one-time signing migration. Download the successful Actions artifact; because the signing certificate changes, do not use the in-app updater from V26.2.14. A one-time uninstall/reinstall may be needed. Reconnect Drive after installation.
5. Set `EXPECTED_APK_CERT_SHA256` to the SHA-256 fingerprint printed for the stable keystore. Rerun the workflow to publish a matching GitHub Release for V26.2.15. After that, future releases must keep the same keystore and increase both `versionName` and `versionCode`; the in-app updater can then update without signature conflict.

Never commit the private keystore or its base64 value into the public repository. The stable signing keystore and the public fingerprints are different things; only the fingerprints belong in Firebase/Google Cloud OAuth.

## PDF catalog matching behavior
- Plant-name token matching ignores marketing text after a dash, while size detection still checks the complete Product Name, SKU and Seller SKU so a C9 after a dash is not discarded.
- Combo N is N plants per sold unit, and PDF Qty is the number of combos. The app computes N × Qty.
- Each imported plant must resolve to a row from the currently loaded app catalog. A unique name/size match is prefilled. Ambiguous/missing size choices remain for Admin review; no catalog row is fabricated and no order is created until Admin assigns it.
- `tools/tiktok_catalog_matcher_test.js` validates catalog matching against `app/src/main/assets/data.json`, including the agreed Combo 5 Cẩm tú mai C6/C7 → existing C7 catalog row behavior and Qty 2 → 10 plants.

## Confirmed and learned recognition rules
- `Combo 5 cây cẩm tú mai thái C6, Combo 5 C7` maps to the existing Cẩm tú mai C7 catalog row; Qty 2 means 10 plants.
- When Admin fixes a different ambiguous mapping, the app persists a normalized recognition rule locally for future equivalent labels. A C9 or different Combo/name signature will not inherit the rule.
- Rules are device-local (localStorage), not synced to other Admin devices.


## V26.2.10 — Hoàn tất đơn bằng một ảnh

- Mọi đơn đóng hàng chỉ cần 1 ảnh bằng chứng để hoàn tất, gồm đơn riêng, đơn chung, TT, ĐN và đơn TikTok nhập từ PDF.
- Ảnh nên thể hiện được kiện hàng và nhãn vận đơn rõ ràng trong cùng khung hình. Đơn TT thông thường OCR mã vận đơn từ ảnh duy nhất; đơn đã xác minh bằng quét mã/PDF giữ nguyên kết quả đó.
- Ảnh vẫn phải tải lên Google Drive thành công và đơn chỉ được xác nhận hoàn tất sau khi Firestore xác nhận ghi thành công. Công thức tiền công, tồn kho, phân công và schema dữ liệu không đổi.
- **Bắt buộc:** publish tệp `firestore.rules` đi kèm source này vào đúng Firebase project, nếu không rules cũ có thể vẫn yêu cầu 2 ảnh và từ chối hoàn tất.


## In-app update

- The app checks the public GitHub Releases endpoint for this repository every 24 hours and when the user opens the Sync panel; the user can also check manually.
- Updates are offered as a download and Android package-installer handoff. Android still requires user confirmation; this is not a silent installer.
- The updater only accepts HTTPS release assets from `github.com/tiennt9939/QuanLyCayAPK/releases/download/`. It requires a matching `.apk.sha256` sidecar and verifies SHA-256 before opening Android's installer.
- The build workflow publishes `v26.2.14` and later APK assets to GitHub Releases only when both `DEBUG_KEYSTORE_BASE64` and `EXPECTED_APK_CERT_SHA256` Actions secrets are configured and the certificate fingerprint matches. Keep that secret identical across releases. Never commit the keystore or its base64 string to the repository.
- **Signing compatibility warning:** Android only updates an installed package when the certificate matches. Set `EXPECTED_APK_CERT_SHA256` to the 64-hex SHA-256 signer fingerprint of the APK currently installed, and `DEBUG_KEYSTORE_BASE64` to that exact signing keystore. The workflow compares the built APK fingerprint before publishing. A different key causes Android to reject an update; do not uninstall the existing app before backing up local-only data.
- A V26.2.12 APK does not contain the new bridge/UI, so the initial upgrade to V26.2.15 must be installed manually once. In-app updates work for later releases that use the same signing key.




## Fix Google Drive sign-in and enable stable in-app updates (V26.2.15)

- Google Sign-In error code 10 is surfaced with a clear OAuth/package/SHA diagnostic. It is not silently treated as a Drive upload error.
- This source includes the stable-signing migration workflow. It decodes the existing `DEBUG_KEYSTORE_BASE64` Actions secret whenever available and prints the keystore SHA-1/SHA-256 in the Actions log. If `EXPECTED_APK_CERT_SHA256` is missing, it creates an artifact but intentionally does not publish a Release.
- The currently installed V26.2.14 APK from Actions run `38352179346` was inspected directly: package `com.quanlycay.apk`; SHA-1 `86:56:08:0C:EB:29:7B:4F:72:FC:98:70:7E:63:4D:74:69:6A:28:C8`; SHA-256 `4E:27:5A:0B:C3:01:76:64:A5:42:8E:E5:12:CD:5B:1C:C5:DA:AB:1F:B6:EF:56:C0:65:50:88:EE:DA:0C:8B:4A`. Add its SHA-1/SHA-256 to Firebase / Google Cloud OAuth to fix Drive on that installed APK.
- Because previous GitHub builds used ephemeral debug signing (verified V26.2.11 and V26.2.14 artifacts had different certificate fingerprints), the existing V26.2.14 cannot be guaranteed to accept an APK signed by the stable keystore. Perform a one-time manual signing migration after sync and export/backup any local-only data; reconnect Drive after reinstall. Do not distribute a stable-signed APK as an in-app update to the old signature.
- After running the workflow with `EXPECTED_APK_CERT_SHA256` blank, add the printed stable-keystore SHA-1/SHA-256 to Firebase/Google Cloud and manually install the stable-signed V26.2.15 artifact. Then set `EXPECTED_APK_CERT_SHA256` to the printed stable keystore SHA-256 and rerun to publish the matching Release. Future builds use the same key; increment versionCode/versionName for each subsequent release.
