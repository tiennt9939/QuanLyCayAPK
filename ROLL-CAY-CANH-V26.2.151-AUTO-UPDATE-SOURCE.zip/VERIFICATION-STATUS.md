# ROLL CÂY CẢNH V26.2.151 — Source verification status

- Android package: `com.quanlycay.apk`
- `versionName`: `26.2.151`
- `versionCode`: `203`
- Source basis: supplied `ROLL-CAY-CANH-V26.2.151-AUTO-UPDATE-SOURCE.zip` from the uploaded project archive.

## Checks completed in this environment

- Inner source ZIP integrity: PASS.
- Inner ZIP vs extracted project tree: 189/189 files match SHA-256.
- `tools/preflight.py`: PASS.
- JavaScript regression tests: 136/136 PASS.
- JavaScript syntax: 9 inline script blocks + 3 external JavaScript files PASS.

## Not verified

- Android Gradle/APK build: NOT RUN (Gradle and Android SDK are not installed in this environment).
- APK signature continuity with the installed production APK: NOT VERIFIED (requires the original signing certificate/keystore fingerprint and GitHub Secrets).
- Real-device testing: NOT RUN.
- Live Firebase Authentication / Firestore / Google Drive / GAS behavior: NOT RUN.
- Production data integrity and restore: NOT verified against the user's actual JSON backup or live database.

## Important release gate

`.github/workflows/build-apk.yml` requires the GitHub Actions secret `DEBUG_KEYSTORE_BASE64`. If `EXPECTED_APK_CERT_SHA256` is absent, the workflow may create an Artifact but deliberately skips publishing a GitHub Release. Do not replace the signing key for an existing installation: Android may reject the update because of a signature mismatch.

## Safety

This package preserves the supplied application source and business logic. No production data, Firebase, Firestore, GAS deployment, or user account was changed during these checks. This is a verified source package, **not a certified production APK**.
