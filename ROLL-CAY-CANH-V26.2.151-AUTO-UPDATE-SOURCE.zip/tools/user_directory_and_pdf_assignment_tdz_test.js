const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8');

// PDF assignment regression: users must be initialized before target validation reads users.find().
const assignStart=html.indexOf('async function adminAssignDailyShipmentLabels(date,assignments){');
const assignEnd=html.indexOf('\n  async function ',assignStart+20);
assert(assignStart>=0&&assignEnd>assignStart,'adminAssignDailyShipmentLabels must exist');
const assign=html.slice(assignStart,assignEnd);
const usersInit=assign.indexOf('const users=await dailyShipmentAwaitWithTimeout(listUsers(),12000');
const userFind=assign.indexOf('users.find(');
assert(usersInit>=0&&userFind>usersInit,'the users directory must be awaited before users.find() validation');
assert((assign.match(/const users\s*=/g)||[]).length===1,'assignment must have exactly one users binding; no later TDZ shadow declaration');

// Account creation regression: bounded fresh directory validation must finish before Firebase Auth creation.
const createStart=html.indexOf('async function createUser(email,password,employeeId,roleValue){');
const createEnd=html.indexOf('\n  let usersListCache=',createStart);
assert(createStart>=0&&createEnd>createStart,'createUser must exist');
const create=html.slice(createStart,createEnd);
const directoryCheck=create.indexOf('userDirectoryAwaitWithTimeout(listUsers(true),18000');
const authCreate=create.indexOf('a.createUserWithEmailAndPassword(');
assert(directoryCheck>=0&&authCreate>directoryCheck,'Firebase Auth must not be created before bounded user-directory read');
assert(create.includes('invalidateUsersListCache();throw new Error('),'a directory timeout must release the stuck request/cache and fail closed');
assert(create.includes('Chưa xác nhận được danh sách tài khoản hiện có'),'user must receive a clear directory-read failure, not an endless spinner');

// Directory helper must bound direct hint reads and listUsers must bound the overall supplemental read.
assert(html.includes('function userDirectoryAwaitWithTimeout(task,timeoutMs,label){'),'bounded user-directory timeout helper missing');
assert(html.includes("userDirectoryAwaitWithTimeout(db._getManyCompat(missing.slice(-100).map(uid=>'users/'+uid)),6500"),'GAS direct hint read must be bounded');
assert(html.includes("userDirectoryAwaitWithTimeout(loadVerifiedUserHints(rows),7000"),'listUsers must bound its verified-UID fallback');
assert(/catch\(error\)\{console\.warn\('Verified user profile direct-read fallback',error\);throw new Error/.test(html),'failed user hint verification must fail closed, not silently continue account creation');

// Current package identity.
assert(/versionName\s*=\s*"26\.2\.151"/.test(gradle)&&/versionCode\s*=\s*203/.test(gradle),'V26.2.151 / code203 metadata mismatch');
console.log('USER DIRECTORY + PDF ASSIGNMENT TDZ REGRESSION PASS');
