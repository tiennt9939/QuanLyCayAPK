const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const code=fs.readFileSync(path.join(root,'Code.gs'),'utf8');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8');
assert(gradle.includes('versionName = "26.2.152"')&&gradle.includes('versionCode = 204'),'release metadata');
assert(code.includes("VERSION: 'gas-firestore-compat-phase3.2-user-directory-path-scan'"),'GAS compatibility version');
assert(code.includes('function fsCompatBuildIndexForCollections_(collectionPaths)'),'scoped collection index exists');
const scoped=code.slice(code.indexOf('function fsCompatBuildIndex_()'),code.indexOf('function fsCompatFindOperation_(sheet, opId)'));
assert(scoped.includes('getRange(2,1,count,4).getValues()'),'scoped index reads A:D metadata only');
assert(scoped.includes('getRange(2,6,count,6).getValues()'),'scoped index reads F:K metadata only');
assert(scoped.includes('wanted[metadata[path].collectionPath]'),'unrelated collections are skipped before payload reads');
assert(scoped.includes('fsCompatReadPayloadChunks_(sheet,rowNumbers)'),'payload chunks are fetched in batched contiguous ranges');
assert(scoped.includes('getRange(start,5,end-start+1,1).getValues()'),'payload data is read in range batches rather than one Spreadsheet call per chunk');
assert(!scoped.includes('getRange(rowNo,5).getValue()'),'no per-document payload service calls remain');
assert(code.includes("function fsCompatReadCurrentDoc_(path) {" )&&code.includes('fsCompatBuildIndexForPaths_([clean])'),'auth profile lookup reads only its exact document');
const handler=code.slice(code.indexOf("if (command === 'get' || command === 'query'"),code.indexOf("if (command === 'importBatch')"));
assert(handler.includes('fsCompatBuildIndexForQuery_(body)'),'normal collection reads avoid full-sheet JSON index reconstruction');
assert(handler.includes('fsCompatBuildIndexForCollections_(queryCollections)'),'multiQuery uses only required collections');
assert(!handler.includes('var index = fsCompatBuildIndex_();'),'read path no longer rebuilds every collection');
assert(html.includes('window.__rollGasDirectoryDb=candidate;'),'pre-cutover GAS account snapshot retained read-only');
assert(html.includes("readUsersCollection(recoveryDb,15000,'bản sao Google Sheets')")&&html.includes('Promise.allSettled(tasks)'),'account list reads the GAS migration snapshot in parallel');
assert(html.includes('function mergeUserDirectoryRows(primaryRows,gasRows)')&&html.includes('mergeUserDirectoryRows(primaryRows,gasRows)'),'active and backup user profiles are merged by UID');
assert(html.includes('merged._rollNeedsGasRepair=true'),'missing profile fields from GAS are surfaced for explicit repair');
assert(html.includes('async function restoreMissingStaffProfilesFromGas()'),'admin recovery operation exists');
assert(html.includes("if(!Object.prototype.hasOwnProperty.call(current,'active'))patch.active=row.active!==false"),'account lock state is preserved during recovery');
assert(html.includes('!u._rollRecoveredFromGas&&!u._rollNeedsGasRepair'),'unrestored profiles are not assigned until copied into the active backend');
assert(html.includes("error.code='deadline-exceeded'"),'account list request has a bounded timeout');
assert(html.includes("if(existingByEmail){")&&html.includes('profileRef(existingByEmail.uid).set(relinkPatch,{merge:true})'),'existing registered email is linked by admin profile update without second Auth registration');
assert(html.includes("if(!password){toast('Email này chưa có hồ sơ tài khoản để liên kết."),'password is required only for new Auth accounts');
assert(html.includes('u.employeeName||u.displayName||u.name||\'\''),'legacy employee name aliases are normalized');
assert(html.includes('&&!u._rollRecoveredFromGas&&!u._rollNeedsGasRepair'),'packing assignment selector waits until profile restoration is complete');
const outsideSelector=html.slice(html.indexOf('function renderOutsideOrderEmployeeOptions'),html.indexOf('// Use the catalog row index',html.indexOf('function renderOutsideOrderEmployeeOptions')));
assert(outsideSelector.includes('!u._rollRecoveredFromGas&&!u._rollNeedsGasRepair'),'outside TikTok assignment selector uses only restored profiles');
const pdfSelector=html.slice(html.indexOf('async function loadTikTokAssignees'),html.indexOf('function tiktokLabelCompositionOverrideItems'));
assert(pdfSelector.includes('!u._rollRecoveredFromGas&&!u._rollNeedsGasRepair'),'staff PDF import selector uses only restored profiles');

const mergeStart=html.indexOf('function mergeUserDirectoryRows(primaryRows,gasRows)');
const mergeEnd=html.indexOf('async function readUsersCollection',mergeStart);
assert(mergeStart>=0&&mergeEnd>mergeStart,'pure account-directory merge helper exists');
const mergeCtx={Map,String,Array};require('vm').createContext(mergeCtx);
require('vm').runInContext(html.slice(mergeStart,mergeEnd)+'\nthis.merge=mergeUserDirectoryRows;',mergeCtx);
const merged=mergeCtx.merge(
  [{uid:'u1',role:'packer',active:false,employeeId:'',employeeName:'',email:'worker@example.com',_rollRoleMissing:false}],
  [{uid:'u1',role:'packer',active:true,employeeId:'3',employeeName:'Luân nhỏ',email:'worker@example.com'},
   {uid:'u2',role:'packer',active:true,employeeId:'4',employeeName:'Huy',email:'huy@example.com'}]
);
assert(merged.rows.find(x=>x.uid==='u1').employeeId==='3'&&merged.rows.find(x=>x.uid==='u1')._rollNeedsGasRepair,'existing profile receives only missing employee fields');
assert(merged.rows.find(x=>x.uid==='u1').active===false,'existing locked account stays locked');
assert(merged.rows.find(x=>x.uid==='u2')._rollRecoveredFromGas,'GAS-only profile is surfaced for explicit restoration');


const scopedStart=code.indexOf('function fsCompatBuildIndex_()');
const scopedEnd=code.indexOf('function fsCompatFindOperation_(sheet, opId)',scopedStart);
const payloads={2:'{"role":"packer","employeeId":"old"}',3:'{"role":"packer","employeeId":"3"}',4:'{"trackingNo":"SHIP-1"}',6:'{"role":"packer","employeeId":"2",',7:'"employeeName":"Luân nhỏ"}'};
const payloadRanges=[];
const metaLeft=[
 ['doc','users/u1','users','u1'],
 ['doc','users/u2','users','u2'],
 ['doc','packingOrders/t1','packingOrders','t1'],
 ['op','','',''],
 ['doc','users/u1','users','u1'],
 ['doc','users/u1','users','u1']
];
const metaRight=[
 [0,1,1,100,'admin',false],
 [0,1,1,101,'admin',false],
 [0,1,1,102,'admin',false],
 [0,1,0,103,'admin',false],
 [0,2,2,104,'admin',false],
 [1,2,2,104,'admin',false]
];
const sheetMock={
 getLastRow:()=>7,
 getRange:(row,col,numRows,numCols)=>({
  getValues:()=>{
   if(col===1)return metaLeft.slice(row-2,row-2+numRows).map(x=>x.slice(0,numCols));
   if(col===6)return metaRight.slice(row-2,row-2+numRows).map(x=>x.slice(0,numCols));
   if(col===5){payloadRanges.push({row,numRows});const out=[];for(let i=0;i<numRows;i++)out.push([payloads[row+i]||'']);return out;}
   throw new Error('Unexpected mock range '+col);
  }
 })
};
const scopedCtx={Object,String,Number,Math,Array,JSON,fsCompatNormalizeCollectionPath_:x=>String(x).replace(/^\/+|\/+$/g,''),fsCompatNormalizeDocPath_:x=>String(x).replace(/^\/+|\/+$/g,''),fsCompatSheet_:()=>sheetMock,fsCompatError_:(code,msg)=>Object.assign(new Error(msg),{code})};
require('vm').createContext(scopedCtx);
require('vm').runInContext(code.slice(scopedStart,scopedEnd)+'\nthis.byCollection=fsCompatBuildIndexForCollections_;this.byPath=fsCompatBuildIndexForPaths_;this.related=fsCompatRelatedSecurityPaths_;',scopedCtx);
const scopedIndex=scopedCtx.byCollection(['users']);
assert(Object.keys(scopedIndex).sort().join(',')==='users/u1,users/u2','scoped GAS query returns only requested collection documents');
assert(scopedIndex['users/u1'].data.employeeName==='Luân nhỏ','latest multi-chunk profile version is reconstructed');
assert(payloadRanges.every(x=>!(x.row<=4&&x.row+x.numRows-1>=4)),'unrelated packing order payload is not fetched');
assert(payloadRanges.some(x=>x.row===6&&x.numRows===2),'adjacent chunks are read in one range call');
payloadRanges.length=0;
const one=scopedCtx.byPath(['users/u2']);
assert(Object.keys(one).join(',')==='users/u2'&&payloadRanges.length===1&&payloadRanges[0].row===3,'getMany exact path read fetches only the requested document');
const related=scopedCtx.related([{path:'packingOrders/order1',before:{},after:{shipmentTrackingNo:'GHVNABC123'}}]);
assert(related.includes('shipmentTrackingClaims/GHVNABC123')&&related.includes('dailyShipmentScans/GHVNABC123'),'security dependency paths are loaded for transaction writes');

console.log('V26.2.144 account directory recovery + batched GAS IO regression: PASS');
