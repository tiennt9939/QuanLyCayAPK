# V26.2.152 – Recipient name extraction fix

## Scope
- Continued from the supplied V26.2.152 source; kept `versionName=26.2.152`, `versionCode=204`, package `com.quanlycay.apk`.
- Changed only `app/src/main/assets/tiktok-label-import.js`, `app/src/main/assets/index.html`, and `tools/tiktok_label_import_test.js`.
- No Firebase/Firestore/GAS deployment, no production data access or mutation, no Firestore Rules changes.

## Changes
1. Added conservative `extractRecipientName()` for PDF text-layer labels: Vietnamese `Người nhận` / `Tên người nhận`, English `Recipient` / `Recipient Name` / `Receiver` / `Ship to`; supports value on same line or immediately next line.
2. Rejects obvious address/phone/tracking/other-field values and values over 100 characters. If different available PDF text representations disagree on recipient, leaves the name blank rather than guessing.
3. `parsePage()` preserves a single unambiguous recipient across available PDF text representations; `parsePages()` preserves it when merging continuation pages.
4. Daily PDF import now stores `customerName` in the existing local daily shipment row and updates an unprocessed row without replacing a previously known name.
5. PDF-to-delivery-order linking passes through the parsed recipient name.
6. Daily shipment report reads the existing `customerName`, `recipientName`, or shipment customer-name fields instead of hardcoding an empty string.
7. Added regression cases for same-line name, next-line name, and conflicting text representations.

## Verification
- `node tools/tiktok_label_import_test.js`: PASS.
- `node --check app/src/main/assets/tiktok-label-import.js`: PASS.
- `python tools/preflight.py`: PASS; version remains 26.2.152 / code 204.
- Full `tools/*test.js` suite: 138 scripts exited successfully when run from project root.
- Test output included mock/local warnings (`QuotaExceededError` and mock `PERMISSION_DENIED`) in some suites; these were emitted by tests and did not cause a nonzero test exit. They are not evidence of a live production failure or a live production pass.

## Important limitations
- No real sample PDF was supplied with this request, so the exact recipient-label layout in the user's PDF is not yet verified. If the label uses another heading/column arrangement, this conservative extractor may leave the field blank; it will not guess.
- No Android APK was built and no device/Firebase/Drive integration test was performed. This source ZIP is not an installable APK.
- Version metadata intentionally remains 26.2.152 / 204. Do not install as an update over the existing 26.2.152 build without increasing versionCode through the approved release workflow.
