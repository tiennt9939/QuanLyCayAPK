# ROLL CÂY CẢNH V26.2.150 — Direct Firestore lookup for Admin outside-order completion

## Baseline
- Base: V26.2.149 / versionCode 201.
- Version: V26.2.150 / versionCode 202.
- Package: `com.quanlycay.apk`.

## Confirmed issue
The Admin outside-order photo modal can retain a valid order ID and captured assignee while the local packing-order cache or `adminListOrders()` result omits that row. The submit handler previously stopped at a UI-level `!row` guard and never called the existing backend completion method, even though that method performs a direct Firestore document read and transactional assignee/status validation.

## Change
- For the Admin outside-order path only, a missing row in local caches or the broad Admin list no longer blocks completion.
- The handler passes the captured order ID and original assignee UID to `adminCompleteAssignedOutsideOrder()`.
- That backend method reads `packingOrders/{id}` directly, validates the order type, outside-order marker, assigned UID and pending status, uploads/uses Drive proof, and repeats the ownership/status checks inside a Firestore transaction.
- Other completion paths still require a locally/server-listed row.
- If the document is truly missing, reassigned, or already completed, the backend returns a specific error and does not record completion/payroll twice.

## Preserved
- Existing Firestore schema and collection.
- Employee receiving the wage remains the originally assigned employee.
- Admin remains the actor recorded in `completionRecordedBy`.
- Drive image upload requirement.
- Payroll formulas, inventory, PDF import and already-completed records.

## Validation
- 135/135 JavaScript regression tests passed.
- `tools/preflight.py`: PASS.
- No live Firestore or Drive data was modified or tested.
- APK build and on-device completion test have not yet been run.
