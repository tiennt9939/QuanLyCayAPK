# TÓM TẮT KIỂM TOÁN KỸ THUẬT DỰ ÁN ROLL CÂY CẢNH
## Báo cáo Rút gọn Dành cho Quản trị & Kỹ thuật (Tối đa 5 trang)

> [!IMPORTANT]
> **Nguyên tắc an toàn đã tuân thủ nghiêm ngặt trong suốt quá trình kiểm toán:**
> 1. Chỉ đọc và phân tích mã nguồn, không tự ý can thiệp logic nghiệp vụ.
> 2. Không build APK tại máy local, không commit, không push lên git remote.
> 3. Không triển khai Google Apps Script (GAS) và không ghi dữ liệu thử nghiệm vào Firebase/Firestore Production.
> 4. Toàn bộ 136 bài kiểm thử và preflight đã chạy thành công 100% trong sandbox.

---

## 1. BASELINE VÀ PHIÊN BẢN THỰC TẾ

```mermaid
flowchart LR
    V100["V26.2.100 (Code 152)\nHandover 24/10\nLỗi Quota & Assert"] --> V101["V26.2.101 (Code 153)\nHandover 24/10\nXuất JSON OK"]
    V101 --> V131["V26.2.131 - 135\nDrive 2-Queue\nOffline First\nGAS Prep"]
    V131 --> V144["V26.2.144 - 147\nPDF Batch Close\nDate-mismatch Fix"]
    V144 --> V148["V26.2.148 - 150\nOutside Order\nCamera Fallback\nDirect Lookup"]
    V148 --> V151["V26.2.151 (Code 203)\nPHIÊN BẢN HIỆN HÀNH\nTDZ & Timeout Fix"]
```

- **Mốc bàn giao ban đầu (24/10/2026 - `BAN_GIAO_ROLL_CAY_CANH_24-10-2026.md`):**
  - APK cài đặt thực tế trên máy Admin tại thời điểm đó: **V26.2.100 (versionCode 152)**.
  - Bản mã nguồn xuất JSON thành công: **V26.2.101 (versionCode 153)** (`ROLL-CAY-CANH-V26.2.101-JSON-EXPORT-FIX-AUTO-UPDATE-SOURCE.zip`), bổ sung `@JavascriptInterface` cho `saveFile` để lưu file `.json`. Người dùng đã xuất file sao lưu an toàn.
  - Tồn tại hai sự cố nghiêm trọng: Đầy bộ nhớ cục bộ (`localStorage`) và lỗi đồng bộ Firestore `INTERNAL ASSERTION FAILED: Unexpected state`.
- **Quá trình nâng cấp liên tục từ V101 đến V151:**
  - *V26.2.123 - V26.2.132:* Xử lý quota an toàn, chuyển tải ảnh Google Drive sang hàng đợi giới hạn 2 luồng đồng thời, cơ chế quét ngoại tuyến trước (offline-first outbox).
  - *V26.2.133 - V26.2.135:* Xây dựng hạ tầng dự phòng Google Apps Script (`Code.gs`, `gas-firestore-compat.js`), khóa cứng cờ an toàn `ROLL_GAS_BACKEND_ENABLED = false`.
  - *V26.2.144 - V26.2.147:* Thêm công cụ Admin "Kết thúc lô PDF cũ – giữ nguyên dữ liệu", khắc phục nhãn tồn đọng và lệch ngày backend.
  - *V26.2.148 - V26.2.150:* Khắc phục sự cố chụp ảnh đơn ngoài sàn: bổ sung fallback mở thư viện ảnh thiết bị khi Camera native lỗi, chống mất dòng đơn và bổ sung hàm `adminCompleteAssignedOutsideOrder` đọc trực tiếp Firestore.
- **Phiên bản thực tế hiện hành cao nhất trong kho:**
  - **V26.2.151 (versionCode 203)**, commit `d445c59` (Sat Oct 31 16:38:23 2026).
  - Khắc phục triệt để lỗi JavaScript Temporal Dead Zone (TDZ) trong gán nhãn PDF và thiết lập trần timeout 18 giây (`userDirectoryAwaitWithTimeout`) khi kiểm tra danh bạ tài khoản `listUsers()`.

---

## 2. FILE NGUỒN CHÍNH XÁC DÙNG ĐỂ BUILD APK

- **Tệp nguồn đóng gói chuẩn duy nhất:**
  **`ROLL-CAY-CANH-V26.2.151-AUTO-UPDATE-SOURCE.zip`** (Dung lượng: 1.708.738 bytes).
- **Cơ chế hoạt động của CI/CD (`.github/workflows/build-apk.yml`):**
  - Workflow chạy tự động trên runner Ubuntu của GitHub Actions.
  - Tìm kiếm tệp `*AUTO-UPDATE-SOURCE.zip` có số phiên bản lớn nhất trên nhánh `main`.
  - Thực hiện lệnh xóa sạch thư mục làm việc (trừ `.git` và file zip), sau đó giải nén toàn bộ nội dung trong ZIP ra root:
    ```bash
    find . -mindepth 1 -maxdepth 1 ! -name '.git' ! -name "$archive_basename" -exec rm -rf -- {} +
    cp -a "$source_root"/. .
    ```
  - Chạy `preflight.py`, toàn bộ bài test `tools/*_test.js`, kiểm tra cú pháp JS, nạp chứng chỉ ký `debug.keystore` từ Secret và biên dịch APK bằng Gradle 8.13 + Java 17 Temurin.
- **Hiện trạng thư mục gốc (`C:\QuanLyCayAPK`):**
  Đã được giải nén đồng bộ 100% từ chính tệp ZIP V26.2.151 này, giúp mã nguồn hiển thị trực tiếp trên repository khớp hoàn toàn với những gì GitHub Actions sẽ biên dịch.

---

## 3. CÁC LỖI NGHIÊM TRỌNG, NGUYÊN NHÂN VÀ BẰNG CHỨNG

| STT | Tên lỗi & Hiện tượng | Nguyên nhân gốc rễ (Root Cause) | Bằng chứng mã nguồn & Giải pháp đã xử lý |
| :---: | :--- | :--- | :--- |
| **1** | **Đầy `localStorage` dù ảnh đã chuyển Drive**<br>*Hiện tượng:* Toast/Cảnh báo `Bộ nhớ cục bộ vẫn đầy...` | 1. Tích lũy trùng lặp: vừa lưu snapshot toàn bộ `D` vào key `quanlycay`, vừa ghi bản sao vận chuyển vào `roll_cay_daily_shipment_state_backup_v1`.<br>2. Cache đơn hàng nhân viên `ROLL_CAY_PACKER_ORDERS_<uid>` lưu dồn tích qua nhiều tháng vượt 5MB WebView.<br>3. Tàn dư ảnh Base64 cũ chưa migrate hết. | - `DriveStorage.toLocalCacheValue(D)` cấm lưu Base64 vào cache.<br>- `dailyShipmentBackupMatchesSnapshot()` hủy ghi trùng lặp nếu nội dung đã có trong `D`.<br>- Tự động dọn đơn completed > 30 ngày khỏi máy con qua `runRetentionCleanupInternal()`.<br>- Công cụ chẩn đoán dung lượng `rollCayStorageDiagnostics`. |
| **2** | **Lỗi `FIRESTORE (10.14.1) INTERNAL ASSERTION FAILED: Unexpected state`**<br>*Hiện tượng:* Thanh trạng thái đỏ, không ghi được `/apps/roll-cay-canh`. | 1. Nhiều lệnh `pushNow()` chạy đồng thời khi mạng chập chờn.<br>2. Vòng lặp phản hồi: Listener nhận snapshot $\rightarrow$ cập nhật `D` $\rightarrow$ vô tình bật cờ dirty $\rightarrow$ lập lịch push ngược Cloud.<br>3. Document `/apps/roll-cay-canh` quá tải tiệm cận giới hạn 1 MiB. | - Tách riêng collection `/packingOrders` ra khỏi document tổng `/apps`.<br>- Áp dụng khóa đơn chuyến (single-flight execution lock) cho `CloudSync.pushNow()`.<br>- Phân biệt rõ sự kiện remote snapshot và thao tác local dirty. |
| **3** | **Lỗi JavaScript TDZ & Treo Modal Cấp Tài khoản (V150)**<br>*Hiện tượng:* Báo lỗi đỏ `ReferenceError: Cannot access 'users' before initialization`; treo modal tạo user. | 1. Trong `adminAssignDailyShipmentLabels()`, lệnh `users.find()` được gọi trước khi biến `const users` được khai báo phía dưới.<br>2. Hàm `listUsers()` gọi `_getManyCompat` bổ sung không có timeout, gây treo vô hạn nếu mạng lag. | - Đảo thứ tự khai báo biến `users` lên trước khi dùng.<br>- Bổ sung trần timeout 18 giây `userDirectoryAwaitWithTimeout`, giải phóng cache nghẽn và báo lỗi rõ ràng.<br>- Kiểm chứng: `tools/user_directory_and_pdf_assignment_tdz_test.js` PASS. |
| **4** | **Đơn ngoài sàn biến mất khi Admin nộp ảnh hoàn tất**<br>*Hiện tượng:* Modal mở được đơn nhưng bấm Hoàn tất thì báo “Không tìm thấy đơn hàng”. | UI-level guard `if (!row)` kiểm tra cache cục bộ `D.packingOrders`. Nếu danh sách cục bộ vừa reload làm mất dòng đơn, tiến trình bị chặn dù backend có dữ liệu. | - Bổ sung `if (!row && !outsideDelegate)`.<br>- Gọi API trực tiếp `adminCompleteAssignedOutsideOrder` đọc thẳng document `/packingOrders/{id}` từ Firestore bằng transaction.<br>- Kiểm chứng: `tools/admin_outside_order_direct_document_recovery_test.js` PASS. |
| **5** | **Lỗi Camera Native trên một số dòng Android**<br>*Hiện tượng:* Báo lỗi “Không thể mở camera”, WebView mất tương tác. | `MainActivity.launchCamera()` bắt exception nhưng hủy ngay `filePathCallback = null` mà không có phương án dự phòng. | Bổ sung fallback Intent `ACTION_GET_CONTENT` mở thư viện ảnh máy khi camera lỗi, giữ nguyên callback WebView. |

---

## 4. NHỮNG NGHIỆP VỤ ĐANG ĐÚNG CẦN BẢO TOÀN

Tất cả các logic nghiệp vụ dưới đây đã được kiểm chứng qua bộ kiểm thử tự động và **tuyệt đối không được thay đổi**:

1. **Phân công đóng hàng (Assignment):**
   - Hỗ trợ quy cách từ **1 đến 100 cây/đơn**; loại bỏ hoàn toàn combo selector gộp cũ; mỗi dòng cây sở hữu số lượng riêng biệt (`item.qty`).
   - Phân công đa sản phẩm trong cùng một đơn (`addAssignmentItem`).
   - Lưu trữ bền vững `catalogId` để không bị lệch cây khi danh mục thay đổi vị trí.
2. **Quy trình đóng hàng & Xác thực ảnh (Packer Flow):**
   - Nhân viên đóng hàng tuyệt đối không tự nhập số lượng cây.
   - Bắt buộc chụp 1 ảnh kiện hàng qua camera; chưa có ảnh thì nút nộp bị khóa (`pack-submit-blocked`); có ảnh thì nút chuyển sang sẵn sàng (`pack-submit-ready`).
   - Firestore Rules bảo vệ: Chỉ cho phép cập nhật trạng thái sang `completed` khi `completionImages.size() == 1`, cấm nhân viên sửa trường tiền công/đơn giá. Admin có quyền ghi nhận hoàn thành trực tiếp không ảnh (`admin_no_photo`).
3. **Đơn ngoài sàn TikTok (Outside Orders):**
   - Admin chụp ảnh hoàn tất thay nhân viên (`openAdminOutsideOrderPhotoCompletion`).
   - Tiền công luôn ghi nhận đúng cho nhân viên được giao ban đầu (`completedBy: expectedUid`), ghi rõ người thao tác là Admin (`completionRecordedBy`).
4. **Bóc tách vận đơn PDF TikTok & Đóng lô an toàn:**
   - Trích xuất bảng theo tọa độ ô (`tableRows`), tự động khớp sản phẩm vào danh mục cây (`tiktok_catalog_matcher`).
   - Nhận diện đơn vị vận chuyển: GHN (`GHVN...`), J&T Express (`862...`), J&T Cargo (`530...`).
   - Tính năng "Kết thúc lô PDF cũ – giữ nguyên dữ liệu" (`legacyPdfBatchCloseCard`): Yêu cầu mật khẩu xác nhận `KET THUC LO PDF CU`, chỉ xóa 3 cờ đánh dấu lô cục bộ để giải phóng đồng bộ, tuyệt đối không xóa đơn hàng, báo cáo hay ảnh trên Cloud.
5. **Quản lý kho & Tồn kho chuẩn Excel:**
   - Bám sát 100% workbook `Tổng_hợp_sd1_đồng_bộ_danh_mục.xlsx`: Tồn cuối = Đang có + Nhập trong ngày − Tổng xuất; Đang có hôm sau = Tồn cuối hôm trước.
   - Tự động chốt sổ tháng (`monthlyStockSnapshots`, `stockBaseDate`) chống tràn bộ nhớ tính toán.
6. **Tiền công, Đơn giá & Lương:**
   - Đơn giá chuẩn theo kích thước từ bảng F:G `Danh_Muc_Cay` (C6: 2k, C7: 2k, C9: 3k, C10: 5k, C11: 7k, C12: 10k).
   - Bảo toàn các quy tắc ngoại lệ: Cẩm tú mai C7 ($\ge 5$ cây $\rightarrow$ 1.600đ), Cẩm tú mai C9 ($\ge 4$ cây $\rightarrow$ 2.500đ), Táo Thái C9 (5.000đ), Kim tiền C9 (4.000đ).
   - Chu kỳ lương 7 ngày; ghi nhận tạm ứng lương (`saveSalaryAdvance`); xuất bảng lương CSV UTF-8 BOM.
7. **Báo giá & Phân tích Lợi nhuận:**
   - Báo giá A4/CSV: Cho phép chọn giá bán, giá nhập hoặc cả hai; chỉ Admin thấy và xuất được giá nhập.
   - Lợi nhuận ngày Admin: $\text{Doanh thu giá sàn} - \text{Giá vốn cây} - \text{Tiền công} - \text{Chi phí vật tư}$.

---

## 5. CÁC SAI LỆCH GIỮA SOURCE ROOT, ZIP VÀ GITHUB ACTIONS

```mermaid
flowchart TD
    subgraph RootBefore["Thư mục Gốc Trước Đồng Bộ (Lệch Pha)"]
        R_Ver["versionCode = 43 (V26.1.1)"]
        R_Html["index.html ngoài root: 403 KB"]
        R_Files["Thiếu 170 files (Code.gs, Scanner, 136 tests...)"]
        R_Stale["Tồn tại 5 file tàn dư cũ (test.js, ROLL141.zip...)"]
    end

    subgraph ZipSource["Tệp ZIP V26.2.151 (Bản Chuẩn CI/CD)"]
        Z_Ver["versionCode = 203 (V26.2.151)"]
        Z_Html["app/src/main/assets/index.html: 1.2 MB"]
        Z_Files["Đầy đủ 189 files chuẩn Android project"]
    end

    subgraph ActionsBuild["GitHub Actions (.github/workflows/build-apk.yml)"]
        G_Action["Luôn tự động xóa root và giải nén ZIP cao nhất ra để build"]
    end

    subgraph RootAfter["Thư mục Gốc Sau Đồng Bộ (Hiện Tại)"]
        A_Sync["Khớp 100% với ZIP V26.2.151\nĐã xóa 5 file tàn dư\n136/136 test PASS"]
    end

    ZipSource -->|Build APK thực tế| ActionsBuild
    RootBefore -.->|Gây nhầm lẫn khi đọc repo| ActionsBuild
    ZipSource -->|Giải nén đồng bộ| RootAfter
```

- **Trước khi đồng bộ:**
  - Thư mục gốc lưu trữ bản cũ V26.1.1 (code 43); thiếu tệp logic chính [app/src/main/assets/index.html](file:///C:/QuanLyCayAPK/app/src/main/assets/index.html) (chỉ có file `index.html` 403KB lạc ở root); thiếu hoàn toàn [Code.gs](file:///C:/QuanLyCayAPK/Code.gs), [ShippingBarcodeScannerActivity.java](file:///C:/QuanLyCayAPK/app/src/main/java/com/quanlycay/apk/ShippingBarcodeScannerActivity.java) và 136 tệp test.
  - Tuy nhiên, GitHub Actions workflow không bị ảnh hưởng vì kịch bản CI/CD luôn xóa sạch root và giải nén từ ZIP `ROLL-CAY-CANH-V26.2.151-AUTO-UPDATE-SOURCE.zip`.
- **Sau khi đồng bộ (Hiện tại):**
  - Thư mục gốc đã được giải nén đồng bộ toàn bộ 189 tệp từ ZIP V26.2.151.
  - Đã xóa sạch 5 tệp tàn dư: `index.html` (root 403KB), `test.js`, `segment.txt`, `tools/prght.py`, và `app/src/main/assets/ROLL141.zip`.
  - Mọi tệp tin trên thư mục gốc hiện tại đã phản ánh trung thực 100% mã nguồn build của GitHub Actions.

---

## 6. THỨ TỰ SỬA LỖI VÀ KẾ HOẠCH KIỂM THỬ THỰC TẾ

```mermaid
flowchart TD
    B1["BƯỚC 1: BẢO VỆ DỮ LIỆU SAO LƯU\n- Xác nhận file JSON đã xuất ngày 24/10\n- Tạo bản sao độc lập ra PC/Drive"] --> B2["BƯỚC 2: CÁC ĐIỀU CẤM TRÊN THIẾT BỊ\n- Không gỡ app, không Clear Storage\n- Không xóa cache, không bấm sync liên tục"]
    B2 --> B3["BƯỚC 3: ĐỒNG BỘ MÃ NGUỒN (ĐÃ XONG)\n- Root khớp ZIP V26.2.151\n- 136/136 test PASS, preflight PASS"]
    B3 --> B4["BƯỚC 4: KÍCH HOẠT BUILD GITHUB ACTIONS\n- Commit/Push lên main khi được duyệt\n- Xác minh SHA-256 chữ ký APK"]
    B4 --> B5["BƯỚC 5: NGHIỆM THU TRÊN ĐIỆN THOẠI ADMIN\n- Cài đè APK V26.2.151\n- Kiểm tra phân công PDF, camera đơn ngoài\n- Đồng bộ Cloud 1 lần xác nhận hết lỗi"]
```

### Chi tiết các bước thực hiện:
1. **Bước 1 — Bảo vệ Dữ liệu Sao lưu (Ưu tiên số 1):**
   - Xác nhận file sao lưu JSON người dùng đã xuất thành công từ bản V26.2.101 trong thư mục `Download/ROLL CAY CANH/`.
   - Sao chép thêm một bản lưu trữ an toàn ra máy tính cá nhân hoặc Google Drive. Tuyệt đối không xóa file này.
2. **Bước 2 — Các Điều Cấm Tuyệt đối trên Thiết bị Thật:**
   - Không gỡ cài đặt ứng dụng; không thực hiện *Clear Data / Clear Storage* trong Cài đặt Android (để tránh mất ảnh offline outbox chưa kịp tải lên Drive).
   - Không xóa thủ công các key `quanlycay` hay `roll_cay_daily_shipment_*`.
3. **Bước 3 — Đồng bộ và Kiểm thử Mã nguồn (Đã Hoàn tất):**
   - Đã giải nén đồng bộ root repo khớp chuẩn V26.2.151.
   - `python tools/preflight.py` đạt **PASS 100%** (323/323 checks).
   - Chạy toàn bộ 136 bài test hồi quy `tools/*_test.js` đạt **136/136 PASS 100%**.
   - Kiểm tra cú pháp JavaScript đạt chuẩn không lỗi.
4. **Bước 4 — Kích hoạt Build APK trên GitHub Actions (Chờ phê duyệt):**
   - Đẩy commit mã nguồn sạch lên nhánh `main`.
   - Workflow tự động chạy test, build Gradle và đóng gói `QuanLyCayAPK-V26.2.151.apk`.
   - Kiểm tra mã băm SHA-256 chứng chỉ ký (`EXPECTED_APK_CERT_SHA256`) đảm bảo tương thích với bản APK đang cài đặt trên điện thoại.
5. **Bước 5 — Nghiệm thu Thực tế trên Thiết bị:**
   - Cài đặt bản cập nhật APK V26.2.151 đè lên ứng dụng hiện tại trên máy Admin.
   - Mở màn hình Phân công đơn PDF: Xác nhận không còn lỗi đỏ TDZ `ReferenceError`.
   - Mở màn hình Chụp ảnh đơn ngoài: Xác nhận camera mở bình thường; nếu camera từ chối thì bộ chọn ảnh thư viện máy tự động xuất hiện.
   - Bấm "Đồng bộ ngay": Xác nhận dữ liệu đẩy lên Firestore thành công, thanh trạng thái chuyển sang xanh và không còn xuất hiện lỗi `FIRESTORE INTERNAL ASSERTION FAILED: Unexpected state`.

---

## 7. NHỮNG NỘI DUNG CHƯA XÁC MINH

Để minh bạch tuyệt đối về phạm vi kiểm toán kỹ thuật:
1. **Chưa biên dịch file APK vật lý tại máy kiểm toán:** Môi trường máy local chưa cài đặt Android SDK 35 (`platforms;android-35`, `build-tools;35.0.0`), Java 17 Temurin và không nắm giữ biến bí mật `DEBUG_KEYSTORE_BASE64`. Việc biên dịch bắt buộc thực hiện an toàn trên GitHub Actions.
2. **Chưa gọi mạng kiểm thử trên Firebase / Firestore Production:** Không gửi bất kỳ request đọc/ghi thử nghiệm nào lên cụm Cloud Firestore thật để bảo vệ 100% dữ liệu đơn hàng, kho và tiền công thực tế của cửa hàng.
3. **Chưa triển khai Web App Google Apps Script (GAS):** Mã nguồn `Code.gs` và adapter `gas-firestore-compat.js` đã sẵn sàng và hợp lệ cú pháp, nhưng cờ hệ thống vẫn khóa cứng `ROLL_GAS_BACKEND_ENABLED = false` theo đúng thiết kế an toàn.
4. **Chưa thử nghiệm thao tác quang học trên thiết bị vật lý:** Các tương tác chạm vuốt màn hình, quét mã vạch bằng camera quang học thực tế cần được kiểm chứng sau khi người dùng cài đặt bản APK V26.2.151.

---

> [!NOTE]
> **KẾT LUẬN & TRẠNG THÁI HIỆN TẠI:**
> File tóm tắt kiểm toán kỹ thuật đã được tạo hoàn chỉnh. Hệ thống đang dừng lại tại đây và **chờ ý kiến phê duyệt / chỉ đạo tiếp theo từ bạn.**
