# ROLL CÂY CẢNH V26.2.152 — sửa độ tin cậy quét nhãn

## Thay đổi

- Ghi claim vận đơn, bản ghi quét, trạng thái đơn và báo cáo/tiền công trong cùng giao dịch Firestore có kiểm tra phân công và nhân viên. Ảnh được lưu bền vững trên Android trước; tải Drive chạy riêng, có thể thử lại và không chặn camera.
- Tách hàng đợi nghiệp vụ khỏi hàng đợi Drive, giới hạn số ảnh chờ, chống quét trùng theo tracking, giữ hàng đợi qua lần mở lại ứng dụng và giới hạn retry tự động.
- Cho phép nhân viên đồng bộ hàng đợi ngoại tuyến bằng đúng tài khoản đã quét và chỉ xử lý entry khớp employee ID/tên. Không đổi công thức tiền công.
- Thêm công cụ Admin đọc đối soát các nhãn đã `recorded` nhưng thiếu claim, scan, báo cáo, nhân viên, số lượng, tiền công hoặc ảnh. Công cụ chỉ đọc Firebase; không có thao tác sửa/xóa production.
- Giữ nguyên schema Firestore và Firestore Rules trong lượt sửa này. Các thay đổi Rules đang có trong working tree là thay đổi đã tồn tại trước lượt sửa; không chỉnh hoặc triển khai Rules.

## Kiểm thử

- 138/138 test JavaScript: đạt.
- 9 inline script trong WebView: `node --check` đạt.
- `tools/preflight.py`: đạt, versionName `26.2.152`, versionCode `204`.
- Regression quét: 2 nhãn liên tiếp; lỗi transaction rồi retry; quét trùng; offline; khôi phục hàng đợi sau khi tạo lại WebView; hai nhân viên; đối soát chỉ đọc; 200 nhãn giả lập bằng transaction mock. Kịch bản 200 nhãn chạy trong khoảng 11 ms trên mock trong bộ test; đây không phải benchmark Firestore thật hoặc thiết bị Android.
- Trước khi điều chỉnh test cũ, full suite có 6 failure. Năm test so chuỗi bị sai do CRLF trên Windows; một test Admin đang mong `ref.update` cũ dù implementation dùng transaction và kiểm tra assignee. Đã sửa assertion/chuẩn hóa newline và chạy lại full suite: 138/138 đạt.
- Không có test nào ghi vào Firebase production.

## Giới hạn phát hành

- Máy hiện tại không có Java, Gradle, Android SDK hoặc `gradlew`, nên chưa thể build/kiểm thử APK trong môi trường này. ZIP source được workflow chọn theo tên/version và là đầu vào build đúng source; APK cần được tạo trên GitHub Actions/runner Android trước khi cài vận hành.
- Cần kiểm thử thêm trên thiết bị Android thật với Firebase/Drive test project (offline, đóng/mở ứng dụng, quyền packer/Admin và tải ảnh) trước khi đưa vào vận hành thực tế.
