# ROLL CÂY CẢNH V26.2.151 — User directory timeout and PDF assignment TDZ fix

## Baseline
- Base: V26.2.150 / versionCode 202.
- Version: V26.2.151 / versionCode 203.
- Android package: `com.quanlycay.apk`.

## Confirmed defects from the supplied screenshots and source audit

### 1. PDF assignment — JavaScript temporal dead zone
`adminAssignDailyShipmentLabels()` validated employee targets using `users.find(...)` before declaring `const users = await listUsers(...)` later in the same function. This causes `ReferenceError: Cannot access 'users' before initialization`, matching the Admin status banner and preventing assignment.

Fix: load the user directory with a bounded wait before validating the selected assignment targets. The function now has one `users` binding in the correct order.

### 2. Employee account creation — user-directory read could hang
`createUser()` waited on `listUsers()` before creating Firebase Auth. The directory read also performs supplemental direct reads for previously verified user profiles. Those `_getManyCompat` / per-profile reads had no timeout, so the modal could remain at “Đang kiểm tra danh sách tài khoản hiện có…”.

Fix:
- Added `userDirectoryAwaitWithTimeout`.
- Bounded GAS verified-UID reads and the overall supplemental-hints stage.
- Account creation now forces a fresh user-directory read with an 18-second ceiling.
- If the directory cannot be fully checked, the app invalidates the stuck in-flight cache and stops before Firebase Auth creation. It gives an explicit error rather than creating a duplicate login or orphan profile.

## Preserved
- Existing 13 user profiles and employee mappings are not changed by this patch.
- No Auth account, Firestore/GAS record, order, payroll, stock, PDF queue, or Drive photo was modified in this source-only work.
- Employee selection, role validation, email duplicate checks, existing Auth reuse, profile write verification, and Drive-folder setup remain in place.
- PDF recognition and assignment transaction rules are unchanged apart from fixing the user-list variable initialization order.

## Validation
- 136/136 JavaScript regression tests PASS.
- 136/136 JavaScript test syntax checks PASS.
- 9/9 inline JS blocks PASS.
- 3/3 external JS files PASS.
- `tools/preflight.py`: PASS.
- ZIP integrity: PASS (verified after packaging).

## Not yet verified
- No Android APK build in this environment.
- No real Firebase Authentication / Firestore / GAS operation was attempted.
- No live user or order data was modified.
