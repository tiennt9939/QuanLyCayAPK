# ROLL CÂY CẢNH V26.2.148 — Admin chụp ảnh đơn ngoài: camera fallback + assignment recovery

## Baseline and release
- Base: V26.2.147 / versionCode 199.
- Version: V26.2.148 / versionCode 200.
- Package: `com.quanlycay.apk`.

## Root causes confirmed in V147 source
1. `MainActivity.launchCamera()` caught camera-launch exceptions, closed `filePathCallback`, and only showed “Không thể mở camera”. There was no gallery fallback, so the Admin outside-order proof flow could not select a photo after camera launch failed.
2. The Admin photo modal kept the selected order only in transient JS lists. `submitAdminCompleteOrder()` looked only in `D.packingOrders` and `adminFullAssignmentRowsCache`; if a refresh removed the row from those caches, it returned “Không tìm thấy đơn hàng” without re-reading the authoritative backend.
3. The existing `adminCompletePackingOrder()` for the outside-order path did not bind the write to the assignee captured when the Admin opened the modal. A reassignment during the photo wait could therefore leave stale UI state.

## Changes
- Camera launch failure now logs the exception and opens Android's image picker (`ACTION_GET_CONTENT`) while retaining the WebView file callback. The Admin can choose a photo from the phone if camera launch is unavailable.
- The outside-order photo modal snapshots order ID + assigned employee UID.
- If the order disappears from local/cache state before submit, the app reloads the authoritative Admin order list and recovers the order by ID.
- Added `adminCompleteAssignedOutsideOrder()`: uploads the photo to Drive, then uses a Firestore transaction to re-read the order and verify type `ĐN`, status, and the exact original `assignedUid` before completion. If the order was reassigned or already completed, the transaction stops without recording completion/payroll again.
- Completion keeps `completedBy` as the assigned employee and `completionRecordedBy` as the Admin. Audit method is `admin_outside_photo`.
- No changes to PDF parser, Firestore schema, plant catalog, payroll formulas, inventory logic, or existing completed records.

## Validation
- 133/133 JavaScript regression tests passed.
- 133/133 JavaScript syntax checks passed.
- `tools/preflight.py`: PASS.
- Gradle build not run in this environment because the source ZIP does not include `gradlew` and no system Gradle executable is installed.
- No live Firebase/Google Drive data was changed or tested.
