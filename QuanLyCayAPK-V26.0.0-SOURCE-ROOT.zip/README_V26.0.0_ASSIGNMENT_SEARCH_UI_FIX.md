# V26.0.0 — Assignment Plant Search UI Fix

- Redesigned Admin → Phân công đơn hàng → Tìm và chọn cây.
- Search now supports partial Vietnamese names without accents and size codes such as C7/C9/C10.
- Results are grouped by plant name instead of showing repeated rows for every size.
- Tapping a result immediately selects the plant; sizes remain in the separate Kích thước selector.
- Enter selects the first search result.
- Added Xóa search button and refresh catalog button.
- Existing stable assignment/catalogId logic is preserved.
- Existing OCR, completion, payroll, printing, and Firestore logic is preserved.
