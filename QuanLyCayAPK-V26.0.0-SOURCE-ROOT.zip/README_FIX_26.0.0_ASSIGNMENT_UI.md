# V26.0.0 – Assignment UI fix

## Fixes
- Removed the redundant visible “Cây đã chọn” selector from the Admin assignment UI.
- Plant search results are now the primary plant selector.
- Clicking a plant result selects it directly by `catalogId` group key; if it has exactly one size, that size is selected automatically.
- Assignment UI no longer depends on array index for plant identity.
- Admin packing-order list prefers the already-authorized `/packingOrders` realtime listener/cache before issuing a second collection query. This avoids transient `Missing or insufficient permissions` failures in the Android WebView and ensures newly-created orders appear immediately.
- Newly created packing orders are inserted into the local/listener cache immediately after Firestore confirms the write.
- Firestore completion rules are canonical `catalogId` only; legacy `plantIndex` completion fallback was removed.
- Static catalog audit and preflight pass.
