#!/usr/bin/env python3
from pathlib import Path
import re, sys

ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/"app/src/main/assets/index.html").read_text(encoding="utf-8")
RULES=(ROOT/"firestore.rules").read_text(encoding="utf-8")

scripts=re.findall(r"<script(?:[^>]*)>(.*?)</script>",HTML,re.S|re.I)
assert scripts, "No script blocks found"

checks=[
    ("catalogId helper", "function catalogIdAt(" in HTML and "function catalogIndexById(" in HTML),
    ("canonical migration", "function migrateCatalogCanonicalData(" in HTML),
    ("catalog merge", "function mergeCatalogCanonical(" in HTML),
    ("packing order catalogId", "catalogId:String(first.catalogId)" in HTML),
    ("assignment payload no plantIndex", "function plainAssignmentItem" in HTML and "plantIndex" not in HTML[HTML.find("function plainAssignmentItem"):HTML.find("function savePlantEdit")]),
    ("daily canonical lookup", "String(x.catalogId||catalogIdFromRecord(x))" in HTML),
    ("rules create catalogId", "request.resource.data.catalogId is string" in RULES),
    ("rules completion keeps catalog identity", "request.resource.data.catalogId == resource.data.catalogId" in RULES),
]
bad=[name for name,ok in checks if not ok]
for name,ok in checks:
    print(("PASS" if ok else "FAIL"), name)
if bad:
    print("FAILED:", ", ".join(bad))
    sys.exit(1)
print("Catalog Canonical V1 static audit: PASS")
