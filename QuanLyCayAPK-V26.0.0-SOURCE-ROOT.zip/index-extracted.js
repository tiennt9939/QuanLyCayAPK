
// V20.5: Login gate helpers. Giữ màn hình đăng nhập độc lập với giao diện bên trong app.
function showLoginGate(){
  const gate=document.getElementById('loginGate');
  if(gate) gate.classList.remove('hidden');
  const email=document.getElementById('gateEmail');
  const remembered=localStorage.getItem('ROLL_CAY_REMEMBER_EMAIL')||'';
  if(email && !email.value && remembered) email.value=remembered;
  setTimeout(()=>{ if(email && !email.value) email.focus(); },80);
}
function hideLoginGate(){
  const gate=document.getElementById('loginGate');
  if(gate) gate.classList.add('hidden');
  const pass=document.getElementById('gatePass');
  if(pass) pass.value='';
}
function showLoginGateError(msg){
  const el=document.getElementById('gateError');
  if(el) el.textContent=msg||'';
}
function clearLoginGateError(){showLoginGateError('')}
function toggleGatePassword(){
  const el=document.getElementById('gatePass');
  if(!el)return;
  el.type=el.type==='password'?'text':'password';
}
async function gateLogin(){
  const email=(document.getElementById('gateEmail')?.value||'').trim();
  const password=document.getElementById('gatePass')?.value||'';
  const remember=!!document.getElementById('gateRemember')?.checked;
  const btn=document.querySelector('#loginGate .login-btn');
  if(!email||!password){showLoginGateError('Vui lòng nhập tên đăng nhập và mật khẩu');return false}
  clearLoginGateError();
  if(btn){btn.disabled=true;btn.textContent='ĐANG ĐĂNG NHẬP…'}
  try{
    if(typeof CloudSync==='undefined') throw new Error('Cloud chưa khởi tạo');
    const ok=await CloudSync.signIn(email,password,remember);
    if(!ok)return false;
    // onAuthStateChanged sẽ kiểm tra hồ sơ/quyền rồi tự đóng màn hình.
    return true;
  }catch(e){
    showLoginGateError(typeof firebaseError==='function'?firebaseError(e):(e?.message||'Không thể đăng nhập'));
    return false;
  }finally{
    if(btn){btn.disabled=false;btn.textContent='ĐĂNG NHẬP'}
  }
}
function cloudLogin(){showLoginGate()}
document.addEventListener('DOMContentLoaded',()=>{
  ['gateEmail','gatePass'].forEach(id=>{
    const el=document.getElementById(id);
    if(el)el.addEventListener('keydown',e=>{if(e.key==='Enter')gateLogin()});
  });
});





// V23.1: Firebase SDK loader chịu lỗi mạng/WebView. Nếu CDN chính tạm thời không tải,
// thử CDN dự phòng; không khóa initPromise vĩnh viễn và không báo sai là "Firebase chưa cấu hình".
let __firebaseSdkPromise=null;
function __loadScript(src){return new Promise((resolve,reject)=>{
  const existing=document.querySelector('script[data-firebase-sdk="'+src+'"]');
  if(existing){existing.addEventListener('load',resolve,{once:true});existing.addEventListener('error',()=>reject(new Error('Không tải được '+src)),{once:true});return}
  const s=document.createElement('script');s.src=src;s.async=false;s.dataset.firebaseSdk=src;
  s.onload=()=>resolve();s.onerror=()=>reject(new Error('Không tải được Firebase SDK: '+src));
  document.head.appendChild(s);
})}
async function ensureFirebaseSdk(){
  if(window.firebase?.auth && window.firebase?.firestore)return true;
  if(__firebaseSdkPromise)return __firebaseSdkPromise;
  __firebaseSdkPromise=(async()=>{
    const hosts=[
      'https://www.gstatic.com/firebasejs/10.14.1/',
      'https://cdn.jsdelivr.net/npm/firebase@10.14.1/',
      'https://cdnjs.cloudflare.com/ajax/libs/firebase/10.14.1/'
    ];
    const files=[
      ['firebase-app-compat.js','firebase-app'],
      ['firebase-auth-compat.js','firebase-auth'],
      ['firebase-firestore-compat.js','firebase-firestore']
    ];
    let last=null;
    for(const base of hosts){
      try{
        if(!window.firebase)await __loadScript(base+files[0][0]);
        if(!window.firebase?.auth)await __loadScript(base+files[1][0]);
        if(!window.firebase?.firestore)await __loadScript(base+files[2][0]);
        if(window.firebase?.auth && window.firebase?.firestore)return true;
      }catch(e){last=e;console.warn('Firebase CDN fallback:',base,e)}
    }
    throw last||new Error('Không tải được Firebase SDK');
  })();
  try{return await __firebaseSdkPromise}
  finally{__firebaseSdkPromise=null}
}



// Fallback để WebView vẫn có cấu hình Firebase nếu file config bị lỗi/không tải được.
if (!window.ROLL_CAY_FIREBASE_CONFIG || !window.ROLL_CAY_FIREBASE_CONFIG.apiKey) {
  window.ROLL_CAY_FIREBASE_CONFIG = {
    apiKey: "AIzaSyB6qZX3FZAnWX0wagxSBbnr-TG7ZK3ASTU",
    authDomain: "roll-cay-canh.firebaseapp.com",
    projectId: "roll-cay-canh",
    storageBucket: "roll-cay-canh.firebasestorage.app",
    messagingSenderId: "311724804563",
    appId: "1:311724804563:web:ae8331367750f508860726",
    measurementId: "G-BZ90BLW5EV"
  };
}



const DEFAULT_DATA = 
{"employees":["Luân lớn","Luân nhỏ","Huy","Mi","Hưng","Bé Hai"],"rates":[{"size":"C6","rate":2000.0},{"size":"C7","rate":2000.0},{"size":"C9","rate":3000.0},{"size":"C10","rate":5000.0},{"size":"C11","rate":7000.0},{"size":"C12","rate":10000.0}],"catalog":[{"stt":1,"name":"Vàng bạc","size":"C7","price":10000.0},{"stt":2,"name":"Vàng bạc","size":"C9","price":15000.0},{"stt":3,"name":"Vàng bạc","size":"C10","price":30000.0},{"stt":4,"name":"Vàng bạc","size":"C12","price":120000.0},{"stt":5,"name":"Nguyệt quế thái","size":"C7","price":10000.0},{"stt":6,"name":"Nguyệt quế thái","size":"C9","price":25000.0},{"stt":7,"name":"Nguyệt quế thái","size":"C10","price":70000.0},{"stt":8,"name":"Cẩm tú mai","size":"C7","price":0.0},{"stt":9,"name":"Cẩm tú mai","size":"C9","price":0.0},{"stt":10,"name":"Cẩm tú mai","size":"C10","price":0.0},{"stt":11,"name":"Cẩm tú mai","size":"C11","price":0.0},{"stt":12,"name":"Trầu bà thanh xuân","size":"C9","price":45000.0},{"stt":13,"name":"Trầu bà thanh xuân","size":"C10","price":60000.0},{"stt":14,"name":"Trầu bà thanh xuân","size":"C11","price":90000.0},{"stt":15,"name":"Trầu bà thanh xuân","size":"C13","price":180000.0},{"stt":16,"name":"Mai vạn phúc C9","size":"C9","price":16000.0},{"stt":17,"name":"Mai vạn phúc C10","size":"C10","price":28000.0},{"stt":18,"name":"Mai vạn phúc C11","size":"C11","price":45000.0},{"stt":19,"name":"Mai vạn phúc C16","size":"C16","price":160000.0},{"stt":20,"name":"Ngọc ngân","size":"C7","price":10000.0},{"stt":21,"name":"Ngọc ngân","size":"C9","price":0.0},{"stt":22,"name":"Phú quý c7","size":"C7","price":35000.0},{"stt":23,"name":"Phú quý c9","size":"C9","price":35000.0},{"stt":24,"name":"Táo thái","size":"","price":0.0},{"stt":25,"name":"Táo thái","size":"","price":0.0},{"stt":26,"name":"Hàm hương","size":"C7","price":40000.0},{"stt":27,"name":"Hàm hương","size":"C9","price":55000.0},{"stt":28,"name":"Bụp thấp nhiều màu","size":"C9","price":15000.0},{"stt":29,"name":"Lài Tây","size":"C9","price":13000.0},{"stt":30,"name":"Lài Tây","size":"C11","price":45000.0},{"stt":31,"name":"Dừa cạn nhiều màu","size":"","price":19000.0},{"stt":32,"name":"Phong lá đỏ C7","size":"C7","price":23000.0},{"stt":33,"name":"Trang thái (đỏ, vàng, hồng) C9","size":"C9","price":30000.0},{"stt":34,"name":"Trang thái (đỏ, vàng, hồng) C10","size":"C10","price":90000.0},{"stt":35,"name":"Trang thái (đỏ, vàng, hồng) T25","size":"T25","price":180000.0},{"stt":36,"name":"Trang thái (đỏ, vàng, hồng) T28","size":"T28","price":250000.0},{"stt":37,"name":"Trang thái (đỏ, vàng, hồng) tàng 1m","size":"tàng 1m","price":350000.0},{"stt":38,"name":"Hồng phụng C9","size":"C9","price":40000.0},{"stt":39,"name":"Hồng phụng C11","size":"C11","price":90000.0},{"stt":40,"name":"Hồng siêu nụ C9","size":"C9","price":45000.0},{"stt":41,"name":"Hồng siêu nụ C11","size":"C11","price":75000.0},{"stt":42,"name":"Sơn liễu C9","size":"C9","price":25000.0},{"stt":43,"name":"Sơn liễu C7","size":"C7","price":13000.0},{"stt":44,"name":"Trầu bà sữa C9","size":"C9","price":25000.0},{"stt":45,"name":"Trang mỹ hồng (hồng + đỏ + vàng) C9","size":"C9","price":30000.0},{"stt":46,"name":"Thiên lý C9","size":"C9","price":21000.0},{"stt":47,"name":"Cau Đài Loan C10","size":"C10","price":210000.0},{"stt":48,"name":"Chuối rẽ quạt C11","size":"C11","price":145000.0},{"stt":49,"name":"Cây không khí 1 bó","size":"1 bó","price":52000.0},{"stt":50,"name":"Vạn lộc C7","size":"C7","price":25000.0},{"stt":51,"name":"Vạn lộc C9","size":"C9","price":35000.0},{"stt":52,"name":"Nghệ tây C10","size":"C10","price":53000.0},{"stt":53,"name":"Bướm (hồng + trắng) C9","size":"C9","price":45000.0},{"stt":54,"name":"Địa lan tím C8","size":"C8","price":18000.0},{"stt":55,"name":"Chuối cẩm thạch C9","size":"C9","price":40000.0},{"stt":56,"name":"Chuối cẩm thạch C11","size":"C11","price":75000.0},{"stt":57,"name":"Tùng bồng lai tiên cảnh chậu gốm","size":"chậu gốm","price":120000.0},{"stt":58,"name":"Trúc quân tử (3 cây)","size":"3 cây","price":25000.0},{"stt":59,"name":"Kim Tiền","size":"C9","price":35000.0},{"stt":60,"name":"Kim Tiền","size":"C10","price":50000.0},{"stt":61,"name":"Kim Tiền","size":"C12","price":95000.0},{"stt":62,"name":"Thanh xà","size":"C9","price":25000.0},{"stt":63,"name":"Thanh xà","size":"C10","price":45000.0},{"stt":64,"name":"Hồng phát tài","size":"C7","price":20000.0},{"stt":65,"name":"Hồng phát tài","size":"C9","price":43000.0},{"stt":66,"name":"Lan chi","size":"C9","price":25000.0},{"stt":67,"name":"Polly","size":"C9","price":45000.0},{"stt":68,"name":"Lindini","size":"C7","price":60000.0},{"stt":69,"name":"Hạc cam","size":"C9","price":90000.0},{"stt":70,"name":"Hạc cam","size":"C10","price":110000.0},{"stt":71,"name":"Trầu bà lỗ","size":"C7","price":15000.0},{"stt":72,"name":"Như ý","size":"C7","price":15000.0},{"stt":73,"name":"Sơn liễu","size":"C7","price":15000.0},{"stt":74,"name":"Sơn liễu","size":"C9","price":25000.0},{"stt":75,"name":"Gia huy","size":"C9","price":15000.0},{"stt":76,"name":"Lá màu","size":"C9","price":15000.0},{"stt":77,"name":"Liễu 2 da cẩm thạch","size":"C9","price":23000.0},{"stt":78,"name":"Lan quân tử","size":"C9","price":45000.0},{"stt":79,"name":"Quỳnh hương đỏ vàng","size":"C9","price":23000.0},{"stt":80,"name":"Đuôi công xanh + tím + hồng","size":"C9","price":38000.0},{"stt":81,"name":"Phát tài lá đỏ","size":"C9","price":30000.0},{"stt":82,"name":"Phát tài mỹ","size":"C9","price":30000.0},{"stt":83,"name":"Thiết mộc lan","size":"C9","price":40000.0},{"stt":84,"name":"Thiết mộc lan","size":"C11","price":140000.0},{"stt":85,"name":"Cây trường sinh","size":"C7","price":15000.0},{"stt":86,"name":"Cây trường sinh","size":"C9","price":35000.0},{"stt":87,"name":"Thiên tuế","size":"C9","price":75000.0},{"stt":88,"name":"Thiên tuế","size":"C11","price":230000.0},{"stt":89,"name":"Thiên tuế","size":"C13","price":450000.0},{"stt":90,"name":"Đại phú","size":"C10","price":55000.0},{"stt":91,"name":"Đại phú","size":"C11","price":130000.0},{"stt":92,"name":"Bàng sing","size":"C9","price":55000.0},{"stt":93,"name":"Bàng sing","size":"C11","price":160000.0},{"stt":94,"name":"Tùng đuôi chồn","size":"C9","price":35000.0},{"stt":95,"name":"Tùng đuôi chồn","size":"C10","price":75000.0},{"stt":96,"name":"Tiểu trâm","size":"C9","price":15000.0},{"stt":97,"name":"Tiểu trâm","size":"C11","price":65000.0},{"stt":98,"name":"Hàm hương","size":"C7","price":40000.0},{"stt":99,"name":"Hàm hương","size":"C9","price":55000.0}],"daily":[{"date":"2026-09-01","plantIndex":0,"in":0.0,"counts":{"Luân lớn":80.0,"Luân nhỏ":50.0,"Huy":70.0}}],"opening":{"0":500.0,"1":0.0,"2":0.0,"3":0.0,"4":0.0,"5":0.0,"6":0.0,"7":0.0,"8":0.0,"9":0.0,"10":0.0,"11":0.0,"12":0.0,"13":0.0,"14":0.0,"15":0.0,"16":0.0,"17":0.0,"18":0.0,"19":0.0,"20":0.0,"21":0.0,"22":0.0,"23":0.0,"24":0.0,"25":0.0,"26":0.0,"27":0.0,"28":0.0,"29":0.0,"30":0.0,"31":0.0,"32":0.0,"33":0.0,"34":0.0,"35":0.0,"36":0.0,"37":0.0,"38":0.0,"39":0.0,"40":0.0,"41":0.0,"42":0.0,"43":0.0,"44":0.0,"45":0.0,"46":0.0,"47":0.0,"48":0.0,"49":0.0,"50":0.0,"51":0.0,"52":0.0,"53":0.0,"54":0.0,"55":0.0,"56":0.0,"57":0.0,"58":0.0,"59":0.0,"60":0.0,"61":0.0,"62":0.0,"63":0.0,"64":0.0,"65":0.0,"66":0.0,"67":0.0,"68":0.0,"69":0.0,"70":0.0,"71":0.0,"72":0.0,"73":0.0,"74":0.0,"75":0.0,"76":0.0,"77":0.0,"78":0.0,"79":0.0,"80":0.0,"81":0.0,"82":0.0,"83":0.0,"84":0.0,"85":0.0,"86":0.0,"87":0.0,"88":0.0,"89":0.0,"90":0.0,"91":0.0,"92":0.0,"93":0.0,"94":0.0,"95":0.0,"96":0.0,"97":0.0,"98":0.0},"periodStart":"2026-09-01","periodEnd":"2027-12-31","appVersion":"9.0.0"};
const START='2026-09-01',END='2027-12-31';
let D,entryMode='pack',stockFilter='all',selected={plantName:'',sizeIndex:null,empIndex:0,inPlantName:'',inSizeIndex:null},pickerMode='',pendingPlantImage=null,pendingPackPhoto='',pendingPackPhotos=[],packerEditingId=null,selectedOrderId=null;
let orderNotificationState={pending:0,completed:0,ready:false,role:'',uid:'',rows:[],authReady:false,source:'none'};
let orderAlertAudioCtx=null;
const $=id=>document.getElementById(id);const money=n=>new Intl.NumberFormat('vi-VN').format(Math.round(Number(n)||0))+' đ';const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const parts=s=>String(s).split('-').map(Number);const dateObj=s=>{let [y,m,d]=parts(s);return new Date(y,m-1,d)};const fmt=d=>{let y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');return `${y}-${m}-${day}`};const addDays=(s,n)=>{let d=dateObj(s);d.setDate(d.getDate()+n);return fmt(d)};const daysBetween=(a,b)=>Math.round((dateObj(b)-dateObj(a))/86400000);const fmtDMY=s=>{let [y,m,d]=parts(s);return `${d}/${m}/${y}`};
function toast(t){const e=$('toast');e.textContent=t;e.style.display='block';clearTimeout(window._tt);window._tt=setTimeout(()=>e.style.display='none',1900)}
function localSaveOnly(){localStorage.setItem('quanlycay',JSON.stringify(D));localStorage.setItem('quanlycay_local_updated',String(Date.now()))}
function save(){localSaveOnly();localStorage.setItem('quanlycay_dirty','1');try{if(window.CloudSync&&typeof window.CloudSync.schedulePush==='function')window.CloudSync.schedulePush()}catch(e){console.warn('schedulePush',e)}}
function repairCanonicalConfig(){
  const def=DEFAULT_DATA;
  if(!Array.isArray(D.catalog)||D.catalog.length===0)D.catalog=structuredClone(def.catalog);
  if(!Array.isArray(D.rates)||D.rates.length===0)D.rates=structuredClone(def.rates);
  if(!Array.isArray(D.employees)||D.employees.length===0)D.employees=structuredClone(def.employees);
  if(!D.opening||typeof D.opening!=='object')D.opening=structuredClone(def.opening||{});
  if(!Array.isArray(D.daily))D.daily=[];
  if(!Array.isArray(D.packerRecords))D.packerRecords=[];
  if(!Array.isArray(D.salaryAdvances))D.salaryAdvances=[];
  if(!Array.isArray(D.shipments))D.shipments=[];
  D.salaryAdvances=D.salaryAdvances.filter(a=>a&&String(a.employee||'').trim()&&/^\d{4}-\d{2}-\d{2}$/.test(String(a.date||''))&&Number(a.amount)>0).map(a=>({...a,employee:canonicalEmployeeName(a.employee),amount:Math.round(Number(a.amount)||0)}));
  ensureCatalogIds();migrateCatalogCanonicalData();
  D.daily.forEach(x=>{if(!x.counts)x.counts={};if(!Array.isArray(x.adjustments))x.adjustments=[]});
}

function load(){try{const x=JSON.parse(localStorage.getItem('quanlycay')||'null');D=x||structuredClone(DEFAULT_DATA)}catch(e){D=structuredClone(DEFAULT_DATA)}repairCanonicalConfig()}
function activeCatalog(){ensureCatalogIds();return D.catalog.map((p,i)=>({p,i,catalogId:String(p?.catalogId||'').trim()})).filter(o=>!o.p.deleted&&o.catalogId)}
function employees(){return D.employees||[]}
function rate(size){const r=(D.rates||[]).find(x=>String(x.size).trim().toLowerCase()===String(size??'').trim().toLowerCase());return r?Number(r.rate)||0:0}
function packerPay(r){return orderTotalPay(r)}
function canonicalEmployeeName(name){const raw=String(name||'').trim();if(!raw)return 'Nhân viên';const hit=employees().find(e=>String(e||'').trim().toLowerCase()===raw.toLowerCase());return hit||raw}
function completedOrderDate(r){const explicit=String(r?.completedDate||'').trim();if(/^\d{4}-\d{2}-\d{2}$/.test(explicit))return explicit;const ms=Number(r?.completedAtMs||0);if(ms)return fmt(new Date(ms));const orderDate=String(r?.date||r?.createdAtDate||'').trim();return /^\d{4}-\d{2}-\d{2}$/.test(orderDate)?orderDate:''}
function orderItems(r){
  const arr=Array.isArray(r?.items)?r.items.filter(Boolean):[];
  if(arr.length)return arr.map((x,i)=>{const catalogId=catalogIdFromRecord(x),p=catalogById(catalogId);return {catalogId,plantName:String(x.plantName||p?.name||''),size:String(x.size||p?.size||''),qty:Math.max(0,Number(x.qty)||0),itemIndex:i}}).filter(x=>x.catalogId&&x.qty>0);
  const catalogId=catalogIdFromRecord(r),p=catalogById(catalogId),qty=Math.max(0,Number(r?.qty??r?.packSize)||0);
  if(!catalogId||!p||qty<=0)return [];
  return [{catalogId,plantName:String(r?.plantName||p.name||''),size:String(r?.size||p.size||''),qty,itemIndex:0}];
}
function orderTotalQty(r){return orderItems(r).reduce((s,x)=>s+x.qty,0)}
function orderItemPay(r){return orderItems(r).reduce((s,x)=>s+x.qty*rate(x.size),0)}
function orderTotalPay(r){const base=orderItemPay(r),adj=Number(r?.payAdjustment||0),snap=Number(r?.payAmount);if(Number.isFinite(snap)&&snap>=0&&r?.completedAtMs){const storedBase=snap-adj;if(Number.isFinite(storedBase)&&storedBase>=0)return storedBase+adj;return snap+adj}return base+adj}
function completedOrderItemRecords(){const out=[];completedOrderRecords().forEach(r=>orderItems(r).forEach(it=>out.push({...r,...it,orderId:String(r.id||''),qty:Number(it.qty)||0,plantName:it.plantName||r.plantName||'',size:it.size||r.size||'',payAmount:(Number(it.qty)||0)*rate(it.size),orderPayAmount:orderTotalPay(r)})));return out}
function resolveOrderCatalogId(r){
  const direct=String(r?.catalogId??'').trim();if(direct&&catalogIndexById(direct)>=0)return direct;
  const first=(Array.isArray(r?.items)?r.items:[]).find(x=>{const id=String(x?.catalogId||'').trim();return id&&catalogIndexById(id)>=0});if(first)return String(first.catalogId).trim();
  return '';
}
function completedOrderRecords(){
  const map=new Map();
  const addRows=rows=>{(Array.isArray(rows)?rows:[]).filter(r=>r&&String(r.status||'').toLowerCase()==='completed').forEach(r=>{const id=String(r.id||'');if(id)map.set(id,{...(map.get(id)||{}),...r})})};
  addRows(D?.packerRecords);addRows(D?.packingOrders);addRows(orderNotificationState?.rows);
  return [...map.values()].map(r=>({...r,qty:orderTotalQty(r),catalogId:resolveOrderCatalogId(r),date:completedOrderDate(r),payAmount:Number.isFinite(Number(r.payAmount))?Number(r.payAmount):undefined,employee:canonicalEmployeeName(r.employee||r.employeeName||currentPackerName()),image:r.completionImage||r.image||''})).filter(r=>r.catalogId);
}
function rowsByName(name){const key=normalizeAssignSearch(name);return activeCatalog().filter(o=>normalizeAssignSearch(o.p.name||'')===key)}
function plantNames(){return [...new Set(activeCatalog().map(o=>String(o.p.name||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'vi'))}
function rec(date,plantRef,create=false){
  const catalogId=String(plantRef??'').trim();if(!catalogId||catalogIndexById(catalogId)<0)return null;
  let x=D.daily.find(x=>x.date===date&&String(x.catalogId||'')===catalogId);
  if(!x&&create){x={date,catalogId,in:0,counts:{}};D.daily.push(x)}return x;
}
function outOf(x){return Object.values(x?.counts||{}).reduce((a,b)=>a+(Number(b)||0),0)}
function adjustmentsOf(x,e){return (x?.adjustments||[]).filter(a=>a&&a.employee===e).reduce((s,a)=>s+(Number(a.amount)||0),0)}
function employeePay(x,e){const id=catalogIdFromRecord(x);const p=id?catalogById(id):null;if(!p)return adjustmentsOf(x,e);return (Number(x?.counts?.[e])||0)*rate(p.size)+adjustmentsOf(x,e)}
function imageSrc(p){return p?.image||'logo.png'}
function payOf(x){return employees().reduce((s,e)=>s+employeePay(x,e),0)}
function completedPackerQty(plantRef,date,strictBefore=false){
  const target=String(plantRef??'').trim();if(!target||catalogIndexById(target)<0)return 0;
  return completedOrderItemRecords().filter(r=>String(r.catalogId||'')===target&&/^\d{4}-\d{2}-\d{2}$/.test(String(r.date||''))&&(strictBefore?String(r.date)<String(date):String(r.date)<=String(date))).reduce((s,r)=>s+(Number(r.qty)||0),0);
}
function completedPackerQtyForDate(plantRef,date){const target=String(plantRef??'').trim(),d=String(date||'');if(!target||catalogIndexById(target)<0)return 0;return completedOrderItemRecords().filter(r=>String(r.catalogId||'')===target&&String(r.date||'')===d).reduce((s,r)=>s+(Number(r.qty)||0),0)}
function opening(plantRef,date){const catalogId=String(plantRef??'').trim();if(!catalogId||catalogIndexById(catalogId)<0)return 0;let v=Number(D.opening?.[catalogId]||0);for(const x of D.daily){if(x.date<date&&String(x.catalogId||catalogIdFromRecord(x))===catalogId)v+=(Number(x.in)||0)-outOf(x)}v-=completedPackerQty(catalogId,date,true);return v}
function closing(plantRef,date){const catalogId=String(plantRef??'').trim();if(!catalogId||catalogIndexById(catalogId)<0)return 0;const x=rec(date,catalogId);return opening(catalogId,date)+(Number(x?.in)||0)-outOf(x)-completedPackerQty(catalogId,date,false)+completedPackerQty(catalogId,date,true)}
function totalStock(date){return activeCatalog().reduce((s,o)=>s+Math.max(0,closing(o.catalogId,date)),0)}
function totalPay(a,b){return D.daily.filter(x=>x.date>=a&&x.date<=b).reduce((s,x)=>s+payOf(x),0)}
function dayEntries(date){return D.daily.filter(x=>x.date===date&&((Number(x.in)||0)>0||outOf(x)>0)).sort((a,b)=>catalogIndexById(catalogIdFromRecord(a))-catalogIndexById(catalogIdFromRecord(b)))}
function go(tab,mode){document.querySelectorAll('.bottomnav button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.id===tab));if(tab==='day'){if(mode)setEntryMode(mode);renderDay()}if(tab==='stock'){if(!$('stockDate').value)$('stockDate').value=$('dDate').value||START;renderStock()}if(tab==='summary'){renderReport();initShipmentTracking();}if(tab==='payroll')renderPayroll();if(tab==='quote')renderQuote();if(tab==='control')renderControls();window.scrollTo(0,0)}
function shiftDay(n){const input=$('dDate');let d=dateObj(input.value||START);d.setDate(d.getDate()+n);let s=fmt(d);if(s<START)s=START;if(s>END)s=END;input.value=s;renderDay()}
function init(){
 toggleCustomerFields();
 const today=fmt(new Date());const start=today>=START&&today<=END?today:START;$('dDate').value=start;$('stockDate').value=start;$('rFrom').value=start;$('rTo').value=start;$('homeDateBadge').textContent=fmtDMY(start);syncReportDateLimits();renderAll();
}
function renderAll(){const d=$('dDate').value||START;$('sPlants').textContent=activeCatalog().length;$('sEmp').textContent=employees().length;$('sStock').textContent=Math.round(totalStock(d));$('homeDateBadge').textContent=fmtDMY(d);updateOrderNotificationUI(orderNotificationState.pending,orderNotificationState.completed);if($('stockDate')){$('stockDate').value=$('stockDate').value||d;$('stockDateBadge').textContent=fmtDMY($('stockDate').value||d)}renderCycles();renderDay();renderStock();renderReport();initShipmentTracking();renderControls();renderQuote()}
function syncPackSelection(){
  const plantName=String(selected.plantName||'').trim();
  const rows=plantName?rowsByName(plantName):[];
  if(selected.sizeIndex!=null&&!rows.some(o=>Number(o.i)===Number(selected.sizeIndex))) selected.sizeIndex=null;
  const p=selected.sizeIndex!=null?D.catalog[Number(selected.sizeIndex)]:null;
  const emp=employees()[Number(selected.empIndex)];
  if($('plantValue'))$('plantValue').textContent=plantName||'Chọn cây';
  if($('sizeValue'))$('sizeValue').textContent=p?(p.size||'Không ghi kích thước'):'Chọn kích thước';
  if($('empValue'))$('empValue').textContent=emp||'Chọn nhân viên';
  const qty=Math.max(0,Math.floor(Number($('eQty')?.value)||0));
  const combo=Math.max(1,Number($('adminPackCombo')?.value)||1);
  const valid=!!p&&!!emp&&qty>0;
  if($('entryInfo')){
    $('entryInfo').innerHTML=valid
      ? `👤 ${esc(emp)} · ${Math.round(qty)} cây × ${money(rate(p.size))}/cây = <b>${money(qty*rate(p.size))}</b>${combo>1?` · Quy cách ${combo} cây/combo`:''}`
      : 'Chọn cây, kích thước và nhân viên để xem tiền công.';
  }
  if($('sizeSelector'))$('sizeSelector').disabled=!rows.length;
  if($('adminPackSubmitBtn'))$('adminPackSubmitBtn').disabled=!(valid&&!!pendingAdminPackPhoto&&!isPacker());
}
function syncInSelection(){
  const plantName=String(selected.inPlantName||'').trim();
  const rows=plantName?rowsByName(plantName):[];
  if(selected.inSizeIndex!=null&&!rows.some(o=>Number(o.i)===Number(selected.inSizeIndex))) selected.inSizeIndex=null;
  const p=selected.inSizeIndex!=null?D.catalog[Number(selected.inSizeIndex)]:null;
  if($('inPlantValue'))$('inPlantValue').textContent=plantName||'Chọn cây';
  if($('inSizeValue'))$('inSizeValue').textContent=p?(p.size||'Không ghi kích thước'):'Chọn kích thước';
  if($('inSizeSelector'))$('inSizeSelector').disabled=!rows.length;
  const qty=Math.max(0,Math.floor(Number($('inQty')?.value)||0));
  if($('inInfo')){
    if(p){
      const date=$('dDate')?.value||START;
      const current=Math.max(0,closing(Number(selected.inSizeIndex),date));
      $('inInfo').innerHTML=`📦 ${esc(p.name)} · ${esc(p.size||'Không ghi kích thước')} · Tồn hiện tại: <b>${Math.round(current)}</b>${qty>0?` · Sau khi nhập ${Math.round(qty)} cây: <b>${Math.round(current+qty)}</b>`:''}`;
    }else $('inInfo').textContent='Chọn cây và kích thước để xem tồn kho.';
  }
}
function openPicker(mode){
  if((mode==='size'||mode==='inSize') && !(mode==='size'?String(selected.plantName||'').trim():String(selected.inPlantName||'').trim())){toast('Hãy chọn cây trước');return}
  pickerMode=mode;
  const titles={plant:'Chọn cây',size:'Chọn kích thước',emp:'Chọn nhân viên',inPlant:'Chọn cây nhập kho',inSize:'Chọn kích thước nhập kho'};
  if($('pickerTitle'))$('pickerTitle').textContent=titles[mode]||'Chọn';
  if($('pickerSearch'))$('pickerSearch').value='';
  $('picker')?.classList.add('show');
  renderPicker();
  setTimeout(()=>$('pickerSearch')?.focus(),60);
}
function closePicker(){ $('picker')?.classList.remove('show'); pickerMode=''; }
function renderPicker(){
  const box=$('optionList');if(!box)return;
  const q=String($('pickerSearch')?.value||'').trim().toLowerCase();
  let opts=[];
  if(pickerMode==='plant'||pickerMode==='inPlant'){
    opts=plantNames().map(name=>({value:name,label:name}));
  }else if(pickerMode==='size'||pickerMode==='inSize'){
    const name=pickerMode==='size'?selected.plantName:selected.inPlantName;
    opts=rowsByName(name).map(o=>({value:o.i,label:o.p.size||'Không ghi kích thước',sub:o.p.name||''}));
  }else if(pickerMode==='emp'){
    opts=employees().map((e,i)=>({value:i,label:e}));
  }
  opts=opts.filter(o=>!q||`${o.label} ${o.sub||''}`.toLowerCase().includes(q));
  if(!opts.length){box.innerHTML='<div class="empty">Không tìm thấy lựa chọn phù hợp.</div>';return}
  box.innerHTML=opts.map((o,idx)=>`<button type="button" class="option" data-picker-index="${idx}"><div><b>${esc(o.label)}</b>${o.sub?`<div class="tiny muted">${esc(o.sub)}</div>`:''}</div></button>`).join('');
  box.querySelectorAll("[data-picker-index]").forEach(btn=>btn.addEventListener("click",()=>choosePickerOption(opts[Number(btn.dataset.pickerIndex)]?.value)));
}
function choosePickerOption(value){
  // Chọn từ danh sách phải luôn cập nhật trạng thái trước khi đóng cửa sổ.
  // Kiểm tra giá trị để tránh trường hợp danh sách có nhưng lựa chọn không được ghi nhận.
  try{
    if(pickerMode==='plant'){
      const name=String(value||'').trim();
      if(!name||!plantNames().includes(name)){toast('Không tìm thấy loại cây này');return}
      selected.plantName=name;selected.sizeIndex=null;syncPackSelection();
    }else if(pickerMode==='size'){
      const i=Number(value),ok=Number.isInteger(i)&&rowsByName(selected.plantName).some(o=>o.i===i);
      if(!ok){toast('Kích thước không hợp lệ');return}
      selected.sizeIndex=i;syncPackSelection();
    }else if(pickerMode==='emp'){
      const i=Number(value),ok=Number.isInteger(i)&&!!employees()[i];
      if(!ok){toast('Nhân viên không hợp lệ');return}
      selected.empIndex=i;syncPackSelection();
    }else if(pickerMode==='inPlant'){
      const name=String(value||'').trim();
      if(!name||!plantNames().includes(name)){toast('Không tìm thấy loại cây này');return}
      selected.inPlantName=name;selected.inSizeIndex=null;syncInSelection();
    }else if(pickerMode==='inSize'){
      const i=Number(value),ok=Number.isInteger(i)&&rowsByName(selected.inPlantName).some(o=>o.i===i);
      if(!ok){toast('Kích thước không hợp lệ');return}
      selected.inSizeIndex=i;syncInSelection();
    }
    closePicker();
  }catch(e){console.error('choosePickerOption',e);toast('Không thể chọn mục này');}
}
function updatePackInfo(){syncPackSelection()}
function updateInInfo(){syncInSelection()}
function currentPackerName(){
  const s=CloudSync?.state?.();
  return String(s?.profile?.employeeName||s?.profile?.displayName||s?.user?.email||'Nhân viên');
}
function rebuildPackerDaily(){
  // Đơn phân công hoàn thành được lưu riêng trong packingOrders/packerRecords.
  // Không chép chúng vào D.daily để tránh cộng sản lượng hai lần.
  if(!Array.isArray(D.packerRecords))D.packerRecords=[];
}
function deletePlant(i){
  if(!CloudSync.requirePerm('catalog'))return;
  const p=D.catalog[Number(i)];if(!p)return;
  if(!confirm(`Ẩn cây "${p.name||''}${p.size?' · '+p.size:''}" khỏi danh mục? Dữ liệu lịch sử sẽ được giữ nguyên.`))return;
  p.deleted=true;save();closeEdit();renderAll();toast('Đã ẩn cây khỏi danh mục; lịch sử vẫn được giữ.');
}
function installPermissionGuards(){
  if(window.__rollPermissionGuardsInstalled)return;
  window.__rollPermissionGuardsInstalled=true;
  document.addEventListener('click',ev=>{
    const btn=ev.target?.closest?.('[data-remove-pack]');
    if(!btn)return;
    ev.preventDefault();ev.stopPropagation();
    const s=CloudSync?.state?.();
    if(!s?.user||!CloudSync.can('pack')){toast('Tài khoản này không có quyền xóa bản ghi đóng hàng');return}
    const date=btn.dataset.date,pi=Number(btn.dataset.pi),emp=decodeURIComponent(btn.dataset.emp||'');
    removePack(date,pi,emp);
  },true);
}
function openCloudSync(){renderCloudBody();$('cloudModal')?.classList.add('show')}
function closeCloudSync(){$('cloudModal')?.classList.remove('show')}
async function syncNow(){
  try{
    const s=CloudSync.state();
    if(!s.user){showLoginGate();return false}
    if(s.role==='packer'){
      await s.loadPackerRecords();
    }else{
      const ok=await CloudSync.pushNow();
      if(!ok && !CloudSync.can('report')) return false;
      if(s.role==='admin')await s.loadAllPackerRecords();
    }
    renderCloudBody();renderAll();
    toast('☁️ Đồng bộ thành công');
    return true;
  }catch(e){console.error('syncNow',e);toast('Lỗi Cloud: '+(e?.message||e?.code||'Không xác định'));return false}
}

function setEntryMode(m){
  entryMode=m==='in'?'in':'pack';
  const packBtn=$('modePack'),inBtn=$('modeIn'),packForm=$('packForm'),inForm=$('inForm');
  if(packBtn)packBtn.classList.toggle('active',entryMode==='pack');
  if(inBtn)inBtn.classList.toggle('active',entryMode==='in');
  if(packForm){packForm.classList.remove('hidden');packForm.style.display=entryMode==='pack'?'block':'none';}
  if(inForm){inForm.classList.remove('hidden');inForm.style.display=entryMode==='in'?'block':'none';}
  if(entryMode==='pack'){
    if(!selected.plantName)selected.plantName=plantNames()[0]||'';
    if(selected.empIndex>=employees().length)selected.empIndex=0;
    syncPackSelection();
  }else{
    if(!selected.inPlantName)selected.inPlantName=plantNames()[0]||'';
    syncInSelection();
  }
}
function packerAcceptedKey(){
  try{const uid=String(orderNotificationState.uid||CloudSync.state()?.user?.uid||'').trim();return uid?'ROLL_CAY_ACCEPTED_ORDERS_'+uid:''}catch(e){return ''}
}
function getPackerAcceptedOrderIds(){
  try{const k=packerAcceptedKey();if(!k)return [];const a=JSON.parse(localStorage.getItem(k)||'[]');return Array.isArray(a)?a.map(String):[]}catch(e){return []}
}
function markPackerOrderAccepted(id){const k=packerAcceptedKey();if(!k)return;const a=getPackerAcceptedOrderIds(),sid=String(id);if(!a.includes(sid))a.push(sid);localStorage.setItem(k,JSON.stringify(a))}
function isPackerOrderAccepted(id){return getPackerAcceptedOrderIds().includes(String(id))}
function renderPackerOrders(){
  // Luồng đơn của nhân viên phải dùng chính dữ liệu đã chứng minh là của packer
  // trong thông báo/listener. Không để trạng thái UI tạm thời làm mất danh sách.
  const packerMode=isPacker()||String(orderNotificationState.role||'')==='packer';
  if(!packerMode)return;
  const st=window.CloudSync?.state?.()||{};
  const uid=String(orderNotificationState.uid||st?.user?.uid||'').trim();
  let sourceRows=Array.isArray(D.packingOrders)&&D.packingOrders.length?D.packingOrders:orderNotificationState.rows;
  if((!Array.isArray(sourceRows)||!sourceRows.length)&&uid)sourceRows=restorePackerOrderCache(uid);
  const rows=(Array.isArray(sourceRows)?sourceRows:[]).filter(r=>r&&(!uid||String(r.assignedUid||'')===uid)).sort((a,b)=>Number(b.createdAtMs||0)-Number(a.createdAtMs||0));
  // Giữ bản dữ liệu vừa được xác nhận làm nguồn cho các thao tác tiếp theo.
  if(rows.length){D.packingOrders=rows.slice();orderNotificationState.rows=rows.slice();}
  const acceptedIds=getPackerAcceptedOrderIds();
  const pending=rows.filter(r=>r.status!=='completed'&&!acceptedIds.includes(String(r.id)));
  const accepted=rows.filter(r=>r.status!=='completed'&&acceptedIds.includes(String(r.id)));
  const done=rows.filter(r=>r.status==='completed');
  const n=$('packerOrderNotice');
  if(n){n.classList.toggle('hidden',!pending.length&&!accepted.length);n.innerHTML=(pending.length||accepted.length)?`🔔 Bạn có <b>${pending.length+accepted.length}</b> đơn chưa hoàn thành.`:''}
  const box=$('packerOrders');if(!box)return;
  const card=r=>{
    const selected=String(r.id)===String(selectedOrderId);
    const pay=orderTotalPay(r);
    const imgs=completionImages(r);const img=imgs.length?imgs.map((src,i)=>`<img src="${src}" onclick="openImageSrc(this.src,'Ảnh hoàn thành ${i+1}')" alt="Ảnh hoàn thành ${i+1}" style="max-width:90px;margin-right:6px">`).join(''):'';
    return `<div id="packer-order-${esc(String(r.id))}" class="order-card ${r.status==='completed'?'done':'pending'}" style="${selected?'border:2px solid #0ca566':''}"><div class="order-head"><div><div class="order-title">🌿 ${orderItemsLabel(r)}</div><div class="order-meta">📦 Đơn #${esc(r.orderNo||String(r.id||'').slice(-6))} · ${Math.round(orderTotalQty(r))} cây/combo · ${esc(r.employee||currentPackerName())}</div><div class="tiny muted" style="margin-top:5px">💰 Tiền công đơn: <b>${money(packerPay(r))}</b></div></div><span class="order-badge ${r.status==='completed'?'done':''}">${r.status==='completed'?'✅ Đã hoàn thành':acceptedIds.includes(String(r.id))?'📋 Đã nhận':'🔔 Chờ nhận'}</span></div>${r.status==='completed'?`<div class="order-proof">${img}<div><b>Đã có ảnh hoàn thành</b><div class="tiny muted">${r.completedAtMs?new Date(r.completedAtMs).toLocaleString('vi-VN'):''}</div></div></div>`:acceptedIds.includes(String(r.id))?`<button type="button" class="secondary" style="margin-top:9px;width:100%" onclick="selectAssignedOrder('${esc(String(r.id))}')">${selected?'Đang chọn đơn này':'📋 ĐÓNG ĐƠN NÀY'}</button>`:`<button type="button" class="primary" style="margin-top:9px;width:100%" onclick="acceptAssignedOrder('${esc(String(r.id))}')">📥 NHẬN ĐƠN</button>`}</div>`;
  };
  let html=`<div class="section-title" style="margin-top:4px"><h3>📥 Đơn chờ nhận</h3><span class="badge">${pending.length}</span></div>`;
  html+=pending.length?pending.map(card).join(''):'<div class="card empty">Không có đơn mới.</div>';
  html+=`<div class="section-title" style="margin-top:16px"><h3>📋 ĐƠN ĐÃ NHẬN · CẦN HOÀN THÀNH</h3><span class="badge">${accepted.length}</span></div>`;
  html+=accepted.length?accepted.map(card).join(''):'<div class="card empty">Chưa có đơn đã nhận.</div>';
  html+=`<div class="section-title" style="margin-top:16px"><h3>✅ Đơn đã hoàn thành</h3><span class="badge">${done.length}</span></div>`;
  html+=done.length?done.map(card).join(''):'<div class="card empty">Chưa có đơn hoàn thành.</div>';
  box.innerHTML=html;
  const panel=$('packerProofPanel');if(panel)panel.classList.toggle('hidden',!selectedOrderId||!accepted.some(r=>String(r.id)===String(selectedOrderId)));
}
async function acceptAssignedOrder(id){
  // Chỉ sửa bước NHẬN ĐƠN: khi danh sách đơn đã được xác nhận là của packer,
  // không dùng isPacker()/role() làm cổng chặn vì profile Firebase có thể đang
  // hydrate chậm hơn UI. Không thay đổi quyền hay dữ liệu Firestore.
  const st=window.CloudSync?.state?.()||{};
  const uid=String(orderNotificationState.uid||st?.user?.uid||'').trim();
  const notificationRole=String(orderNotificationState.role||'').toLowerCase();
  const currentRole=String(st?.role||'').toLowerCase();
  if(notificationRole!=='packer' && currentRole!=='packer'){
    toast('Tài khoản hiện tại không phải nhân viên đóng hàng');return false
  }
  if(!uid){toast('Chưa xác nhận được tài khoản nhân viên. Vui lòng chờ kết nối hoàn tất.');return false}
  const r=(D.packingOrders||[]).find(x=>String(x.id)===String(id)) || (orderNotificationState.rows||[]).find(x=>String(x.id)===String(id));
  if(!r||String(r.assignedUid||'')!==uid){toast('Đơn hàng không thuộc tài khoản hiện tại');return false}
  if(r.status==='completed'){toast('Đơn này đã hoàn thành');return false}
  if(!D.packingOrders?.length){D.packingOrders=[r]}
  markPackerOrderAccepted(id);
  selectedOrderId=null;resetPackProof();closeOrderNotifications();renderPackerOrders();
  toast('✅ Đã nhận đơn. Đơn đã chuyển sang danh sách cần hoàn thành');
  return true;
}
function selectAssignedOrder(id){
  const r=(D.packingOrders||[]).find(x=>String(x.id)===String(id));
  if(!r||r.status==='completed')return;
  if(!isPackerOrderAccepted(id)){toast('Hãy bấm NHẬN ĐƠN trước khi đóng hàng');return}
  selectedOrderId=id;pendingPackPhoto='';resetPackProof();selectedOrderId=id;renderPackerOrders();
  $('packProofStatus').textContent=`Đơn ${r.orderNo||r.id.slice(-6)} · ${Math.round(orderTotalQty(r))} cây. Chụp ảnh sau khi đóng xong.`;toast('Đã chọn đơn cần đóng');
}
function completionImages(r){
  const arr=Array.isArray(r?.completionImages)?r.completionImages.filter(x=>String(x||'').startsWith('data:image/')):[];
  if(arr.length)return arr;
  return r?.completionImage? [r.completionImage] : [];
}
function proofReady(){return Array.isArray(pendingPackPhotos)&&pendingPackPhotos.filter(Boolean).length>=2}
function shipmentProofReady(){return proofReady()&&!pendingShipmentOcrBusy&&!!pendingShipmentOcr.trackingNo}
function renderPackProofPreview(){
  const pv=$('packProofPreview');if(!pv)return;
  const imgs=(pendingPackPhotos||[]).filter(Boolean);
  if(!imgs.length){pv.classList.add('hidden');pv.innerHTML='';return}
  pv.classList.remove('hidden');
  pv.innerHTML=imgs.map((src,i)=>`<div style="display:flex;align-items:center;gap:8px;margin-top:7px"><img src="${src}" onclick="openImageSrc(this.src,'Ảnh hoàn thành ${i+1}')" alt="Ảnh hoàn thành ${i+1}" style="width:86px;height:86px;object-fit:cover;border-radius:10px"><div><b>📷 Ảnh ${i+1}</b><div class="tiny muted">${i===0?'Ảnh 1':'Ảnh 2'}</div></div></div>`).join('');
  const ok=proofReady();
  const canSubmit=shipmentProofReady();
  $('packProofStatus').textContent=canSubmit?'Đã đủ 2 ảnh · 🚚 Đã đọc vận đơn. Có thể xác nhận hoàn thành đơn.':(ok?'Đã đủ 2 ảnh · ⏳ Đang xác nhận thông tin vận đơn…':`Đã chụp ${imgs.length}/2 ảnh. Cần thêm ${2-imgs.length} ảnh.`);
  if($('packSubmitBtn')){ $('packSubmitBtn').disabled=!canSubmit; $('packSubmitBtn').textContent=canSubmit?'✅ XÁC NHẬN HOÀN THÀNH ĐƠN':'🔒 XÁC NHẬN HOÀN THÀNH ĐƠN'; }
}
function readPackProofImage(ev){
  const f=ev.target.files?.[0];if(!f)return;
  if(!String(f.type||'').startsWith('image/')){toast('Chỉ được chụp ảnh');ev.target.value='';return}
  const reader=new FileReader();reader.onload=()=>{const img=new Image();img.onload=()=>{const max=700,scale=Math.min(1,max/Math.max(img.width,img.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.width*scale));c.height=Math.max(1,Math.round(img.height*scale));const ctx=c.getContext('2d');ctx.drawImage(img,0,0,c.width,c.height);const photo=c.toDataURL('image/jpeg',.58);
    if(!Array.isArray(pendingPackPhotos))pendingPackPhotos=[];
    const slot=pendingPackPhotos.length<2?pendingPackPhotos.length:1;
    pendingPackPhotos[slot]=photo;
    pendingPackPhoto=pendingPackPhotos[0]||'';
    if(slot===1){pendingShipmentOcrBusy=true;pendingShipmentOcr={trackingNo:'',carrier:'',customerName:'',ocrText:''};if($('packProofStatus'))$('packProofStatus').textContent='⏳ Đang đọc ảnh 2 để lấy mã vận đơn, đơn vị vận chuyển và người nhận…';if(window.AndroidBridge&&AndroidBridge.ocrShippingImage){AndroidBridge.ocrShippingImage(photo,'__packingShipmentOcrResult')}else{pendingShipmentOcrBusy=false;pendingShipmentOcr=parseShipmentOcr('');}}
    renderPackProofPreview();
  };img.src=reader.result};reader.readAsDataURL(f);ev.target.value=''
}
function resetPackProof(){pendingPackPhoto='';pendingPackPhotos=[];pendingShipmentOcr={trackingNo:'',carrier:'',customerName:'',ocrText:''};pendingShipmentOcrBusy=false;packerEditingId=null;if($('packSubmitBtn')){$('packSubmitBtn').disabled=true;$('packSubmitBtn').textContent='🔒 XÁC NHẬN HOÀN THÀNH ĐƠN'}if($('packProofStatus'))$('packProofStatus').textContent='Chưa chọn đơn hoặc chưa chụp đủ 2 ảnh.';if($('packProofPreview')){$('packProofPreview').classList.add('hidden');$('packProofPreview').innerHTML=''}}
async function completeAssignedOrder(){
  const id=String(selectedOrderId||'');
  if(!id){toast('Hãy chọn đơn cần đóng');return}
  if(!isPackerOrderAccepted(id)){toast('Hãy nhận đơn trước khi hoàn thành');return}
  if(!proofReady()){toast('📷 Phải chụp đủ ít nhất 2 ảnh hoàn thành trước khi ghi nhận');return}
  if(!shipmentProofReady()){toast(pendingShipmentOcrBusy?'⏳ Đang đọc ảnh 2, vui lòng chờ…':'⚠️ Chưa đọc được mã vận đơn từ ảnh 2. Hãy chụp lại ảnh 2 rõ hơn.');return}
  const btn=$('packSubmitBtn');
  try{
    if(btn){btn.disabled=true;btn.textContent='⏳ ĐANG GHI NHẬN...'}
    const r=await CloudSync.state().completePackingOrder(id,pendingPackPhotos,pendingShipmentOcr);
    if(!r||String(r.status)!=='completed')throw new Error('Đơn chưa chuyển được sang trạng thái hoàn thành');
    const local=(D.packingOrders||[]).find(x=>String(x.id)===id);
    if(local)Object.assign(local,r);
    else D.packingOrders=[...(D.packingOrders||[]),r];
    const uid=String(r.completedBy||CloudSync.state()?.user?.uid||'');
    const recRow={id:r.id,...r,uid,employee:r.employee||currentPackerName(),qty:orderTotalQty(r),catalogId:resolveOrderCatalogId(r),date:completedOrderDate(r),payAdjustment:Number(r.payAdjustment)||0,payAdjustmentNote:r.payAdjustmentNote||'',payAmount:Number(r.payAmount),image:r.completionImage||'',completionImages:completionImages(r)};
    D.packerRecords=[recRow,...(D.packerRecords||[]).filter(x=>String(x.id)!==id)];
    rebuildPackerDaily();
    selectedOrderId=null;resetPackProof();
    renderPackerOrders();
    renderPackerDay();
    toast('✅ Đã hoàn thành đơn. Đơn đã ghi nhận và tiền công đã được tính');
  }catch(e){
    console.error('completeAssignedOrder',e);
    toast(e?.message||'Không thể hoàn thành đơn');
    if(btn){btn.disabled=!pendingPackPhoto;btn.textContent='🔒 XÁC NHẬN HOÀN THÀNH ĐƠN'}
  }
}
async function addPackerEntry(){toast('Nhân viên không nhập số cây. Hãy chọn đơn Admin phân công và chụp ảnh hoàn thành.')}
function startPackerEdit(id){toast('Bản ghi đóng hàng theo đơn đã hoàn thành, không sửa từ màn hình nhân viên.')}
async function deletePackerRecord(id){toast('Nhân viên không được xóa đơn đã hoàn thành.')}
let pendingAdminPackPhoto='';
function readAdminPackProofImage(ev){
  const f=ev.target.files?.[0];if(!f)return;
  if(!String(f.type||'').startsWith('image/')){toast('Chỉ được chụp ảnh');ev.target.value='';return}
  const reader=new FileReader();reader.onload=()=>{const img=new Image();img.onload=()=>{const max=700,scale=Math.min(1,max/Math.max(img.width,img.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.width*scale));c.height=Math.max(1,Math.round(img.height*scale));const ctx=c.getContext('2d');ctx.drawImage(img,0,0,c.width,c.height);pendingAdminPackPhoto=c.toDataURL('image/jpeg',.76);const pv=$('adminPackProofPreview');pv.classList.remove('hidden');pv.innerHTML=`<img src="${pendingAdminPackPhoto}" onclick="openImageSrc(this.src,'Ảnh bằng chứng đóng hàng')" alt="Ảnh bằng chứng"><div><b>✅ Đã chụp ảnh</b><div class="tiny muted">Có thể ghi nhận đóng hàng.</div></div>`;$('adminPackProofStatus').textContent='Ảnh hợp lệ. Có thể ghi nhận đóng hàng.';$('adminPackSubmitBtn').disabled=false};img.src=reader.result};reader.readAsDataURL(f);ev.target.value=''
}
function resetAdminPackProof(){pendingAdminPackPhoto='';if($('adminPackProofStatus'))$('adminPackProofStatus').textContent='Chưa chụp ảnh. Chỉ được chụp trực tiếp bằng camera.';if($('adminPackProofPreview')){$('adminPackProofPreview').classList.add('hidden');$('adminPackProofPreview').innerHTML=''}if($('adminPackSubmitBtn'))$('adminPackSubmitBtn').disabled=true}
function addPackEntry(){if(!CloudSync.can('pack')){toast('Tài khoản này không có quyền đóng hàng');return}if(isPacker())return addPackerEntry();const date=$('dDate').value||START,pi=Number(selected.sizeIndex),catalogId=catalogIdAt(pi),ei=Number(selected.empIndex),qty=Math.floor(Number($('eQty').value)||0),combo=Math.max(1,Number($('adminPackCombo')?.value)||1),p=catalogById(catalogId);if(!catalogId||!p||!employees()[ei]||qty<=0){toast('Vui lòng chọn đủ cây, kích thước, nhân viên và số cây');return}if(!hasCatalogRate(catalogId)){toast(`❌ Size ${p.size||'chưa ghi'} chưa có đơn giá lương. Hãy thêm đơn giá trước khi đóng hàng.`);return}if(!pendingAdminPackPhoto){toast('📷 Vui lòng chụp ảnh bằng chứng trước khi ghi nhận');return}const e=employees()[ei],x=rec(date,catalogId,true);x.counts=x.counts||{};x.counts[e]=(Number(x.counts[e])||0)+qty;x.comboSize=x.comboSize||{};x.comboSize[e]=combo;x.proofImages=x.proofImages||{};x.proofImages[e]=pendingAdminPackPhoto;x.proofTimes=x.proofTimes||{};x.proofTimes[e]=Date.now();x.proofCapturedBy=x.proofCapturedBy||{};x.proofCapturedBy[e]=CloudSync.state()?.user?.uid||'';save();$('eQty').value=1;if($('adminPackCombo'))$('adminPackCombo').value='1';resetAdminPackProof();renderAll();toast(`Đã ghi ${qty} cây · ${e}${combo>1?' · Combo '+combo+' cây':''}`)}
function addInEntry(){if(!CloudSync.can('in')){toast('Tài khoản này không có quyền nhập kho');return}const date=$('dDate').value||START,pi=Number(selected.inSizeIndex),catalogId=catalogIdAt(pi),qty=Math.floor(Number($('inQty').value)||0);if(!catalogId||!catalogById(catalogId)||qty<=0){toast('Vui lòng chọn cây, kích thước và số lượng');return}const x=rec(date,catalogId,true);x.in=(Number(x.in)||0)+qty;save();$('inQty').value=1;renderAll();toast(`Đã ghi nhập ${qty} cây`)}
function removePack(date,pi,e){if(!CloudSync.can('pack')){toast('Tài khoản này không có quyền xóa bản ghi đóng hàng');return}const catalogId=catalogIdAt(pi)||String(pi||'');const x=rec(date,catalogId);const q=Number(x?.counts?.[e])||0;if(!x||q<=0){toast('Không tìm thấy số cây cần xóa');return}delete x.counts[e];if(x.adjustments)x.adjustments=x.adjustments.filter(a=>a.employee!==e);cleanupRec(x);save();renderAll();toast(`Đã xóa ${Math.round(q)} cây của ${e}`)}
function removeIn(date,pi,qty){if(!CloudSync.can('in')){toast('Tài khoản này không có quyền hoàn tác nhập kho');return}const catalogId=catalogIdAt(pi)||String(pi||'');const x=rec(date,catalogId);if(!x)return;x.in=Math.max(0,(Number(x.in)||0)-Number(qty));cleanupRec(x);save();renderAll();toast('Đã hoàn tác nhập kho')}
function cleanupRec(x){if(!(Number(x.in)||0)&&!outOf(x)){const i=D.daily.indexOf(x);if(i>=0)D.daily.splice(i,1)}}

function renderPackerDay(){
  renderPackerOrders();
  const date=$('dDate').value||START;
  const allCompleted=completedOrderRecords();
  const rows=allCompleted.filter(r=>r.date===date);
  const total=rows.reduce((s,r)=>s+(Number(r.qty)||0),0);
  const pay=rows.reduce((s,r)=>s+packerPay(r),0);
  $('dayIn').textContent='—';$('dayOut').textContent=Math.round(total);$('dayPay').textContent=money(pay);if($('dayOrdersDone'))$('dayOrdersDone').textContent=String(rows.length);$('dayTotalBadge').textContent=`${Math.round(total)} cây đã hoàn thành`;
  let html='';if(!rows.length)html=`<div class="card empty">Chưa có đơn hoàn thành trong ngày này.</div>`;rows.forEach(r=>{const img=r.image?`<img class="pack-record-photo" src="${r.image}" onclick="openImageSrc(this.src,'Ảnh hoàn thành đơn hàng')" alt="">`:'';html+=`<div class="card"><div class="section-title"><div class="plant-row">${img}<div><h3>${esc(r.plantName||'Cây')}</h3><div class="tiny muted">${esc(r.size||'')} · Combo ${Math.round(r.qty||0)} cây · ${money(packerPay(r))}</div></div></div><span class="pack-lock locked">✅ Đã hoàn thành</span></div></div>`});$('dayBody').innerHTML=html;updatePackInfo();updateInInfo();}
function isPacker(){
  try{
    return !!(window.CloudSync && CloudSync.state && CloudSync.state().role==='packer');
  }catch(e){
    return false;
  }
}
async function ensureAdminPrintAccess(){
  try{
    const state0=window.CloudSync?.state?.()||{};
    if(state0.role==='admin') return true;
    if(window.CloudSync?.waitUntilAuthReady){
      const ok=await window.CloudSync.waitUntilAuthReady(8000);
      if(ok){
        const state1=window.CloudSync.state();
        if(state1.role==='admin') return true;
      }
    }
  }catch(e){console.warn('ensureAdminPrintAccess',e)}
  toast('Chỉ Admin được in phiếu đơn');
  return false;
}
function isAdminUser(){return !!(window.CloudSync&&CloudSync.state().role==='admin')}
function renderAdminPackerRecords(date){
  if(!isAdminUser())return;const rows=completedOrderRecords().filter(r=>r.date===date);if(!rows.length)return;
  const totalQty=rows.reduce((s,r)=>s+(Number(r.qty)||0),0),totalPay=rows.reduce((s,r)=>s+packerPay(r),0);
  const by={};rows.forEach(r=>{const e=canonicalEmployeeName(r.employee);if(!by[e])by[e]={orders:0,qty:0,pay:0};by[e].orders++;by[e].qty+=Number(r.qty)||0;by[e].pay+=packerPay(r)});
  let html=`<div class="card" style="border:2px solid #cfe8da"><div class="section-title"><h3>👑 Đơn nhân viên đã hoàn tất · ${fmtDMY(date)}</h3><span class="badge">${rows.length} đơn</span></div><div class="grid2"><div class="stat"><span>Tổng đơn hoàn tất</span><b>${rows.length}</b></div><div class="stat"><span>Tổng cây</span><b>${Math.round(totalQty)}</b></div><div class="stat"><span>Tổng tiền công</span><b>${money(totalPay)}</b></div><div class="stat"><span>Nhân viên</span><b>${Object.keys(by).length}</b></div></div><div style="margin-top:10px">${Object.entries(by).map(([e,v])=>`<div class="entry"><div><div class="name">${esc(e)}</div><div class="meta">${v.orders} đơn · ${Math.round(v.qty)} cây</div></div><div class="amount">${money(v.pay)}</div></div>`).join('')}</div>`;
  rows.forEach(r=>{const img=r.image?`<img class="pack-record-photo" src="${r.image}" onclick="openImageSrc(this.src,'Ảnh bằng chứng · ${esc(r.employee||'')}')" alt="">`:'';html+=`<div class="entry"><div class="plant-row">${img}<div><div class="name">${esc(r.employee||'Nhân viên')} · ${esc(r.plantName||'')}</div><div class="meta">${esc(r.size||'')} · ${Math.round(r.qty||0)} cây · ${money(packerPay(r))}</div></div></div><div class="pack-record-actions"><button class="secondary" onclick="adminEditPackerQty('${r.id}')">Sửa SL</button><button class="remove" onclick="adminDeletePacker('${r.id}')">Xóa</button></div></div>`});html+='</div>';$('dayBody').insertAdjacentHTML('beforeend',html);
}
async function adminEditPackerQty(id){const r=(D.packerRecords||[]).find(x=>x.id===id);if(!r)return;const q=prompt('Nhập số cây mới cho bản ghi của '+(r.employee||'nhân viên'),String(Math.round(r.qty||0)));if(q===null)return;const qty=Math.floor(Number(q)||0);if(qty<=0){toast('Số lượng không hợp lệ');return}try{await CloudSync.state().adminUpdatePackerRecord(id,{qty,packSize:qty});r.qty=qty;rebuildPackerDaily();localSaveOnly();renderAll();toast('Admin đã cập nhật số lượng')}catch(e){toast(e?.message||'Không thể cập nhật bản ghi')}}
async function adminDeletePacker(id){if(!confirm('Admin xóa bản ghi đóng hàng này?'))return;try{await CloudSync.state().adminDeletePackerRecord(id);D.packerRecords=D.packerRecords.filter(x=>x.id!==id);renderAll();toast('Admin đã xóa bản ghi')}catch(e){toast(e?.message||'Không thể xóa bản ghi')}}
function mergePackerTotalsIntoReport(by,from,to){let out=0,pay=0;completedOrderRecords().filter(r=>r.date>=from&&r.date<=to).forEach(r=>{const e=canonicalEmployeeName(r.employee);if(!by[e])by[e]={qty:0,pay:0};const q=Number(r.qty)||0;by[e].qty+=q;by[e].pay+=packerPay(r);out+=q;pay+=packerPay(r)});return {out,pay}}
function renderDay(){
  if(!$('dDate').value)$('dDate').value=START;if(isPacker()){renderPackerDay();return}setEntryMode(entryMode);
  const date=$('dDate').value,allEntries=dayEntries(date),entries=allEntries.filter(x=>entryMode==='in'?Number(x.in)>0:outOf(x)>0);
  let totalIn=0,totalOut=0,totalPay=0,html='';allEntries.forEach(x=>{totalIn+=Number(x.in)||0;totalOut+=outOf(x);totalPay+=payOf(x)});
  if(!entries.length)html=`<div class="card empty">Chưa có dữ liệu ${entryMode==='in'?'nhập kho':'đóng hàng'} trong ngày này.<br><span class="tiny">Hãy chọn ${entryMode==='in'?'Nhập kho':'Đóng hàng'} ở phía trên.</span></div>`;
  else entries.forEach(x=>{
    const catalogId=String(x.catalogId||catalogIdFromRecord(x)),pi=catalogIndexById(catalogId),p=catalogById(catalogId);if(!p)return;
    const img=`<img class="plant-thumb plant-photo-click" src="${imageSrc(p)}" onerror="this.src='logo.png'" onclick="openPlantImage(${pi})" alt="" title="Nhấn để phóng to">`;
    html+=`<div class="card"><div class="section-title"><div class="plant-row"><div>${img}</div><div><h3>${esc(p.name)}</h3><div class="tiny muted">${esc(p.size||'Không ghi kích thước')} · Tồn cuối: <b>${Math.round(closing(catalogId,date))}</b></div></div></div><span class="badge">${entryMode==='in'?Math.round(x.in)+' nhập':Math.round(outOf(x))+' đóng'}</span></div>`;
    if(entryMode==='in')html+=`<div class="entry"><div><div class="name">📦 Nhập kho</div><div class="meta">+${Math.round(x.in)} cây</div></div><div><button class="remove" onclick="removeIn('${date}',${pi},${Number(x.in)})">− Hoàn tác</button></div></div>`;
    else Object.entries(x.counts||{}).forEach(([emp,q])=>{const wage=rate(p.size),adj=adjustmentsOf(x,emp),proof=x.proofImages?.[emp]||'',proofTime=Number(x.proofTimes?.[emp]||0);html+=`<div class="entry"><div style="min-width:0"><div class="name">${esc(emp)}</div><div class="meta">${Math.round(q)} cây × ${money(wage)}/cây${adj?` · Điều chỉnh ${adj>0?'+':''}${money(adj)}`:''}</div>${proof?`<div class="pack-proof-inline"><img class="pack-record-photo" src="${proof}" onclick="openImageSrc(this.src,'Ảnh bằng chứng · ${esc(emp)} · ${esc(p.name)} ${esc(p.size||'')}')" alt="Ảnh bằng chứng"><span class="tiny muted">📷 Có ảnh bằng chứng${proofTime?` · ${new Date(proofTime).toLocaleString('vi-VN')}`:''}</span></div>`:`<div class="tiny muted">⚠️ Chưa có ảnh bằng chứng</div>`}</div><div style="display:flex;align-items:center;gap:5px;flex-wrap:wrap;justify-content:flex-end"><div class="amount">${money(Number(q)*wage+adj)}</div><button type="button" class="adjust" onclick="openAdjustMoney('${date}',${pi},'${encodeURIComponent(emp)}')">± Tiền</button><button type="button" class="remove" data-remove-pack data-date="${date}" data-pi="${pi}" data-emp="${encodeURIComponent(emp)}" aria-label="Xóa số cây đã ghi">− Xóa</button></div></div>`});
    html+=`<div class="stock" style="margin-top:9px"><div class="box"><span>Đầu ngày</span><b>${Math.round(opening(catalogId,date))}</b></div><div class="box closing"><span>Tồn cuối</span><b>${Math.round(closing(catalogId,date))}</b></div></div></div>`;
  });
  $('dayBody').innerHTML=html;const completedToday=completedOrderRecords().filter(r=>r.date===date),completedQty=completedToday.reduce((s,r)=>s+(Number(r.qty)||0),0),completedPay=completedToday.reduce((s,r)=>s+packerPay(r),0);
  totalOut+=completedQty;totalPay+=completedPay;$('dayIn').textContent=Math.round(totalIn);$('dayOut').textContent=Math.round(totalOut);$('dayPay').textContent=money(totalPay);if($('dayOrdersDone'))$('dayOrdersDone').textContent=String(completedToday.length);$('dayTotalBadge').textContent=entryMode==='in'?`${Math.round(totalIn)} cây nhập`:`${Math.round(totalOut)} cây đóng`;renderAdminPackerRecords(date);updatePackInfo();updateInInfo();
}

function renderCycles(){const ref=$('dDate')?.value||START;let idx=Math.max(0,Math.floor(daysBetween(START,ref)/7));let html='';for(let k=Math.max(0,idx-5);k<=idx;k++){let s=addDays(START,k*7),e=addDays(s,6);if(s>END)break;if(e>END)e=END;let vals=employees().map(emp=>D.daily.filter(x=>x.date>=s&&x.date<=e).reduce((sum,x)=>sum+employeePay(x,emp),0));if(isAdminUser()){vals.push(completedOrderRecords().filter(r=>r.date>=s&&r.date<=e).reduce((sum,r)=>sum+packerPay(r),0))}html+=`<div class="entry"><div><div class="name">Kỳ ${String(k+1).padStart(2,'0')}</div><div class="meta">${fmtDMY(s)} – ${fmtDMY(e)}</div></div><div class="amount">${money(vals.reduce((a,b)=>a+b,0))}</div></div>`}$('cycles').innerHTML=html||'<div class="empty">Chưa có dữ liệu.</div>'}
function shiftStockDay(n){const input=$('stockDate');let d=dateObj(input.value||START);d.setDate(d.getDate()+n);let s=fmt(d);if(s<START)s=START;if(s>END)s=END;input.value=s;renderStock()}
function clearStockSearch(){if($('stockSearch'))$('stockSearch').value='';renderStock()}
function setStockFilter(f){stockFilter=f;document.querySelectorAll('[data-stock-filter]').forEach(b=>b.classList.toggle('active',b.dataset.stockFilter===f));renderStock()}
function renderStock(){
 const date=$('stockDate')?.value||$('dDate').value||START;
 if($('stockDateBadge'))$('stockDateBadge').textContent=fmtDMY(date);
 const allRows=activeCatalog().map(o=>{const x=rec(date,o.i);const completed=completedPackerQtyForDate(o.i,date);return {o,in:Number(x?.in)||0,out:outOf(x)+completed,open:opening(o.i,date),close:closing(o.i,date)}});
 const totalIn=allRows.reduce((s,r)=>s+r.in,0),totalOut=allRows.reduce((s,r)=>s+r.out,0),totalClose=allRows.reduce((s,r)=>s+Math.max(0,r.close),0);
 const q=($('stockSearch')?.value||'').trim().toLowerCase();
 const rows=allRows.filter(r=>{
   const hay=`${r.o.p.name||''} ${r.o.p.size||''}`.toLowerCase();
   const match=!q||hay.includes(q); const c=Math.max(0,r.close);
   const status=stockFilter==='in'?c>0:stockFilter==='low'?c>0&&c<=10:stockFilter==='zero'?c<=0:true;
   return match&&status;
 }).sort((a,b)=>String(a.o.p.name||'').localeCompare(String(b.o.p.name||''),'vi')||String(a.o.p.size||'').localeCompare(String(b.o.p.size||''),'vi'));
 if($('stockCount'))$('stockCount').textContent=`Hiển thị ${rows.length}/${allRows.length} cây/kích thước`;
 let html=`<div class="card"><div class="section-title"><h3>Tổng quan ngày ${fmtDMY(date)}</h3><span class="badge">${Math.round(totalClose)} cây tồn</span></div><div class="grid2"><div class="stat"><span>Đầu ngày</span><b>${Math.round(allRows.reduce((s,r)=>s+r.open,0))}</b></div><div class="stat"><span>Nhập kho</span><b>${Math.round(totalIn)}</b></div><div class="stat"><span>Đóng hàng</span><b>${Math.round(totalOut)}</b></div><div class="stat"><span>Tồn cuối</span><b>${Math.round(totalClose)}</b></div></div></div>`;
 html+=rows.map(r=>{const c=Math.max(0,r.close);const status=c<=0?'<span class="stock-status empty">HẾT</span>':c<=10?'<span class="stock-status low">SẮP HẾT</span>':'<span class="stock-status">CÒN HÀNG</span>';return `<div class="card stock-card"><div class="stock-head"><div class="stock-main"><img class="plant-thumb-lg plant-photo-click" src="${imageSrc(r.o.p)}" onerror="this.src='logo.png'" onclick="openPlantImage(${r.o.i})" alt="" title="Nhấn để phóng to"><div style="min-width:0"><div class="stock-title">${esc(r.o.p.name)}</div><div class="tiny muted">${esc(r.o.p.size||'Không ghi kích thước')}</div></div></div>${status}</div><div class="stock-grid"><div class="mini"><span>Đầu ngày</span><b>${Math.round(r.open)}</b></div><div class="mini"><span>Nhập</span><b>${Math.round(r.in)}</b></div><div class="mini"><span>Đóng</span><b>${Math.round(r.out)}</b></div><div class="mini closing"><span>Tồn cuối</span><b>${Math.round(r.close)}</b></div></div></div>`}).join('');
 if(!rows.length)html+=`<div class="card empty">Không tìm thấy cây phù hợp. Hãy thử tên cây, mã C7/C9/C10... hoặc chọn “Tất cả”.</div>`;
 $('stockBody').innerHTML=html;
}

function syncReportDateLimits(){const a=$('rFrom').value||START,b=$('rTo').value||a;if(a&&b&&a>b)$('rTo').value=a;if($('rFrom')){$('rFrom').min=START;$('rFrom').max=END}if($('rTo')){$('rTo').min=START;$('rTo').max=END}}
function onReportFromChange(){const a=$('rFrom').value||START;if(($('rTo').value||'')<a)$('rTo').value=a;syncReportDateLimits();renderReport()}
function onReportToChange(){const b=$('rTo').value||START;if(($('rFrom').value||'')>b)$('rFrom').value=b;syncReportDateLimits();renderReport()}
function renderPackerReport(from,to){
  const rows=completedOrderRecords().filter(r=>r.date>=from&&r.date<=to);const qty=rows.reduce((s,r)=>s+(Number(r.qty)||0),0);const pay=rows.reduce((s,r)=>s+packerPay(r),0);let by={};rows.forEach(r=>{const k=r.date;by[k]=(by[k]||0)+(Number(r.qty)||0)});
  let html=`<div class="card"><div class="section-title"><h3>📊 Báo cáo của tôi · ${fmtDMY(from)} – ${fmtDMY(to)}</h3></div><div class="grid2"><div class="stat"><span>Cây đã đóng</span><b>${Math.round(qty)}</b></div><div class="stat"><span>Tiền công</span><b>${money(pay)}</b></div></div></div><div class="card"><div class="section-title"><h3>Chi tiết từng ngày</h3></div>`;
  const dates=[];for(let d=from;d<=to;d=addDays(d,1))dates.push(d);dates.forEach(d=>{html+=`<div class="report-row"><div class="top"><span>${fmtDMY(d)}</span><span>${Math.round(by[d]||0)} cây</span></div><div class="tiny muted">${money(rows.filter(r=>r.date===d).reduce((s,r)=>s+packerPay(r),0))}</div></div>`});html+='</div>';$('reportBody').innerHTML=html;
}
function renderReport(){syncReportDateLimits();const from=$('rFrom').value||START,to=$('rTo').value||from;if(isPacker()){renderPackerReport(from,to);return}const by={};employees().forEach(e=>by[e]={qty:0,pay:0});let totalIn=0,totalOut=0;D.daily.filter(x=>x.date>=from&&x.date<=to).forEach(x=>{totalIn+=Number(x.in)||0;totalOut+=outOf(x);employees().forEach(e=>{by[e].qty+=Number(x.counts?.[e])||0;by[e].pay+=employeePay(x,e)})});const completedRange=completedOrderRecords().filter(r=>r.date>=from&&r.date<=to);const extra=mergePackerTotalsIntoReport(by,from,to);totalOut+=extra.out;const totalPayDay=Object.values(by).reduce((s,x)=>s+x.pay,0);let html=`<div class="card"><div class="section-title"><h3>Tổng hợp ${fmtDMY(from)} – ${fmtDMY(to)}</h3><span class="badge">${completedOrderRecords().filter(r=>r.date>=from&&r.date<=to).length} đơn hoàn tất</span></div><div class="grid2"><div class="stat"><span>Nhập kho</span><b>${Math.round(totalIn)}</b></div><div class="stat"><span>Đóng hàng</span><b>${Math.round(totalOut)}</b></div><div class="stat"><span>Tiền công</span><b>${money(totalPayDay)}</b></div><div class="stat"><span>Tồn cuối</span><b>${Math.round(totalStock(to))}</b></div></div></div>`;
 const maxPay=Math.max(1,...Object.values(by).map(x=>x.pay));html+=`<div class="card"><div class="section-title"><h3>Tiền công theo nhân viên</h3></div>`;employees().forEach(e=>{html+=`<div class="report-row"><div class="top"><span>${esc(e)}</span><span>${money(by[e].pay)}</span></div><div class="tiny muted">${Math.round(by[e].qty)} cây</div><div class="bar"><i style="width:${Math.min(100,by[e].pay/maxPay*100)}%"></i></div></div>`});html+=`</div>`;
 // Hiển thị đầy đủ từng ngày trong đúng khoảng người dùng đã chọn, kể cả ngày không có phát sinh.
 html+=`<div class="card"><div class="section-title"><h3>Chi tiết từng ngày</h3><span class="badge">${fmtDMY(from)} → ${fmtDMY(to)}</span></div>`;
 for(let d=from; d<=to; d=addDays(d,1)){let dayRows=D.daily.filter(x=>x.date===d);let di=dayRows.reduce((s,x)=>s+(Number(x.in)||0),0);let dout=dayRows.reduce((s,x)=>s+outOf(x),0);let dpay=dayRows.reduce((s,x)=>s+payOf(x),0);const completedDay=completedOrderRecords().filter(r=>r.date===d);const completedQty=completedDay.reduce((s,r)=>s+(Number(r.qty)||0),0);const completedPay=completedDay.reduce((s,r)=>s+packerPay(r),0);dout+=completedQty;dpay+=completedPay;html+=`<div class="entry"><div><div class="name">${fmtDMY(d)}</div><div class="meta">Nhập ${Math.round(di)} cây · Đóng ${Math.round(dout)} cây · Đơn nhân viên hoàn tất ${completedDay.length} · Tồn cuối ${Math.round(totalStock(d))} cây</div></div><div class="amount">${money(dpay)}</div></div>`}html+=`</div>`;
 if(!isPacker()){if(completedRange.length){const byEmp={};completedRange.forEach(r=>{const e=canonicalEmployeeName(r.employee);if(!byEmp[e])byEmp[e]={orders:0,qty:0,pay:0};byEmp[e].orders++;byEmp[e].qty+=Number(r.qty)||0;byEmp[e].pay+=packerPay(r)});html+=`<div class="card"><div class="section-title"><h3>👑 Đơn phân công đã hoàn tất theo nhân viên</h3><span class="badge">${completedRange.length} đơn</span></div>${Object.entries(byEmp).map(([e,v])=>`<div class="entry"><div><div class="name">${esc(e)}</div><div class="meta">${v.orders} đơn hoàn tất · ${Math.round(v.qty)} cây</div></div><div class="amount">${money(v.pay)}</div></div>`).join('')}<div class="entry" style="border-top:2px solid #dfeee6;margin-top:6px;padding-top:10px"><div><div class="name">TỔNG</div><div class="meta">${completedRange.length} đơn · ${Math.round(completedRange.reduce((s,r)=>s+(Number(r.qty)||0),0))} cây</div></div><div class="amount">${money(completedRange.reduce((s,r)=>s+packerPay(r),0))}</div></div></div>`}}
 const plantTotals={};D.daily.filter(x=>x.date>=from&&x.date<=to).forEach(x=>{const id=catalogIdFromRecord(x),p=catalogById(id);if(!p)return;plantTotals[id]=(plantTotals[id]||0)+outOf(x)});completedOrderItemRecords().filter(r=>r.date>=from&&r.date<=to).forEach(r=>{const id=String(r.catalogId||'');if(id)plantTotals[id]=(plantTotals[id]||0)+(Number(r.qty)||0)});html+=`<div class="card"><div class="section-title"><h3>Sản lượng theo cây/kích thước</h3></div>`;const arr=Object.entries(plantTotals).sort((a,b)=>b[1]-a[1]);html+=arr.length?arr.map(([id,q])=>{const p=catalogById(id);if(!p)return '';return `<div class="entry"><div><div class="name">${esc(p.name)}</div><div class="meta">${esc(p.size||'Không ghi kích thước')}</div></div><div class="amount">${Math.round(q)} cây</div></div>`}).join(''):'<div class="empty">Chưa có sản lượng trong khoảng này.</div>';html+=`</div>`;
 html+=`<div class="card"><div class="section-title"><h3>Kỳ trả lương 7 ngày (tham khảo)</h3></div>`;let no=1;for(let s=START;s<=END;s=addDays(s,7),no++){let e=addDays(s,6);if(e>END)e=END;if(e<from||s>to)continue;let aa=s<from?from:s,bb=e>to?to:e;let vals=employees().map(emp=>D.daily.filter(x=>x.date>=aa&&x.date<=bb).reduce((sum,x)=>sum+employeePay(x,emp),0));if(!isPacker())vals.push(completedOrderRecords().filter(r=>r.date>=aa&&r.date<=bb).reduce((sum,r)=>sum+packerPay(r),0));html+=`<div class="entry"><div><div class="name">Kỳ ${String(no).padStart(2,'0')}</div><div class="meta">${fmtDMY(aa)} – ${fmtDMY(bb)}</div></div><div class="amount">${money(vals.reduce((a,b)=>a+b,0))}</div></div>`}html+=`</div>`;$('reportBody').innerHTML=html}
function renderControls(){renderEmployees();renderRates();renderPlantControls();renderOpening();renderUserManagement();applyPermissionsUI()}
function renderEmployees(){$('empList').innerHTML=employees().length?employees().map((e,i)=>`<div class="control-item"><div class="control-head"><span class="control-title">${esc(e)}</span><button class="secondary" onclick="openEditEmployee(${i})">Sửa</button></div><div class="tiny muted">Tiền công được tự tính theo từng kích thước.</div></div>`).join(''):'<div class="empty">Chưa có nhân viên.</div>'}
function renderRates(){$('rateList').innerHTML=D.rates.length?D.rates.map((r,i)=>`<div class="control-item"><div class="control-head"><div><div class="control-title">${esc(r.size)}</div><div class="tiny muted">${money(r.rate)} / cây</div></div><div class="actions"><button class="secondary" onclick="openEditRate(${i})">Sửa</button><button class="danger" onclick="deleteRate(${i})">Xóa</button></div></div></div>`).join(''):'<div class="empty">Chưa có đơn giá.</div>'}
function renderPlantControls(){const q=($('plantSearch')?.value||'').trim().toLowerCase(),health=catalogHealth(),arr=activeCatalog().filter(o=>!q||String(o.p.name).toLowerCase().includes(q)||String(o.p.size).toLowerCase().includes(q)),warning=health.missingRate.length?`<div class="card" style="border:1px solid #f0c36d;background:#fff9e8"><b>⚠️ ${health.missingRate.length} size chưa có đơn giá lương</b><div class="tiny muted" style="margin-top:5px">${health.missingRate.slice(0,8).map(x=>`${esc(x.name)} · ${esc(x.size||'Chưa ghi size')}`).join(' · ')}${health.missingRate.length>8?' · ...':''}</div><div class="tiny muted" style="margin-top:5px">Hệ thống sẽ chặn phân công cho size chưa có đơn giá để tránh tính lương = 0.</div></div>`:'';$('plantList').innerHTML=warning+(arr.length?arr.slice(0,60).map(o=>`<div class="control-item"><div class="control-head"><div class="plant-row"><img class="plant-thumb plant-photo-click" src="${o.p.image||'logo.png'}" onerror="this.src='logo.png'" onclick="openPlantImage(${o.i})" alt="" title="Nhấn để phóng to"><div class="plant-main"><div class="control-title">${esc(o.p.name)}</div><div class="tiny muted">${esc(o.p.size||'Không ghi kích thước')} · Giá cây ${money(o.p.price)}${hasCatalogRate(o.catalogId)?'':' · ⚠️ Chưa có đơn giá lương'}</div></div></div><button class="secondary" onclick="openEditPlant(${o.i})">Sửa</button></div></div>`).join(''):'<div class="empty">Chưa có cây phù hợp.</div>')+(arr.length>60?`<div class="empty">Đang hiển thị 60 kết quả. Hãy tìm tên cây cụ thể.</div>`:'');}
function renderOpening(){$('openingList').innerHTML=activeCatalog().map(o=>`<div class="control-item"><div class="control-head"><div><div class="control-title">${esc(o.p.name)}</div><div class="tiny muted">${esc(o.p.size||'Không ghi kích thước')}</div></div><input style="width:110px;padding:9px;border:1px solid #d6e1dc;border-radius:10px;text-align:right" type="number" min="0" value="${Number(D.opening[o.catalogId])||0}" onchange="D.opening['${esc(o.catalogId)}']=Math.max(0,Number(this.value)||0);save();renderAll();toast('Đã lưu tồn đầu kỳ')"></div></div>`).join('')}
function openEditEmployee(i){$('editTitle').textContent=i<0?'Thêm nhân viên':'Sửa nhân viên';$('editBody').innerHTML=`<div class="field"><label>Tên nhân viên</label><input id="editName" value="${i>=0?esc(employees()[i]):''}" placeholder="Ví dụ: Nam"></div><button class="primary" onclick="saveEmployeeEdit(${i})">LƯU</button>${i>=0?`<div class="actions"><button class="danger" onclick="deleteEmployee(${i})">Xóa nhân viên</button></div>`:''}`;$('editModal').classList.add('show')}
function saveEmployeeEdit(i){const n=$('editName').value.trim();if(!n){toast('Tên nhân viên không được trống');return}if(i<0){if(employees().includes(n)){toast('Tên nhân viên đã tồn tại');return}D.employees.push(n)}else{const old=D.employees[i];if(n!==old&&employees().includes(n)){toast('Tên nhân viên đã tồn tại');return}D.employees[i]=n;D.daily.forEach(x=>{if(x.counts&&x.counts[old]!=null){x.counts[n]=(Number(x.counts[n])||0)+(Number(x.counts[old])||0);delete x.counts[old]}});(D.salaryAdvances||[]).forEach(a=>{if(String(a.employee||'')===String(old))a.employee=n});(D.packingOrders||[]).forEach(o=>{if(String(o.employee||'')===String(old))o.employee=n});(D.packerRecords||[]).forEach(r=>{if(String(r.employee||'')===String(old))r.employee=n})}save();closeEdit();renderAll();toast('Đã lưu nhân viên')}
function deleteEmployee(i){const old=employees()[i];if(!confirm(`Xóa ${old}? Lịch sử của người này sẽ được bỏ khỏi báo cáo.`))return;D.employees.splice(i,1);D.daily.forEach(x=>{if(x.counts)delete x.counts[old]});save();closeEdit();renderAll();toast('Đã xóa nhân viên')}
function openEditRate(i){const r=i>=0?D.rates[i]:{size:'',rate:0};$('editTitle').textContent=i<0?'Thêm đơn giá':'Sửa đơn giá';$('editBody').innerHTML=`<div class="field"><label>Kích thước</label><input id="editSize" value="${esc(r.size)}" placeholder="C6, C7, C9..."></div><div class="field"><label>Tiền công / cây (VNĐ)</label><input id="editRate" type="number" min="0" value="${Number(r.rate)||0}"></div><button class="primary" onclick="saveRateEdit(${i})">LƯU</button>`;$('editModal').classList.add('show')}
function saveRateEdit(i){const size=$('editSize').value.trim();const ratev=Math.max(0,Number($('editRate').value)||0);if(!size){toast('Kích thước không được trống');return}if(D.rates.some((r,j)=>j!==i&&String(r.size).toLowerCase()===size.toLowerCase())){toast('Kích thước đã có đơn giá');return}if(i<0)D.rates.push({size,rate:ratev});else D.rates[i]={size,rate:ratev};save();closeEdit();renderAll();toast('Đã lưu đơn giá')}
function deleteRate(i){if(!confirm(`Xóa đơn giá ${D.rates[i].size}?`))return;D.rates.splice(i,1);save();renderAll();toast('Đã xóa đơn giá')}
function openEditPlant(i){const p=i>=0?D.catalog[i]:{name:'',size:'',price:0,image:''};pendingPlantImage=p.image||'';$('editTitle').textContent=i<0?'Thêm cây':'Sửa cây';$('editBody').innerHTML=`<div class="field"><label>Tên cây</label><input id="editPlantName" value="${esc(p.name)}"></div><div class="field"><label>Kích thước</label><input id="editPlantSize" value="${esc(p.size||'')}" placeholder="C7, C9..."></div><div class="field"><label>Giá cây (VNĐ)</label><input id="editPlantPrice" type="number" min="0" value="${Number(p.price)||0}"></div><div class="field"><label>Hình ảnh cây</label><div id="plantPhotoPreview" class="photo-preview">${p.image?`<img src="${p.image}" class="plant-photo-click" onclick="openImageSrc(this.src,'${esc(p.name)} ${esc(p.size||'')}')" alt="" title="Nhấn để phóng to">`:`<div class="empty-photo">🌿</div>`}<div><b>${p.image?'Đã có ảnh':'Chưa có ảnh'}</b><div class="tiny muted">Có thể thay ảnh nhiều lần.</div></div></div><div class="photo-actions"><button type="button" class="secondary" onclick="$('plantCameraInput').click()">📷 Chụp ảnh</button><button type="button" class="secondary" onclick="$('plantGalleryInput').click()">🖼️ Thư viện ảnh</button><button type="button" class="danger" onclick="clearPlantImage()">Xóa ảnh</button></div><input id="plantCameraInput" class="hidden" type="file" accept="image/*" capture="environment" onchange="readPlantImage(event)"><input id="plantGalleryInput" class="hidden" type="file" accept="image/*" onchange="readPlantImage(event)"></div><button class="primary" onclick="savePlantEdit(${i})">LƯU</button>${i>=0?`<div class="actions"><button class="danger" onclick="deletePlant(${i})">Ẩn/xóa khỏi danh mục</button></div>`:''}`;$('editModal').classList.add('show')}
function readPlantImage(ev){const f=ev.target.files?.[0];if(!f)return;const reader=new FileReader();reader.onload=()=>{const img=new Image();img.onload=()=>{const max=520,scale=Math.min(1,max/Math.max(img.width,img.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.width*scale));c.height=Math.max(1,Math.round(img.height*scale));const ctx=c.getContext('2d');ctx.drawImage(img,0,0,c.width,c.height);pendingPlantImage=c.toDataURL('image/jpeg',.72);$('plantPhotoPreview').innerHTML=`<img src="${pendingPlantImage}" alt=""><div><b>Ảnh mới</b><div class="tiny muted">Ảnh sẽ được lưu gọn trong điện thoại.</div></div>`};img.src=reader.result};reader.readAsDataURL(f);ev.target.value=''}
function clearPlantImage(){pendingPlantImage='';if($('plantPhotoPreview'))$('plantPhotoPreview').innerHTML='<div class="empty-photo">🌿</div><div><b>Đã xóa ảnh</b><div class="tiny muted">Bấm LƯU để xác nhận.</div></div>'}
function catalogKey(p,i){
  // Stable identity for an individual catalog row. Never return a Promise/object.
  const raw=String(p?.catalogId??p?.plantId??p?.id??'').trim();
  if(raw)return raw;
  const name=String(p?.name??'').trim().toLowerCase().replace(/\s+/g,' ');
  const size=String(p?.size??'').trim().toLowerCase().replace(/\s+/g,' ');
  const stt=String(p?.stt??'').trim();
  return `legacy:${stt||((Number.isInteger(Number(i)))?Number(i):0)}|${name}|${size}`;
}
function findCatalogByKey(key){
  // Legacy/migration helper only. Business logic must call catalogById().
  const k=String(key??'').trim();
  if(!k)return null;
  const i=catalogIndexById(k);
  return i>=0?{p:D.catalog[i],i}:null;
}
function findCatalogByNameSize(name,size){
  // Migration/import diagnostic only; never use for active business identity.

  const n=String(name??'').trim().toLowerCase();
  const z=String(size??'').trim().toLowerCase();
  const rows=activeCatalog().filter(o=>String(o.p?.name??'').trim().toLowerCase()===n);
  return rows.find(o=>String(o.p?.size??'').trim().toLowerCase()===z)||rows[0]||null;
}
function ensureCatalogIds(){
  if(!Array.isArray(D.catalog))return;
  const used=new Set();
  D.catalog.forEach((p,i)=>{
    if(!p||typeof p!=='object')return;
    let id=String(p.catalogId??p.plantId??p.id??'').trim();
    if(!id||used.has(id)){
      const base=catalogKey({...p,catalogId:''},i);
      id=base;let n=2;while(used.has(id))id=`${base}#${n++}`;
      p.catalogId=id;
    }
    used.add(id);
  });
}
function catalogIdAt(index){
  // Migration-only helper: array index may be used ONLY while converting legacy data.
  const i=Number(index),p=Number.isInteger(i)?D?.catalog?.[i]:null;
  return p?String(p.catalogId||'').trim():'';
}
function catalogIndexById(id){
  const k=String(id??'').trim();
  if(!k)return -1;
  return (D?.catalog||[]).findIndex(p=>String(p?.catalogId??'').trim()===k);
}
function catalogById(id){const i=catalogIndexById(id);return i>=0?D.catalog[i]:null}
function catalogIdFromRecord(x){
  const direct=String(x?.catalogId??'').trim();
  return direct&&catalogIndexById(direct)>=0?direct:'';
}
function hasCatalogRate(catalogId){
  const p=catalogById(catalogId);
  if(!p)return false;
  const size=String(p.size??'').trim().toLowerCase();
  return !!size&&(D.rates||[]).some(r=>String(r?.size??'').trim().toLowerCase()===size);
}
function catalogHealth(){
  ensureCatalogIds();
  const ids=new Set(),duplicateIds=[],missingRate=[];
  (D.catalog||[]).forEach((p,i)=>{
    if(!p||p.deleted)return;
    const id=String(p.catalogId||'').trim();
    if(!id||ids.has(id))duplicateIds.push({index:i,name:p.name,size:p.size,id});
    ids.add(id);
    if(!hasCatalogRate(id))missingRate.push({catalogId:id,name:p.name,size:p.size});
  });
  return {duplicateIds,missingRate};
}
function normalizeCatalogRows(rows){
  const out=Array.isArray(rows)?rows.map(p=>({...p})):[];
  const used=new Set();
  out.forEach((p,i)=>{
    let id=String(p?.catalogId||p?.plantId||p?.id||'').trim();
    if(!id||used.has(id)){
      const base=catalogKey({...p,catalogId:''},i);
      id=base;let n=2;while(used.has(id))id=`${base}#${n++}`;
      p.catalogId=id;
    }
    used.add(id);
  });
  return out;
}
function mergeCatalogCanonical(localRows,cloudRows,prefer='local'){
  const local=normalizeCatalogRows(localRows),cloud=normalizeCatalogRows(cloudRows);
  const map=new Map(),order=[];
  const add=(row,source)=>{
    if(!row||typeof row!=='object')return;
    const id=String(row.catalogId||'').trim();if(!id)return;
    if(!map.has(id)){map.set(id,{...row});order.push(id);return}
    const current=map.get(id);
    map.set(id,prefer==='cloud'
      ?(source==='cloud'?{...current,...row}:{...row,...current})
      :(source==='local'?{...current,...row}:{...row,...current}));
  };
  local.forEach(p=>add(p,'local'));cloud.forEach(p=>add(p,'cloud'));
  return order.map(id=>map.get(id));
}
function mergeRatesCanonical(localRows,cloudRows,prefer='cloud'){
  const key=r=>String(r?.size||'').trim().toLowerCase(),map=new Map();
  (Array.isArray(localRows)?localRows:[]).forEach(r=>{if(key(r))map.set(key(r),{...r})});
  (Array.isArray(cloudRows)?cloudRows:[]).forEach(r=>{if(!key(r))return;const k=key(r);map.set(k,prefer==='cloud'?{...map.get(k),...r}:{...r,...map.get(k)})});
  return [...map.values()];
}
function migrateCatalogCanonicalData(){
  // One-time migration only. Legacy plantIndex is read here and immediately discarded.
  ensureCatalogIds();
  const legacyId=x=>{const direct=String(x?.catalogId??'').trim();if(direct&&catalogIndexById(direct)>=0)return direct;const idx=Number(x?.plantIndex);return Number.isInteger(idx)&&idx>=0?catalogIdAt(idx):''};
  const opening=D.opening&&typeof D.opening==='object'?D.opening:{},migratedOpening={};
  Object.keys(opening).forEach(k=>{const id=catalogIndexById(k)>=0?k:catalogIdAt(Number(k));if(id)migratedOpening[id]=Number(opening[k])||0});
  (D.catalog||[]).forEach((p,i)=>{const id=catalogIdAt(i);if(id&&migratedOpening[id]==null)migratedOpening[id]=0});
  D.opening=migratedOpening;
  const migrateRows=rows=>(Array.isArray(rows)?rows:[]).forEach(x=>{if(!x||typeof x!=='object')return;const id=legacyId(x);if(id)x.catalogId=id;delete x.plantIndex});
  migrateRows(D.daily);migrateRows(D.packerRecords);migrateRows(D.shipments);
  (D.packingOrders||[]).forEach(o=>{if(!o||typeof o!=='object')return;const id=legacyId(o);if(id)o.catalogId=id;(Array.isArray(o.items)?o.items:[]).forEach(it=>{if(!it||typeof it!=='object')return;const iid=legacyId(it);if(iid)it.catalogId=iid;delete it.plantIndex});delete o.plantIndex});
}
function plainAssignmentItem(x){
  const catalogId=String(x?.catalogId??'').trim(),qty=Math.max(1,Math.floor(Number(x?.qty)||0));
  const plantKey=String(x?.plantKey??catalogId).trim(),plantName=String(x?.plantName??'').trim(),size=String(x?.size??'').trim(),p=catalogById(catalogId);
  if(!catalogId||!p||p.deleted||!plantName||!Number.isFinite(qty))return null;
  return {catalogId,plantKey,plantName,size,qty};
}

function savePlantEdit(i){
  // Quyền catalog lấy từ session/profile chuẩn của CloudSync.
  // Admin được nhận diện bằng role admin hoặc email bootstrap.
  try{
    const st=CloudSync.state();
    const r=String(st?.role||'').trim().toLowerCase();
    const catalogAllowed=!!st?.user && (r==='admin'||r==='procurement');
    if(!catalogAllowed){toast('Tài khoản này không có quyền chỉnh sửa danh mục cây');return}

    const name=$('editPlantName')?.value.trim()||'';
    const size=$('editPlantSize')?.value.trim()||'';
    const raw=String($('editPlantPrice')?.value??'').trim().replace(/[\s,.]/g,'');
    if(!name){toast('Tên cây không được trống');return}
    if(raw===''||!/^-?\d+$/.test(raw)){toast('Giá cây không hợp lệ');return}
    const price=Math.max(0,Number(raw));
    if(!Number.isSafeInteger(price)){toast('Giá cây không hợp lệ');return}

    if(i<0){
      const duplicate=activeCatalog().some(o=>normalizeAssignSearch(o.p.name||'')===normalizeAssignSearch(name)&&String(o.p.size||'').trim().toLowerCase()===String(size||'').trim().toLowerCase());
      if(duplicate){toast('Tên cây + kích thước này đã tồn tại trong danh mục.');return}
      const catalogId='plant-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8);
      D.catalog.push({stt:D.catalog.length+1,catalogId,name,size,price,image:pendingPlantImage||'',deleted:false,updatedAtMs:Date.now()});
      D.opening[catalogId]=0;
    }else{
      const prev=D.catalog[i]||{};
      const sameIdentity=normalizeAssignSearch(prev.name||'')===normalizeAssignSearch(name)&&String(prev.size||'').trim().toLowerCase()===String(size||'').trim().toLowerCase();
      if(!sameIdentity){
        const duplicate=activeCatalog().some(o=>o.i!==i&&normalizeAssignSearch(o.p.name||'')===normalizeAssignSearch(name)&&String(o.p.size||'').trim().toLowerCase()===String(size||'').trim().toLowerCase());
        if(duplicate){toast('Tên cây + kích thước này đã tồn tại trong danh mục.');return}
        D.catalog[i]={...prev,deleted:true,updatedAtMs:Date.now()};
        const catalogId='plant-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8);
        D.catalog.push({stt:D.catalog.length+1,catalogId,name,size,price,image:pendingPlantImage||'',deleted:false,updatedAtMs:Date.now()});
        D.opening[catalogId]=0;
      }else{
        D.catalog[i]={...prev,catalogId:String(prev.catalogId||'').trim(),name,size,price,image:pendingPlantImage||'',deleted:false,updatedAtMs:Date.now()};
      }
    }

    // Lưu local trước để thao tác không phụ thuộc mạng.
    localSaveOnly();
    localStorage.setItem('quanlycay_dirty','1');
    closeEdit();
    renderAll();
    toast(`✅ Đã lưu giá ${money(price)} trên máy`);

    // Sau đó đồng bộ lên /apps/roll-cay-canh theo Rules hiện hành.
    try{CloudSync.schedulePush()}catch(e){console.warn('catalog schedulePush',e)}
  }catch(e){
    console.error('savePlantEdit ROOT CAUSE FIX',e);
    toast('Không thể lưu danh mục cây: '+(e?.message||e));
  }
}
function openImageSrc(src,title='Ảnh cây'){if(!src)return;$('imageViewerImg').src=src;$('imageViewerTitle').textContent=title||'Ảnh cây';$('imageViewer').classList.add('show');document.body.style.overflow='hidden'}
function openPlantImage(i){const p=D?.catalog?.[Number(i)];if(!p)return;openImageSrc(imageSrc(p),`${p.name||'Cây'}${p.size?' · '+p.size:''}`)}
function closeImageViewer(){$('imageViewer').classList.remove('show');$('imageViewerImg').src='';document.body.style.overflow=''}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('imageViewer')?.classList.contains('show'))closeImageViewer()});
function openAdjustMoney(date,pi,empEncoded){const emp=decodeURIComponent(empEncoded||'');const x=rec(date,pi,true);const current=adjustmentsOf(x,emp);$('editTitle').textContent='Điều chỉnh tiền công';$('editBody').innerHTML=`<div class="info"><b>${esc(emp)}</b><div class="tiny muted">${fmtDMY(date)} · ${esc(D.catalog[pi]?.name||'')} ${esc(D.catalog[pi]?.size||'')}</div><div class="money">Đang điều chỉnh: ${money(current)}</div></div><div class="field"><label>Số tiền điều chỉnh (VNĐ)</label><input id="adjAmount" type="number" step="1000" inputmode="numeric" value="0" placeholder="Ví dụ: 50000 hoặc -30000"></div><div class="field"><label>Ghi chú</label><input id="adjNote" placeholder="Thưởng, phụ cấp, trừ tiền..."></div><button class="primary" onclick="saveAdjustMoney('${date}',${pi},'${encodeURIComponent(emp)}')">LƯU ĐIỀU CHỈNH</button><div class="tiny muted" style="margin-top:8px">Nhập số dương để cộng, số âm để trừ. Có thể thực hiện nhiều lần.</div>`;$('editModal').classList.add('show')}
function saveAdjustMoney(date,pi,empEncoded){const emp=decodeURIComponent(empEncoded||''),amount=Number($('adjAmount').value)||0,note=$('adjNote').value.trim();if(!amount){toast('Số tiền phải khác 0');return}const x=rec(date,pi,true);x.adjustments=x.adjustments||[];x.adjustments.push({employee:emp,amount,note,at:Date.now()});save();closeEdit();renderAll();toast(`Đã ${amount>0?'cộng':'trừ'} ${money(Math.abs(amount))}`)}
function closeEdit(){$('editModal').classList.remove('show')}
function csvCell(v){const s=String(v??'');return '"'+s.replace(/"/g,'""')+'"'}
function downloadText(filename,text,mime='text/csv;charset=utf-8'){if(window.AndroidBridge&&AndroidBridge.saveFile){try{const b64=btoa(unescape(encodeURIComponent(text)));const ok=AndroidBridge.saveFile(filename,b64,mime);if(ok){toast('Đã lưu file vào Tải xuống / ROLL CÂY CẢNH');return}}catch(e){console.error(e)}}const blob=new Blob([text],{type:mime});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function payrollDateRange(){const from=$('pFrom')?.value||START,to=$('pTo')?.value||from;return from<=to?{from,to}:{from:to,to:from}}
function payrollEntries(from,to){
  // Lương trong ngày = tiền công Admin ghi nhận trực tiếp + tiền công các đơn phân công đã hoàn tất.
  // Hai nguồn độc lập và luôn được cộng, không nguồn nào ghi đè nguồn nào.
  const by={};employees().forEach(e=>{by[e]={qty:0,basePay:0,adjustment:0,pay:0,days:{}}});
  const ensure=e=>{const k=canonicalEmployeeName(e);if(!by[k])by[k]={qty:0,basePay:0,adjustment:0,pay:0,days:{}};return by[k]};
  const add=(e,date,qty,base,adj,source)=>{
    const k=canonicalEmployeeName(e);if(!k||!date)return;
    const v=ensure(k),d=v.days[date]||(v.days[date]={qty:0,basePay:0,adjustment:0,pay:0,manualPay:0,orderPay:0,manualQty:0,orderQty:0});
    const q=Number(qty)||0,b=Number(base)||0,a=Number(adj)||0;
    d.qty+=q;d.basePay+=b;d.adjustment+=a;d.pay=d.basePay+d.adjustment;
    v.qty+=q;v.basePay+=b;v.adjustment+=a;v.pay=v.basePay+v.adjustment;
    if(source==='order'){d.orderPay+=b+a;d.orderQty+=q}else{d.manualPay+=b+a;d.manualQty+=q}
  };
  // Nguồn 1: Admin nhập/đóng hàng trực tiếp. Đọc toàn bộ counts để không bỏ sót tên
  // nhân viên do khác hoa/thường hoặc khoảng trắng so với danh sách chuẩn.
  D.daily.filter(x=>x.date>=from&&x.date<=to).forEach(x=>{
    const p=catalogById(catalogIdFromRecord(x)),w=rate(p?.size);
    Object.entries(x.counts||{}).forEach(([employee,qRaw])=>{
      const q=Number(qRaw)||0,adj=adjustmentsOf(x,employee);
      if(q||adj)add(employee,x.date,q,q*w,adj,'manual');
    });
    (x.adjustments||[]).forEach(a=>{
      const employee=String(a?.employee||'').trim();
      const q=Number(x.counts?.[employee])||0;
      if(!q&&Number(a?.amount))add(employee,x.date,0,0,Number(a.amount)||0,'manual');
    });
  });
  // Nguồn 2: đơn phân công đã hoàn tất, trả tiền công cho nhân viên được chỉ định.
  completedOrderRecords().filter(r=>r.date>=from&&r.date<=to).forEach(r=>{
    const base=orderItemPay(r),pay=orderTotalPay(r),adj=pay-base;
    add(r.employee,r.date,orderTotalQty(r),base,adj,'order');
  });
  return by;
}
function payrollDays(from,to){const days=[];let d=new Date(from+'T00:00:00');const end=new Date(to+'T00:00:00');while(d<=end){days.push(fmt(d));d.setDate(d.getDate()+1)}return days}
function payrollAdvanceEntries(from,to){return (Array.isArray(D.salaryAdvances)?D.salaryAdvances:[]).filter(a=>String(a.date)>=from&&String(a.date)<=to&&Number(a.amount)>0)}
function payrollAdvanceByEmployee(from,to){const by={};payrollAdvanceEntries(from,to).forEach(a=>{const e=canonicalEmployeeName(a.employee),v=by[e]||(by[e]={total:0,days:{},rows:[]}),amt=Math.round(Number(a.amount)||0);v.total+=amt;v.days[a.date]=(v.days[a.date]||0)+amt;v.rows.push(a)});return by}
function payrollAdvanceTotalForEmployee(name,from,to){return Number(payrollAdvanceByEmployee(from,to)[canonicalEmployeeName(name)]?.total)||0}
function payrollAdvanceAvailable(employee,date){
  const e=canonicalEmployeeName(employee||'');
  if(!e)return 0;
  const until=String(date||fmt(new Date()));
  const earned=payrollEntries(START,until)[e]?.pay||0;
  const advanced=payrollAdvanceByEmployee(START,until)[e]?.total||0;
  return Math.max(0,Math.round(earned-advanced));
}
function updateAdvanceAvailable(){
  const e=String($('advanceEmployee')?.value||'').trim();
  const date=$('advanceDate')?.value||fmt(new Date());
  const available=payrollAdvanceAvailable(e,date);
  const box=$('advanceAvailable');
  if(box)box.innerHTML=`<b>${money(available)}</b><div class="tiny muted">Lũy kế đã kiếm được − các khoản đã ứng trước đến ${fmtDMY(date)}</div>`;
  const input=$('advanceAmount');
  if(input)input.max=String(available);
}
function saveSalaryAdvance(){
  if(!CloudSync.can('payroll'))return;
  const employee=canonicalEmployeeName($('advanceEmployee')?.value||'');
  const date=$('advanceDate')?.value||fmt(new Date());
  const amount=Math.round(Number($('advanceAmount')?.value)||0);
  const note=String($('advanceNote')?.value||'').trim();
  if(!employee||employee==='Nhân viên'){toast('Hãy chọn nhân viên');return}
  if(!/^\d{4}-\d{2}-\d{2}$/.test(date)){toast('Ngày ứng không hợp lệ');return}
  if(amount<=0){toast('Số tiền ứng phải lớn hơn 0');return}
  D.salaryAdvances=Array.isArray(D.salaryAdvances)?D.salaryAdvances:[];
  D.salaryAdvances.push({id:'adv-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7),employee,date,amount,note,createdAtMs:Date.now()});
  save();
  $('advanceAmount').value='';$('advanceNote').value='';$('advanceEmployee').value=employee;$('advanceDate').value=date;
  renderPayroll();
  toast(`✅ Đã ghi nhận ứng ${money(amount)} cho ${employee}`);
}
function deleteSalaryAdvance(id){
  if(!CloudSync.can('payroll'))return;
  const a=(D.salaryAdvances||[]).find(x=>String(x.id)===String(id));
  if(!a)return;
  if(!confirm(`Xóa khoản ứng ${money(a.amount)} của ${a.employee} ngày ${fmtDMY(a.date)}?`))return;
  D.salaryAdvances=(D.salaryAdvances||[]).filter(x=>String(x.id)!==String(id));
  save();renderPayroll();toast('Đã xóa khoản ứng lương');
}
function renderPayrollAdvanceList(from,to){
  const box=$('payrollAdvanceList');if(!box)return;
  const rows=payrollAdvanceEntries(from,to).sort((a,b)=>String(b.date).localeCompare(String(a.date))||Number(b.createdAtMs||0)-Number(a.createdAtMs||0));
  const total=rows.reduce((s,a)=>s+Number(a.amount||0),0);
  if(!rows.length){box.innerHTML='<div class="empty">Chưa có khoản ứng lương trong khoảng thời gian đã chọn.</div>';return}
  box.innerHTML=`<div class="section-title"><h4 style="margin:0">📋 Khoản ứng trong kỳ</h4><span class="badge">${money(total)}</span></div><div class="payroll-table-wrap"><table class="payroll-table compact"><thead><tr><th>Ngày</th><th>Nhân viên</th><th>Số tiền ứng</th><th>Ghi chú</th><th></th></tr></thead><tbody>${rows.map(a=>`<tr><td>${fmtDMY(a.date)}</td><td><b>${esc(a.employee)}</b></td><td><b>${money(a.amount)}</b></td><td style="text-align:left;white-space:normal">${esc(a.note||'')}</td><td><button class="secondary" type="button" onclick="deleteSalaryAdvance('${esc(a.id)}')">Xóa</button></td></tr>`).join('')}</tbody><tfoot><tr><th colspan="2">TỔNG ỨNG</th><th>${money(total)}</th><th colspan="2"></th></tr></tfoot></table></div>`;
}
function renderPayroll(){
  if(!CloudSync.can('payroll'))return;
  const {from,to}=payrollDateRange();
  if($('pFrom'))$('pFrom').value=from;
  if($('pTo'))$('pTo').value=to;
  const by=payrollEntries(from,to),days=payrollDays(from,to),emps=employees(),adv=payrollAdvanceByEmployee(from,to);
  let totalQty=0,totalGross=0,totalAdvance=0,totalNet=0;
  emps.forEach(e=>{const v=by[e]||{qty:0,pay:0};const a=Number(adv[e]?.total)||0;totalQty+=v.qty||0;totalGross+=v.pay||0;totalAdvance+=a;totalNet+=(v.pay||0)-a});
  const selected=String($('payrollEmployee')?.value||'');
  if($('payrollEmployee'))$('payrollEmployee').innerHTML='<option value="">-- Chọn nhân viên --</option>'+emps.map(e=>`<option value="${esc(e)}" ${e===selected?'selected':''}>${esc(e)}</option>`).join('');
  if($('advanceEmployee'))$('advanceEmployee').innerHTML='<option value="">-- Chọn nhân viên --</option>'+emps.map(e=>`<option value="${esc(e)}" ${e===String($('advanceEmployee').value||'')?'selected':''}>${esc(e)}</option>`).join('');
  if($('advanceDate')&&!$('advanceDate').value)$('advanceDate').value=to;
  let html=`<div class="card"><div class="section-title"><h3>📋 Bảng lương tổng hợp</h3><span class="badge">${fmtDMY(from)} – ${fmtDMY(to)}</span></div><div class="payroll-summary-grid"><div class="stat"><span>Tổng số cây</span><b>${Math.round(totalQty)}</b></div><div class="stat"><span>Lương gộp</span><b>${money(totalGross)}</b></div><div class="stat"><span>Đã ứng</span><b>${money(totalAdvance)}</b></div><div class="stat"><span>Thực nhận</span><b>${money(totalNet)}</b></div></div><div class="payroll-table-wrap"><table class="payroll-table"><thead><tr><th>Nhân viên</th><th>Cây</th><th>Lương gộp</th><th>Đã ứng</th><th>Thực nhận</th><th>Xem</th></tr></thead><tbody>`;
  emps.forEach(e=>{const v=by[e]||{qty:0,pay:0};const a=Number(adv[e]?.total)||0;html+=`<tr><td><b>${esc(e)}</b></td><td>${Math.round(v.qty||0)}</td><td>${money(v.pay||0)}</td><td>${money(a)}</td><td><b>${money((v.pay||0)-a)}</b></td><td><button class="secondary" type="button" onclick="selectPayrollEmployee('${encodeURIComponent(e)}')">Xem</button></td></tr>`});
  html+=`</tbody><tfoot><tr><th>TỔNG</th><th>${Math.round(totalQty)}</th><th>${money(totalGross)}</th><th>${money(totalAdvance)}</th><th>${money(totalNet)}</th><th></th></tr></tfoot></table></div></div>`;
  html+=`<div class="card"><div class="section-title"><h3>📅 Cộng dồn theo ngày</h3><span class="badge">${days.length} ngày</span></div><div class="tiny muted" style="margin-bottom:8px">Lũy kế ở đây là <b>lũy kế thực nhận</b> = lương trong ngày − tiền ứng trong ngày.</div><div class="payroll-day-list">`;
  emps.forEach(e=>{const v=by[e]||{days:{}},av=adv[e]||{days:{}};let cumulative=0;html+=`<div class="payroll-emp-block"><div class="payroll-emp-title"><b>${esc(e)}</b><span>Thực nhận: ${money((v.pay||0)-(av.total||0))}</span></div><div class="payroll-table-wrap"><table class="payroll-table compact"><thead><tr><th>Ngày</th><th>Cây</th><th>Lương ngày</th><th>Ứng</th><th>Thực nhận ngày</th><th>Lũy kế thực nhận</th></tr></thead><tbody>`;days.forEach(date=>{const d=v.days?.[date]||{qty:0,pay:0},a=Number(av.days?.[date])||0,net=(Number(d.pay)||0)-a;cumulative+=net;html+=`<tr><td>${fmtDMY(date)}</td><td>${Math.round(d.qty||0)}</td><td>${money(d.pay||0)}${((d.manualPay||0)||(d.orderPay||0))?`<div class="tiny muted">${d.manualPay?`Nhập: ${money(d.manualPay)}`:''}${d.manualPay&&d.orderPay?' · ':''}${d.orderPay?`Đơn: ${money(d.orderPay)}`:''}</div>`:''}</td><td>${a?'-'+money(a):money(0)}</td><td><b>${money(net)}</b></td><td><b>${money(cumulative)}</b></td></tr>`});html+=`</tbody></table></div></div>`});
  html+=`</div></div><div id="payrollEmployeeDetail"></div>`;
  $('payrollBody').innerHTML=html;
  renderPayrollEmployeeDetail();renderPayrollAdvanceList(from,to);updateAdvanceAvailable();
}
function selectPayrollEmployee(encoded){const name=decodeURIComponent(encoded||'');if($('payrollEmployee'))$('payrollEmployee').value=name;if($('advanceEmployee'))$('advanceEmployee').value=name;renderPayrollEmployeeDetail();document.getElementById('payrollEmployeeDetail')?.scrollIntoView({behavior:'smooth',block:'start'})}
function renderPayrollEmployeeDetail(){
  const box=$('payrollEmployeeDetail');if(!box)return;
  const name=String($('payrollEmployee')?.value||'').trim();
  if(!name){box.innerHTML='';return}
  const {from,to}=payrollDateRange(),by=payrollEntries(from,to),adv=payrollAdvanceByEmployee(from,to),v=by[name]||{qty:0,basePay:0,adjustment:0,pay:0,days:{}},a=adv[name]||{total:0,days:{}},days=payrollDays(from,to);
  let cumulative=0,rows='';
  days.forEach(date=>{const d=v.days?.[date]||{qty:0,basePay:0,adjustment:0,pay:0},advance=Number(a.days?.[date])||0,net=(Number(d.pay)||0)-advance;cumulative+=net;rows+=`<tr><td>${fmtDMY(date)}</td><td>${Math.round(d.qty||0)}</td><td>${money(d.pay||0)}${((d.manualPay||0)||(d.orderPay||0))?`<div class="tiny muted">${d.manualPay?`Nhập: ${money(d.manualPay)}`:''}${d.manualPay&&d.orderPay?' · ':''}${d.orderPay?`Đơn: ${money(d.orderPay)}`:''}</div>`:''}</td><td>${advance?'-'+money(advance):money(0)}</td><td><b>${money(net)}</b></td><td><b>${money(cumulative)}</b></td></tr>`});
  box.innerHTML=`<div class="payroll-detail"><div class="payroll-detail-head"><div><h4>👤 ${esc(name)}</h4><div class="tiny muted">Chi tiết từ ${fmtDMY(from)} đến ${fmtDMY(to)}</div></div><button class="secondary" type="button" onclick="$('payrollEmployee').value='';renderPayrollEmployeeDetail()">Đóng</button></div><div class="payroll-summary-grid"><div class="stat"><span>Tổng cây</span><b>${Math.round(v.qty||0)}</b></div><div class="stat"><span>Lương gộp</span><b>${money(v.pay||0)}</b></div><div class="stat"><span>Đã ứng</span><b>${money(a.total||0)}</b></div><div class="stat"><span>Thực nhận</span><b>${money((v.pay||0)-(a.total||0))}</b></div></div><div class="payroll-table-wrap"><table class="payroll-table compact"><thead><tr><th>Ngày</th><th>Cây</th><th>Lương ngày</th><th>Ứng</th><th>Thực nhận ngày</th><th>Lũy kế thực nhận</th></tr></thead><tbody>${rows}</tbody><tfoot><tr><th>TỔNG</th><th>${Math.round(v.qty||0)}</th><th>${money(v.pay||0)}</th><th>${a.total?'-'+money(a.total):money(0)}</th><th>${money((v.pay||0)-(a.total||0))}</th><th>${money((v.pay||0)-(a.total||0))}</th></tr></tfoot></table></div></div>`;
}
function exportPayrollCsv(){
  if(!CloudSync.can('payroll'))return;const {from,to}=payrollDateRange(),by=payrollEntries(from,to),days=payrollDays(from,to),adv=payrollAdvanceByEmployee(from,to),lines=[];
  lines.push([csvCell('BẢNG LƯƠNG ROLL CÂY CẢNH')].join(','));lines.push([csvCell('Từ ngày'),csvCell(fmtDMY(from)),csvCell('Đến ngày'),csvCell(fmtDMY(to))].join(','));lines.push('');lines.push(['Ngày','Nhân viên','Số cây','Lương gộp ngày','Ứng lương','Thực nhận ngày','Lũy kế thực nhận'].map(csvCell).join(','));
  employees().forEach(e=>{let cumulative=0;days.forEach(date=>{const d=by[e]?.days?.[date]||{qty:0,pay:0},a=Number(adv[e]?.days?.[date])||0,net=(Number(d.pay)||0)-a;cumulative+=net;lines.push([date,e,Math.round(d.qty||0),Math.round(d.pay||0),Math.round(a),Math.round(net),Math.round(cumulative)].map(csvCell).join(','))})});
  lines.push('');lines.push(['NHÂN VIÊN','TỔNG CÂY','LƯƠNG GỘP','ĐÃ ỨNG','THỰC NHẬN'].map(csvCell).join(','));employees().forEach(e=>{const v=by[e]||{qty:0,pay:0},a=Number(adv[e]?.total)||0;lines.push([e,Math.round(v.qty||0),Math.round(v.pay||0),Math.round(a),Math.round((v.pay||0)-a)].map(csvCell).join(','))});
  lines.push('');lines.push(['CHI TIẾT ỨNG LƯƠNG','Ngày','Nhân viên','Số tiền','Ghi chú'].map(csvCell).join(','));payrollAdvanceEntries(from,to).sort((a,b)=>String(a.date).localeCompare(String(b.date))).forEach(a=>lines.push(['Ứng lương',a.date,a.employee,Math.round(a.amount||0),a.note||''].map(csvCell).join(',')));
  downloadText(`Bang-luong-ROLL-CAY-CANH-${from}-${to}.csv`,'\ufeff'+lines.join('\r\n'));if(!(window.AndroidBridge&&AndroidBridge.saveFile))toast('Đã xuất bảng lương CSV — mở bằng Excel')
}
function exportReportCsv(){syncReportDateLimits();const from=$('rFrom').value||START,to=$('rTo').value||from;const lines=[];lines.push([csvCell('BÁO CÁO ROLL CÂY CẢNH')].join(','));lines.push([csvCell('Từ ngày'),csvCell(fmtDMY(from)),csvCell('Đến ngày'),csvCell(fmtDMY(to))].join(','));let totalIn=0,totalOut=0,totalPayValue=0;D.daily.filter(x=>x.date>=from&&x.date<=to).forEach(x=>{totalIn+=Number(x.in)||0;totalOut+=outOf(x);totalPayValue+=payOf(x)});const completedOrders=completedOrderRecords().filter(r=>r.date>=from&&r.date<=to);totalOut+=completedOrders.reduce((s,r)=>s+(Number(r.qty)||0),0);totalPayValue+=completedOrders.reduce((s,r)=>s+packerPay(r),0);lines.push([csvCell('Tổng nhập kho'),Math.round(totalIn),csvCell('Tổng đóng hàng'),Math.round(totalOut),csvCell('Tổng tiền công'),Math.round(totalPayValue),csvCell('Tồn cuối'),Math.round(totalStock(to))].join(','));lines.push('');lines.push(['Ngày','Cây','Kích thước','Nhập kho','Nhân viên','Số cây đóng','Đơn giá/cây','Tiền theo cây','Điều chỉnh tiền','Tổng tiền công','Tồn đầu ngày','Tồn cuối','Ghi chú điều chỉnh'].map(csvCell).join(','));D.daily.filter(x=>x.date>=from&&x.date<=to).sort((a,b)=>a.date.localeCompare(b.date)||catalogIndexById(catalogIdFromRecord(a))-catalogIndexById(catalogIdFromRecord(b))).forEach(x=>{const p=catalogById(catalogIdFromRecord(x));if(!p)return;const names=new Set([...Object.keys(x.counts||{}),...(x.adjustments||[]).map(a=>a.employee)]);if(!names.size)names.add('');names.forEach(emp=>{const q=Number(x.counts?.[emp])||0,w=rate(p.size),adj=adjustmentsOf(x,emp),total=q*w+adj;const notes=(x.adjustments||[]).filter(a=>a.employee===emp&&a.note).map(a=>a.note).join(' | ');lines.push([x.date,p.name,p.size||'',Number(x.in)||0,emp,q,w,q*w,adj,total,Math.round(opening(x.catalogId,x.date)),Math.round(closing(x.catalogId,x.date)),notes].map(csvCell).join(','))})});completedOrders.forEach(r=>{const p=catalogById(String(r.catalogId||''));const q=Number(r.qty)||0;const w=rate(r.size);const adj=Number(r.payAdjustment)||0;const total=packerPay(r);lines.push([r.date,p?.name||r.plantName||'',p?.size||r.size||'',0,r.employee||'Nhân viên',q,w,q*w,adj,total,Math.round(opening(String(r.catalogId||''),r.date)),Math.round(closing(String(r.catalogId||''),r.date)),r.payAdjustmentNote||''].map(csvCell).join(','))});lines.push('');lines.push(['Nhân viên','Số cây','Tiền công + điều chỉnh'].map(csvCell).join(','));employees().forEach(emp=>{let qty=0,pay=0;D.daily.filter(x=>x.date>=from&&x.date<=to).forEach(x=>{qty+=Number(x.counts?.[emp])||0;pay+=employeePay(x,emp)});completedOrders.filter(r=>String(r.employee||'')===String(emp)).forEach(r=>{qty+=Number(r.qty)||0;pay+=packerPay(r)});lines.push([emp,Math.round(qty),Math.round(pay)].map(csvCell).join(','))});downloadText(`Bao-cao-ROLL-CAY-CANH-${from}-${to}.csv`,'\ufeff'+lines.join('\r\n'));if(!(window.AndroidBridge&&AndroidBridge.saveFile))toast('Đã xuất file báo cáo CSV')}
function exportData(){const blob=new Blob([JSON.stringify(D,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='ROLL-CAY-CANH-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function importData(ev){const f=ev.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{D=JSON.parse(r.result);if(!D.opening)D.opening={};repairCanonicalConfig();save();renderAll();toast('Đã nhập dữ liệu sao lưu')}catch(e){toast('File sao lưu không hợp lệ')}};r.readAsText(f);ev.target.value=''}
function restoreExcelDefaults(){if(!confirm('Khôi phục danh mục cây, nhân viên và đơn giá theo Excel gốc? Dữ liệu đã nhập theo ngày sẽ được giữ lại.'))return;const keepDaily=D.daily,keepOpening=D.opening;D=structuredClone(DEFAULT_DATA);D.daily=keepDaily;D.opening=keepOpening;repairCanonicalConfig();save();renderAll();toast('Đã khôi phục danh mục Excel')}
const CLOUD_CONFIG = window.ROLL_CAY_FIREBASE_CONFIG || null;
const ADMIN_EMAIL='tiennt9939@gmail.com';
const ROLE_LABELS={admin:'Quản trị viên',manager:'Quản lý',packer:'Nhân viên đóng hàng',warehouse:'Nhân viên kho',procurement:'Nhân viên thu mua',purchaser:'Nhân viên thu mua (cũ)',viewer:'Chỉ xem'};
const ROLE_PERMS={admin:['pack','in','report','payroll','control','users','quote','catalog'],manager:['pack','in','report'],packer:['pack'],warehouse:['in'],procurement:['quote','catalog'],purchaser:['quote','catalog'],viewer:['report']};
function notificationKey(){const st=window.CloudSync?.state?.();return st?.role==='admin'?'admin':(st?.user?.uid||'guest')}
function updateOrderNotificationUI(pending,completed){orderNotificationState.pending=Math.max(0,Number(pending)||0);orderNotificationState.completed=Math.max(0,Number(completed)||0);const b=$('orderBellBadge'),bell=$('orderBell');if(b){b.textContent=orderNotificationState.pending>99?'99+':String(orderNotificationState.pending);b.classList.toggle('show',orderNotificationState.pending>0)}if(bell)bell.classList.toggle('has-alert',orderNotificationState.pending>0);const ac=$('adminOrderStats');const isAdmin=window.CloudSync?.state?.().role==='admin';if(ac)ac.classList.toggle('show',!!isAdmin);if(ac)ac.classList.toggle('perm-hidden',!isAdmin);if(isAdmin){$('adminPendingCount')&&($('adminPendingCount').textContent=String(orderNotificationState.pending));$('adminCompletedCount')&&($('adminCompletedCount').textContent=String(orderNotificationState.completed))}}
function unlockOrderAlertAudio(){try{if(!orderAlertAudioCtx)orderAlertAudioCtx=new(window.AudioContext||window.webkitAudioContext)();if(orderAlertAudioCtx.state==='suspended')orderAlertAudioCtx.resume()}catch(e){}}
function playOrderAlertSound(){try{unlockOrderAlertAudio();if(!orderAlertAudioCtx)return;const ctx=orderAlertAudioCtx;[0,0.18,0.36].forEach((delay,i)=>{const o=ctx.createOscillator(),g=ctx.createGain();o.type='sine';o.frequency.value=i===1?880:660;g.gain.setValueAtTime(.0001,ctx.currentTime+delay);g.gain.exponentialRampToValueAtTime(.16,ctx.currentTime+delay+.02);g.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+delay+.14);o.connect(g);g.connect(ctx.destination);o.start(ctx.currentTime+delay);o.stop(ctx.currentTime+delay+.16)})}catch(e){}}
function vibrateOrderAlert(){try{navigator.vibrate&&navigator.vibrate([120,70,120,70,180])}catch(e){}}
function renderOrderAlertList(rows){
  const box=$('orderAlertList');if(!box)return;
  const pending=(Array.isArray(rows)?rows:[]).filter(x=>x&&x.status!=='completed');
  if(!pending.length){box.innerHTML='<div class="tiny muted">Không còn đơn chờ xử lý. Danh sách đã được cập nhật.</div>';return}
  box.innerHTML=pending.slice(0,30).map(r=>`<button type="button" class="order-alert-row" onclick="openOrderFromAlert('${esc(String(r.id||''))}')"><div><b>${orderItemsLabel(r)}</b><div class="tiny muted">Đơn #${esc(r.orderNo||String(r.id||'').slice(-6))} · ${Math.round(orderTotalQty(r))} cây/combo${r.employee?` · ${esc(r.employee)}`:''}</div></div><span>›</span></button>`).join('')+(pending.length>30?`<div class="tiny muted" style="padding:7px 2px">Còn ${pending.length-30} đơn khác.</div>`:'');
}
function showOrderAlert(pending,source='',rows=[]){
  if(!Array.isArray(rows)||!rows.length)rows=Array.isArray(orderNotificationState.rows)?orderNotificationState.rows:[];
  $('orderAlertCount')&&($('orderAlertCount').textContent=String(pending));
  $('orderAlertText')&&($('orderAlertText').textContent=source==='admin'?`Hiện có ${pending} đơn chưa hoàn tất trong hệ thống.`:`Bạn đang có ${pending} đơn được phân công cần đóng.`);
  renderOrderAlertList(rows);
  $('orderAlertModal')?.classList.add('show');playOrderAlertSound();vibrateOrderAlert();
}
async function refreshOrdersForNotification(){
  const st=window.CloudSync?.state?.();
  if(!st?.user||!db)return [];
  const watched=Array.isArray(orderNotificationState.rows)?orderNotificationState.rows.filter(Boolean):[];
  const cached=Array.isArray(D.packingOrders)?D.packingOrders.filter(Boolean):[];
  const filterMine=rows=>st.role==='packer'
    ? rows.filter(x=>String(x.assignedUid||'')===String(st.user.uid))
    : rows;
  try{
    // Khi người dùng CHỦ ĐỘNG bấm chuông, đọc thẳng Firestore một lần.
    // Đây là nguồn xác nhận cuối cùng; listener chỉ dùng để cập nhật badge theo thời gian thực.
    // Với packer, query luôn phải có assignedUid == auth.uid để khớp Security Rules.
    let fresh=[];
    if(st.role==='packer'){
      const snap=await db.collection('packingOrders').where('assignedUid','==',st.user.uid).get();
      fresh=normalizeOrders(snap.docs.map(d=>({id:d.id,...d.data()})));
    }else if(st.role==='admin'){
      const snap=await db.collection('packingOrders').get();
      fresh=normalizeOrders(snap.docs.map(d=>({id:d.id,...d.data()})));
    }
    const freshMine=filterMine(fresh);
    // Với nhân viên, listener đã chứng minh có đơn thì một lần get() trả []
    // không được phép xóa danh sách đang hiển thị. Đây là điểm gây lỗi:
    // vừa đăng nhập thấy 8 đơn, bấm XEM ĐƠN NGAY lại thành 0 đơn.
    // Listener là nguồn realtime; get() chỉ dùng để làm mới khi có dữ liệu.
    let rows=freshMine;
    const known=filterMine(watched.length?watched:cached);
    if(st.role==='packer' && !freshMine.length && known.length){
      rows=known;
    }else if(!freshMine.length && fresh.length===0 && known.length){
      rows=known;
    }else if(!freshMine.length && fresh.length>0){
      rows=known;
    }
    orderNotificationState.rows=rows.slice();
    if(st.role==='packer')D.packingOrders=rows.slice();
    else if(st.role==='admin')D.packingOrders=rows.slice();
    localSaveOnly();
    if(st.role==='admin')await renderAssignmentControls();
    const pending=rows.filter(x=>x.status!=='completed').length;
    const completed=rows.filter(x=>x.status==='completed').length;
    updateOrderNotificationUI(pending,completed);
    return rows;
  }catch(e){
    console.error('refreshOrdersForNotification',e);
    // Không biến lỗi mạng/quyền thành “0 đơn”. Giữ dữ liệu listener/cache nếu còn.
    let rows=filterMine(watched.length?watched:cached);
    if(!rows.length && st.role==='packer')rows=restorePackerOrderCache(st.user.uid);
    if(rows.length){
      updateOrderNotificationUI(rows.filter(x=>x.status!=='completed').length,rows.filter(x=>x.status==='completed').length);
      return rows;
    }
    toast('Không tải được đơn: '+(e?.message||e?.code||'Lỗi Cloud'));
    return [];
  }
}

function persistPackerOrderCache(rows,uid){
  try{
    if(!uid)return;
    const safe=(Array.isArray(rows)?rows:[]).filter(x=>x&&String(x.assignedUid||'')===String(uid));
    localStorage.setItem('ROLL_CAY_PACKER_ORDERS_'+String(uid),JSON.stringify(safe));
  }catch(e){console.warn('persistPackerOrderCache',e)}
}
function restorePackerOrderCache(uid){
  try{
    if(!uid)return [];
    const raw=localStorage.getItem('ROLL_CAY_PACKER_ORDERS_'+String(uid));
    const rows=raw?JSON.parse(raw):[];
    return Array.isArray(rows)?rows.filter(x=>x&&String(x.assignedUid||'')===String(uid)):[];
  }catch(e){return []}
}
function activatePackerOrdersView(){
  try{
    hideLoginGate();
    document.querySelectorAll('.bottomnav button').forEach(b=>b.classList.toggle('active',b.dataset.tab==='day'));
    document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.id==='day'));
    const packForm=$('packForm'),inForm=$('inForm'),adminPanel=$('adminPackEntryPanel'),assignCard=$('orderAssignCard');
    if(packForm){packForm.classList.remove('hidden');packForm.style.display='block'}
    if(inForm){inForm.classList.add('hidden');inForm.style.display='none'}
    if(adminPanel){adminPanel.classList.add('perm-hidden');adminPanel.style.display='none'}
    if(assignCard){assignCard.classList.add('perm-hidden');assignCard.style.display='none'}
    if($('modePack')){$('modePack').classList.add('hidden');$('modePack').style.display='none'}
    if($('modeIn')){$('modeIn').classList.add('hidden');$('modeIn').style.display='none'}
    if($('entryInfoPacker'))$('entryInfoPacker').classList.remove('hidden');
    if($('packerOrderPanel')){$('packerOrderPanel').classList.remove('perm-hidden');$('packerOrderPanel').style.display='block'}
    renderPackerOrders();
    return true;
  }catch(e){console.error('activatePackerOrdersView',e);toast('Không thể mở danh sách đơn. Đơn vẫn được giữ lại.');return false}
}
async function openOrderNotifications(){
  // V24 ROOT FIX: the bell must NEVER be blocked by the transient Firebase Auth session gate.
  // If the realtime listener already populated the bell (badge > 0), those rows are the
  // authenticated user's canonical /packingOrders data. Open them immediately.
  unlockOrderAlertAudio();
  try{
    let st=window.CloudSync?.state?.()||{};
    const bellRole=String(orderNotificationState.role||st.role||'');
    let rows=Array.isArray(orderNotificationState.rows)?orderNotificationState.rows.filter(Boolean):[];
    if(!rows.length)rows=Array.isArray(D.packingOrders)?D.packingOrders.filter(Boolean):[];

    // Listener-owned rows are already permission-scoped: packer rows were queried by assignedUid.
    // Only filter when a concrete UID is available; never discard valid listener rows because
    // firebase.auth().currentUser is temporarily null inside Android WebView.
    const uid=String(st?.user?.uid||'');
    if(bellRole==='packer'&&uid)rows=rows.filter(x=>String(x.assignedUid||'')===uid);

    const pending=rows.filter(x=>x&&x.status!=='completed');
    if(pending.length){
      orderNotificationState.rows=rows.slice();
      if(bellRole==='packer'&&uid)D.packingOrders=rows.slice();
      showOrderAlert(pending.length,bellRole==='admin'?'admin':'packer',rows);
      return;
    }

    // No cached rows: only now try a Firestore refresh. This is a data-load fallback,
    // not an Auth gate for the bell.
    let fresh=[];
    try{fresh=await refreshOrdersForNotification()}catch(e){console.warn('bell refresh',e)}
    const freshPending=(Array.isArray(fresh)?fresh:[]).filter(x=>x&&x.status!=='completed');
    if(freshPending.length){
      showOrderAlert(freshPending.length,bellRole==='admin'?'admin':'packer',fresh);
      return;
    }
    toast('🔔 Hiện không có đơn nào đang chờ xử lý');
  }catch(e){
    console.error('openOrderNotifications',e);
    // Never show the old misleading "Firebase session" error from the bell.
    toast('Không thể mở danh sách đơn. Dữ liệu đơn vẫn được giữ nguyên.');
  }
}
function closeOrderNotifications(){$('orderAlertModal')?.classList.remove('show')}
async function openOrderFromAlert(id){
  try{
    const orderId=String(id||'').trim();if(!orderId){toast('Không xác định được đơn hàng');return}
    const bellRole=String(orderNotificationState.role||'');
    let rows=Array.isArray(orderNotificationState.rows)?orderNotificationState.rows.filter(Boolean):[];if(!rows.length)rows=Array.isArray(D.packingOrders)?D.packingOrders.filter(Boolean):[];
    const target=rows.find(x=>String(x.id)===orderId);
    if(bellRole==='packer'){
      if(!target){toast('Đơn hàng không còn trong danh sách được phân công');return}
      const uid=String(orderNotificationState.uid||'').trim();if(uid&&String(target.assignedUid||'')!==uid){toast('Đơn hàng không thuộc tài khoản hiện tại');return}
      const mine=uid?rows.filter(x=>String(x.assignedUid||'')===uid):rows.slice();D.packingOrders=mine.slice();orderNotificationState.rows=mine.slice();if(uid)persistPackerOrderCache(mine,uid);
      selectedOrderId=(target.status==='completed')?null:orderId;if(selectedOrderId)resetPackProof();
      closeOrderNotifications();
      activatePackerOrdersView();
      renderPackerOrders();
      return;
    }
    toast('Tài khoản hiện tại chưa xác định quyền đóng hàng.');
  }catch(e){console.error('openOrderFromAlert',e);toast('Không thể mở đơn. Dữ liệu đơn vẫn được giữ nguyên.')}
}

function goToPendingOrders(ev){
  if(ev){ev.preventDefault();ev.stopPropagation()}
  try{
    const roleName=String(orderNotificationState.role||'');
    let rows=Array.isArray(orderNotificationState.rows)?orderNotificationState.rows.filter(Boolean):[];if(!rows.length)rows=Array.isArray(D.packingOrders)?D.packingOrders.filter(Boolean):[];
    if(roleName==='packer'){
      const uid=String(orderNotificationState.uid||'').trim();if(uid)rows=rows.filter(x=>String(x.assignedUid||'')===uid);if(!rows.length&&uid)rows=restorePackerOrderCache(uid);
      if(!rows.length){toast('🔔 Không tìm thấy dữ liệu đơn trên máy. Vui lòng chờ thông báo tải lại.');return false}
      D.packingOrders=rows.slice();orderNotificationState.rows=rows.slice();if(uid)persistPackerOrderCache(rows,uid);
      // Đã xác định đây là danh sách của packer: mở trực tiếp đúng khu vực xử lý đơn.
      closeOrderNotifications();
      activatePackerOrdersView();
      renderPackerOrders();
      return false;
    }
    if(roleName==='admin'){closeOrderNotifications();if(rows.length){D.packingOrders=rows.slice();renderAssignmentControls();go('day','pack');return false}}
    toast('Tài khoản hiện tại chưa xác định là nhân viên đóng hàng.');
  }catch(e){console.error('goToPendingOrders',e);toast('Không thể mở danh sách đơn. Dữ liệu đơn vẫn được giữ nguyên.')}
  return false;
}

function maybeAlertForPending(pending,roleName,rows=[]){const key='ROLL_CAY_LAST_PENDING_'+notificationKey();const raw=localStorage.getItem(key);const previous=raw===null?null:Number(raw);localStorage.setItem(key,String(pending));if(previous!==null&&pending>previous){showOrderAlert(pending,roleName,rows);toast(`🔔 Có ${pending} đơn đang chờ đóng`)}else if(previous===null&&pending>0){showOrderAlert(pending,roleName,rows);toast(roleName==='admin'?`🔔 Có ${pending} đơn chưa hoàn tất`:`🔔 Bạn có ${pending} đơn cần đóng`)}}
const CloudSync = (()=>{
  let app=null,auth=null,db=null,user=null,pushTimer=null,ready=false,authReady=false,profile=null,orderUnsubs=[],initPromise=null,sessionEpoch=0;
  const sharedRef=()=>db.collection('apps').doc('roll-cay-canh');
  const configRef=()=>db.collection('config').doc('roll-cay-canh');
  const packerEntriesRef=uid=>db.collection('packerRecords').doc(uid).collection('entries');
  const ordersRef=()=>db.collection('packingOrders');
  const profileRef=uid=>db.collection('users').doc(uid);
  function setStatus(text,kind=''){const s=$('cloudStatus'),d=$('cloudDot'),b=$('syncBadge'),u=$('syncUser');if(s)s.textContent=text;if(d)d.className='cloud-dot '+kind;if(b)b.textContent=text;if(u)u.innerHTML=user?`Tài khoản: ${esc(user.email||'')} · <span class="role-pill">${esc(ROLE_LABELS[profile?.role]||'Đang kiểm tra quyền')}</span>`:'Đăng nhập để dùng chung dữ liệu trên nhiều điện thoại.'}
  function available(){return !!(CLOUD_CONFIG&&CLOUD_CONFIG.apiKey&&CLOUD_CONFIG.projectId&&window.firebase)}
  function currentAuthUser(){try{return auth?.currentUser||null}catch(e){return null}}
  function sessionUsable(){const au=currentAuthUser();return !!(au&&user&&profile&&String(au.uid)===String(user.uid)&&profile.active!==false)}
  async function ensureActionSession(timeoutMs=8000){
    const deadline=Date.now()+Number(timeoutMs||8000);
    try{if(!auth||!db){await init()}}catch(e){console.warn('init for action session',e)}
    while(Date.now()<deadline){
      // Sau khi onAuthStateChanged đã xác nhận tài khoản, biến `user` là session
      // nội bộ hợp lệ của ứng dụng. `auth.currentUser` có thể tạm thời null trong
      // WebView khi Firebase đang khôi phục persistence; không được biến trạng thái
      // trung gian đó thành lỗi "không xác nhận được phiên".
      const au=currentAuthUser();
      if(au && user && String(au.uid)!==String(user.uid)){
        user=au;profile=null;
      }else if(au && (!user || String(user.uid)!==String(au.uid))){
        user=au;profile=null;
      }
      if(!user && au){user=au;profile=null}
      if(user){
        if(!profile){try{await ensureProfile()}catch(e){console.warn('ensureProfile for action',e)}}
        if(profile && profile.active!==false && !!user?.uid){
          authReady=true;ready=true;orderNotificationState.authReady=true;
          const r=role();
          if((r==='admin'||r==='packer')&&!orderUnsubs.length){try{startOrderWatch()}catch(e){console.error('startOrderWatch for action',e)}}
          return {user,profile,role:r};
        }
      }
      await new Promise(r=>setTimeout(r,100));
    }
    return null;
  }
  function profileUid(p,u){return String(u?.uid||user?.uid||'');}
  function role(){const u=user||currentAuthUser();if(u&&String(u.email||'').trim().toLowerCase()===ADMIN_EMAIL.toLowerCase())return 'admin';const raw=String(profile?.role||'viewer').trim().toLowerCase();if(['purchaser','purchasing','purchasing_staff','procurement_staff','thu_mua','nhan_vien_thu_mua','nhân viên thu mua'].includes(raw))return 'procurement';return raw}
  function can(permission){const u=user||currentAuthUser();const r=role();return !!u&&(r==='admin'||ROLE_PERMS[r]?.includes(permission))}
  function requirePerm(permission){if(can(permission))return true;toast('Tài khoản này không có quyền thực hiện tác vụ này');return false}
  async function ensureProfile(){
    const ref=profileRef(user.uid),snap=await ref.get();
    if(!snap.exists){
      const r=(String(user.email||'').toLowerCase()===ADMIN_EMAIL.toLowerCase())?'admin':'viewer';
      await ref.set({email:user.email||'',displayName:user.displayName||'',role:r,active:true,createdAt:firebase.firestore.FieldValue.serverTimestamp(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()});
      profile={email:user.email||'',displayName:user.displayName||'',role:r,active:true};
    } else { profile=snap.data(); if(profile.active===false){toast('Tài khoản đã bị khóa');await auth.signOut();return false;} }
    if(String(user.email||'').toLowerCase()===ADMIN_EMAIL.toLowerCase()){const patch={role:'admin',active:true,updatedAt:firebase.firestore.FieldValue.serverTimestamp()};if(profile.employeeId||profile.employeeName){patch.employeeId=firebase.firestore.FieldValue.delete();patch.employeeName=firebase.firestore.FieldValue.delete();}await ref.set(patch,{merge:true});profile={...profile,role:'admin',active:true};delete profile.employeeId;delete profile.employeeName;}
    return true;
  }
  function stopOrderWatch(){orderUnsubs.forEach(fn=>{try{fn&&fn()}catch(e){}});orderUnsubs=[];orderNotificationState={pending:0,completed:0,ready:false,role:'',uid:orderNotificationState.uid||'',rows:[],authReady:orderNotificationState.authReady,source:'none'}}
  function startOrderWatch(){
    stopOrderWatch();
    if(!user||!db)return;
    const r=role();
    if(r!=='admin'&&r!=='packer')return;
    orderNotificationState.role=r;orderNotificationState.uid=String(user.uid||'');
    let q=ordersRef();
    if(r==='packer')q=q.where('assignedUid','==',user.uid);
    const unsub=q.onSnapshot(snap=>{
      const rows=normalizeOrders(snap.docs.map(d=>({id:d.id,...d.data()})));
      // /packingOrders is the SINGLE source of truth for assignment workflow.
      orderNotificationState.rows=rows.slice();
      orderNotificationState.ready=true;
      orderNotificationState.source='firestore-listener';
      if(r==='packer'){
        D.packingOrders=rows.slice();
        persistPackerOrderCache(rows,user.uid);
        const completed=rows.filter(x=>x.status==='completed');
        D.packerRecords=completed.map(d=>({id:d.id,...d,uid:user.uid,qty:orderTotalQty(d),image:d.completionImage||'',createdAtMs:Number(d.completedAtMs||Date.now()),employee:d.employee||currentPackerName(),catalogId:resolveOrderCatalogId(d),plantName:d.plantName,size:d.size,date:completedOrderDate(d),payAdjustment:Number(d.payAdjustment)||0,payAdjustmentNote:d.payAdjustmentNote||'',payAmount:Number(d.payAmount)}));
        rebuildPackerDaily();
      }else{
        D.packingOrders=rows.slice();
      }
      // Do not persist the entire D object on every snapshot. The order cache has its own key.
      try{renderAll()}catch(e){console.error('render after order snapshot',e)}
      const pending=rows.filter(x=>x.status!=='completed').length;
      const completedCount=rows.filter(x=>x.status==='completed').length;
      updateOrderNotificationUI(pending,completedCount);
      maybeAlertForPending(pending,r,rows);
    },e=>{
      console.error('packingOrders watcher',e);
      orderNotificationState.ready=false;
      // Never turn a listener error into zero orders. Keep last known rows/cache.
      const cached=r==='packer'&&user?restorePackerOrderCache(user.uid):[];
      if(!orderNotificationState.rows.length&&cached.length)orderNotificationState.rows=cached.slice();
      const msg=e?.code==='permission-denied'?'Không có quyền đọc đơn được phân công. Kiểm tra assignedUid của đơn và tài khoản nhân viên.':('Lỗi theo dõi đơn: '+(e?.message||e?.code||'Không xác định'));
      setStatus(msg,'offline');
    });
    orderUnsubs.push(unsub);
  }
  async function ensureInteractiveSession(){
    if(!auth||!db)return false;
    const au=currentAuthUser();
    if(!au)return false;
    // Repair any transient state mismatch instead of merely reporting "session not ready".
    if(!user || String(user.uid)!==String(au.uid)){user=au;profile=null;authReady=false;ready=false;}
    if(!profile){
      const ok=await ensureProfile();
      if(!ok)return false;
    }
    if(String(user.uid)!==String(au.uid))return false;
    authReady=true;ready=true;orderNotificationState.authReady=true;
    if(role()==='admin'||role()==='packer'){
      if(!orderUnsubs.length)startOrderWatch();
    }
    return true;
  }
  async function init(){
    if(initPromise)return initPromise;
    initPromise=(async()=>{
      try{
        try{await ensureFirebaseSdk()}catch(e){initPromise=null;setStatus('Đang chờ kết nối Firebase…','offline');showLoginGateError('Đang kết nối Firebase…');return false}
        if(!available()){initPromise=null;setStatus('Firebase chưa sẵn sàng','offline');showLoginGateError('Firebase chưa sẵn sàng. Vui lòng thử lại sau giây lát.');return false}
        app=firebase.apps.length?firebase.app():firebase.initializeApp(CLOUD_CONFIG);
        auth=firebase.auth();
        db=firebase.firestore();
        try{await auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL)}catch(e){console.warn('Không đặt được LOCAL persistence',e)}
        try{await db.enablePersistence({synchronizeTabs:true})}catch(e){}
        auth.onAuthStateChanged(async u=>{
          const epoch=++sessionEpoch;
          user=u;profile=null;ready=false;authReady=false;orderNotificationState.authReady=!!u;
          stopOrderWatch();
          if(u){
            try{
              // Auth callbacks are asynchronous. Ignore stale callbacks that belong
              // to an earlier user/session and must never overwrite the current one.
              const isCurrent=()=>epoch===sessionEpoch && String(auth?.currentUser?.uid||'')===String(u.uid);
              if(!isCurrent())return;
              // PHASE 1 — authentication only. Once this succeeds, the session is usable.
              if(!(await ensureProfile())){if(epoch!==sessionEpoch)return;ready=false;authReady=false;orderNotificationState.authReady=false;showLoginGate();return}
              if(!isCurrent())return;
              hideLoginGate();
              authReady=true;
              orderNotificationState.authReady=true;
              // 'ready' means the interactive session is usable. It MUST NOT wait for
              // reconcile/report/push/order-history jobs to finish.
              ready=true;
              setStatus('Đã kết nối · '+(u.email||''),'online');
              renderCloudBody();applyPermissionsUI();

              // PHASE 2 — start canonical order listener immediately. A slow/failing
              // secondary sync job must never disable the bell or the packing workflow.
              startOrderWatch();

              if(role()==='packer'){
                const cachedOrders=restorePackerOrderCache(u.uid);
                if(cachedOrders.length){
                  D.packingOrders=cachedOrders.slice();
                  orderNotificationState.rows=cachedOrders.slice();
                  orderNotificationState.source='local-cache';
                  updateOrderNotificationUI(cachedOrders.filter(x=>x.status!=='completed').length,cachedOrders.filter(x=>x.status==='completed').length);
                }
                // Secondary hydration: never let a failure invalidate the authenticated session.
                try{await loadPackerRecords()}catch(e){console.warn('loadPackerRecords failed; listener remains canonical',e)}
                activatePackerOrdersView();
              }else{
                // Secondary shared-data reconciliation. It may fail without affecting Auth/order watch.
                try{await reconcile()}catch(e){console.warn('reconcile failed; keeping authenticated session',e)}
                if(role()==='admin'){
                  try{await pushNow()}catch(e){console.warn('pushNow failed; keeping authenticated session',e)}
                  try{await loadAllPackerRecords()}catch(e){console.warn('loadAllPackerRecords failed; order listener remains canonical',e)}
                  try{await renderAssignmentControls()}catch(e){console.warn('renderAssignmentControls failed',e)}
                }
                renderControls();
              }
            }catch(e){
              // Only unexpected Auth/profile failures should affect the login gate.
              console.error('post-auth initialization',e);
              ready=true;authReady=true;orderNotificationState.authReady=true;
              setStatus('Đã kết nối · '+(u.email||''),'online');
              try{startOrderWatch()}catch(w){console.error('startOrderWatch',w)}
              toast('⚠️ Một phần dữ liệu đang đồng bộ lại. Bạn vẫn có thể sử dụng các chức năng đã sẵn sàng.');
            }
          }else{
            ready=false;authReady=false;stopOrderWatch();orderNotificationState.authReady=false;showLoginGate();setStatus('Chưa đăng nhập · cần đăng nhập','offline');renderCloudBody();applyPermissionsUI();renderControls();
          }
        });
        return true;
      }catch(e){console.error(e);auth=null;db=null;ready=false;setStatus('Lỗi cấu hình Cloud','offline');showLoginGateError(firebaseError(e));return false}
    })();
    return initPromise;
  }
  async function waitUntilAuthReady(timeoutMs=5000){return !!(await ensureActionSession(timeoutMs))}
  function waitUntilReady(timeoutMs=5000){return waitUntilAuthReady(timeoutMs)}
  // V20.7: dùng /apps/roll-cay-canh làm đường dữ liệu tương thích với Rules cũ.
  // Không để /config làm hỏng đồng bộ/đóng hàng nếu Rules trên Firebase chưa được cập nhật.
  async function loadCloudCatalog(){ return true; }
  function cloudDataSnapshot(){
    ensureCatalogIds();migrateCatalogCanonicalData();const x=JSON.parse(JSON.stringify(D));
    // Giữ catalog/rates và đơn phân công trong document dùng chung để hoạt động với Rules V17/V20 cũ.
    x.packerRecords=[];
    x.catalog=Array.isArray(D.catalog)?D.catalog:[];
    x.rates=Array.isArray(D.rates)?D.rates:[];
    // packingOrders is canonical in /packingOrders and MUST NOT be copied into /apps.
    delete x.packingOrders;
    return x;
  }
  async function writeCloudCatalog(){
    // Catalog đã nằm trong /apps/roll-cay-canh.data, không cần ghi /config nữa.
    return true;
  }
  async function refreshCatalogForAssignment(){
    if(!user||!db||!can('catalog'))return false;
    try{
      // V26.0.0 ROOT CAUSE FIX — OCR + COMPLETION DELETE FIX: assignment UI must NEVER wait for Cloud push/read
      // before showing the catalog already present on this device.
      // A newly-created plant is therefore immediately usable in Chia đơn.
      ensureCatalogIds();
      const localCatalog=Array.isArray(D.catalog)?D.catalog.map(p=>({...p})):[];
      const localKeys=new Set(localCatalog.map(p=>String(p?.catalogId||'')));

      // Render local catalog immediately. Cloud is reconciliation only.
      try{renderAll();}catch(_){ }

      // If local changes are pending, queue the normal Cloud push in the
      // background. It must not block assignment UI or be required for lookup.
      if(localStorage.getItem('quanlycay_dirty')==='1'){
        try{CloudSync.schedulePush();}catch(_){ }
      }

      const snap=await sharedRef().get();
      const incoming=snap.exists?(snap.data()?.data||{}):{};
      const cloudCatalog=Array.isArray(incoming.catalog)?incoming.catalog:[];
      if(!cloudCatalog.length){
        return localCatalog.length>0;
      }

      ensureCatalogIds();
      const currentLocal=Array.isArray(D.catalog)?D.catalog:localCatalog;
      const merged=mergeCatalogCanonical(currentLocal,cloudCatalog,'local');
      D.catalog=merged;
      repairCanonicalConfig();
      localSaveOnly();
      renderAll();
      return true;
    }catch(e){
      // Cloud permission/network failure must never remove the local catalog.
      console.warn('refreshCatalogForAssignment: giữ catalog local',e);
      try{ensureCatalogIds();renderAll();}catch(_){ }
      return Array.isArray(D.catalog)&&D.catalog.length>0;
    }
  }
  async function reconcile(){
    if(!user||!db)return;
    try{
      const ref=sharedRef(),snap=await ref.get();
      const localDirty=localStorage.getItem('quanlycay_dirty')==='1';
      if(localDirty && (can('pack')||can('in')||can('control')||can('catalog'))){
        const ok=await pushNow();
        if(ok){setStatus('Đã đồng bộ dữ liệu đang chờ lên Cloud','online');return}
      }
      const localTs=Number(localStorage.getItem('quanlycay_local_updated')||0);
      if(!snap.exists){
        if(can('control')||can('catalog')){
          const old=await db.collection('users').doc(user.uid).collection('apps').doc('roll-cay-canh').get();
          if(old.exists&&old.data().data){
            D={...D,...old.data().data,catalog:D.catalog||[],rates:D.rates||[],packingOrders:D.packingOrders||[]};
            await ref.set({data:cloudDataSnapshot(),updatedAtMs:Number(old.data().updatedAtMs||Date.now()),updatedAt:firebase.firestore.FieldValue.serverTimestamp(),appVersion:'V20.9',migratedFromUid:user.uid});
            localSaveOnly();renderAll();toast('☁️ Đã chuyển dữ liệu hiện tại lên kho dùng chung');
            return;
          }
          await pushNow();
        }else{
          setStatus('Chưa có dữ liệu dùng chung','offline');
        }
        return;
      }
      const cloud=snap.data();
      if(cloud.data){
        // V20.8: Cloud rỗng không được phép xoá cấu hình hiện có trên máy.
        // Catalog/rates/daily/opening là dữ liệu nghiệp vụ; chỉ nhận từ Cloud khi thực sự có dữ liệu.
        if(role()==='packer' || Number(cloud.updatedAtMs||0)>=localTs){
          const incoming=cloud.data||{};
          const localCatalog=Array.isArray(D.catalog)?D.catalog:[];
          const localRates=Array.isArray(D.rates)?D.rates:[];
          const localEmployees=Array.isArray(D.employees)?D.employees:[];
          const localDaily=Array.isArray(D.daily)?D.daily:[];
          const localOpening=(D.opening&&typeof D.opening==='object')?D.opening:{};
          const cloudCatalog=Array.isArray(incoming.catalog)?incoming.catalog:[];
          const cloudRates=Array.isArray(incoming.rates)?incoming.rates:[];
          const cloudEmployees=Array.isArray(incoming.employees)?incoming.employees:[];
          const cloudDaily=Array.isArray(incoming.daily)?incoming.daily:[];
          const cloudOpening=(incoming.opening&&typeof incoming.opening==='object')?incoming.opening:{};
          const cloudWasMissingConfig=cloudCatalog.length===0 || cloudRates.length===0;
          D={...D,...incoming,
            catalog:cloudCatalog.length?mergeCatalogCanonical(localCatalog,cloudCatalog,'cloud'):localCatalog,
            rates:cloudRates.length?mergeRatesCanonical(localRates,cloudRates,'cloud'):localRates,
            employees:cloudEmployees.length?[...new Set([...localEmployees,...cloudEmployees])]:localEmployees,
            daily:cloudDaily.length?cloudDaily:localDaily,
            opening:Object.keys(cloudOpening).length?cloudOpening:localOpening};
          repairCanonicalConfig();
          // Packer orders are canonical in /packingOrders; never import them from /apps.
          localSaveOnly();renderAll();setStatus('Đã đồng bộ','online');
          // Nếu Cloud từng chứa catalog/rates rỗng, ghi lại bộ dữ liệu đã tự phục hồi.
          if(cloudWasMissingConfig && role()!=='packer')setTimeout(()=>pushNow(),0);
          return;
        }
      }
      if(localTs>Number(cloud.updatedAtMs||0) && (can('pack')||can('in')||can('control')||can('catalog'))){
        await pushNow();
      }else{
        setStatus('Đã đồng bộ','online');
      }
    }catch(e){
      console.error(e);
      setStatus('Lỗi đồng bộ · '+firebaseError(e),'offline');
    }
  }
  async function pushNow(){if(!user||!db)return false;if(role()==='packer'){setStatus('Đã đồng bộ','online');return true}if(!can('pack')&&!can('in')&&!can('control')&&!can('catalog')){setStatus('Chỉ xem · không ghi dữ liệu','online');return false}try{setStatus('Đang đồng bộ…','online');ensureCatalogIds();migrateCatalogCanonicalData();const ref=sharedRef(),ts=Date.now();try{await ref.set({data:cloudDataSnapshot(),packingOrders:firebase.firestore.FieldValue.delete(),updatedAtMs:ts,updatedAt:firebase.firestore.FieldValue.serverTimestamp(),appVersion:'V25.1'},{merge:true})}catch(e){throw new Error('Không ghi được dữ liệu chung /apps/roll-cay-canh: '+(e?.message||e?.code||e))}localStorage.setItem('quanlycay_local_updated',String(ts));localStorage.removeItem('quanlycay_dirty');setStatus('Đã đồng bộ','online');return true}catch(e){console.error(e);setStatus('Lỗi đồng bộ · '+(e?.message||firebaseError(e)),'offline');window.__lastCloudError=e?.message||firebaseError(e);return false}}
  function schedulePush(){clearTimeout(pushTimer);if(!user||role()==='packer'||(!can('pack')&&!can('in')&&!can('control')&&!can('catalog')))return;pushTimer=setTimeout(()=>pushNow(),1200)}
  async function signIn(email,password,remember=true){
    try{await ensureFirebaseSdk()}catch(e){showLoginGateError('Không tải được Firebase. Hãy kiểm tra kết nối mạng rồi bấm ĐĂNG NHẬP lại.');return false}
    if(!available()){showLoginGateError('Firebase chưa sẵn sàng. Vui lòng thử lại sau giây lát.');return false}
    try{
      if(remember&&email)localStorage.setItem('ROLL_CAY_REMEMBER_EMAIL',email);else localStorage.removeItem('ROLL_CAY_REMEMBER_EMAIL');
      if(!email||!password){showLoginGateError('Vui lòng nhập tên đăng nhập và mật khẩu');return false}
      // Chặn lỗi race khi người dùng bấm ĐĂNG NHẬP trước khi CloudSync.init() hoàn tất.
      if(!auth)await init();
      if(!auth){showLoginGateError('Cloud chưa sẵn sàng. Vui lòng chờ ứng dụng kết nối rồi thử lại.');return false}
      try{await auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL)}catch(e){}
      await auth.signInWithEmailAndPassword(email,password);clearLoginGateError();return true
    }catch(e){console.error('CloudSync.signIn',e);showLoginGateError(firebaseError(e));return false}
  }
  function normalizeOrders(data){return Array.isArray(data)?data.filter(Boolean).sort((a,b)=>Number(b.createdAtMs||0)-Number(a.createdAtMs||0)):[]}
  async function loadPackerRecords(){
    if(!user||!db||role()!=='packer')return [];
    const uid=user.uid;
    const snap=await ordersRef().where('assignedUid','==',uid).get();
    const all=normalizeOrders(snap.docs.map(d=>({id:d.id,...d.data()})));
    // Luôn lọc thêm ở phía ứng dụng để không bao giờ hiển thị nhầm đơn của tài khoản khác.
    const mine=all.filter(x=>String(x.assignedUid||'')===String(uid));
    const cachedMine=Array.isArray(D.packingOrders)?D.packingOrders.filter(x=>String(x.assignedUid||'')===String(uid)):[];
    // Nếu listener đã có đơn nhưng một lần get() tạm thời trả rỗng, giữ dữ liệu listener.
    const effectiveMine=(mine.length===0 && cachedMine.length>0)?cachedMine:mine;
    D.packingOrders=effectiveMine;
    const completed=effectiveMine.filter(x=>x.status==='completed');
    D.packerRecords=completed.map(d=>({id:d.id,...d,uid,qty:orderTotalQty(d),image:d.completionImage||'',createdAtMs:Number(d.completedAtMs||Date.now()),employee:d.employee||currentPackerName(),catalogId:resolveOrderCatalogId(d),plantName:d.plantName,size:d.size,date:completedOrderDate(d),payAdjustment:Number(d.payAdjustment)||0,payAdjustmentNote:d.payAdjustmentNote||'',payAmount:Number(d.payAmount)}));
    rebuildPackerDaily();
    localSaveOnly();
    // Việc vẽ lại giao diện không được phép làm mất kết quả Firestore vừa đọc.
    try{renderAll()}catch(e){console.error('render after loadPackerRecords',e)}
    const pending=effectiveMine.filter(x=>x.status!=='completed').length;
    if(pending)updateOrderNotificationUI(pending,completed.length);
    return effectiveMine;
  }
  async function createPackingOrder(data){
    if(!user||role()!=='admin')throw new Error('Chỉ Admin được phân công đơn');
    const items=Array.isArray(data?.items)?data.items.map(x=>({catalogId:String(x?.catalogId||'').trim(),plantKey:String(x?.plantKey||x?.catalogId||'').trim(),plantName:String(x?.plantName||'').trim(),size:String(x?.size||'').trim(),qty:Number(x?.qty)})).map(plainAssignmentItem).filter(Boolean):[];
    if(!items.length)throw new Error('Không tạo được đơn: dữ liệu cây/kích thước không hợp lệ. Vui lòng chọn lại dòng cây.');
    const ref=ordersRef().doc(),first=items[0],order={id:ref.id,assignedUid:String(data?.assignedUid||''),employee:String(data?.employee||''),employeeId:String(data?.employeeId||''),catalogId:first.catalogId,plantName:first.plantName,size:first.size,packSize:Number(items.reduce((s,x)=>s+x.qty,0)),items,orderNo:String(data?.orderNo||''),status:'pending',date:String(data?.date||''),assignedAtMs:Number(data?.assignedAtMs||Date.now()),note:String(data?.note||''),orderType:['ĐN','ĐD','TT'].includes(String(data?.orderType||'').trim().toUpperCase())?String(data.orderType).trim().toUpperCase():'TT',customerName:String(data?.customerName||''),customerPhone:String(data?.customerPhone||''),customerAddress:String(data?.customerAddress||''),cod:String(data?.cod||''),freeShip:Boolean(data?.freeShip),createdBy:String(user.uid),createdAtMs:Date.now(),payAdjustment:0,payAdjustmentNote:''};
    await ref.set(order);
    // Cập nhật ngay cache/listener state để giao diện phân công không phải đọc lại một query khác.
    orderNotificationState.rows=[order,...(orderNotificationState.rows||[]).filter(x=>String(x.id)!==String(order.id))];
    D.packingOrders=[order,...(D.packingOrders||[]).filter(x=>String(x.id)!==String(order.id))];
    try{renderAll()}catch(_){}
    return order;
  }

  async function completePackingOrder(id,images,shipmentData){
    // Chỉ sửa bước HOÀN THÀNH: dùng Auth hiện tại để ghi Firestore, không dùng
    // sessionReady làm cổng chặn lần nữa. Quyền Firestore vẫn là lớp bảo vệ cuối cùng.
    const proofImages=Array.isArray(images)?images.filter(x=>String(x||'').startsWith('data:image/')):(images?[images]:[]);
    if(proofImages.length<2)throw new Error('Phải chụp đủ ít nhất 2 ảnh hoàn thành');
    try{if(!auth||!db)await init()}catch(e){}
    const au=currentAuthUser();
    if(!au||!au.uid)throw new Error('Phiên đăng nhập chưa sẵn sàng. Vui lòng thử lại sau giây lát.');
    if(!profile){try{await ensureProfile()}catch(e){}}
    if(role()!=='packer')throw new Error('Tài khoản hiện tại không phải nhân viên đóng hàng');
    const ref=ordersRef().doc(String(id));
    const snap=await ref.get();
    if(!snap.exists)throw new Error('Không tìm thấy đơn được phân công');
    const old={id:snap.id,...snap.data()};
    if(String(old.assignedUid||'')!==String(au.uid))throw new Error('Đơn này không được phân công cho tài khoản hiện tại');
    if(old.status==='completed')return old;
    // Chốt tiền công ngay tại thời điểm hoàn thành và lưu cùng đơn hàng.
    // Không thay đổi đơn giá hiện tại; chỉ chụp lại đúng mức giá đã dùng cho đơn này.
    repairCanonicalConfig();
    const completedQty=orderTotalQty(old);
    const payAmount=orderItemPay(old)+Number(old.payAdjustment||0);
    const sh={trackingNo:normalizeTracking(shipmentData?.trackingNo||''),carrier:String(shipmentData?.carrier||''),customerName:String(shipmentData?.customerName||''),ocrText:String(shipmentData?.ocrText||'')};
    if(!sh.trackingNo)throw new Error('Chưa lấy được mã vận đơn từ ảnh 2');
    const completedAtMs=Date.now();
    const completedDate=fmt(new Date(completedAtMs));
    await ref.update({status:'completed',completionImage:proofImages[0],completionImages:proofImages.slice(0,2),completedAtMs,completedDate,completedAt:firebase.firestore.FieldValue.serverTimestamp(),completedBy:au.uid,payRate:completedQty?Math.round(payAmount/completedQty):0,payAmount,employeePay:payAmount,shipment:sh,shipmentTrackingNo:sh.trackingNo,shipmentCarrier:sh.carrier,shipmentCustomerName:sh.customerName,shipmentOcrText:sh.ocrText});
    const done=await ref.get();
    const result={id:done.id,...done.data()};
    if(String(result.status)!=='completed')throw new Error('Firebase chưa xác nhận đơn đã hoàn thành');
    return result;
  }
  async function migrateLegacyOrdersToCollection(){
    if(!user||role()!=='admin')return;
    const existing=await ordersRef().get();
    if(!existing.empty)return;
    const legacy=await sharedRef().get();
    const rows=legacy.exists?((legacy.data()?.data?.packingOrders)||[]):[];
    if(!Array.isArray(rows)||!rows.length)return;
    const batch=db.batch();
    rows.filter(Boolean).forEach(o=>{const id=String(o.id||('PO-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7)));batch.set(ordersRef().doc(id),{...o,id,payAdjustment:Number(o.payAdjustment)||0,payAdjustmentNote:o.payAdjustmentNote||''},{merge:true})});
    await batch.commit();
    toast(`☁️ Đã chuyển ${rows.length} đơn cũ sang kho phân công mới`);
  }
  async function adminListOrders(){
    if(!user||role()!=='admin')return[];
    // Admin đã có listener /packingOrders là nguồn dữ liệu chính. Dùng cache listener trước
    // để tránh một lần query collection thứ hai gây lỗi permission/transient trong WebView.
    const watched=Array.isArray(orderNotificationState.rows)?orderNotificationState.rows.filter(Boolean):[];
    if(orderNotificationState.ready&&watched.length)return normalizeOrders(watched);
    const local=Array.isArray(D.packingOrders)?D.packingOrders.filter(Boolean):[];
    if(local.length)return normalizeOrders(local);
    const snap=await ordersRef().get();
    return normalizeOrders(snap.docs.map(d=>({id:d.id,...d.data()})));
  }
  async function adminDeleteOrder(id){if(!user||role()!=='admin')throw new Error('Không có quyền Admin');await ordersRef().doc(id).delete();D.packingOrders=(D.packingOrders||[]).filter(x=>String(x.id)!==String(id));orderNotificationState.rows=(orderNotificationState.rows||[]).filter(x=>String(x.id)!==String(id));localSaveOnly();/* Không xóa dirty flag: các thay đổi kho/ngày khác đang chờ đồng bộ phải được giữ nguyên. */ }
  async function adminCompletePackingOrder(id,images,shipmentData){
    if(!user||role()!=='admin')throw new Error('Chỉ Admin được hoàn tất đơn');
    const proofImages=Array.isArray(images)?images.filter(x=>String(x||'').startsWith('data:image/')):[];
    if(proofImages.length<2)throw new Error('Phải chụp đủ 2 ảnh hoàn thành');
    const ref=ordersRef().doc(String(id));
    const snap=await ref.get();if(!snap.exists)throw new Error('Không tìm thấy đơn');
    const old={id:snap.id,...snap.data()};if(old.status==='completed')return old;
    repairCanonicalConfig();
    const completedQty=orderTotalQty(old),payAmount=orderItemPay(old)+Number(old.payAdjustment||0),completedAtMs=Date.now(),completedDate=fmt(new Date(completedAtMs));const sh={trackingNo:normalizeTracking(shipmentData?.trackingNo||''),carrier:String(shipmentData?.carrier||''),customerName:String(shipmentData?.customerName||''),ocrText:String(shipmentData?.ocrText||'')};
    await ref.update({status:'completed',completionImage:proofImages[0],completionImages:proofImages.slice(0,2),completedAtMs,completedDate,completedAt:firebase.firestore.FieldValue.serverTimestamp(),completedBy:user.uid,payRate:completedQty?Math.round(payAmount/completedQty):0,payAmount,employeePay:payAmount,...(sh.trackingNo?{shipment:sh,shipmentTrackingNo:sh.trackingNo,shipmentCarrier:sh.carrier,shipmentCustomerName:sh.customerName,shipmentOcrText:sh.ocrText}:{} )});
    const done=await ref.get();return {id:done.id,...done.data()};
  }
  async function adminUpdatePackingOrder(id,changes){
    if(!user||role()!=='admin')throw new Error('Không có quyền Admin');
    await ordersRef().doc(id).update(changes);
    const x=(D.packingOrders||[]).find(o=>o.id===id);if(x)Object.assign(x,changes);
  }
  async function createPackerRecord(data){if(!user||role()!=='packer')throw new Error('Tài khoản không có quyền đóng hàng');const ref=packerEntriesRef(user.uid).doc();await ref.set(data);const snap=await ref.get();return {id:ref.id,...snap.data(),createdAtMs:Number(snap.data()?.createdAtMs||Date.now())}}
  async function updatePackerRecord(id,changes){if(!user||role()!=='packer')throw new Error('Không có quyền');await packerEntriesRef(user.uid).doc(id).update({...changes,updatedAt:firebase.firestore.FieldValue.serverTimestamp()})}
  async function deletePackerRecord(id){if(!user||role()!=='packer')throw new Error('Không có quyền');await packerEntriesRef(user.uid).doc(id).delete()}
  async function loadAllPackerRecords(){
    if(!user||!db||role()!=='admin')return;
    const snap=await ordersRef().get();const rows=normalizeOrders(snap.docs.map(d=>({id:d.id,...d.data()})));
    D.packerRecords=rows.filter(x=>x.status==='completed').map(x=>({...x,uid:x.assignedUid,employee:x.employee,qty:Number(x.packSize)||0,image:x.completionImage||'',date:completedOrderDate(x),catalogId:resolveOrderCatalogId(x),payAdjustment:Number(x.payAdjustment)||0,payAdjustmentNote:x.payAdjustmentNote||'',payAmount:Number(x.payAmount)}));
    D.packingOrders=rows;localSaveOnly();renderAll();
  }
  async function adminUpdatePackerRecord(id,changes){return adminUpdatePackingOrder(id,changes)}
  async function adminDeletePackerRecord(id){return adminDeleteOrder(id)}
  async function createUser(email,password,employeeId,roleValue){if(!requirePerm('users'))return false;if(!email||!password||!employeeId){toast('Cần email, mật khẩu và chọn nhân viên có sẵn');return false}const emp=(D.employees||[])[Number(employeeId)];if(!emp){toast('Không tìm thấy nhân viên đã chọn');return false}let sec=null;try{const users=await listUsers();if(users.some(u=>u.employeeId===String(employeeId)&&u.active!==false)){toast('Nhân viên này đã được liên kết với một tài khoản');return false}sec=firebase.apps.find(a=>a.name==='USER_CREATOR')||firebase.initializeApp(CLOUD_CONFIG,'USER_CREATOR');const a=sec.auth();const cred=await a.createUserWithEmailAndPassword(email,password);await profileRef(cred.user.uid).set({email:email.trim(),displayName:emp,employeeId:String(employeeId),employeeName:emp,role:(roleValue==='purchaser'?'procurement':(ROLE_LABELS[roleValue]?roleValue:'viewer')),active:true,createdAt:firebase.firestore.FieldValue.serverTimestamp(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()});await a.signOut();toast('✅ Đã cấp tài khoản cho '+emp);await renderUserManagement();return true}catch(e){console.error('createUser',e);let msg=firebaseError(e);if(e?.code==='permission-denied')msg='Không thể lưu hồ sơ nhân viên. Hãy Publish Firestore Rules V20 mới.';toast(msg);try{if(sec)await sec.auth().signOut()}catch(_){}return false}}
  async function listUsers(){if(!can('users'))return[];const snap=await db.collection('users').get();return snap.docs.map(d=>({uid:d.id,...d.data()})).sort((a,b)=>String(a.email||'').localeCompare(String(b.email||'')))}
  async function linkUserEmployee(uid,employeeId){if(!requirePerm('users'))return false;const target=(await listUsers()).find(u=>u.uid===uid);if(target?.role==='admin'){toast('⚠️ Tài khoản Quản trị viên không được gắn với nhân viên. Admin và nhân viên là hai vai trò riêng.');return false}const emp=(D.employees||[])[Number(employeeId)];if(!emp){toast('Hãy chọn nhân viên');return false}const users=await listUsers();const clash=users.find(u=>u.uid!==uid&&u.employeeId===String(employeeId)&&u.active!==false);if(clash){toast('Nhân viên này đã được liên kết với tài khoản '+(clash.email||''));return false}try{await profileRef(uid).set({employeeId:String(employeeId),employeeName:emp,displayName:emp,updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});toast('✅ Đã liên kết tài khoản với nhân viên '+emp);await renderUserManagement();return true}catch(e){toast(firebaseError(e));return false}}
  async function setUserRole(uid,roleValue){if(!requirePerm('users'))return;const canonical=roleValue==='purchaser'?'procurement':roleValue;if(!ROLE_LABELS[canonical]||canonical==='admin')throw new Error('Quyền không hợp lệ');await profileRef(uid).set({role:canonical,updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});toast('Đã cập nhật quyền');renderUserManagement()}
  async function setUserActive(uid,active){if(!requirePerm('users'))return;await profileRef(uid).set({active,updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});toast(active?'Đã mở khóa tài khoản':'Đã khóa tài khoản');renderUserManagement()}
  async function signOut(){sessionEpoch++;stopOrderWatch();user=null;profile=null;ready=false;authReady=false;orderNotificationState.authReady=false;if(auth)await auth.signOut();closeCloudSync();toast('Đã đăng xuất Cloud')}
  function firebaseError(e){const c=e?.code||'';if(c.includes('invalid-email'))return'Email không hợp lệ';if(c.includes('weak-password'))return'Mật khẩu cần ít nhất 6 ký tự';if(c.includes('wrong-password')||c.includes('invalid-credential'))return'Sai email hoặc mật khẩu';if(c.includes('email-already-in-use'))return'Email này đã được đăng ký';return'Lỗi Cloud: '+(e?.message||c)}
  function state(){return {user:user||currentAuthUser(),profile,role:role(),ready,authReady,sessionReady:sessionUsable(),ensureActionSession,waitUntilReady,waitUntilAuthReady,can,listUsers,linkUserEmployee,loadPackerRecords,createPackerRecord,updatePackerRecord,deletePackerRecord,loadAllPackerRecords,adminUpdatePackerRecord,adminDeletePackerRecord,createPackingOrder,completePackingOrder,adminListOrders,adminDeleteOrder,adminUpdatePackingOrder,adminCompletePackingOrder,refreshCatalogForAssignment}}
  return {init,schedulePush,pushNow,signIn,signOut,state,can,requirePerm,createUser,listUsers,setUserRole,setUserActive};
})();
// Bridge lexical CloudSync to window: inline handlers and legacy permission guards
// in this WebView use window.CloudSync. Without this bridge they silently bypass
// permission checks or fail to schedule Cloud sync.
window.CloudSync=CloudSync;
let assignmentItems=[];
function renderAssignmentItems(){
  const box=$('assignmentItems');if(!box)return;
  if(!assignmentItems.length){box.innerHTML='<div class="tiny muted">Chưa thêm cây. Nếu đơn chỉ có 1 loại cây, thêm 1 dòng là đủ.</div>';return}
  box.innerHTML=assignmentItems.map((it,i)=>`<div class="assign-item-row"><div class="assign-item-main"><b>${esc(it.plantName)} · ${esc(it.size||'')}</b><span>${Math.round(it.qty)} cây · ${money(it.qty*rate(it.size))} tiền công</span></div><button type="button" class="danger" onclick="removeAssignmentItem(${i})">−</button></div>`).join('');
  // Không tự đồng bộ quy cách theo qty dòng. Quy cách đơn là lựa chọn độc lập và
  // là số cây THỰC TẾ của mỗi đơn. Với đơn chỉ có 1 loại cây, khi tạo đơn sẽ lấy
  // chính giá trị assignPackSize (1..100) làm qty của dòng đó.
}
function addAssignmentItem(){
  const plantKey=String($('assignPlant')?.value||'').trim(); const rawKey=String($('assignSize')?.value||'').trim(); const qty=Math.floor(Number($('assignItemQty')?.value)||0);
  const p=catalogById(rawKey); ensureCatalogIds();
  const samePlant=!!p&&normalizeAssignSearch(p.name||'')===normalizeAssignSearch(plantKey);
  if(!plantKey||!rawKey||!p||p.deleted||!samePlant||qty<1){toast('Cây/kích thước chưa hợp lệ. Vui lòng chọn lại cây và kích thước rồi bấm THÊM CÂY.');return}
  assignmentItems.push({catalogId:String(p.catalogId),plantKey:String(p.catalogId),plantName:String(p.name||''),size:String(p.size??''),qty:Number(qty)}); renderAssignmentItems(); if($('assignItemQty'))$('assignItemQty').value=1; toast(`Đã thêm ${qty} cây · ${p.name||''}`);
}
function removeAssignmentItem(i){assignmentItems.splice(Number(i),1);renderAssignmentItems()}
function clearAssignmentItems(){assignmentItems=[];renderAssignmentItems()}
function normalizeAssignSearch(v){
  return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase().trim();
}
function clearAssignPlantSearch(){
  const q=$('assignPlantSearch');if(q)q.value='';
  renderAssignPlantOptions();
  if(q)q.focus();
}
function selectAssignPlantByKey(key){
  const plant=$('assignPlant');
  if(!plant)return;
  ensureCatalogIds();
  const wanted=normalizeAssignSearch(key);
  const rows=(Array.isArray(D.catalog)?D.catalog:[]).map((p,i)=>({p,i}))
    .filter(o=>o.p&&!o.p.deleted&&String(o.p.name||'').trim());
  const group=rows.find(o=>normalizeAssignSearch(o.p.name||'')===wanted)?.p?.name
    ? {name:rows.find(o=>normalizeAssignSearch(o.p.name||'')===wanted).p.name,rows:rows.filter(o=>normalizeAssignSearch(o.p.name||'')===wanted)}
    : null;
  if(!group){toast('Không tìm thấy cây này trong danh mục.');return;}
  // Chọn trực tiếp bằng khóa nhóm ổn định, không phụ thuộc vị trí/index của danh mục.
  plant.value=wanted;
  renderAssignSizes();
  // Nếu cây chỉ có 1 kích thước thì chọn luôn kích thước đó.
  if(group.rows.length===1){
    const only=group.rows[0].p;
    const size=$('assignSize');
    if(size)size.value=String(only.catalogId||'');
  }
  const q=$('assignPlantSearch');if(q)q.value=String(group.name||'');
  renderAssignPlantOptions();
  renderAssignSizes();
  const size=$('assignSize');
  if(group.rows.length===1&&size)size.value=String(group.rows[0].p.catalogId||'');
}

function selectAssignPlantByName(name){
  selectAssignPlantByKey(normalizeAssignSearch(name));
}
function selectFirstAssignPlant(){
  const first=document.querySelector('#assignPlantResults .assign-plant-result');
  if(first)first.click();
}
function renderAssignPlantOptions(){
  const plant=$('assignPlant'),results=$('assignPlantResults');if(!plant)return;ensureCatalogIds();
  const q=normalizeAssignSearch($('assignPlantSearch')?.value||'');
  const rows=(Array.isArray(D.catalog)?D.catalog:[]).map((p,i)=>({p,i}))
    .filter(o=>o.p&&!o.p.deleted&&String(o.p.name||'').trim());
  const groups=new Map();
  rows.forEach(o=>{
    const name=String(o.p.name||'').trim();
    const key=normalizeAssignSearch(name);
    if(!groups.has(key))groups.set(key,{name,rows:[]});
    groups.get(key).rows.push(o);
  });
  let groupsArr=[...groups.values()].filter(g=>{
    if(!q)return true;
    return normalizeAssignSearch(g.name).includes(q)||g.rows.some(o=>normalizeAssignSearch(o.p.size).includes(q));
  }).sort((a,b)=>a.name.localeCompare(b.name,'vi'));
  const current=String(plant.value||'').trim();
  const currentKey=normalizeAssignSearch(current);
  plant.innerHTML=groupsArr.length
    ? '<option value="">-- Chọn loại cây --</option>'+groupsArr.map(g=>{const gkey=normalizeAssignSearch(g.name);return `<option value="${esc(gkey)}">${esc(g.name)}${g.rows.length>1?' · '+g.rows.length+' kích thước':''}</option>`}).join('')
    : '<option value="">Không tìm thấy cây</option>';
  if(currentKey&&groupsArr.some(g=>normalizeAssignSearch(g.name)===currentKey))plant.value=currentKey;
  if(results){
    if(!q){results.innerHTML='<div class="assign-search-hint">Nhập tên cây hoặc kích thước để hiện danh sách. Ví dụ: <b>Cẩm tú mai</b> hoặc <b>C7</b>.</div>';}
    else if(!groupsArr.length){results.innerHTML='<div class="assign-search-empty">Không tìm thấy cây. Hãy thử bỏ dấu hoặc tìm theo C7, C9, C10...</div>';}
    else{results.innerHTML=groupsArr.slice(0,40).map(g=>{
      const gkey=normalizeAssignSearch(g.name);
      const sizes=[...new Set(g.rows.map(o=>String(o.p.size||'').trim()).filter(Boolean))];
      const selected=normalizeAssignSearch(g.name)===normalizeAssignSearch(current)?' selected':'';
      return `<button type="button" class="assign-plant-result${selected}" data-assign-key="${esc(gkey)}" onclick="selectAssignPlantByKey(this.dataset.assignKey)"><span><b>${esc(g.name)}</b><span>${sizes.length?sizes.map(esc).join(' · '):'Chưa ghi kích thước'}</span></span><em>${sizes.length} size</em></button>`;
    }).join('')+(groupsArr.length>40?'<div class="assign-search-hint">Đang hiển thị 40 kết quả. Gõ thêm tên cây để thu hẹp.</div>':'');}
  }
  renderAssignSizes();
}
async function fillAssignOptions(){
  const s=CloudSync.state();if(!s.user||s.role!=='admin')return;
  ensureCatalogIds();
  const emp=$('assignEmployee'),plant=$('assignPlant'),ps=$('assignPackSize');if(!emp||!plant||!ps)return;
  const oldEmp=emp.value,oldPlant=plant.value,oldPack=ps.value;

  // V25.6.4 ROOT FIX: hiển thị danh mục LOCAL trước, không chờ Firestore.
  // Cây vừa thêm vào danh mục phải dùng được ngay trong Chia đơn.
  const renderLocalPlants=()=>{
    ensureCatalogIds();renderAssignPlantOptions();
    ps.innerHTML='<option value="">-- Chọn quy cách --</option>'+Array.from({length:100},(_,i)=>i+1).map(n=>`<option value="${n}">${n===1?'1 cây · không combo':n+' cây / combo'}</option>`).join('');
    if(oldPack)ps.value=oldPack;renderAssignSizes();
  };
  renderLocalPlants();

  // Cloud chỉ là bước đồng bộ bổ sung. Nếu lỗi quyền/mạng, giữ nguyên catalog local.
  try{await s.refreshCatalogForAssignment?.();}catch(e){console.warn('assignment catalog cloud refresh skipped',e)}
  ensureCatalogIds();
  renderLocalPlants();

  emp.innerHTML='<option value="">Đang tải nhân viên…</option>';
  try{
    const users=await s.listUsers();
    const packers=users.filter(u=>u.role==='packer'&&u.active!==false&&u.employeeId!=null&&String(u.employeeName||'').trim());
    emp.innerHTML=packers.length
      ? '<option value="">-- Chọn nhân viên đóng hàng --</option>'+packers.map(u=>`<option value="${esc(u.uid)}">${esc(u.employeeName)} · ${esc(u.email||'')}</option>`).join('')
      : '<option value="">Chưa có nhân viên đóng hàng đã liên kết tài khoản</option>';
    if(packers.some(u=>u.uid===oldEmp))emp.value=oldEmp;
  }catch(e){
    console.error('fillAssignOptions users',e);
    emp.innerHTML='<option value="">Không đọc được tài khoản nhân viên — kiểm tra Firestore Rules</option>';
  }
}
async function refreshAssignmentCatalogUI(){
  try{
    ensureCatalogIds();
    await CloudSync.state().refreshCatalogForAssignment?.();
    ensureCatalogIds();
    await fillAssignOptions();
    toast('✅ Đã tải lại danh mục cây mới nhất');
  }catch(e){console.warn('refreshAssignmentCatalogUI',e);toast('Không tải lại được danh mục: '+(e?.message||e));}
}
function renderAssignSizes(){
  const p=String($('assignPlant')?.value||'').trim(),size=$('assignSize');
  if(!size)return;
  const rows=activeCatalog().filter(o=>normalizeAssignSearch(o.p?.name||'')===normalizeAssignSearch(p));
  size.innerHTML=rows.length
    ? '<option value="">-- Chọn kích thước --</option>'+rows.map(o=>`<option value="${esc(String(o.p.catalogId||''))}">${esc(o.p.size||'Không ghi kích thước')}</option>`).join('')
    : '<option value="">-- Chọn loại cây trước --</option>';
  size.disabled=!rows.length;
}
function toggleCustomerFields(){
  const type=String($('assignOrderType')?.value||'ĐN').trim().toUpperCase();
  const box=$('assignCustomerFields');
  if(!box)return;
  box.classList.toggle('hidden',type!=='ĐN');
}
async function adminCreateAssignments(){
  if(!CloudSync.requirePerm('users'))return;
  const assignedUid=$('assignEmployee')?.value||'',fallbackPlantName=String($('assignPlant')?.selectedOptions?.[0]?.textContent||$('assignPlant')?.value||'').replace(/\s+·\s+\d+\s+kích\s+thước\s*$/i,'').trim(),fallbackKey=String($('assignSize')?.value||'').trim(),fallbackPack=Math.max(1,Number($('assignPackSize')?.value)||0),count=Math.floor(Number($('assignOrderCount')?.value)||0),note=($('assignNote')?.value||'').trim(),orderType=String($('assignOrderType')?.value||'ĐN').trim().toUpperCase(),customerName=String($('assignCustomerName')?.value||'').trim(),customerPhone=String($('assignCustomerPhone')?.value||'').trim(),customerAddress=String($('assignCustomerAddress')?.value||'').trim(),cod=String($('assignCod')?.value||'').trim(),freeShip=!!$('assignFreeShip')?.checked;
  const users=await CloudSync.state().listUsers();
  const target=users.find(u=>String(u.uid||'')===String(assignedUid) && String(u.role||'').trim().toLowerCase()==='packer' && u.active!==false && u.employeeId!=null && String(u.employeeId).trim()!=='' && String(u.employeeName||'').trim()!=='');
  let items=assignmentItems.slice();
  if(!items.length && fallbackPlantName&&fallbackKey){
      const fo=findCatalogByKey(fallbackKey);
      if(fo?.p && String(fo.p.name||'').trim().toLowerCase()===fallbackPlantName.toLowerCase()){
        items=[{catalogId:String(fo.p.catalogId),plantKey:String(fo.p.catalogId),plantName:String(fo.p.name||''),size:String(fo.p.size||''),qty:fallbackPack||1}];
      }
    }
  items=items.map(x=>{
      const catalogId=String(x?.catalogId??'').trim(),p=catalogById(catalogId);
      if(!p||!catalogId||p.deleted)return null;
      const expectedName=String(x?.plantName||'').trim();if(expectedName&&normalizeAssignSearch(p.name)!==normalizeAssignSearch(expectedName))return null;
      return plainAssignmentItem({catalogId,qty:x?.qty,plantKey:catalogId,plantName:String(p.name||''),size:String(p.size||'')});
    }).filter(Boolean);
    const packSize=Math.max(1,Math.floor(Number($('assignPackSize')?.value)||0));
    if(packSize<1||packSize>100){toast('❌ Quy cách đơn phải từ 1 đến 100 cây/đơn.');return}
    const missingRateItems=items.filter(x=>!hasCatalogRate(x.catalogId));
    if(missingRateItems.length){toast('❌ Chưa có đơn giá lương cho size: '+missingRateItems.map(x=>x.size||'Chưa ghi size').join(', ')+'. Hãy thêm đơn giá trong Điều khiển → Đơn giá trước khi phân công.');return}
    // Quy cách là số cây THỰC TẾ của MỖI ĐƠN, không phải nhãn mô tả.
    // Đơn 1 loại cây: combo 1 => 1 cây/đơn; combo 2 => 2 cây/đơn; ... combo 100 => 100 cây/đơn.
    // Đơn nhiều loại cây: tổng qty các dòng phải đúng bằng quy cách đã chọn.
    if(items.length===1){items[0].qty=packSize}
    const totalQty=items.reduce((s,x)=>s+x.qty,0);
    if(items.length>1 && totalQty!==packSize){
      toast(`❌ Đơn có ${items.length} loại cây: tổng số cây phải đúng ${packSize} cây/đơn (hiện ${totalQty}).`);return
    }
    // Validate each dependency separately so a bad employee profile, a bad catalog row,
    // or an invalid quantity can no longer collapse into the misleading generic toast.
    if(!assignedUid){toast('❌ Chưa chọn nhân viên đóng hàng.');return}
    if(!target){toast('❌ Tài khoản nhân viên chưa liên kết đúng với nhân viên. Vào Điều khiển → Tài khoản, kiểm tra Quyền = Nhân viên đóng hàng và Nhân viên đã gắn.');return}
    if(!items.length){toast('❌ Chưa có cây hợp lệ trong danh sách phân công. Hãy chọn lại cây + kích thước rồi bấm THÊM CÂY.');return}
    if(totalQty<1||totalQty>100){toast('❌ Tổng số cây thực tế/đơn phải từ 1 đến 100.');return}
    if(count<1){toast('❌ Số đơn cần đóng phải ít nhất là 1.');return}
    if(orderType==='ĐN' && (!customerName||!customerPhone||!customerAddress)){toast('❌ Đơn ĐN cần nhập đủ tên khách, số điện thoại và địa chỉ.');return}
  const employee=String(target.employeeName).trim();
  const employeeId=String(target.employeeId).trim();
  try{
    for(let i=0;i<count;i++){
      const now=Date.now(),orderNo=`${now.toString().slice(-6)}-${String(i+1).padStart(2,'0')}`;
      const first=items[0];
      // Build a completely plain Firestore payload. Do NOT pass catalog objects,
      // DOM objects, Promise values, or spread objects from UI state here.
      const orderPayload={assignedUid:String(target.uid),employee:String(employee),employeeId:String(employeeId),catalogId:String(first.catalogId),plantName:String(first.plantName),size:String(first.size),packSize:Number(totalQty),items:items.map(x=>({catalogId:String(x.catalogId||''),plantKey:String(x.plantKey||x.catalogId||''),plantName:String(x.plantName||''),size:String(x.size||''),qty:Number(x.qty)})),orderNo:String(orderNo),status:'pending',orderType:['ĐN','ĐD','TT'].includes(orderType)?orderType:'TT',customerName:orderType==='ĐN'?String(customerName):'',customerPhone:orderType==='ĐN'?String(customerPhone):'',customerAddress:orderType==='ĐN'?String(customerAddress):'',cod:orderType==='ĐN'?String(cod):'',freeShip:orderType==='ĐN'?Boolean(freeShip):false,date:String($('dDate')?.value||START),assignedAtMs:Number(now),note:String(note)};
      // Final invariant: no Promise/custom object may ever reach DocumentReference.set().
      const bad=orderPayload.items.some(x=>Object.values(x).some(v=>v===null||typeof v==='undefined'||typeof v==='function'||typeof v==='object'));
      if(bad)throw new Error('Dữ liệu phân công không hợp lệ: phát hiện giá trị không phải dữ liệu Firestore thuần.');
      await CloudSync.state().createPackingOrder(orderPayload);
    }
    toast(`✅ Đã phân công ${count} đơn · ${items.length} loại cây · ${totalQty} cây/đơn cho ${employee}`);
    if($('assignNote'))$('assignNote').value='';if($('assignOrderCount'))$('assignOrderCount').value=1;if($('assignOrderType'))$('assignOrderType').value='ĐN';if($('assignCustomerName'))$('assignCustomerName').value='';if($('assignCustomerPhone'))$('assignCustomerPhone').value='';if($('assignCustomerAddress'))$('assignCustomerAddress').value='';if($('assignCod'))$('assignCod').value='';if($('assignFreeShip'))$('assignFreeShip').checked=false;toggleCustomerFields();clearAssignmentItems();
    await renderAssignmentControls();
  }catch(e){toast(e?.message||'Không thể phân công đơn')}
}
function orderItemsLabel(r){return orderItems(r).map(x=>`${esc(x.plantName||'Cây')} · ${esc(x.size||'')} × ${Math.round(x.qty)}`).join('<br>')}
async function renderAssignmentControls(){
  const card=$('orderAssignCard');if(!card)return;const s=CloudSync.state();if(!s.user||s.role!=='admin'){card.classList.add('perm-hidden');return}card.classList.remove('perm-hidden');await fillAssignOptions();const box=$('assignmentList');if(!box)return;
  try{const rows=await s.adminListOrders();let html='';if(!rows.length)html='<div class="tiny muted">Chưa có đơn được phân công.</div>';
  rows.slice(0,30).forEach(r=>{const basePay=orderItemPay(r),adj=Number(r.payAdjustment)||0,totalPay=orderTotalPay(r);html+=`<div class="order-card ${r.status==='completed'?'done':'pending'}"><div class="order-head"><div><div class="order-title">${esc(r.employee||'')} · ${Math.round(orderTotalQty(r))} cây</div><div class="order-meta">${esc(r.orderType||'ĐN')} · Đơn #${esc(r.orderNo||r.id.slice(-6))} · ${r.status==='completed'?'Đã hoàn thành':'Đang chờ'}</div><div class="tiny muted" style="margin-top:4px">${orderItemsLabel(r)}</div><div class="tiny muted">Tiền công gốc: <b>${money(basePay)}</b>${adj?` · Điều chỉnh: <b>${adj>0?'+':''}${money(adj)}</b>`:''} · <b>Tổng: ${money(totalPay)}</b></div></div><span class="order-badge ${r.status==='completed'?'done':''}">${r.status==='completed'?'✅ Hoàn thành':'🔔 Chờ'}</span></div>${r.status==='completed'&&completionImages(r).length?`<div class="order-proof">${completionImages(r).map((src,i)=>`<img src="${src}" onclick="openImageSrc(this.src,'Ảnh hoàn thành ${i+1} · ${esc(r.employee||'')}')" alt="" style="max-width:90px;margin-right:6px">`).join('')}<div class="tiny muted">${r.payAdjustmentNote?`Ghi chú điều chỉnh: ${esc(r.payAdjustmentNote)}`:''}</div></div>`:''}<div style="display:flex;gap:7px;flex-wrap:wrap;margin-top:8px"><button class="print-order-btn" onclick="printPackingOrder('${esc(r.id)}')">🖨️ IN ĐƠN</button><button class="secondary" onclick="sendPackingOrderToFlashLabel('${esc(r.id)}')">🏷️ FLASHLABEL</button>${r.status!=='completed'?`<button class="primary" onclick="openAdminCompleteOrder('${esc(r.id)}')">📷 ADMIN HOÀN TẤT</button>`:''}<button class="secondary" onclick="openOrderAdjustMoney('${r.id}')">± Tiền công</button><button class="danger" onclick="adminRemoveAssignment('${r.id}')">Xóa đơn</button></div></div>`});box.innerHTML=html}catch(e){box.innerHTML='<div class="tiny muted">Không tải được danh sách phân công.</div>'}}
function openOrderAdjustMoney(id){
  const r=(D.packingOrders||[]).find(x=>x.id===id);if(!r)return;
  const base=orderItemPay(r),current=Number(r.payAdjustment)||0;
  $('editTitle').textContent='Điều chỉnh tiền công cho đơn hàng';
  $('editBody').innerHTML=`<div class="info"><b>Đơn #${esc(r.orderNo||r.id.slice(-6))}</b><div class="tiny muted">${esc(r.employee||'')} · ${Math.round(orderTotalQty(r))} cây<br>${orderItemsLabel(r)}</div><div class="tiny muted">Tiền công gốc: ${money(base)} · Đang điều chỉnh: ${current>0?'+':''}${money(current)}</div><div class="money">Tổng hiện tại: ${money(orderTotalPay(r))}</div></div><div class="field"><label>Số tiền điều chỉnh (VNĐ)</label><input id="orderAdjAmount" type="number" step="1000" inputmode="numeric" value="0" placeholder="Ví dụ: 50000 hoặc -30000"></div><div class="field"><label>Ghi chú</label><input id="orderAdjNote" placeholder="Thưởng, phụ cấp, trừ tiền..."></div><button class="primary" onclick="saveOrderAdjustMoney('${id}')">LƯU ĐIỀU CHỈNH</button><div class="tiny muted" style="margin-top:8px">Số dương = cộng, số âm = trừ. Có thể điều chỉnh lại nhiều lần.</div>`;
  $('editModal').classList.add('show');
}
async function saveOrderAdjustMoney(id){
  const amount=Number($('orderAdjAmount')?.value)||0,note=String($('orderAdjNote')?.value||'').trim();if(!amount){toast('Số tiền phải khác 0');return}
  const r=(D.packingOrders||[]).find(x=>x.id===id);if(!r)return;const next=(Number(r.payAdjustment)||0)+amount;
  try{const nextTotal=orderItemPay(r)+next;await CloudSync.state().adminUpdatePackingOrder(id,{payAdjustment:next,payAdjustmentNote:note,payAmount:nextTotal,employeePay:nextTotal,updatedAt:firebase.firestore.FieldValue.serverTimestamp()});closeEdit();await renderAssignmentControls();renderAll();toast(`Đã ${amount>0?'cộng':'trừ'} ${money(Math.abs(amount))} cho đơn`)}catch(e){toast(e?.message||'Không thể điều chỉnh tiền công')}
}
let pendingAdminOrderProof=[],pendingAdminShipmentOcr={trackingNo:'',carrier:'',customerName:'',ocrText:''},pendingAdminShipmentOcrBusy=false;
window.__adminShipmentOcrResult=function(text){pendingAdminShipmentOcrBusy=false;pendingAdminShipmentOcr=parseShipmentOcr(text);const p=pendingAdminShipmentOcr;const st=$('adminOrderProofStatus');if(st)st.textContent=p.trackingNo?`Đã có 2/2 ảnh · 🚚 ${p.carrier||'Chưa rõ'} · ${p.trackingNo}${p.customerName?' · '+p.customerName:''}`:'Đã có 2/2 ảnh · ⚠️ Chưa đọc được mã vận đơn, hãy chụp lại ảnh 2.';const btn=$('adminOrderCompleteBtn');if(btn)btn.disabled=!p.trackingNo||pendingAdminShipmentOcrBusy;};
function openAdminCompleteOrder(id){
  const r=(D.packingOrders||[]).find(x=>String(x.id)===String(id));if(!r)return;pendingAdminOrderProof=[];pendingAdminShipmentOcr={trackingNo:'',carrier:'',customerName:'',ocrText:''};pendingAdminShipmentOcrBusy=false;
  $('editTitle').textContent='Admin hoàn tất đơn #'+String(r.orderNo||r.id).slice(-12);
  $('editBody').innerHTML=`<div class="info"><b>${esc(r.employee||'Nhân viên')}</b><div class="tiny muted">${esc(r.orderType||'TT')} · ${orderItemsLabel(r).replace(/<br>/g,' · ')}</div><div class="tiny muted">Tiền công sẽ được cộng vào lương của nhân viên được chỉ định: <b>${money(orderTotalPay(r))}</b></div></div><div class="field"><label>Ảnh 1 — kiện hàng đã hoàn thành</label><input type="file" accept="image/*" capture="environment" onchange="readAdminOrderProof(event,0)"></div><div class="field"><label>Ảnh 2 — vận đơn có mã vận đơn</label><input type="file" accept="image/*" capture="environment" onchange="readAdminOrderProof(event,1)"></div><div id="adminOrderProofStatus" class="tiny muted">Chưa đủ 2 ảnh.</div><button id="adminOrderCompleteBtn" class="primary" disabled onclick="submitAdminCompleteOrder('${esc(id)}')">🔒 XÁC NHẬN HOÀN TẤT</button>`;
  $('editModal').classList.add('show');
}
function readAdminOrderProof(ev,index){const f=ev.target.files?.[0];if(!f)return;const rd=new FileReader();rd.onload=()=>{const im=new Image();im.onload=()=>{const max=800,sc=Math.min(1,max/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.width*sc));c.height=Math.max(1,Math.round(im.height*sc));const ctx=c.getContext('2d');ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.drawImage(im,0,0,c.width,c.height);pendingAdminOrderProof[index]=c.toDataURL('image/jpeg',.62);const n=pendingAdminOrderProof.filter(Boolean).length;if(index===1){pendingAdminShipmentOcrBusy=true;pendingAdminShipmentOcr={trackingNo:'',carrier:'',customerName:'',ocrText:''};$('adminOrderProofStatus').textContent='⏳ Đang đọc ảnh 2 để lấy mã vận đơn, đơn vị vận chuyển và người nhận…';if(window.AndroidBridge&&AndroidBridge.ocrShippingImage){AndroidBridge.ocrShippingImage(pendingAdminOrderProof[index],'__adminShipmentOcrResult')}else{pendingAdminShipmentOcrBusy=false;pendingAdminShipmentOcr=parseShipmentOcr('');}}else{$('adminOrderProofStatus').textContent=`Đã có ${n}/2 ảnh. Chụp ảnh 2 để đọc vận đơn.`;$('adminOrderCompleteBtn').disabled=true;}};im.src=rd.result};rd.readAsDataURL(f);ev.target.value=''}
async function submitAdminCompleteOrder(id){if(pendingAdminOrderProof.filter(Boolean).length<2){toast('Phải chụp đủ 2 ảnh');return}if(pendingAdminShipmentOcrBusy){toast('⏳ Đang đọc ảnh 2, vui lòng chờ…');return}if(!pendingAdminShipmentOcr.trackingNo){toast('⚠️ Chưa đọc được mã vận đơn từ ảnh 2. Hãy chụp lại ảnh 2 rõ hơn.');return}try{const r=await CloudSync.state().adminCompletePackingOrder(id,pendingAdminOrderProof,pendingAdminShipmentOcr);const x=(D.packingOrders||[]).find(o=>String(o.id)===String(id));if(x)Object.assign(x,r);else D.packingOrders=[...(D.packingOrders||[]),r];D.packerRecords=[r,...(D.packerRecords||[]).filter(o=>String(o.id)!==String(id))];closeEdit();renderAll();await renderAssignmentControls();toast(`✅ Đã hoàn tất đơn · ${money(orderTotalPay(r))} tiền công cho ${r.employee||'nhân viên'} · 🚚 ${pendingAdminShipmentOcr.carrier||'Chưa rõ'} ${pendingAdminShipmentOcr.trackingNo}`)}catch(e){toast(e?.message||'Không thể hoàn tất đơn')}}

async function adminRemoveAssignment(id){if(!confirm('Xóa đơn phân công này?'))return;try{await CloudSync.state().adminDeleteOrder(id);await renderAssignmentControls();toast('Đã xóa đơn phân công')}catch(e){toast(e?.message||'Không thể xóa đơn')}}


function formatOrderDateTime(r){const ms=Number(r?.completedAtMs||r?.assignedAtMs||r?.createdAtMs||0);if(ms)return new Date(ms).toLocaleString('vi-VN');const d=String(r?.date||'');return d?fmtDMY(d):fmtDMY(fmt(new Date()));}
function formatPackingDate(r){const d=String(r?.date||'').trim();if(d)return fmtDMY(d);return formatOrderDateTime(r);}
function packingShortDate(r){
  const d=String(r?.date||'').trim();
  if(/^\d{4}-\d{2}-\d{2}$/.test(d)){
    const [y,m,day]=d.split('-');
    const type=['ĐN','ĐD','TT'].includes(String(r?.orderType||'').trim().toUpperCase())?String(r.orderType).trim().toUpperCase():'ĐN';
    return type+Number(day)+'.'+Number(m);
  }
  return String(r?.orderType||'ĐN').trim().toUpperCase()+' '+formatOrderDateTime(r);
}
function buildPackingPrintPage(r){
  const items=orderItems(r),total=orderTotalQty(r);
  const orderId=String(r?.orderNo||r?.id||'');
  const employee=String(r?.employee||r?.employeeName||'').trim();
  const dateText=packingShortDate(r);
  const type=String(r?.orderType||'ĐN').trim().toUpperCase();
  const isDelivery=type==='ĐN';
  const customerName=String(r?.customerName||'').trim();
  const customerPhone=String(r?.customerPhone||'').trim();
  const customerAddress=String(r?.customerAddress||'').trim();
  const cod=String(r?.cod||'').trim();
  const freeShip=Boolean(r?.freeShip);
  const firstPageItems=7,laterPageItems=8;
  const chunks=[];
  if(items.length<=firstPageItems)chunks.push(items);
  else{chunks.push(items.slice(0,firstPageItems));for(let i=firstPageItems;i<items.length;i+=laterPageItems)chunks.push(items.slice(i,i+laterPageItems));}
  return chunks.map((chunk,pageIndex)=>{
    const isLast=pageIndex===chunks.length-1;
    const rows=chunk.map(x=>{
      const name=String(x.plantName||'Cây').trim();
      const size=String(x.size||'').trim();
      const qty=Math.round(Number(x.qty)||0);
      const display=name+(size?' '+size:'')+' x '+qty;
      return '<div class="order-print-item"><span class="plant">'+esc(display)+'</span></div>';
    }).join('');
    const customerLine=(isDelivery&&customerName)?'<div class="customer">'+esc(customerName)+(customerPhone?' - '+esc(customerPhone):'')+'</div>':'';
    const addressLine=(isDelivery&&customerAddress)?'<div class="address">'+esc(customerAddress)+'</div>':'';
    const codLine=isDelivery&&(cod||freeShip)?'<div class="cod-line">'+(cod?'Thu COD: '+esc(cod):'')+(freeShip?(cod?' · ':'')+'Free ship':'')+'</div>':'';
    const customerBlock=pageIndex===0&&isDelivery&&(customerLine||addressLine||codLine)?'<div class="order-print-info">'+customerLine+addressLine+codLine+'</div>':'';
    const totalLine=isLast&&items.length>1?'<div class="order-print-total">Tổng '+Math.round(total)+' cây</div>':'';
    // Tên nhân viên luôn ở dưới cùng; ngày loại đơn nằm ngay bên dưới tên NV.
    const employeeLine=isLast?'<div class="order-print-employee">'+esc(employee)+'</div>':'';
    const dateLine=isLast?'<div class="order-print-date-bottom">'+esc(dateText)+'</div>':'';
    const thanksLine=isLast?'<div class="order-print-thanks">CẢM ƠN QUÝ KHÁCH<br><span>Hỗ trợ: 0353636420</span></div>':'';
    const idLine=isLast?'<div class="order-print-id">ID: '+esc(orderId)+'</div>':'';
    return '<div class="order-print-page'+(pageIndex?' continuation':'')+'"><div class="order-print-content">'+customerBlock+'<div class="order-print-items">'+rows+totalLine+'</div>'+employeeLine+dateLine+thanksLine+idLine+'</div></div>';
  }).join('');
}
async function printPackingOrder(id){
  if(!(await ensureAdminPrintAccess()))return;
  const r=(D.packingOrders||[]).find(x=>String(x.id)===String(id));if(!r){toast('Không tìm thấy đơn hàng');return}
  const box=$('orderPrintArea');if(!box)return;
  box.innerHTML=buildPackingPrintPage(r);box.setAttribute('aria-hidden','false');
  document.documentElement.classList.add('print-order');document.body.classList.add('print-order');
  if(window.AndroidBridge&&AndroidBridge.printOrder65x100){try{AndroidBridge.printOrder65x100('ROLL-CAY-CANH-'+String(r.orderNo||r.id).replace(/[^a-zA-Z0-9_-]/g,'_'));setTimeout(()=>{box.innerHTML='';box.setAttribute('aria-hidden','true');document.documentElement.classList.remove('print-order');document.body.classList.remove('print-order')},15000);return}catch(e){console.error(e)}}
  try{window.print();setTimeout(()=>{box.innerHTML='';box.setAttribute('aria-hidden','true');document.documentElement.classList.remove('print-order');document.body.classList.remove('print-order')},1500)}catch(e){document.documentElement.classList.remove('print-order');document.body.classList.remove('print-order');toast('Thiết bị chưa hỗ trợ in trực tiếp')}
}
let batchPrintRows=[];
async function openBatchPrintModal(){
  if(!(await ensureAdminPrintAccess()))return;
  const edit=$('editModal'),body=$('editBody');if(!edit||!body)return;
  body.innerHTML='<div class="info">Đang tải các đơn cần đóng…</div>'; $('editTitle').textContent='🖨️ In phiếu đơn theo nhân viên'; edit.classList.add('show');
  CloudSync.state().adminListOrders().then(rows=>{
    batchPrintRows=(rows||[]).filter(r=>r.status!=='completed');
    const employees=[...new Set(batchPrintRows.map(r=>String(r.employee||'').trim()).filter(Boolean))].sort((a,b)=>String(a).localeCompare(String(b),'vi'));
    if(!employees.length){body.innerHTML='<div class="empty">Không có đơn đang chờ đóng để in.</div>';return}
    body.innerHTML=`<div class="field"><label>Nhân viên được phân công</label><select id="batchPrintEmployee" onchange="renderBatchPrintOrders()"><option value="">-- Chọn nhân viên --</option>${employees.map(e=>`<option value="${esc(e)}">${esc(e)}</option>`).join('')}</select></div><div id="batchPrintOrders" class="assign-items"><div class="tiny muted">Chọn nhân viên để xem các đơn cần đóng.</div></div><div style="display:flex;gap:8px;margin-top:10px"><button type="button" class="secondary" onclick="closeEdit()">ĐÓNG</button><button type="button" class="primary" onclick="printSelectedPackingOrders()">🖨️ IN CÁC ĐƠN ĐÃ CHỌN</button></div><div class="tiny muted" style="margin-top:8px">Mỗi đơn in thành một phiếu 65 × 100 mm; tất cả phiếu được gửi trong cùng một lượt in.</div>`;
  }).catch(e=>{console.error(e);body.innerHTML='<div class="empty">Không tải được danh sách đơn để in.</div>'});
}
function renderBatchPrintOrders(){
  const employee=String($('batchPrintEmployee')?.value||''),box=$('batchPrintOrders');if(!box)return;
  const rows=batchPrintRows.filter(r=>String(r.employee||'')===employee);
  if(!rows.length){box.innerHTML='<div class="empty">Nhân viên này không có đơn đang chờ đóng.</div>';return}
  box.innerHTML=`<label style="display:flex;align-items:center;gap:8px;padding:8px 0;font-weight:800"><input type="checkbox" id="batchPrintAll" checked onchange="toggleBatchPrintAll(this.checked)"> Chọn tất cả (${rows.length} đơn)</label>`+rows.map(r=>`<label class="assign-item-row" style="display:flex;align-items:center;gap:9px;cursor:pointer"><input class="batch-print-check" type="checkbox" value="${esc(r.id)}" checked><div class="assign-item-main"><b>Đơn #${esc(r.orderNo||r.id.slice(-6))}</b><span>${orderItemsLabel(r).replace(/<br>/g,' · ')} · ${Math.round(orderTotalQty(r))} cây</span></div></label>`).join('');
}
function toggleBatchPrintAll(on){document.querySelectorAll('.batch-print-check').forEach(c=>c.checked=!!on)}
async function sendPackingOrderToFlashLabel(id){if(!(await ensureAdminPrintAccess()))return;const r=batchPrintRows.find(x=>String(x.id)===String(id))||(D.packingOrders||[]).find(x=>String(x.id)===String(id));if(!r){toast('Không tìm thấy đơn');return}document.documentElement.classList.add('print-order');document.body.classList.add('print-order');const box=$('orderPrintArea');if(!box)return;box.innerHTML=buildPackingPrintPage(r);box.setAttribute('aria-hidden','false');if(window.AndroidBridge&&AndroidBridge.sendToFlashLabel){AndroidBridge.sendToFlashLabel('ROLL-CAY-CANH-'+String(r.orderNo||r.id).replace(/[^a-zA-Z0-9_-]/g,'_'));setTimeout(()=>{box.innerHTML='';box.setAttribute('aria-hidden','true');document.documentElement.classList.remove('print-order');document.body.classList.remove('print-order')},12000);return}toast('Bản APK này chưa tích hợp FlashLabel');document.documentElement.classList.remove('print-order');document.body.classList.remove('print-order')}
async function printSelectedPackingOrders(){
  if(!(await ensureAdminPrintAccess()))return;
  document.documentElement.classList.add('print-order');document.body.classList.add('print-order');
  const ids=[...document.querySelectorAll('.batch-print-check:checked')].map(x=>x.value),rows=ids.map(id=>batchPrintRows.find(r=>String(r.id)===String(id))).filter(Boolean);
  if(!rows.length){toast('Hãy chọn ít nhất 1 đơn để in');return}
  const box=$('orderPrintArea');if(!box)return;
  box.innerHTML=rows.map(buildPackingPrintPage).join('');box.setAttribute('aria-hidden','false');closeEdit();
  if(window.AndroidBridge&&AndroidBridge.printOrder65x100){try{AndroidBridge.printOrder65x100('ROLL-CAY-CANH-'+String(rows[0].employee||'NHAN-VIEN').replace(/[^a-zA-Z0-9_-]/g,'_')+'-'+rows.length+'DON');setTimeout(()=>{box.innerHTML='';box.setAttribute('aria-hidden','true');document.documentElement.classList.remove('print-order');document.body.classList.remove('print-order')},15000);return}catch(e){console.error(e);document.documentElement.classList.remove('print-order');document.body.classList.remove('print-order')}}
  try{window.print();setTimeout(()=>{box.innerHTML='';box.setAttribute('aria-hidden','true');document.documentElement.classList.remove('print-order');document.body.classList.remove('print-order')},1500)}catch(e){document.documentElement.classList.remove('print-order');document.body.classList.remove('print-order');toast('Thiết bị chưa hỗ trợ in trực tiếp')}
}
function renderCloudBody(){const b=$('cloudBody');if(!b)return;const s=CloudSync.state();if(!CLOUD_CONFIG){b.innerHTML='<div class="info">☁️ Cloud chưa được cấu hình.</div>';return}if(s.user){const isProc=s.role==='procurement'||s.role==='purchaser';b.innerHTML=`<div class="info"><b>Đã đăng nhập</b><div class="cloud-user">${esc(s.user.email||'')}</div><div style="margin-top:6px"><span class="role-pill">${esc(ROLE_LABELS[s.role]||'Chỉ xem')}</span></div>${isProc?'<div class="tiny muted" style="margin-top:7px">Danh mục cây và báo giá được đồng bộ tự động. Nhân viên thu mua không cần đồng bộ dữ liệu kho.</div>':''}</div>${isProc?'':`<button class="primary" onclick="syncNow()">🔄 ĐỒNG BỘ NGAY</button>`}<button class="secondary" style="margin-top:8px;width:100%" onclick="CloudSync.signOut()">Đăng xuất</button>`}else{const remembered=(localStorage.getItem('ROLL_CAY_REMEMBER_EMAIL')||'').replace(/"/g,'&quot;');b.innerHTML='<div class="info"><b>Đăng nhập để sử dụng Cloud</b><div class="tiny muted">Tài khoản do Quản trị viên cấp.</div></div><button class="primary" onclick="showLoginGate()">ĐĂNG NHẬP</button>'}}
async function renderUserManagement(){const card=$('userAdminCard');const list=$('userList');if(!card||!list)return;const s=CloudSync.state();const ok=!!s.user&&(s.role==='admin'||CloudSync.can('users'));card.style.display=ok?'block':'none';if(!ok){list.innerHTML='';return}list.innerHTML='<div class="tiny muted">Đang tải danh sách tài khoản…</div>';try{const users=await CloudSync.listUsers();list.innerHTML=users.length?users.map(u=>{const role=u.role||'viewer';const active=u.active!==false;const self=u.uid===s.user.uid;const linked=role==='admin'?'<span class="role-pill">🔒 Admin · không gắn nhân viên</span>':(u.employeeName?`<span class="role-pill">${esc(u.employeeName)}</span>`:'<span class="tiny muted">⚪ Chưa liên kết nhân viên</span>');return `<div class="control-item"><div class="user-row"><div class="user-meta"><div class="user-email">${esc(u.email||u.uid)}</div><div class="tiny muted">${linked} · <span class="role-pill">${esc(ROLE_LABELS[role]||role)}</span> · ${active?'🟢 Đang hoạt động':'🔴 Đã khóa'}</div></div><div class="user-actions">${role!=='admin'?`<button class="secondary" onclick="openLinkEmployee('${u.uid}','${encodeURIComponent(u.employeeId||'')}')">${u.employeeName?'Đổi NV':'Gắn NV'}</button>`:''}<button class="secondary" onclick="changeUserRole('${u.uid}','${role}')" ${self?'disabled':''}>Quyền</button><button class="secondary" onclick="toggleUserActive('${u.uid}',${active})" ${self?'disabled':''}>${active?'Khóa':'Mở'}</button></div></div></div>`}).join(''):'<div class="empty">Chưa có tài khoản nào.</div>'}catch(e){console.error(e);list.innerHTML='<div class="empty">Không đọc được danh sách user. Kiểm tra Firestore Rules.</div>'}}
function employeeOptions(selected=''){return (D.employees||[]).map((e,i)=>`<option value="${i}" ${String(i)===String(selected)?'selected':''}>${esc(e)}</option>`).join('')}
function openLinkEmployee(uid,current=''){if(!CloudSync.requirePerm('users'))return;$('editTitle').textContent='Liên kết tài khoản với nhân viên';$('editBody').innerHTML=`<div class="info">Tài khoản này sẽ dùng đúng nhân viên đã có trong danh sách. Không tạo thêm nhân viên mới.</div><div class="field"><label>Nhân viên</label><select id="linkEmployeeId"><option value="">-- Chọn nhân viên --</option>${employeeOptions(decodeURIComponent(current||''))}</select></div><button class="primary" onclick="saveUserEmployeeLink('${uid}')">LƯU LIÊN KẾT</button>`;$('editModal').classList.add('show')}
async function saveUserEmployeeLink(uid){const id=$('linkEmployeeId')?.value;if(id===''){toast('Hãy chọn nhân viên');return}const ok=await CloudSync.state().linkUserEmployee(uid,id);if(ok)closeEdit()}
function openCreateUser(){if(!CloudSync.requirePerm('users'))return;$('editTitle').textContent='Cấp tài khoản cho nhân viên có sẵn';$('editBody').innerHTML=`<div class="info">Chọn một nhân viên đã có trong danh sách. Việc cấp tài khoản <b>không tạo thêm nhân viên</b>.</div><div class="field"><label>Nhân viên</label><select id="newUserEmployee"><option value="">-- Chọn nhân viên --</option>${employeeOptions()}</select></div><div class="field"><label>Email đăng nhập</label><input id="newUserEmail" type="email" placeholder="nhanvien@example.com"></div><div class="field"><label>Mật khẩu</label><input id="newUserPass" type="password" placeholder="Ít nhất 6 ký tự"></div><div class="field"><label>Quyền</label><select id="newUserRole"><option value="packer">Nhân viên đóng hàng</option><option value="warehouse">Nhân viên kho</option><option value="procurement">Nhân viên thu mua</option><option value="manager">Quản lý</option><option value="viewer">Chỉ xem</option></select></div><button class="primary" onclick="createNewUser()">CẤP TÀI KHOẢN</button><div class="tiny muted" style="margin-top:8px">Mật khẩu chỉ dùng để tạo tài khoản Firebase; app không lưu mật khẩu.</div>`;$('editModal').classList.add('show')}
async function createNewUser(){const ok=await CloudSync.createUser(($('newUserEmail')?.value||'').trim(),$('newUserPass')?.value||'', $('newUserEmployee')?.value||'', $('newUserRole')?.value||'viewer');if(ok){closeEdit();renderUserManagement();fillAssignOptions()}}
async function changeUserRole(uid,current){if(!CloudSync.requirePerm('users'))return;const normalized=current==='purchaser'?'procurement':current;$('editTitle').textContent='Đổi quyền tài khoản';$('editBody').innerHTML=`<div class="info">Chọn <b>một</b> quyền duy nhất. Quyền Thu mua chỉ có <b>Báo giá</b> và <b>Danh mục cây</b> trong Điều khiển.</div><div class="field"><label>Quyền tài khoản</label><select id="editUserRole"><option value="procurement" ${normalized==='procurement'?'selected':''}>Nhân viên thu mua</option><option value="packer" ${normalized==='packer'?'selected':''}>Nhân viên đóng hàng</option><option value="warehouse" ${normalized==='warehouse'?'selected':''}>Nhân viên kho</option><option value="manager" ${normalized==='manager'?'selected':''}>Quản lý</option><option value="viewer" ${normalized==='viewer'?'selected':''}>Chỉ xem</option></select></div><button class="primary" onclick="saveUserRole('${uid}')">LƯU QUYỀN</button>`;$('editModal').classList.add('show')}
async function saveUserRole(uid){const role=$('editUserRole')?.value||'';if(!role)return;try{await CloudSync.setUserRole(uid,role);closeEdit();renderUserManagement();toast('✅ Đã gán đúng quyền '+(ROLE_LABELS[role]||role))}catch(e){toast(e?.message||'Không thể cập nhật quyền')}}
async function toggleUserActive(uid,active){await CloudSync.setUserActive(uid,!active)}
let shipmentPhoto='',shipmentOcrText='';
function shipmentRows(){return Array.isArray(D.shipments)?D.shipments:[]}
function normalizeTracking(s){return String(s||'').toUpperCase().replace(/[^A-Z0-9]/g,'')}
function shipmentOcrClean(text){return String(text||'').replace(/[\u2010-\u2015]/g,'-').replace(/[|]/g,'I').replace(/\u00a0/g,' ').replace(/\r/g,'');}
function findNumeric12Candidates(text){const raw=shipmentOcrClean(text);const out=[];out.push(...(raw.match(/\b\d{12}\b/g)||[]));for(const line of raw.split(/\n/)){const digits=line.replace(/\D/g,'');if(/^\d{12}$/.test(digits))out.push(digits);const m=line.match(/(?:^|\D)(862|530)(?:[\s.-]?\d){9}(?:$|\D)/);if(m){const d=m[0].replace(/\D/g,'');if(/^\d{12}$/.test(d))out.push(d)}}return [...new Set(out)];}
function findTrackingCandidates(text){const raw=shipmentOcrClean(text).toUpperCase();const out=[];const vngh=raw.match(/V\s*N\s*G\s*H\s*[A-Z0-9]{6,24}/g)||[];vngh.forEach(x=>out.push(normalizeTracking(x)));const alnum=raw.match(/\b[A-Z0-9]{8,30}\b/g)||[];alnum.forEach(x=>{const n=normalizeTracking(x);if(n.length>=8&&n.length<=30&&/[A-Z]/.test(n)&&/\d/.test(n))out.push(n)});findNumeric12Candidates(raw).forEach(x=>out.push(x));return [...new Set(out)];}
function detectTrackingNo(text){const raw=shipmentOcrClean(text);const candidates=findTrackingCandidates(raw);/* Vận đơn cố định: GHN=VNGH..., J&T Express=12 số đầu 862, J&T Cargo=12 số đầu 530. Tuyệt đối không fallback sang chuỗi OCR bất kỳ. */const vngh=candidates.find(x=>/^VNGH[A-Z0-9]{6,24}$/.test(x));if(vngh)return vngh;const jtExpress=candidates.find(x=>/^862\d{9}$/.test(x));if(jtExpress)return jtExpress;const cargo=candidates.find(x=>/^530\d{9}$/.test(x));if(cargo)return cargo;const lines=raw.split(/\n/).map(x=>x.trim()).filter(Boolean);for(const line of lines){if(/(mã vận đơn|ma van don|tracking|waybill|bill|order code|mã đơn hàng|ma don hang)/i.test(line)){const digits=line.replace(/\D/g,'');if(/^862\d{9}$/.test(digits)||/^530\d{9}$/.test(digits))return digits;const vm=line.replace(/[^A-Z0-9]/gi,'').toUpperCase();if(/^VNGH[A-Z0-9]{6,24}$/.test(vm))return vm}}return '';}
function detectShipmentCarrier(text){const raw=shipmentOcrClean(text);const t=raw.toUpperCase().replace(/\s+/g,' ');const tr=detectTrackingNo(raw);/* Mã vận đơn là lớp nhận diện mạnh nhất; logo/từ khóa chỉ là lớp xác nhận. */if(/^862\d{9}$/.test(tr))return 'J&T Express';if(/^530\d{9}$/.test(tr))return 'J&T Cargo';if(/^VNGH[A-Z0-9]{6,24}$/.test(tr))return 'GHN';if(/V\s*N\s*G\s*H/.test(t)||/GIAO\s*HANG\s*NHANH|GIAO\s*HÀNG\s*NHANH|GIAOHANGNHANH|\bGHN\b/.test(t))return 'GHN';if(/CARGO/.test(t)&&(/J\s*&?\s*T|JNT/.test(t)))return 'J&T Cargo';if(/EXPRESS/.test(t)&&(/J\s*&?\s*T|JNT/.test(t)))return 'J&T Express';return ''}
function detectShipmentCustomer(text){const lines=shipmentOcrClean(text).split(/\n/).map(x=>x.trim()).filter(Boolean);for(let i=0;i<lines.length;i++){const line=lines[i];const m=line.match(/(?:người nhận|nguoi nhan|khách hàng|khach hang|recipient|receiver)\s*[:：-]?\s*(.+)$/i);if(m&&m[1].trim())return m[1].trim();if(/^(người nhận|nguoi nhan|khách hàng|khach hang|recipient|receiver)\s*[:：-]?$/i.test(line)){const next=String(lines[i+1]||'').trim();if(next&&!/(^\+?\d|kg$|order|mã|ma )/i.test(next))return next}}/* Một số nhãn OCR dính nhãn với tên; tìm dòng gần 'người nhận' e.g. 'Người nhận Bùi Quang Võ'. */for(let i=0;i<lines.length;i++){if(/người nhận|nguoi nhan|recipient|receiver/i.test(lines[i])){const cleaned=lines[i].replace(/.*?(người nhận|nguoi nhan|recipient|receiver)\s*[:：-]?/i,'').trim();if(cleaned&&cleaned.length>1)return cleaned}}return ''}
function parseShipmentOcr(text){const raw=String(text||'');const trackingNo=detectTrackingNo(raw);const carrier=detectShipmentCarrier(raw);return {trackingNo,carrier,customerName:detectShipmentCustomer(raw),ocrText:raw}}
function completedShipmentRows(){return (Array.isArray(D.packingOrders)?D.packingOrders:[]).filter(r=>String(r?.status||'')==='completed' && (r?.shipmentTrackingNo||r?.shipment?.trackingNo)).map(r=>{const sh=r.shipment||{};return {id:String(r.id),orderId:String(r.id),orderNo:String(r.orderNo||''),date:String(r.completedDate||r.date||''),carrier:String(r.shipmentCarrier||sh.carrier||''),trackingNo:normalizeTracking(r.shipmentTrackingNo||sh.trackingNo||''),customerName:String(r.shipmentCustomerName||sh.customerName||''),employee:String(r.employee||''),photo2:String(r.completionImages?.[1]||''),ocrText:String(r.shipmentOcrText||sh.ocrText||''),createdAtMs:Number(r.completedAtMs||r.createdAtMs||0)}}).filter(x=>x.trackingNo)}
function showShipmentPhoto(src){shipmentPhoto=src||'';const box=$('shipmentPhotoPreview');if(!box)return;if(!shipmentPhoto){box.classList.add('hidden');box.innerHTML='';return}box.classList.remove('hidden');box.innerHTML=`<img class="shipment-photo" src="${shipmentPhoto}" onclick="openImageSrc(this.src,'Ảnh vận đơn')" alt="Ảnh vận đơn"><div class="tiny muted" style="margin-top:5px">Ảnh vận đơn đã chọn.</div>`}
function applyShipmentOcr(text){shipmentOcrText=String(text||'');const p=parseShipmentOcr(shipmentOcrText);if($('shipmentCarrier'))$('shipmentCarrier').value=p.carrier||$('shipmentCarrier').value;if($('shipmentTracking'))$('shipmentTracking').value=p.trackingNo||'';if($('shipmentCustomer'))$('shipmentCustomer').value=p.customerName||'';const box=$('shipmentOcrBox');if(box){box.classList.remove('hidden');box.textContent=shipmentOcrText||'Không nhận diện được chữ.'}return p}
window.__shippingOcrResult=function(text){applyShipmentOcr(text)};
let pendingShipmentOcr={trackingNo:'',carrier:'',customerName:'',ocrText:''},pendingShipmentOcrBusy=false;
window.__packingShipmentOcrResult=function(text){pendingShipmentOcrBusy=false;pendingShipmentOcr=parseShipmentOcr(text);const st=$('packProofStatus');if(st){const p=pendingShipmentOcr;st.textContent=p.trackingNo?`Đã đủ 2 ảnh · 🚚 ${p.carrier||'Chưa rõ'} · ${p.trackingNo}${p.customerName?' · '+p.customerName:''}`:'Đã đủ 2 ảnh · ⚠️ Chưa đọc được mã vận đơn, hãy chụp lại ảnh 2.'}renderPackProofPreview();const btn=$('packSubmitBtn');if(btn){const ok=shipmentProofReady();btn.disabled=!ok;btn.textContent=ok?'✅ XÁC NHẬN HOÀN THÀNH ĐƠN':'🔒 XÁC NHẬN HOÀN THÀNH ĐƠN';}};
function readShipmentImage(ev){const f=ev.target.files?.[0];if(!f)return;if(!String(f.type||'').startsWith('image/')){toast('Chỉ chọn ảnh');ev.target.value='';return}const rd=new FileReader();rd.onload=()=>{const im=new Image();im.onload=()=>{const max=1600,sc=Math.min(1,max/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.width*sc));c.height=Math.max(1,Math.round(im.height*sc));const ctx=c.getContext('2d');ctx.drawImage(im,0,0,c.width,c.height);shipmentPhoto=c.toDataURL('image/jpeg',.82);showShipmentPhoto(shipmentPhoto);if(window.AndroidBridge&&AndroidBridge.ocrShippingImage){AndroidBridge.ocrShippingImage(shipmentPhoto,'__shippingOcrResult')}else{applyShipmentOcr('')}};im.src=rd.result};rd.readAsDataURL(f);ev.target.value=''}
function shipmentDateDefault(){return $('shipmentFilterDate')?.value||fmt(new Date())}
function initShipmentTracking(){const el=$('shipmentFilterDate');if(el&&!el.value)el.value=fmt(new Date());renderShipments()}
function renderShipmentCounts(rows){const date=$('shipmentFilterDate')?.value||shipmentDateDefault(),rs=rows.filter(x=>String(x.date)===date);const c={"J&T Express":0,"J&T Cargo":0,GHN:0};rs.forEach(x=>{if(c[x.carrier]!=null)c[x.carrier]++});const box=$('shipmentCounts');if(box)box.innerHTML=['J&T Express','J&T Cargo','GHN'].map(k=>`<div class="shipment-count"><span>${k}</span><b>${c[k]}</b><small>đơn / ngày</small></div>`).join('')}
function renderShipments(){const box=$('shipmentList');if(!box)return;const date=$('shipmentFilterDate')?.value||shipmentDateDefault(),q=normalizeTracking($('shipmentSearch')?.value||''),fc=String($('shipmentFilterCarrier')?.value||'');let rows=completedShipmentRows().filter(x=>String(x.date)===date);if(q)rows=rows.filter(x=>normalizeTracking(x.trackingNo).includes(q)||normalizeTracking(x.orderNo).includes(q)||normalizeTracking(x.orderId).includes(q));if(fc)rows=rows.filter(x=>x.carrier===fc);const all=completedShipmentRows();renderShipmentCounts(all);rows.sort((a,b)=>Number(b.createdAtMs||0)-Number(a.createdAtMs||0));if(!rows.length){box.innerHTML='<div class="empty">Chưa có đơn hoàn thành có thông tin vận chuyển phù hợp.</div>';return}box.innerHTML=`<table><thead><tr><th>Ảnh 2</th><th>Đơn</th><th>Mã vận đơn</th><th>Đơn vị</th><th>Người nhận</th><th>NV đóng</th><th>Ngày</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${x.photo2?`<img class="shipment-photo" src="${x.photo2}" onclick="openImageSrc(this.src,'Ảnh đơn hàng có mã vận đơn')">`:'—'}</td><td><b>#${esc(x.orderNo||x.orderId.slice(-6))}</b><div class="tiny muted">ID: ${esc(x.orderId)}</div></td><td><b>${esc(x.trackingNo)}</b></td><td><span class="shipment-badge">${esc(x.carrier||'Chưa rõ')}</span></td><td>${esc(x.customerName||'Chưa đọc được')}</td><td>${esc(x.employee||'')}</td><td>${fmtDMY(x.date)}</td></tr>`).join('')}</tbody></table>`}
function deleteShipment(id){toast('Vận đơn được gắn với đơn hoàn thành và không xóa riêng. Nếu cần chỉnh sửa, Admin sửa trực tiếp đơn hoàn thành.')}

let quoteItems=[];
function quoteCatalogRows(){return activeCatalog().map(o=>({i:Number(o.i),p:o.p})).filter(x=>x.p)}
function renderQuote(){if(!$('quote'))return;renderQuoteProducts();renderQuoteItems()}
function renderQuoteProducts(){const box=$('quoteProductList');if(!box)return;const q=String($('quoteSearch')?.value||'').trim().toLowerCase();const rows=quoteCatalogRows().filter(x=>!q||String(x.p.name||'').toLowerCase().includes(q)||String(x.p.size||'').toLowerCase().includes(q));box.innerHTML=rows.length?rows.map(x=>`<button type="button" class="quote-product-card" onclick="addQuoteItem(${x.i})"><img src="${imageSrc(x.p)}" alt=""><span class="qp-main"><b>${esc(x.p.name||'')}</b><span class="quote-item-meta">Kích thước: ${esc(x.p.size||'')}</span><span class="qp-price">${money(x.p.price||0)}</span></span></button>`).join(''):'<div class="quote-empty" style="grid-column:1/-1">Không tìm thấy cây trong danh mục.</div>'}
function addQuoteItem(i){const p=D.catalog[Number(i)];if(!p||p.deleted)return;const catalogId=String(p.catalogId||''),found=quoteItems.find(x=>String(x.catalogId||'')===catalogId);if(found)found.qty=Math.max(1,Number(found.qty)||1)+1;else quoteItems.push({catalogId,qty:1});renderQuoteItems();toast('Đã thêm '+(p.name||'cây')+' vào báo giá')}
function removeQuoteItem(i){quoteItems.splice(Number(i),1);renderQuoteItems()}
function updateQuoteQty(i,v){const q=Math.max(1,Math.floor(Number(v)||1));if(quoteItems[i])quoteItems[i].qty=q;renderQuoteItems()}
function quoteTotal(){return quoteItems.reduce((s,x)=>{const p=catalogById(String(x.catalogId||''));return s+(Number(x.qty)||0)*(Number(p?.price)||0)},0)}
function renderQuoteItems(){const box=$('quoteItems');if(!box)return;const badge=$('quoteCountBadge'),qtyCount=quoteItems.reduce((s,x)=>s+(Number(x.qty)||0),0);if(badge)badge.textContent=`${quoteItems.length} sản phẩm · ${qtyCount} cây`;if(!quoteItems.length)box.innerHTML='<div class="quote-empty">Chưa có cây. Hãy bấm vào sản phẩm ở phía trên để thêm vào đơn báo giá.</div>';else box.innerHTML=quoteItems.map((x,i)=>{const p=catalogById(String(x.catalogId||''))||{},q=Math.max(1,Number(x.qty)||1),total=q*(Number(p.price)||0);return `<div class="quote-item"><div class="quote-item-head"><img class="plant-thumb-lg" src="${imageSrc(p)}" alt=""><div class="quote-item-info"><b>${esc(p.name||'')}</b><div class="quote-item-meta">Kích thước: ${esc(p.size||'')} · Đơn giá: ${money(p.price||0)}</div></div><div class="quote-item-total">${money(total)}</div></div><div class="quote-modal-row" style="margin-top:9px"><div class="field" style="margin:0"><label>Số lượng</label><input type="number" min="1" step="1" value="${q}" onchange="updateQuoteQty(${i},this.value)"></div><button class="danger" type="button" onclick="removeQuoteItem(${i})">Xóa</button></div></div>`}).join('');if($('quoteGrandTotal'))$('quoteGrandTotal').textContent=money(quoteTotal())}
function clearQuote(){if(!quoteItems.length)return;if(confirm('Xóa toàn bộ đơn báo giá hiện tại?')){quoteItems=[];if($('quoteCustomer'))$('quoteCustomer').value='';if($('quotePhone'))$('quotePhone').value='';if($('quoteNote'))$('quoteNote').value='';renderQuoteItems()}}
function quoteDate(){return fmtDMY(fmt(new Date()))}
function quoteCsvCell(v){return '"'+String(v??'').replace(/"/g,'""')+'"'}
function exportQuoteCsv(){if(!quoteItems.length){toast('Chưa có cây trong báo giá');return}const lines=[];lines.push([quoteCsvCell('BÁO GIÁ ROLL GARDEN')].join(','));lines.push([quoteCsvCell('Khách hàng'),quoteCsvCell($('quoteCustomer')?.value||''),quoteCsvCell('Ngày'),quoteCsvCell(quoteDate())].join(','));lines.push([quoteCsvCell('Số điện thoại'),quoteCsvCell($('quotePhone')?.value||'')].join(','));lines.push('');lines.push(['STT','Tên sản phẩm','Kích thước','Số lượng','Đơn giá','Thành tiền'].map(quoteCsvCell).join(','));quoteItems.forEach((x,i)=>{const p=catalogById(String(x.catalogId||''))||{},q=Number(x.qty)||0;lines.push([i+1,p.name||'',p.size||'',q,Number(p.price)||0,q*(Number(p.price)||0)].map(quoteCsvCell).join(','))});lines.push('');lines.push([quoteCsvCell('TỔNG GIÁ'),quoteCsvCell(quoteTotal())].join(','));if($('quoteNote')?.value)lines.push([quoteCsvCell('Ghi chú'),quoteCsvCell($('quoteNote').value)].join(','));downloadText(`Bao-gia-ROLL-GARDEN-${fmt(new Date())}.csv`,'\ufeff'+lines.join('\r\n'));if(!(window.AndroidBridge&&AndroidBridge.saveFile))toast('Đã xuất file CSV')}
window.finishQuotePdfExport=function(ok){const box=$('quotePdfPrint');if(box){box.classList.remove('show');box.innerHTML=''}document.documentElement.classList.remove('print-quote');document.body.classList.remove('print-quote');if(ok)toast('✅ Đã lưu báo giá PDF vào Tải xuống / ROLL CAY CANH')};
function exportQuotePdf(){
  if(!quoteItems.length){toast('Chưa có cây trong báo giá');return}
  const items=quoteItems.map((x,i)=>{const p=catalogById(String(x.catalogId||''))||{},q=Number(x.qty)||0,t=q*(Number(p.price)||0);return {i:i+1,p,q,t}});
  const pages=[];const PAGE_ROWS=8;
  for(let start=0;start<items.length;start+=PAGE_ROWS){
    const chunk=items.slice(start,start+PAGE_ROWS);
    const rows=chunk.map(r=>`<tr><td style=\"text-align:center\">${r.i}</td><td><img src=\"${imageSrc(r.p)}\" alt=\"\"></td><td><b>${esc(r.p.name||'')}</b></td><td>${esc(r.p.size||'')}</td><td style=\"text-align:center\">${r.q}</td><td style=\"text-align:right\">${money(r.p.price||0)}</td><td style=\"text-align:right\">${money(r.t)}</td></tr>`).join('');
    const meta=start===0?`<div class=\"quote-pdf-meta\"><div><b>Khách hàng:</b> ${esc($('quoteCustomer')?.value||'')}</div><div><b>Ngày:</b> ${quoteDate()}</div><div><b>Số điện thoại:</b> ${esc($('quotePhone')?.value||'')}</div><div><b>Đơn vị:</b> ROLL GARDEN</div></div>`:'';
    const isLast=start+PAGE_ROWS>=items.length;
    const total=isLast?`<div class=\"quote-pdf-total\">TỔNG GIÁ: ${money(quoteTotal())}</div>${$('quoteNote')?.value?`<div class=\"quote-pdf-note\"><b>Ghi chú:</b> ${esc($('quoteNote').value)}</div>`:''}`:'';
    pages.push(`<div class=\"quote-pdf-page\"><img class=\"quote-pdf-bg\" src=\"quote-background.jpg\" alt=\"\"><div class=\"quote-pdf-content\"><h1>BÁO GIÁ CÂY CẢNH</h1>${meta}<table class=\"quote-pdf-table\"><colgroup><col style=\"width:7%\"><col style=\"width:20%\"><col style=\"width:28%\"><col style=\"width:12%\"><col style=\"width:7%\"><col style=\"width:13%\"><col style=\"width:13%\"></colgroup><thead><tr><th>STT</th><th>Hình ảnh</th><th>Tên sản phẩm</th><th>Kích thước</th><th>SL</th><th>Đơn giá</th><th>Thành tiền</th></tr></thead><tbody>${rows}</tbody></table>${total}<div class=\"quote-pdf-footer\">ROLL GARDEN · Cây đẹp - Không gian xanh - Cuộc sống an lành</div></div></div>`);
  }
  const box=$('quotePdfPrint');if(!box)return;box.innerHTML=pages.join('');box.classList.add('show');document.documentElement.classList.add('print-quote');document.body.classList.add('print-quote');const job='Bao-gia-ROLL-GARDEN-'+fmt(new Date());if(window.AndroidBridge&&AndroidBridge.exportPdf){try{AndroidBridge.exportPdf(job);return;}catch(e){console.error(e)}} if(window.AndroidBridge&&AndroidBridge.printA4Page){try{AndroidBridge.printA4Page(job);setTimeout(()=>{box.classList.remove('show');box.innerHTML='';document.documentElement.classList.remove('print-quote');document.body.classList.remove('print-quote')},15000);return}catch(e){console.error(e);document.documentElement.classList.remove('print-quote');document.body.classList.remove('print-quote')}}try{window.print()}finally{setTimeout(()=>{box.classList.remove('show');box.innerHTML='';document.documentElement.classList.remove('print-quote');document.body.classList.remove('print-quote')},1800)}}
function applyPermissionsUI(){
  const s=CloudSync.state();const roleNow=s.role||'';const isP=roleNow==='packer';const isPurchaser=roleNow==='procurement'||roleNow==='purchaser';const isA=roleNow==='admin';
  const hasPack=s.user&&CloudSync.can('pack'),hasIn=s.user&&CloudSync.can('in'),hasReport=s.user&&CloudSync.can('report'),hasPayroll=s.user&&CloudSync.can('payroll'),hasControl=s.user&&CloudSync.can('control'),hasQuote=s.user&&CloudSync.can('quote'),hasCatalog=s.user&&CloudSync.can('catalog');
  const nav=document.querySelectorAll('.bottomnav button');nav.forEach(b=>{const t=b.dataset.tab; if(t==='home')b.style.display=(isP||isPurchaser)?'none':''; if(t==='day')b.style.display=(hasPack||hasIn)?'':'none'; if(t==='stock')b.style.display=(isP||isPurchaser)?'none':''; if(t==='quote')b.style.display=hasQuote?'':'none'; if(t==='summary')b.style.display=hasReport?'':'none'; if(t==='payroll')b.style.display=hasPayroll?'':'none'; if(t==='control')b.style.display=(hasControl||hasCatalog)?'':'none'});
  if($('adminPackEntryPanel')){const showAdminPack=hasPack&&!isP&&!isPurchaser;$('adminPackEntryPanel').style.display=showAdminPack?'block':'none';$('adminPackEntryPanel').classList.toggle('perm-hidden',!showAdminPack)}
  if($('entryInfoPacker'))$('entryInfoPacker').classList.toggle('hidden',!isP);
  if($('packerOrderPanel'))$('packerOrderPanel').style.display=isP?'block':'none';
  if($('orderAssignCard'))$('orderAssignCard').style.display=isA?'block':'none';if(!isP)resetAdminPackProof();
  if(isP||isPurchaser){$('modeIn')?.classList.add('hidden')} else {if($('modeIn'))$('modeIn').classList.toggle('hidden',!hasIn)}
  if($('modePack'))$('modePack').style.display=hasPack?'':'none';
  if($('packForm')){$('packForm').classList.remove('hidden');$('packForm').style.display=(hasPack&&entryMode==='pack')?'block':'none';}
  if($('inForm')){$('inForm').classList.remove('hidden');$('inForm').style.display=(hasIn&&entryMode==='in')?'block':'none';}
  const ids=['rateList','openingList','empList'];ids.forEach(id=>{const el=$(id);if(el)el.closest('.card')?.classList.toggle('perm-hidden',!hasControl)});
  const plantCard=document.getElementById('plantList')?.closest('.card');if(plantCard)plantCard.classList.toggle('perm-hidden',!hasControl&&!hasCatalog);
  if($('userAdminCard'))$('userAdminCard').style.display=s.user&&(s.role==='admin'||CloudSync.can('users'))?'block':'none';if($('adminAssignmentShortcutCard'))$('adminAssignmentShortcutCard').style.display=isA?'block':'none';
  const controlHero=document.querySelector('#control .hero');if(controlHero)controlHero.style.display=(hasControl||hasCatalog)?'':'none';
  if(isPurchaser){document.querySelectorAll('#control > .card').forEach(card=>{const plant=card.querySelector('#plantList');if(plant)card.classList.remove('perm-hidden');else card.classList.add('perm-hidden')})}
  const activeTab=document.querySelector('.tab.active')?.id||'home';
  if(isPurchaser){
    // Thu mua được dùng cả Báo giá và Điều khiển > Danh mục cây.
    // Không tự động đá người dùng về tab Báo giá khi họ mở Điều khiển.
    if(!hasQuote&&activeTab==='quote')go('control');
    if(!hasQuote&&!hasCatalog&&activeTab==='control')go('home');
  }
  else if(isP&&['home','stock','summary','control'].includes(activeTab))go(hasPack?'day':'home');
  else if(s.user&&!hasControl&&!hasCatalog&&activeTab==='control')go(hasQuote?'quote':hasReport?'summary':hasPack||hasIn?'day':'home');
}


document.querySelectorAll('.bottomnav button').forEach(b=>b.onclick=()=>go(b.dataset.tab));
$('rFrom').addEventListener('change',onReportFromChange);$('rTo').addEventListener('change',onReportToChange);
load();init();
ensureFirebaseSdk().then(()=>CloudSync.init()).catch(e=>{console.warn('Firebase SDK chưa tải được lúc khởi động',e);showLoginGateError('Đang chờ kết nối Firebase… Bạn có thể bấm ĐĂNG NHẬP để thử lại.')}).finally(()=>{installPermissionGuards();applyPermissionsUI();renderUserManagement()});
window.addEventListener('online',()=>{ensureFirebaseSdk().then(()=>CloudSync.init()).catch(()=>{})});
