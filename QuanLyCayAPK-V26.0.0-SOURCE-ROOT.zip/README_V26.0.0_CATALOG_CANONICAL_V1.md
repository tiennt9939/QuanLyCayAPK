# V26.0.0 — Catalog Canonical V1

## Mục tiêu

Bản này chuẩn hóa danh mục cây theo **một nguồn dữ liệu duy nhất**. `catalogId` là khóa nghiệp vụ của từng dòng cây + kích thước.

## Nguyên tắc

- Mỗi dòng catalog có `catalogId` duy nhất và ổn định.
- `plantIndex` chỉ còn được dùng như dữ liệu tương thích/migration với dữ liệu cũ.
- Nghiệp vụ mới không tạo bản ghi bằng `plantIndex`.
- Không dùng `name + size` làm khóa định danh nghiệp vụ.
- Cây/size mới đi vào chính `D.catalog`.
- Đổi tên hoặc đổi size của một dòng đã có lịch sử sẽ tạo catalog identity mới và giữ dòng cũ ở trạng thái lịch sử (`deleted=true`), tránh làm đổi nghĩa dữ liệu cũ.
- `opening` được lưu theo `catalogId`.
- `daily`, `packerRecords`, `shipments` được migration sang `catalogId`.
- Phân công `packingOrders` mới lưu `catalogId`, không bắt buộc `plantIndex`.
- Báo giá dùng `catalogId`.
- Sync catalog local/cloud merge theo `catalogId`, giữ cả local-only và cloud-only rows, tránh xóa cây mới.
- Sync đơn giá theo `size`, giữ size mới nếu chỉ có ở một phía.
- Size chưa có đơn giá lương sẽ được cảnh báo và bị chặn khi phân công/đóng hàng để tránh lương = 0 ngoài ý muốn.

## Tương thích dữ liệu cũ

Khi app khởi động, `repairCanonicalConfig()` chạy migration:

1. Bổ sung `catalogId` cho catalog cũ.
2. Chuyển `opening[index]` sang `opening[catalogId]`.
3. Chuyển `daily[].plantIndex` → `daily[].catalogId`.
4. Chuyển `packerRecords[].plantIndex` → `catalogId`.
5. Chuyển `shipments[].plantIndex` → `catalogId`.

Các order cũ trên Firestore vẫn được đọc bằng `plantIndex` khi cần; order mới dùng `catalogId`.

## Luồng kiểm thử bắt buộc

Catalog → tìm kiếm không dấu → chọn cây → chọn size → phân công → nhân viên nhận → 2 ảnh → OCR → hoàn thành → tồn kho → lương → báo cáo → báo giá → sync → đăng xuất → đăng nhập lại.

## Firestore Rules

`packingOrders` mới yêu cầu `catalogId` khi tạo. Quy tắc hoàn thành vẫn cho phép dữ liệu order cũ dùng `plantIndex` trong giai đoạn chuyển tiếp.
