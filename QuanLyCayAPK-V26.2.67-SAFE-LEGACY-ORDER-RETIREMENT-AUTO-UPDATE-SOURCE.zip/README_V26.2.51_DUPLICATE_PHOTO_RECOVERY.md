# ROLL CÂY CẢNH V26.2.51 — Khôi phục ảnh cho đơn đã ghi công

## Lỗi được xử lý
Khi Firebase trả về `duplicate`/`alreadyRecorded`, source V26.2.50 trước đó đánh dấu ảnh vừa chụp đã xử lý và xóa ảnh khỏi hàng đợi ngay lập tức. Nếu báo cáo đã ghi tiền công nhưng `photoRef` chưa phải `drive://`, ảnh không được gắn vào báo cáo cũ; đơn tiếp tục thiếu ảnh và mọi lần quét lại đều bị chặn trùng.

## Thay đổi
- Khi nhận diện đơn đã ghi nhận, kiểm tra báo cáo hiện có và `photoRef`.
- Nếu báo cáo đã ghi công nhưng thiếu ảnh Drive: tải ảnh lên Drive rồi gọi `attachDailyShipmentPhoto` để cập nhật báo cáo cũ.
- Không gọi lại `recordDailyShipmentScan`; không tạo tiền công mới và không trừ tồn kho lần hai.
- Nếu tải/gắn ảnh thất bại, giữ ảnh trong hàng đợi thử lại, không ACK/xóa ảnh gốc.
- Nếu ảnh đã có trên Drive, giữ hành vi chặn quét trùng.
- Nâng version lên 26.2.51 / versionCode 103 để cho phép cài cập nhật APK.

## Kiểm tra
`tools/v2651_duplicate_photo_recovery_test.js` kiểm tra nhánh phục hồi ảnh và bảo đảm không gọi lại giao dịch ghi công. Cần chạy toàn bộ regression/preflight và build bằng GitHub Actions; sau đó kiểm tra trên thiết bị thật với đơn đã ghi công nhưng thiếu ảnh.

## Lưu ý
Bản sửa source không tự sửa dữ liệu Firebase hiện có. Sau khi cài APK mới, cần quét/chụp lại từng mã thiếu ảnh; mã phải khớp với nhãn đã nhập. Không xóa lịch sử hoặc ghi công lại.
