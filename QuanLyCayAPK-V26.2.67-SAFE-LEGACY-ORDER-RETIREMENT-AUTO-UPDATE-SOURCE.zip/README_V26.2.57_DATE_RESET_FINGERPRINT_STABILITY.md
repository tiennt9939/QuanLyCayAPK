# V26.2.57 — Ổn định fingerprint xóa dữ liệu nghiệp vụ theo ngày

- Tiếp tục từ V26.2.56; không dựng lại ứng dụng và không đổi schema/công thức tiền công/bảng giá/nhân viên.
- Sửa phạm vi fingerprint để chỉ theo dõi các đơn hoàn tất thực sự thuộc ngày đã chọn; các thay đổi phân công/cache của đơn chưa hoàn tất không còn gây false mismatch. Việc một đơn chuyển sang hoàn tất trong ngày vẫn làm fingerprint thay đổi và bị chặn an toàn.
- Fingerprint claim chỉ chứa trạng thái tồn tại và trường ownership dùng để xác định claim có thuộc ngày đó; metadata không liên quan không gây lỗi giả.
- Bỏ timestamp cảnh báo lưu giữ khỏi fingerprint, vẫn giữ cờ bảo vệ retention đang chờ.
- Đồng bộ việc dọn cache `packingOrders` / `packerRecords` ngay trong shared data, tránh đơn đã xóa hồi sinh khi tải lại.
- Lỗi mismatch nay phân biệt được xảy ra ở bước đọc lại trước transaction hay trong transaction.
- Version `26.2.57`, versionCode `109`.

Kiểm tra tự động không thay thế build Android/GitHub Actions hoặc xác minh Firebase thật. Không tự động xóa dữ liệu.
