const assert = require('assert');
const fs = require('fs');
const path = require('path');
const api = require('../app/src/main/assets/tiktok-label-import.js');
const html = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/index.html'), 'utf8');

const catalog = [
  { key: 'plant_quynhanh_c7', i: 0, p: { catalogId: 'plant_quynhanh_c7', name: 'Quỳnh Anh', size: 'C7' } },
  { key: 'plant_quynhanh_c9', i: 1, p: { catalogId: 'plant_quynhanh_c9', name: 'Quỳnh Anh', size: 'C9' } },
  { key: 'plant_rubi_c7', i: 2, p: { catalogId: 'plant_rubi_c7', name: 'Rubi đỏ', size: 'C7' } },
];
const quynhRule = {
  quickRule: true, enabled: true, aliases: ['quỳnh anh', 'quỳnh anh 4 cây c7', 'quynh anh 4 cay c7'],
  lines: [{ catalogKey: 'plant_quynhanh_c7', perUnit: 4 }],
};
let result = api.applyRecognitionRule({ productName: 'Quỳnh Anh', qty: 2 }, catalog, { quickrule_quynhanh: quynhRule });
assert.strictEqual(result.matched, true, 'keyword rule may define per-unit count when the label omits it');
assert.strictEqual(result.perUnit, 4, 'rule returns 4 plants per sold unit');
assert.strictEqual(2 * result.perUnit, 8, 'PDF Qty=2 multiplies 4 plants per unit to 8 plants');

result = api.applyRecognitionRule({ productName: 'QUYNH ANH 4 CAY C7', sku: '4 cây C7', qty: 2 }, catalog, { quickrule_quynhanh: quynhRule });
assert.strictEqual(result.matched, true, 'keyword matching ignores Vietnamese diacritics and case');
assert.strictEqual(2 * result.perUnit, 8, 'explicit four-plant unit still reconciles with Qty');

result = api.applyRecognitionRule({ productName: 'Quỳnh Anh 5 cây C7', sku: '5 cây C7', qty: 2 }, catalog, { quickrule_quynhanh: quynhRule });
assert.strictEqual(result.matched, false, 'must not apply a four-plant rule to a five-plant label');
assert.strictEqual(result.needsReview, true, 'count mismatch must be surfaced for Admin review');

result = api.applyRecognitionRule({ productName: 'Quỳnh Anh 4 cây C9', sku: '4 cây C9', qty: 2 }, catalog, { quickrule_quynhanh: quynhRule });
assert.strictEqual(result.needsReview, true, 'explicit C9 must not map to C7');

result = api.applyRecognitionRule({ productName: 'Quỳnh Anh', qty: 1 }, catalog, {
  quickrule_a: quynhRule,
  quickrule_b: { quickRule: true, enabled: true, aliases: ['quỳnh anh', 'quỳnh anh 4 cây c7'], lines: [{ catalogKey: 'plant_quynhanh_c9', perUnit: 4 }] },
});
assert.strictEqual(result.needsReview, true, 'conflicting equally-specific quick rules must not guess');

result = api.applyRecognitionRule({ productName: 'Quỳnh Anh', qty: 2 }, catalog, { quickrule_off: { ...quynhRule, enabled: false } });
assert.strictEqual(result.matched, false, 'disabled rule must not be applied');

assert(html.includes('safe[signature].quickRule=true') && html.includes('safe[signature].aliases=aliases') && html.includes('safe[signature].enabled=rule.enabled!==false'), 'Cloud sanitizer must preserve quick-rule metadata');
assert(html.includes('function openTikTokQuickRuleManager()'), 'Admin needs a dedicated in-app quick-rule manager');
assert(html.includes('function saveTikTokQuickRule()'), 'quick rules must be editable and saved from the UI');
assert(html.includes('await persistTikTokRecognitionRulesToCloud()'), 'quick rule changes must sync to existing shared Cloud config');
assert(html.includes("if(learned?.matched||learned?.needsReview)return learned"), 'unsafe quick-rule conflicts must stop normal fallback guessing');
assert(html.includes("quickRulesButton=$('tiktokQuickRulesButton')"), 'quick-rule manager entry should be Admin-controlled');
console.log('TIKTOK QUICK RECOGNITION RULES TEST PASS');
