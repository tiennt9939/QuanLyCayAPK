# V26.2.60 — Quick recognition rules and order status sorting

## Base and compatibility
- Continued from ROLL CÂY CẢNH V26.2.59 / versionCode 111.
- versionName: `26.2.60`; versionCode: `112`.
- No new Firestore collection or schema. Quick rules use the existing shared config document fields `tiktokRecognitionRules`, `tiktokRecognitionRulesUpdatedAtMs`, and `tiktokRecognitionRulesUpdatedByUid`.
- Existing catalog, price/wage formulas, inventory logic, employee data, and order completion logic are not intentionally changed.

## Admin quick recognition rule manager
- Added an Admin-only entry in the daily shipment panel.
- Admin can add/edit/enable/disable/delete quick phrase rules without rebuilding for each new phrase.
- A rule maps one or more normalized label aliases to one catalog row and a plant count per sold unit.
- Qty from the imported PDF is multiplied by per-unit plant count by the existing `tiktokLabelMappedItems` path.
- Vietnamese accents and punctuation are normalized; the most-specific matching phrase wins. Conflicting equally-specific rules, explicit size conflicts, or a mismatch between a count printed on the label and the configured count stop auto-matching for Admin review.
- Includes a preview/test control and explicit warning if Cloud sync fails. Changes are only considered shared after Cloud save succeeds.
- Existing learned exact-signature rules and manual mapping editor remain supported.

## Order list organization
- Admin order assignment page now defaults to incomplete orders and offers status filters: pending, unclaimed shared orders, assigned/waiting for completion, completed, and all.
- Existing order-type and shared/private filters remain available as a secondary filter.
- Employee detail accordions retain the selected status/type filters and sort by the newest relevant timestamp.

## Verification status
- Automated regression suite: 56/56 JavaScript tests pass, including alias matching, per-unit × Qty calculation, conflicting quantities, C7/C9 protection, disabled/conflicting rules, and Admin status filters. Preflight and JavaScript syntax checks pass.
- A one-time APK update is required to install this manager. After install, adding/editing/disabling rules is an in-app Firebase operation and should not require another APK build. APK build and live Firebase operation are not claimed until GitHub Actions and an actual in-app Cloud save are observed.
