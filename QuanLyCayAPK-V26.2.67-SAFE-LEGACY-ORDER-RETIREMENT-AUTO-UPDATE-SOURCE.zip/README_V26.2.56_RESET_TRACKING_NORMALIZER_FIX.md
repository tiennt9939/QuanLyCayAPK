# V26.2.56 — Fix bộ chuẩn hóa mã vận đơn trong xem trước xóa theo ngày

## Lỗi đã sửa
V26.2.55 gọi `normalizeResetTracking()` từ quá trình xem trước/xác nhận xóa nhưng chưa định nghĩa hàm, khiến màn hình báo `normalizeResetTracking is not defined` và dừng an toàn trước khi xóa.

## Thay đổi
- Bổ sung hàm chuẩn hóa tracking bằng cách chuyển thành chữ hoa và loại bỏ ký tự không phải chữ/số, đồng nhất với logic `normalizeTracking()` hiện có.
- Thêm regression test chạy thực tế helper và kiểm tra mã J&T dạng số cũng như mã GHN có chữ.
- Giữ lại chọn ngày tùy ý, xác nhận gõ theo ngày, fingerprint, chặn ngày đã gộp vào tồn đầu kỳ, giới hạn transaction và bảo vệ tiền công/quyết toán.
- Không đổi schema Firestore, công thức tiền công, bảng giá, danh mục cây, tài khoản nhân viên hoặc logic tồn kho ngoài ngày được chọn.

## Kiểm tra
Chạy `python3 tools/preflight.py`, tất cả `tools/*_test.js`, và kiểm tra cú pháp JavaScript. Build APK Android và thao tác Firebase thật vẫn cần xác minh qua GitHub Actions/thiết bị.
