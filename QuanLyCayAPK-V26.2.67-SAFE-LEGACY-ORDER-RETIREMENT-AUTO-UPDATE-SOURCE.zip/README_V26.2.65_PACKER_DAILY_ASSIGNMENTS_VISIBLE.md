# V26.2.65 — Hiển thị nhãn PDF được giao ở tài khoản nhân viên

## Sửa lỗi
- Nhãn PDF được phân công nằm trong `apps/roll-cay-canh` → `data.dailyShipmentOrders`, không nằm trong collection `packingOrders`. Trước đây màn hình nhân viên chỉ đọc `packingOrders`, nên nhãn PDF được giao không xuất hiện.
- Bổ sung API đọc các nhãn PDF được giao, chỉ trả về nhãn có `assignedUid` đúng UID đang đăng nhập và `assignmentRequired=true`; không thay đổi Firestore schema.
- Màn hình nhân viên hiển thị riêng mục “Nhãn PDF được giao cho bạn”, gồm mã vận đơn, hãng vận chuyển, Order ID, ngày, cây/quy cách và số cây; có nút mở luồng quét được phân công.
- Các nhãn được tải từ Firebase được ghép vào hàng chờ hiện có theo mã vận đơn để luồng quét sử dụng cùng dữ liệu; không ghi tiền công/tồn kho khi tải danh sách.

## Bảo toàn
- Không đổi công thức tiền công, tồn kho, bảng giá, danh mục, tài khoản nhân viên hoặc Firestore schema.
- Chỉ đọc nhãn đã giao cho UID hiện tại; không hiển thị nhãn của nhân viên khác.
- Chưa ghi Firebase thật, chưa build APK Android trong môi trường này.

## Kiểm thử
- Kiểm tra cú pháp JavaScript, preflight, kiểm thử hồi quy phân công và quét PDF trước khi build.
