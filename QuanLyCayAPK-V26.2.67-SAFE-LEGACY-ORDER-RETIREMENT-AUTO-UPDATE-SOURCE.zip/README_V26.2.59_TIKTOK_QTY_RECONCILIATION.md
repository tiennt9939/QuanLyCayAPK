# ROLL CÂY CẢNH V26.2.59 — TikTok Qty reconciliation

- Baseline: V26.2.58; no rebuild from scratch.
- Android versionName: 26.2.59; versionCode: 111.
- Fix: reconcile a single-product label's parsed Qty against the PDF's authoritative `Qty Total`. If they differ, use `Qty Total` for that one product.
- Safety: for multi-product labels, the sum of product Qty values must exactly equal `Qty Total`; otherwise the label is marked `needs_review` and cannot silently record a wrong quantity.
- Plant count: mapped physical plant quantity remains `sold Qty × plants per sold unit` exactly once. Example: `4 cây Quỳnh Anh`, Qty 2 → 8 physical plants. Combo gift mapping remains N + M plants per sold unit, multiplied by sold Qty once.
- Existing payroll formula, catalog, pricing, employee data, inventory logic, and Firestore schema are unchanged. Payroll and stock continue to use the corrected total physical plant quantity through existing pathways.
- Validation: preflight PASS; 54/54 JavaScript tests PASS, including new Qty Total reconciliation regression; parser syntax PASS.
- No APK was built here and no live Firebase data was changed.
