# V26.2.58 — Ổn định fingerprint xóa dữ liệu nghiệp vụ theo ngày

- Tiếp tục từ V26.2.56; không dựng lại ứng dụng và không đổi schema/công thức tiền công/bảng giá/nhân viên.
- Sửa phạm vi fingerprint để chỉ theo dõi các đơn hoàn tất thực sự thuộc ngày đã chọn; các thay đổi phân công/cache của đơn chưa hoàn tất không còn gây false mismatch. Việc một đơn chuyển sang hoàn tất trong ngày vẫn làm fingerprint thay đổi và bị chặn an toàn.
- Fingerprint claim chỉ chứa trạng thái tồn tại và trường ownership dùng để xác định claim có thuộc ngày đó; metadata không liên quan không gây lỗi giả.
- Bỏ timestamp cảnh báo lưu giữ khỏi fingerprint, vẫn giữ cờ bảo vệ retention đang chờ.
- Đồng bộ việc dọn cache `packingOrders` / `packerRecords` ngay trong shared data, tránh đơn đã xóa hồi sinh khi tải lại.
- Lỗi mismatch nay phân biệt được xảy ra ở bước đọc lại trước transaction hay trong transaction.
- Version `26.2.58`, versionCode `110`.

Kiểm tra tự động không thay thế build Android/GitHub Actions hoặc xác minh Firebase thật. Không tự động xóa dữ liệu.


## V26.2.58 scope fix

Fixed a JavaScript scope error in the post-reset UI cache cleanup: code outside the CloudSync closure now uses the global `dailyShipmentIsScanDerivedReport` helper with an explicit date check instead of calling the closure-private `isTargetDailyShipmentReport`. Added a regression assertion to prevent this cross-scope reference from returning.


Known fix confirmed by screenshot: the global UI handler called `isTargetDailyShipmentReport`, which exists only inside the `CloudSync` closure. The post-success local cache now filters by selected date and the globally scoped `dailyShipmentIsScanDerivedReport` helper. Regression test checks the handler scope directly.
