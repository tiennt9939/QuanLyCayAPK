# V26.2.48 — Khắc phục quét đơn chung không ghi báo cáo

## Sự cố được xử lý

Ở ảnh từ V26.2.47, danh sách 46 đơn PDF vẫn còn và trạng thái camera có thể báo chụp/quét thành công, nhưng bộ đếm **Đã ghi báo cáo** vẫn bằng 0. Nguyên nhân trong source có hai phần:

1. Bản ghi quét mới được lưu vào collection Firestore riêng `dailyShipmentScans`, nên nếu Firestore Rules đang chạy trên Firebase chưa có quyền cho collection này thì giao dịch ghi nhận bị từ chối dù camera đã chụp ảnh.
2. Native scanner lưu tên nhân viên vào cả trường `employeeName` và `employeeId`. Đối với tài khoản nhân viên liên kết bằng ID khác tên hiển thị, kiểm tra danh tính có thể từ chối bản ghi.

## Thay đổi trong source

- Tăng phiên bản Android lên **26.2.48**, `versionCode = 100`.
- Giữ danh sách PDF của ngày trong một hàng chờ chung; không chia/phân công đơn.
- Admin vẫn được chọn nhân viên ngay trên camera; bản ghi gắn nhân viên được chọn. Chọn `Admin — KHÔNG TÍNH CÔNG` sẽ ghi nhận vận chuyển/tồn kho nhưng tiền công bằng 0.
- Tài khoản `packer` có thể quét đơn chung khi tài khoản đã được Admin liên kết với hồ sơ nhân viên. Người nhận công được lấy từ hồ sơ Firebase liên kết — không cho tài khoản nhân viên tự ghi nhận thay người khác.
- Mỗi mã vận đơn được ghi bằng một giao dịch Firestore cho `shipmentTrackingClaims/{trackingNo}` và `dailyShipmentScans/{trackingNo}`. Cùng mã không thể được cộng công hoặc trừ kho hai lần.
- Khi upload ảnh Drive chậm/thất bại, báo cáo đã commit vẫn được giữ; ảnh ở hàng đợi cục bộ để thử tải lại.
- Báo cáo từ `dailyShipmentScans` được đọc/ghép vào danh sách ngày, báo cáo, tồn kho và tiền công, không bị đẩy ngược vào blob `/apps/roll-cay-canh`.
- Bài test mới xác nhận quyền ghi của nhân viên giới hạn theo hồ sơ liên kết, đường ghi riêng theo mã vận đơn, cảnh báo trùng và chế độ Admin không tính công.

## BẮT BUỘC: Publish Firestore Rules

**Chỉ build APK trong GitHub Actions không cập nhật Firestore Rules đang chạy trên Firebase.** Nếu không publish Rules mới thì ứng dụng vẫn có thể chụp ảnh thành công nhưng giao dịch báo cáo vẫn bị Firebase từ chối.

File đầy đủ nằm ở `firestore.rules` tại thư mục gốc source này. Dùng đúng file đó làm phiên bản Rules của dự án:

1. Mở Firebase Console của dự án đang dùng trong ứng dụng.
2. Mở **Firestore Database → Rules**.
3. Sao lưu rules hiện tại trước khi thay thế; nếu đã thêm các quy tắc riêng ngoài repository, hãy đối chiếu để không làm mất phần riêng đó.
4. Dán nội dung đầy đủ của `firestore.rules` trong source này và bấm **Publish**.
5. Chờ Publish thành công rồi mới thử APK V26.2.48.

Các quy tắc mới gồm `match /dailyShipmentScans/{trackingNo}` và nhánh tạo/cập nhật khóa tương ứng trong `match /shipmentTrackingClaims/{trackingNo}`. Không mở quyền nhân viên sửa toàn bộ document dữ liệu dùng chung.

## Thử nghiệm sau cập nhật

1. Mở đúng ngày 18/10/2026 hoặc ngày bạn đã nhập PDF; kiểm tra danh sách vẫn là 46 nhãn trước khi quét.
2. Đăng nhập Admin, chọn nhân viên `Luân lớn` trong camera và quét một mã đang ở trạng thái **SẴN SÀNG**.
3. Sau khi xử lý Firebase thành công, đơn cần chuyển sang **ĐÃ GHI**, bộ đếm tăng từ 0 lên 1 và báo cáo/tiền công hiển thị đúng Luân lớn.
4. Quét lại cùng mã: ứng dụng phải phát còi trùng, không tăng báo cáo, công hoặc trừ kho lần thứ hai.
5. Đăng nhập bằng tài khoản nhân viên đã liên kết và thử một mã khác: hệ thống tự gắn đúng nhân viên với tài khoản đó.
6. Chọn Admin để quét: đơn được ghi nhận nhưng không cộng công.

Nếu mã đã chụp ở APK cũ nhưng chưa ghi được báo cáo, source mới **không tự biến ảnh chụp cũ thành một báo cáo hợp lệ** nếu không còn bản ghi giao dịch; hãy thử lại mã khi nó vẫn ở trạng thái SẴN SÀNG. Nếu mã báo đã có khóa trên Firebase nhưng không có báo cáo, ứng dụng sẽ chặn ghi đè để bảo vệ chống ghi công trùng và cần Admin kiểm tra khóa đó trước.

## Kiểm tra đã chạy trong môi trường phát triển

- `python3 tools/preflight.py`: PASS.
- Tất cả **49/49** bài kiểm thử `tools/*_test.js`: PASS.
- Cú pháp 4 khối JavaScript nhúng trong `index.html`: PASS.
- Chưa build APK và chưa thử Firebase Emulator/điện thoại thực tế trong môi trường này (không có Gradle Wrapper/Android SDK/Firebase CLI). Cần kiểm tra lại bằng GitHub Actions và Firebase Rules sau khi Publish.
