# V26.2.67 — Stale shipment-claim assignment fix

## Problem addressed
Admin could see a PDF label and select a staff member, but assignment failed with `Mã ... đang bị khóa trong hệ thống ghi nhận` because any non-voided `shipmentTrackingClaims` document blocked assignment, even when it had no recorded scan/report evidence and no legacy order document.

## Change
- Keep blocking if the PDF row, daily shipment report, or `dailyShipmentScans` has recorded evidence.
- Keep blocking if a legacy `packingOrders/tiktok_<tracking>` order still exists.
- Only recover an orphan claim when its status is empty, it points only to an empty/deterministic legacy ID for this tracking, and no recorded scan/report or legacy order exists.
- Mark that recovered claim `voided` with an audit reason, timestamp, actor UID, source and previous order ID, then continue assignment in the same Firestore transaction.
- Claims with `recorded`, any other non-empty status, or a link to another order remain blocked with a more useful diagnostic. This preserves duplicate protection.
- No changes to wage formulas, inventory logic, catalog, employee records, or Firestore schema.

## Verification
- Android versionName 26.2.67 / versionCode 118.
- Preflight PASS.
- 61/61 Node regression tests PASS.
- Inline JavaScript syntax PASS (6 blocks) and tiktok-label-import.js syntax PASS.
- ZIP integrity must be checked after packaging.

## Not claimed
No Android APK build, live Firebase transaction, or physical-device test was performed here. The source only is provided; test the assignment on one known unrecorded PDF label after building and installing it.
