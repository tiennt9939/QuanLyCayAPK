# V26.2.61 — Assignment-first PDF workflow

## Purpose
Continue the existing ROLL CÂY CẢNH Android WebView app from V26.2.60. This release adds an assignment-first workflow for imported PDF shipping labels. It does not rebuild the app and does not change the Firestore collection model, wage formula, stock calculation, catalog, price list, or employee accounts.

## New operational flow
1. Admin imports the shipping-label PDF. Labels enter the shared `data.dailyShipmentOrders` queue as unassigned rows; importing PDF no longer creates the legacy shared-pool `packingOrders` records.
2. Admin uses **Chia việc theo nhóm cây** to combine filters for status, employee, plant name, size, plants per unit/combo, and search text.
3. Admin can assign one label or bulk-assign selected labels to one employee. The board summarizes each employee's assigned order count and estimated plant count. Reassignment history is retained on the existing queue row.
4. The camera only receives labels assigned to the signed-in identity. Wrong-owner scans and assignment-revision changes are blocked before recording. Firestore transaction remains the final duplicate/owner guard.
5. The former per-barcode employee-switching/shared-pool scanner bridge returns a retired-workflow error and no longer launches its old camera flow. Stale `open_pool` rows cannot be accepted or scanned; their reassignment control is removed from the PDF queue. Firestore Rules also reject creating or claiming `open_pool` orders once published.

## Cleaning up previous unfinished orders
Admin can open **Dọn đơn cũ chưa hoàn tất** and review a Firebase-backed preview. This is the one-time cleanup path for the unfinished legacy queue before using assignment-first intake. It includes incomplete legacy packing-order documents and PDF queue labels that have no recorded report/scan, no active tracking claim, and no completed-order evidence. Execution requires the exact phrase `XOA DON CHUA HOAN TAT`, a second confirmation, an unchanged preview fingerprint, and an idle scanner/photo queue.

Cleanup does not delete completed orders, recorded scan/report documents, active claims, payroll archives/settlements, manual daily inventory/payroll entries, catalog, prices, employee accounts, or physical Google Drive image files. If any scope is too large, inconsistent, recorded, or protected, the UI stops and asks for investigation. The client clears corresponding local stale unfinished rows only after Firebase confirms success.

## Important deployment notes
- Building the APK does not publish Firestore Rules. Review and publish the `firestore.rules` from this package to the same Firebase project before enabling the new assignment-only flow. Rules may contain project-specific customizations; back up and merge them carefully instead of blindly overwriting unrelated rules.
- Build through the existing GitHub Actions workflow with the exact source ZIP filename in `source_zip`.
- The source package has automated preflight/regression checks. This does not prove a live Firebase cleanup has happened or validate the live project. After installing the build and publishing Rules, run the cleanup preview first; inspect all counts and protected/inconsistent items, then explicitly confirm if the scope is correct.
- No live Firebase writes or deletes were executed while preparing this source. No APK was built in this local environment.
