# ROLL CÂY CẢNH V26.2.50 — Import PDF Tracking Format Scan Fix

## Symptom addressed
The daily shipment panel could show a label as “SẴN SÀNG”, but the Android camera only loaded labels matching four hard-coded tracking patterns (`VNGH`, `GHVN`, `862…`, `530…`). Other valid tracking formats imported from the PDF were omitted from the camera's expected-label map. They could remain ready after the user had passed them in the scanning session.

## Changes
- Daily batch camera now indexes each nonempty normalized tracking number (8–40 characters) from the already-imported PDF queue.
- The camera recognizes a barcode in batch mode when it is an exact normalized match to the imported queue, while unknown labels remain blocked.
- Added EAN-13, EAN-8, UPC-A, and UPC-E linear barcode formats. QR codes remain excluded to avoid promotional QR matches.
- Cloud report validation still uses the previous supported-pattern allowlist. It relaxes that allowlist only when the scanned tracking exactly matches a parsed row from the imported PDF (`source: pdf_label`, carrier present, products nonempty, and normalized tracking length 8–40).
- Existing Firebase transaction/idempotency, employee attribution, Admin no-wage mode, image queue, inventory, wage rules, and duplicate alarm behavior remain unchanged.

## Build metadata
- `versionName`: `26.2.50`
- `versionCode`: `102`

## Validation
The regression test `tools/v2650_imported_tracking_format_scan_test.js` covers exact matching to imported PDF tracking identifiers and rejects mismatched/non-PDF rows. Full JavaScript regression suite and preflight results are recorded in `V26.2.50_VALIDATION_REPORT.txt`.

## Deployment
Build using the existing GitHub Actions workflow. Existing rows do not need to be re-imported. After installing the new APK, open the same date and scan the remaining ready labels; the camera should recognize codes based on the exact imported list, not only the legacy prefix patterns.

APK compilation/device testing must be verified through GitHub Actions and on the actual phone; this local environment does not include Android SDK/Gradle.
