# V26.2.63 — Assignment Board Data Wiring / Visibility Fix

Tiếp tục source V26.2.62. Bản này sửa giao diện bảng Chia việc theo nhóm cây để bảng bám trực tiếp danh sách nhãn PDF của ngày được chọn, hiển thị trước các thẻ bảo trì/reset, và không âm thầm biến mất khi trạng thái quyền Admin đang khởi tạo.

- Bảng luôn lấy dữ liệu từ `dailyShipmentOrdersForSelectedDate()` — nguồn nhãn PDF đã nhập theo ngày.
- Gọi render bảng sau mỗi lần render màn hình vận chuyển; không chỉ gọi trong một nhánh điều kiện riêng.
- UI có fallback nhận diện Admin bootstrap theo email khi `role` chưa hydrate, nhưng thao tác ghi vẫn yêu cầu `role === admin` và API Firestore hiện có.
- Nếu renderer có lỗi, bảng hiện thông báo lỗi và mã vận đơn trong phạm vi để tránh tình trạng danh sách trống khó chẩn đoán.
- Nhãn không đối chiếu được cây vẫn hiện trong nhóm cần kiểm tra, không bị bỏ khỏi danh sách.
- Bảng phân công được chuyển ngay dưới nút Nhập PDF/Quét để dễ tìm.

Không đổi Firestore schema, công thức tiền công, tồn kho, bảng giá, nhân viên hoặc dữ liệu thật. Chưa build APK Android, chưa ghi/xóa Firebase thật.
