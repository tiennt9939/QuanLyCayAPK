# V26.2.64 — Fix assignment-filter helper name

## Lỗi được sửa

Ảnh kiểm thử trên thiết bị báo `dailyAssignmentFilterValue is not defined`. Trong `index.html`, helper thực tế được khai báo là `dailyShipmentAssignmentFilterValue(id)`, nhưng các bộ lọc cây/quy cách/số cây/trạng thái/nhân viên lại gọi nhầm tên `dailyAssignmentFilterValue`.

Bản này đổi tất cả các nơi gọi sang helper được khai báo, đồng thời thêm kiểm thử hồi quy bảo đảm không còn tham chiếu tên cũ. Không thay đổi cấu trúc dữ liệu Firebase, phân công, công thức tiền công, tồn kho, danh mục, bảng giá hoặc nhân viên.

## Kiểm thử

- `tools/preflight.py`
- Tất cả kiểm thử `tools/*_test.js`
- Kiểm tra cú pháp từng script JavaScript nội tuyến trong `app/src/main/assets/index.html` và các tệp JavaScript trong assets.

Chưa build APK Android và chưa thao tác ghi/xóa Firebase thật.
