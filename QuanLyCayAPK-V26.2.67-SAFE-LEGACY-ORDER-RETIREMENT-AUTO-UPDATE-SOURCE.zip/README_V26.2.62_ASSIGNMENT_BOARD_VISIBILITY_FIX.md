# V26.2.62 — Fix hiển thị nhãn PDF trong bảng phân công

Tiếp tục source V26.2.61; không đổi Firestore schema, công thức tiền công, tồn kho, bảng giá hoặc tài khoản nhân viên.

## Sửa lỗi
- Đưa bảng “Chia việc theo nhóm cây” xuống ngay sau bộ đếm nhãn đã nhập, gần danh sách nhãn để Admin không bỏ lỡ bảng phân công.
- Sau khi nhập PDF, tự cuộn tới bảng phân công.
- Bộ lọc mặc định là “Tất cả nhãn”, nên nhãn đã nhập vẫn hiện kể cả khi cần kiểm tra cây; các nhãn cần kiểm tra hiện rõ lý do và không thể giao cho tới khi xử lý.
- Tải hồ sơ nhân viên ở nền; danh sách nhãn được render ngay cả khi truy vấn nhân viên chậm hoặc lỗi.
- Giữ nguyên thao tác giao riêng lẻ/giao hàng loạt, transaction Firebase, chống trùng mã, người phụ trách chính và lịch sử đổi người.

## Kiểm thử
Chạy `python3 tools/preflight.py`, toàn bộ `tools/*_test.js` và cú pháp các script JavaScript. APK Android vẫn phải được build bằng GitHub Actions; giao dịch Firebase thật cần được kiểm tra sau khi cài APK.
