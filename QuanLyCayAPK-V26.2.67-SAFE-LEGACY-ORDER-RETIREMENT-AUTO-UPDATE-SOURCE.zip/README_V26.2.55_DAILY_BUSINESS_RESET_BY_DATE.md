# V26.2.55 — Admin xóa dữ liệu nghiệp vụ theo ngày

## Mục tiêu
Tiếp tục trực tiếp từ source V26.2.54, không dựng lại ứng dụng. Giữ nguyên schema Firestore, quy tắc nhận dạng cây, bảng giá, công thức tiền công, tài khoản nhân viên và logic đơn hàng còn lại.

## Cách sử dụng
1. Đăng nhập bằng tài khoản Admin.
2. Mở mục Vận chuyển/Theo ngày, tìm thẻ **Xóa dữ liệu nghiệp vụ theo ngày**.
3. Chọn ngày trên bộ chọn lịch và bấm **Xem trước**.
4. Đối chiếu toàn bộ số lượng được liệt kê. Chức năng phải dừng nếu ngày đã gộp vào mốc tồn kho chốt.
5. Dừng máy quét ở mọi thiết bị. Chỉ tiếp tục nếu số liệu xem trước chính xác; nhập nguyên cụm `XOA DD/MM/YYYY` cho đúng ngày đã chọn và xác nhận lần cuối.
6. Sau khi app báo Firebase xác nhận thành công, thử một đơn trước rồi mới xử lý cả lô.

## Phạm vi xóa theo ngày được chọn
- Nhãn/PDF đã nhập trong `dailyShipmentOrders` của ngày được chọn.
- Báo cáo quét ngày đó và bản ghi `dailyShipmentScans` thuộc nguồn quét trong ngày.
- Đơn đóng hàng đã hoàn tất đúng ngày trong collection `packingOrders`.
- Khóa chống trùng `shipmentTrackingClaims` chỉ khi chứng minh được liên quan đến đơn/báo cáo mục tiêu trong ngày.
- Dòng nhập/xuất và tiền công trong `daily`, ứng lương `salaryAdvances`, báo cáo `shipments`, bản lưu `payrollArchives`, và khóa quyết toán có tiền tố ngày được chọn.
- Cache dữ liệu hoàn tất được loại bỏ và đánh dấu reset theo ngày để dữ liệu cache cũ không tự xuất hiện lại.

## Dữ liệu giữ nguyên
- Danh mục cây, quy tắc nhận dạng, bảng giá/công thức, tài khoản nhân viên.
- Đơn đóng hàng chưa hoàn tất và mọi dữ liệu ngày khác.
- Tệp ảnh vật lý trên Google Drive (các liên kết ảnh trong báo cáo đã xóa không còn được hiển thị từ báo cáo đó).
- Mốc tồn kho chốt không bị sửa trực tiếp.

## Bảo vệ và giới hạn
- Chỉ Admin được xem trước và thực thi.
- Ngày phải hợp lệ theo định dạng lịch ISO `YYYY-MM-DD`.
- Xác nhận gõ theo đúng ngày: `XOA DD/MM/YYYY`.
- Tạo fingerprint từ dữ liệu ngày đã chọn, bỏ các timestamp đồng bộ không ổn định; đọc lại dữ liệu trước khi commit và hủy an toàn nếu phát hiện thay đổi.
- Transaction giới hạn 400 thao tác. Nếu phạm vi lớn hơn, chức năng dừng toàn bộ thay vì xóa một phần.
- Nếu ngày đã nằm trong hoặc trước `stockBaseDate`, không thực hiện vì dữ liệu tồn kho đã gộp vào baseline và không thể khôi phục phép tính lịch sử chỉ bằng xóa bản ghi. Cần nghiệp vụ điều chỉnh tồn/khôi phục snapshot có kiểm soát trước khi xử lý loại ngày này.
- Trước khi thực hiện, dừng quét và chờ hàng đợi ảnh/đồng bộ kết thúc trên tất cả thiết bị.

## Kiểm định đã chạy trong môi trường phát triển
- `python3 tools/preflight.py`: PASS.
- `node tools/daily_shipment_reset_test.js`: PASS.
- Tất cả `tools/*_test.js`: 53/53 PASS.
- Cú pháp JavaScript inline trong `index.html`: PASS; sẽ kiểm tra thêm `tiktok-label-import.js` khi đóng gói.
- ZIP: sẽ kiểm tra `zipfile.testzip()` và SHA-256.

## Chưa xác minh
- Chưa build APK Android thực tế trong môi trường này; cần chạy GitHub Actions từ đúng source ZIP.
- Chưa chạy thao tác xóa trên Firebase thật.
- Chưa kiểm thử trực tiếp trên điện thoại; xem trước trong app và thao tác quét 1 đơn sau reset vẫn bắt buộc.
