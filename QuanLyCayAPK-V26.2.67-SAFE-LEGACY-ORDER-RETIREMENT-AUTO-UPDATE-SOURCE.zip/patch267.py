from pathlib import Path
p=Path('/mnt/data/audit266/app/src/main/assets/index.html')
s=p.read_text()
old="""      const nextRows=rows.slice();
      for(const [i,tracking] of [...seen].entries()){
        const index=nextRows.findIndex(row=>normalizeTracking(row?.trackingNo||'')===tracking&&String(row?.date||'')===String(date));
        if(index<0)throw new Error(`Không tìm thấy nhãn ${tracking} ngày ${date} trên Firebase. Đồng bộ lại PDF trước khi phân công.`);
        const current=nextRows[index],claim=claims[i]?.exists?(claims[i].data()||{}):null,scan=scans[i]?.exists?(scans[i].data()||{}):null,oldOrder=legacyOrders[i]?.exists?(legacyOrders[i].data()||{}):null;
        const hasRecordedEvidence=String(current.status||'')==='recorded'||reports.some(r=>normalizeTracking(r?.trackingNo||'')===tracking&&String(r?.status||'')==='recorded')||(scan&&(String(scan.status||'')==='recorded'||String(scan.report?.status||'')==='recorded'));
        if(hasRecordedEvidence)throw new Error(`Đơn ${tracking} đã ghi nhận. Không thể phân công lại đơn đã hoàn tất.`);
        if(oldOrder)throw new Error(`Mã ${tracking} vẫn còn liên kết với đơn cũ ${String(oldOrder.orderNo||oldOrder.id||'')}. Hãy kiểm tra/dọn đơn cũ chưa hoàn tất trước khi giao theo luồng mới.`);
        // Repair only a provably orphaned, pre-recording claim. Never clear a recorded claim,
        // a claim linked to an unrelated order, or any claim when scan/report evidence exists.
        if(claim&&String(claim.status||'')!=='voided'){
          const claimStatus=String(claim.status||'').trim().toLowerCase(),claimOrderId=String(claim.orderId||'').trim();
          const allowedStaleIds=new Set(['',`tiktok_${tracking}`,`daily_${tracking}`]);
          if(claimStatus==='recorded'||claimStatus!==''||!allowedStaleIds.has(claimOrderId))throw new Error(`Mã ${tracking} vẫn bị khóa bởi bản ghi ${claimOrderId||'(không rõ đơn)'} (trạng thái ${claimStatus||'cũ/không rõ'}). Để bảo vệ chống trùng, cần Admin kiểm tra bản ghi khóa trước khi giao.`);
          const now=Date.now();
          tx.set(claimRefs[i],{trackingNo:tracking,orderId:`daily_${tracking}`,status:'voided',voidedAtMs:now,voidedBy:adminUid,voidReason:'Tự giải phóng khóa mồ côi khi phân công: không có báo cáo/quét ghi nhận và không còn đơn cũ liên kết',recoveredFromOrderId:claimOrderId||null,source:'assignment_orphan_claim_recovery',claimedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
        }
"""
new="""      const nextRows=rows.slice();
      const legacyPackingRows=Array.isArray(data.packingOrders)?data.packingOrders.slice():null;
      const legacyOrderIdsToDelete=[];
      const voidedClaims=[];
      for(const [i,tracking] of [...seen].entries()){
        const index=nextRows.findIndex(row=>normalizeTracking(row?.trackingNo||'')===tracking&&String(row?.date||'')===String(date));
        if(index<0)throw new Error(`Không tìm thấy nhãn ${tracking} ngày ${date} trên Firebase. Đồng bộ lại PDF trước khi phân công.`);
        const current=nextRows[index],claim=claims[i]?.exists?(claims[i].data()||{}):null,scan=scans[i]?.exists?(scans[i].data()||{}):null,oldOrderSnap=legacyOrders[i],oldOrder=oldOrderSnap?.exists?(oldOrderSnap.data()||{}):null;
        const reportEvidence=reports.some(r=>normalizeTracking(r?.trackingNo||'')===tracking&&String(r?.status||'')==='recorded');
        const scanEvidence=!!(scan&&(String(scan.status||'')==='recorded'||String(scan.report?.status||'')==='recorded'));
        const hasRecordedEvidence=String(current.status||'')==='recorded'||reportEvidence||scanEvidence;
        if(hasRecordedEvidence)throw new Error(`Đơn ${tracking} đã có bằng chứng ghi nhận trên báo cáo/quét. Không thể phân công lại.`);

        // V26.2.67: safely retire a legacy pending order linked to this exact tracking number,
        // instead of blocking the new assignment forever. This is allowed only when no scan/report,
        // completion, payroll adjustment/payment, completion photo, or inventory side-effect exists.
        if(oldOrder){
          const oldOrderId=String(oldOrderSnap.id||`tiktok_${tracking}`),oldOrderTracking=normalizeTracking(oldOrder.shipmentTrackingNo||oldOrder.shipment?.trackingNo||(oldOrderId.startsWith('tiktok_')?oldOrderId.slice(7):''));
          const hasFinancialOrInventoryEvidence=Number(oldOrder.payAmount||0)!==0||Number(oldOrder.employeePay||0)!==0||Number(oldOrder.payAdjustment||0)!==0||Number(oldOrder.completedAtMs||0)>0||!!String(oldOrder.completionImage||'').trim()||(Array.isArray(oldOrder.completionImages)&&oldOrder.completionImages.length>0)||!!oldOrder.inventoryApplied||!!oldOrder.inventoryDeducted||!!oldOrder.stockDeducted||Number(oldOrder.inventoryAppliedAtMs||0)>0||!!String(oldOrder.inventoryTransactionId||'').trim();
          if(cleanupOrderHasCompletionEvidence(oldOrder)||hasFinancialOrInventoryEvidence||String(oldOrder.status||'').toLowerCase()==='completed')throw new Error(`Mã ${tracking} còn liên kết đơn ${String(oldOrder.orderNo||oldOrderId)} có dấu vết hoàn tất/tiền công/tồn kho. Đã giữ nguyên an toàn; Admin cần đối soát thủ công.`);
          if(oldOrderTracking&&oldOrderTracking!==tracking)throw new Error(`Đơn cũ ${String(oldOrder.orderNo||oldOrderId)} có mã vận đơn khác (${oldOrderTracking}); không tự dọn.`);
          if(claim&&String(claim.status||'').toLowerCase()!=='voided'){
            const claimStatus=String(claim.status||'').trim().toLowerCase(),claimOrderId=String(claim.orderId||'').trim();
            const linkedClaimIds=new Set(['',oldOrderId,String(oldOrder.orderNo||''),`tiktok_${tracking}`,`daily_${tracking}`]);
            const safeClaimStatuses=new Set(['','pending','claimed','assigned','in_progress']);
            if(claimStatus==='recorded'||!safeClaimStatuses.has(claimStatus)||!linkedClaimIds.has(claimOrderId))throw new Error(`Mã ${tracking} có khóa vận đơn không an toàn (${claimOrderId||'không rõ đơn'}, trạng thái ${claimStatus||'cũ/không rõ'}). Đã giữ nguyên dữ liệu; cần Admin đối soát.`);
            const now=Date.now();tx.set(claimRefs[i],{trackingNo:tracking,orderId:`daily_${tracking}`,status:'voided',voidedAtMs:now,voidedBy:adminUid,voidReason:'Thu hồi claim của đơn legacy chưa hoàn tất sau khi xác minh không có báo cáo/quét, tiền công hoặc giao dịch tồn kho',recoveredFromOrderId:claimOrderId||oldOrderId,source:'safe_legacy_order_retirement',claimedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});voidedClaims.push(tracking);
          }
          // Remove only the exact legacy order document and its matching shared-blob copy.
          // A duplicate copy with completion/financial evidence aborts the whole transaction.
          if(legacyPackingRows){
            const matches=legacyPackingRows.filter(row=>String(row?.id||'')===oldOrderId||(normalizeTracking(row?.shipmentTrackingNo||row?.shipment?.trackingNo||'')===tracking&&String(row?.orderNo||'')===String(oldOrder.orderNo||'')));
            if(matches.some(row=>cleanupOrderHasCompletionEvidence(row)||Number(row?.payAmount||0)!==0||Number(row?.employeePay||0)!==0||Number(row?.payAdjustment||0)!==0||!!row?.inventoryApplied||!!row?.inventoryDeducted||!!row?.stockDeducted))throw new Error(`Bản sao đơn cũ ${String(oldOrder.orderNo||oldOrderId)} có dấu vết tiền công/tồn kho. Đã giữ nguyên; cần Admin đối soát.`);
            for(let j=legacyPackingRows.length-1;j>=0;j--){const row=legacyPackingRows[j];if(String(row?.id||'')===oldOrderId||(normalizeTracking(row?.shipmentTrackingNo||row?.shipment?.trackingNo||'')===tracking&&String(row?.orderNo||'')===String(oldOrder.orderNo||'')))legacyPackingRows.splice(j,1)}
          }
          tx.delete(orderRefs[i]);legacyOrderIdsToDelete.push(oldOrderId);
        }
        // A remaining claim without an old order may be cleared only when it is a provable orphan.
        if(claim&&String(claim.status||'')!=='voided'&&!oldOrder){
          const claimStatus=String(claim.status||'').trim().toLowerCase(),claimOrderId=String(claim.orderId||'').trim();
          const allowedStaleIds=new Set(['',`tiktok_${tracking}`,`daily_${tracking}`]);
          if(claimStatus!==' '&&claimStatus!=='' )throw new Error(`Mã ${tracking} vẫn bị khóa bởi bản ghi ${claimOrderId||'(không rõ đơn)'} (trạng thái ${claimStatus}). Để bảo vệ chống trùng, cần Admin kiểm tra bản ghi khóa trước khi giao.`);
          if(!allowedStaleIds.has(claimOrderId))throw new Error(`Mã ${tracking} vẫn bị khóa bởi đơn ${claimOrderId||'(không rõ đơn)'}. Không tự giải phóng khóa không xác định.`);
          const now=Date.now();tx.set(claimRefs[i],{trackingNo:tracking,orderId:`daily_${tracking}`,status:'voided',voidedAtMs:now,voidedBy:adminUid,voidReason:'Giải phóng claim mồ côi sau khi xác minh không có báo cáo/quét và không còn đơn liên kết',recoveredFromOrderId:claimOrderId||null,source:'assignment_orphan_claim_recovery',claimedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});voidedClaims.push(tracking);
        }
"""
if old not in s:
    raise SystemExit('Could not find assignment block to replace')
s=s.replace(old,new,1)
old2="""      const now=Date.now();tx.set(appRef,{data:{...data,dailyShipmentOrders:nextRows},updatedAtMs:now,updatedAt:firebase.firestore.FieldValue.serverTimestamp(),appVersion:'V26.2.64-ASSIGNMENT-FILTER-HELPER-FIX'},{merge:true});
      finalOrders=nextRows;
    });
    return {ok:true,orders:finalOrders,assignedRows,assignedCount:assignedRows.length};
"""
new2="""      const now=Date.now(),nextData={...data,dailyShipmentOrders:nextRows};if(legacyPackingRows)nextData.packingOrders=legacyPackingRows;
      tx.set(appRef,{data:nextData,updatedAtMs:now,updatedAt:firebase.firestore.FieldValue.serverTimestamp(),appVersion:'V26.2.67-SAFE-LEGACY-ORDER-RETIREMENT'},{merge:true});
      finalOrders=nextRows;
    });
    return {ok:true,orders:finalOrders,assignedRows,assignedCount:assignedRows.length,retiredLegacyOrderIds:legacyOrderIdsToDelete,voidedLegacyClaims:voicedClaims};
""".replace('voicedClaims','voidedClaims')
if old2 not in s:
    raise SystemExit('Could not find assignment transaction final block')
s=s.replace(old2,new2,1)
p.write_text(s)
# version bump
p=Path('/mnt/data/audit266/app/build.gradle.kts'); s=p.read_text().replace('versionCode = 118','versionCode = 119').replace('versionName = "26.2.66"','versionName = "26.2.67"'); p.write_text(s)
