# ROLL CÂY CẢNH V26.2.67 — Safe legacy order retirement during assignment

## Root cause found in V26.2.66
The assignment transaction still rejected every existing `packingOrders/tiktok_<tracking>` document before it evaluated whether the legacy order was incomplete and safe to retire. The prior stale-claim fix therefore could not resolve labels linked to old pending orders such as TT-38461426.

## Fix
- During Admin assignment, inspect the existing legacy order, daily scan, recorded reports, and tracking claim in the same Firestore transaction.
- If a linked legacy order is demonstrably incomplete and has no recorded scan/report, completion evidence, paid wage/adjustment, completion photo, or inventory side-effect, retire that exact legacy order and its matching shared `packingOrders` copy atomically with the new PDF assignment.
- A matching old claim is changed to `voided` with an audit reason/source before assignment; unrelated/unknown claims remain blocked.
- Completed or ambiguous legacy rows, mismatched tracking/order numbers, any recorded evidence, nonzero actual pay/adjustment, completion images, or inventory markers stop the transaction without changing anything.
- Existing Firestore schema is reused. No collection/schema migration was introduced.
- No change to wage formulas, inventory calculation, catalog/prices, employee accounts, or completed history.

## Verification
- Android `versionName`: `26.2.67`
- Android `versionCode`: `119`
- Preflight: PASS
- Inline JavaScript syntax (4 scripts): PASS
- JavaScript regression tests: 62 PASS / 0 FAIL
- ZIP integrity: checked after packaging

## Not done
- APK was not built in this environment.
- No live Firebase operation was executed by packaging/testing.
- The legacy order is retired only when Admin performs a real assignment in the built app and the live transaction confirms all safety checks.
