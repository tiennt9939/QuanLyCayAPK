# V26.2.49 — Idempotent daily shipment count

## Điều chỉnh
- Sửa bộ đếm “Đã ghi báo cáo”: không cộng thêm 1 theo mỗi callback tải ảnh/ghi ảnh. Bộ đếm được tính lại từ các mã vận đơn duy nhất trong danh sách ngày và trạng thái báo cáo thực tế.
- Nếu callback gắn ảnh Drive chạy lại cho đơn đã ghi nhận, số đơn đã ghi không tăng lần hai. Điều này không thay đổi tiền công; giao dịch Firebase chống trùng vẫn là nguồn quyết định chính.
- Chuẩn hóa hàng đợi hiển thị theo mã vận đơn và ngày, gộp các hàng trùng phát sinh từ lần nhập/khôi phục cũ; giữ thông tin cây chất lượng tốt nhất và giữ trạng thái/nhân viên của bản ghi đã được ghi nhận.
- Không thêm truy vấn Firebase vào mỗi lần cập nhật bộ đếm. Cập nhật UI chỉ dùng dữ liệu đã có trong bộ nhớ; nếu phát hiện hàng trùng, sửa hàng đợi cục bộ và xếp lịch đồng bộ nền.
- Giữ nguyên luồng quét nhanh, danh sách PDF chung, lựa chọn nhân viên và Admin không tính công.

## Kiểm thử
- Bài test mới: `tools/v2649_idempotent_daily_shipment_count_test.js`.
- Chạy `python tools/preflight.py` và các test `tools/*_test.js` qua workflow build.
- Chưa thể xác nhận APK build hay chạy trên thiết bị thật trong môi trường tạo source này.
