# V26.2.53 — Admin đặt lại dữ liệu quét vận chuyển ngày 18/10/2026

## Mục tiêu

Thêm một công cụ chỉ dành cho Admin để đặt lại dữ liệu quét vận chuyển của riêng ngày `2026-10-18`, nhằm cho phép quét lại các nhãn đã ghi tiền công nhưng cần làm lại.

## Phạm vi xử lý

- Xóa các bản ghi quét `dailyShipmentScans` thuộc ngày đích.
- Xóa các khóa `shipmentTrackingClaims` chỉ khi khóa có `orderId = daily_<mã vận đơn>`, `source = daily_shipment_scan` và được gắn với báo cáo/quét của ngày đích. Khóa của quy trình đóng đơn ĐD/TT hoặc ngày khác được giữ nguyên.
- Gỡ các báo cáo quét theo mã vận đơn của ngày đích khỏi `dailyShipmentReports`; các báo cáo/ngày khác được giữ.
- Đặt lại trạng thái các nhãn PDF thuộc ngày đích về `imported` để chúng có thể được quét lại; giữ các trường nhận dạng, sản phẩm, số lượng, mã vận đơn, hãng vận chuyển, Order ID và trang PDF. Nếu một nhãn bị mất khỏi hàng đợi nhưng còn dấu vết PDF trong `orderPatch` của bản ghi quét, chức năng cố gắng khôi phục nhãn đó.
- Ghi dấu mốc đặt lại tại tài liệu app để cache cũ không khôi phục dữ liệu quét đã xóa. Dấu mốc có xét thời gian để các lượt quét mới sau khi reset vẫn hiển thị.

## Không xóa

- Danh mục cây, bảng giá, quy tắc nhận dạng và tài khoản nhân viên.
- Báo cáo và dữ liệu các ngày khác.
- Đơn đóng hàng thông thường và dữ liệu tồn kho nhập tay trong `D.daily`.
- Tệp ảnh vật lý đã tải lên Google Drive. Chức năng chỉ gỡ liên kết ảnh khỏi báo cáo bị đặt lại; ảnh vật lý vẫn nằm trên Drive.

## Cách sử dụng sau khi build và cài APK

1. Đăng nhập tài khoản Admin và dừng máy quét trên tất cả điện thoại/thiết bị đang xử lý đơn. Đợi hàng đợi ảnh không còn hoạt động.
2. Mở mục vận chuyển/quét nhãn. Trong thẻ Admin **“Đặt lại dữ liệu quét ngày 18/10/2026”**, nhấn **“1 · KIỂM TRA LẠI PHẠM VI TRƯỚC KHI XÓA”**.
3. Đọc tất cả số liệu xem trước: số bản ghi quét, báo cáo, khóa trùng, nhãn sẽ được giữ/khôi phục, liên kết ảnh, tiền công và số cây.
4. Nếu số liệu không đúng với phạm vi dự định (ví dụ số lượng bằng 0 hoặc có số liệu bất ngờ), **không tiếp tục**. Dừng thao tác và kiểm tra tài khoản/project Firebase đang đăng nhập.
5. Chỉ khi phạm vi chính xác, nhập `XOA 18/10/2026`, nhấn nút bước 2 và xác nhận lần cuối.
6. Sau khi ứng dụng báo thành công, kiểm tra hàng đợi còn các nhãn của ngày 18 rồi thử quét một nhãn. Xác nhận không còn báo trùng và báo cáo ghi lại đúng trước khi xử lý hết các đơn còn lại.

Nếu kết quả báo lỗi hoặc xác nhận rằng dữ liệu đã thay đổi kể từ bước xem trước, chức năng phải hủy an toàn; hãy chạy lại bước xem trước. Không xóa thủ công trên Firestore Console.

## Kiểm soát an toàn

- Đích ngày được khóa cứng trong mã: `2026-10-18`.
- Chỉ Admin đã đăng nhập mới có thể xem trước/thực thi.
- Cần cụm xác nhận chính xác `XOA 18/10/2026` và hộp xác nhận lần cuối.
- Trước khi xóa, chức năng so dấu vân tay dữ liệu đã xem trước với dữ liệu hiện tại. Nếu khác, giao dịch bị hủy.
- Giao dịch có giới hạn 200 mã; nếu vượt giới hạn sẽ dừng, không tự chia đợt và không xóa một phần.
- Khi thực thi, tiền công báo cáo và số lượng cây tính từ báo cáo quét ngày đó sẽ không còn được tính cho đến khi quét lại. Đây là kết quả dự định của thao tác reset.

## Phiên bản và kiểm thử

- Android `versionName`: `26.2.53`
- Android `versionCode`: `105`
- Đã chạy: regression test đặt lại ngày, preflight, 53 bài test JavaScript hiện có, kiểm tra cú pháp 6 khối script inline.
- Chưa build APK và chưa chạy thao tác trên Firebase thật. Source ZIP chỉ thêm chức năng; thao tác đặt lại dữ liệu chỉ diễn ra sau khi người dùng build, cài APK, đăng nhập Admin, kiểm tra phạm vi và tự xác nhận.
