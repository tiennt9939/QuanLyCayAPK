# ROLL CÂY CẢNH V26.2.93 — Sửa hiển thị đối chiếu nhãn ở tài khoản nhân viên

## Căn cứ nền

- Kế thừa trực tiếp ZIP source V26.2.92 (versionCode 144), không dựng lại dự án.
- SHA256 source đầu vào đã đối chiếu: `e452c646c17ff6522e473fcfac068d21ba6350f1824e1e1da6215ff0a993309d`.
- Bản cập nhật được nâng lên **V26.2.93 / versionCode 145** để Android cho phép cài đè bản V26.2.92.
- Package tiếp tục là `com.quanlycay.apk`.

## Nguyên nhân xác định từ code

1. `renderDailyShipmentPanel()` trước đây gọi `dailyShipmentMappedItems(row)` độc lập với trạng thái báo cáo. Vì thế kể cả khi nhãn đã có báo cáo `recorded`, giao diện vẫn có thể chạy lại phép ghép Product Name với bảng mapping cục bộ và in cảnh báo `Chưa đối chiếu đủ sản phẩm`. Đây là nguyên nhân trực tiếp khiến một dòng vừa hiện `ĐÃ GHI` vừa hiện cảnh báo ghép cây. Bản sửa dùng `report.items` — bản chụp danh sách cây đã được ghi nhận — để hiển thị cho đơn đã ghi.
2. Báo cáo trong `dailyShipmentScans` được tải theo trường ngày báo cáo/quét, trong khi hàng đợi PDF được lọc theo ngày nhập PDF. Khi hai ngày này khác nhau, truy vấn theo ngày không nhất thiết trả về báo cáo đúng mã vận đơn; thiết bị nhân viên có thể tiếp tục nhìn trạng thái hàng đợi cũ. Danh sách nhãn nhân viên cũng được tải từ `apps/roll-cay-canh` và không tự bao gồm toàn bộ tài liệu `dailyShipmentScans`.

Hai cơ chế này được xác nhận bằng cách đọc và kiểm thử code. Dữ liệu Firebase thật của hai mã `862652114050` và `862602696370` không có trong gói source, nên không thể xác nhận từ đây ngày quét thực tế của từng mã.

## Thay đổi

- Bổ sung `loadDailyShipmentScanRecordsByTrackingNos()` trong CloudSync: đọc tài liệu `dailyShipmentScans/{tracking}` theo mã vận đơn chuẩn hóa, không phụ thuộc ngày quét. Không tạo collection/trường mới, không sửa `firestore.rules`.
- Bổ sung refresh/cache theo mã vận đơn cho nhãn được giao ở tài khoản nhân viên. Khi tìm thấy báo cáo từ Firebase, ứng dụng hợp nhất báo cáo vào cache hiện có và dựng lại giao diện.
- Khi báo cáo `recorded` có `items`, danh sách cây trên giao diện lấy từ snapshot đó; không chạy lại mapping cục bộ để dựng cảnh báo.
- Nếu hàng đợi báo `recorded` nhưng chi tiết báo cáo chưa tải về, hiển thị tên sản phẩm nguyên gốc từ nhãn PDF hoặc thông báo đồng bộ trung tính, không giả mạo cảnh báo chưa đối chiếu.
- Cảnh báo với hàng chưa ghi nhận và thực sự chưa đối chiếu vẫn được giữ nguyên. Không thay đổi điều kiện an toàn của scanner (`dailyShipmentReadiness()`), nhận dạng PDF, bảng mapping, ghép tên cây, phân công, tiền công, tồn kho hay nghiệp vụ admin.
- Tăng versionName/versionCode lên V26.2.93 / 145; các assertion phiên bản hiện hành trong bộ test được đồng bộ theo metadata mới.

## Tệp chính được sửa

- `app/src/main/assets/index.html` — truy vấn báo cáo theo tracking và hiển thị snapshot đã ghi.
- `app/build.gradle.kts` — versionName 26.2.93, versionCode 145.
- `.github/workflows/build-apk.yml` — đổi tên workflow cho bản mới; quy tắc chọn ZIP auto-update vẫn giữ nguyên.
- `tools/preflight.py` và các file test đang kiểm tra version hiện hành — cập nhật assertion metadata.
- `tools/v2693_employee_shipment_reconciliation_display_test.js` — test hồi quy mới.

Danh sách đường dẫn đầy đủ nằm trong `ROLL_CAY_CANH_V26.2.93_CHANGED_FILES.txt`.

## Hạn chế cần biết

Đây là sửa lỗi hiển thị/đồng bộ được tìm ra từ source. Bản sửa không tự xác nhận mọi cảnh báo trên Firebase đều là cảnh báo giả. Nếu mã `862602696370` vẫn báo `CẦN KIỂM TRA` sau khi tải bản mới và đồng bộ, cảnh báo được giữ lại có thể phản ánh báo cáo chưa tồn tại hoặc hàng đợi thực sự chưa đối chiếu đủ; cần đối chiếu tài liệu Firebase của chính mã đó trước khi thay đổi quy tắc cây.
