# ROLL CÂY CẢNH V26.2.93 — Audit và sửa cảnh báo đối chiếu phía nhân viên

## 1. Nền source và tính toàn vẹn

| Mục | Kết quả |
|---|---|
| ZIP nền | `QuanLyCayAPK-V26.2.92-EMPLOYEE-PDF-PAYROLL-ATTRIBUTION-FIX-AUTO-UPDATE-SOURCE.zip` |
| SHA256 gói nền so với giá trị bàn giao | Khớp: `e452c646c17ff6522e473fcfac068d21ba6350f1824e1e1da6215ff0a993309d` |
| Kiểm tra ZIP nền | `unzip -t`: PASS |
| Metadata source nền | versionName 26.2.92, versionCode 144 |
| Source đầu ra | V26.2.93, versionCode 145; package giữ nguyên `com.quanlycay.apk` |

## 2. Nguyên nhân gốc tìm được

### A. Hiển thị cảnh báo dù đã ghi

Trước sửa, `renderDailyShipmentPanel()` dựng dòng cây bằng `dailyShipmentMappedItems(row)` cho mọi hàng. Hàm đó kiểm tra `tiktokProductMaps` trên chính thiết bị, rồi ném `Chưa đối chiếu đủ sản phẩm: <Product Name>` nếu mapping cục bộ không hợp lệ/không tồn tại. Việc này không phụ thuộc việc `dailyShipmentReportByTracking()` đã trả về báo cáo `recorded` hay chưa. Kết quả có thể là nhãn `ĐÃ GHI` đi kèm cảnh báo từ lần đối chiếu PDF cục bộ, dù báo cáo đã có snapshot `report.items` của cây thực tế đã ghi.

### B. Báo cáo quét có thể không tải về máy nhân viên

`refreshDailyShipmentCloudScanRecords(from,to)` lọc `dailyShipmentScans` theo ngày ghi trong báo cáo. Ngược lại, `dailyShipmentOrdersForSelectedDate()` lọc hàng đợi nhãn theo `row.date` — ngày nhập PDF. Đây là hai khái niệm ngày khác nhau. Trên tài khoản nhân viên, `loadAssignedDailyShipmentLabels()` đọc danh sách phân công từ tài liệu app dùng chung; báo cáo quét nằm trong collection `dailyShipmentScans` và có thể chưa được nạp nếu ngày quét khác ngày nhập PDF.

Không có dữ liệu Firestore trực tiếp trong ZIP, vì vậy không thể chứng minh hai mã vận đơn người dùng nêu có ngày quét khác ngày nhập hay không. Đây là đường code phù hợp với hiện tượng và được bao phủ trong kiểm thử giả lập.

## 3. Phạm vi sửa

1. Thêm đọc báo cáo theo `dailyShipmentScans/{tracking}` đã chuẩn hóa, theo lô nhỏ 12 mã mỗi lần; không đặt điều kiện ngày.
2. Tài khoản nhân viên yêu cầu đồng bộ báo cáo theo tracking của các nhãn thuộc ngày PDF đang chọn và nhãn đã có trạng thái recorded. Cache chống gọi trùng trong 20 giây.
3. Khi dữ liệu trả về, dùng hàm hợp nhất hiện có để cập nhật `D.dailyShipmentReports` và trạng thái hàng đợi; không đổi schema hoặc quy trình ghi nhận.
4. Dòng đã ghi dùng `report.items` làm dữ liệu hiển thị. Dòng được đánh dấu recorded nhưng báo cáo chưa tải sẽ hiển thị thông tin PDF trung tính thay vì chạy mapping cục bộ và phát cảnh báo giả.
5. Giữ nguyên logic mapping, nhận dạng, readiness của scanner, kiểm tra trùng mã, gán nhân viên, công thức tiền công, tồn kho, quy tắc Firestore và luồng admin.

## 4. Kết quả kiểm thử thực tế trong môi trường source

- `python3 tools/preflight.py`: **PASS**.
- Tất cả test `tools/*_test.js`: **85/85 PASS** (84 test sẵn có và 1 test mới).
- JavaScript cú pháp: **6/6 inline script blocks PASS**.
- Parser PDF `app/src/main/assets/tiktok-label-import.js`: **PASS**.
- Test mới xác minh: snapshot của báo cáo recorded được hiển thị mà không gọi mapping cục bộ; hàng unresolved chưa ghi vẫn cảnh báo; API theo tracking tìm được báo cáo có ngày quét khác ngày PDF; hàm merge giữ ngày nhập PDF và UID nhân viên.
- Test/preflight không sửa dữ liệu Firebase thật.

## 5. Chưa xác minh

- **Chưa build APK** bằng Gradle/GitHub Actions trong lượt này.
- Chưa cài APK lên điện thoại thật.
- Chưa đăng nhập Firebase/Drive thật để kiểm tra hai mã vận đơn `862652114050`, `862602696370`.
- Vì vậy không ghi nhận là đã kiểm chứng trực tiếp trên thiết bị. Kết quả hiện tại là audit source, test code và kiểm tra cú pháp.
