# ROLL CÂY CẢNH V25.4.4 – Báo giá build fix

## Mục đích
Bản này là bản sửa lỗi build từ V25.4 Báo giá.

## Lỗi đã xác định
GitHub Actions báo:
`MainActivity.java:145: error: JavascriptInterface is not a repeatable annotation type`

Nguyên nhân là `@JavascriptInterface` bị ghi **2 lần liên tiếp** trước `printA4Page(...)`.

## Cách sửa
Chỉ xóa **1 dòng annotation bị trùng**.
Không thay đổi Firebase, Rules, dữ liệu, giao diện, luồng báo giá, quyền nhân viên thu mua, PDF/CSV hoặc các chức năng V25.4 khác.

## Kiểm tra
- Không còn block `@JavascriptInterface` lặp liên tiếp trong `MainActivity.java`.
- Thay đổi source chỉ gồm đúng 1 dòng xóa annotation trùng.
- Workflow vẫn dùng Java 17, Android SDK 35, Build Tools 35.0.0, Gradle 8.13.
