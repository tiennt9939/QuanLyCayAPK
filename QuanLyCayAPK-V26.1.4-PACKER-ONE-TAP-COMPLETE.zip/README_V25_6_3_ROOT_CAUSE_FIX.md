# V25.6.3 ROOT CAUSE FIX

This release fixes the missing final link in the catalog/assignment pipeline.

- Assignment UI uses local catalog immediately; Cloud reconciliation is non-blocking.
- Assignment payload preserves `catalogId`.
- `createPackingOrder()` preserves `catalogId` in each item and top-level order.
- Reporting/order resolution prefers `catalogId` over legacy array index, preventing a reordered/stale catalog from pointing at the wrong plant.
- Version: 25.6.3 / versionCode 38.
