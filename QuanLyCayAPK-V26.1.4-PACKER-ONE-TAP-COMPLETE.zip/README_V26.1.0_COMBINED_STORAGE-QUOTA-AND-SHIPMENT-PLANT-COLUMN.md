# V26.1.0 combined fix

1. Keeps the localStorage quota fallback from STORAGE-QUOTA-CATALOG-FIX.
2. In the shipping report table, adds `Cây / SL` as the final column (after `Ngày`) to avoid shifting existing columns.
3. Plant names and sizes fall back to the catalog entry by plant index when an order item does not carry its own name/size.
4. Multi-item orders list each plant, size and quantity, plus total plant quantity.

Validation performed: ZIP integrity and static JavaScript syntax checks. Android build and on-device testing have not been run.
