# Google Drive HTTP 404 / empty-folder fix

Changes in this package:
- Image cache is now namespaced per connected Google account.
- An existing cached Drive file ID is verified by downloading it before reuse; stale/deleted/cross-account IDs are discarded and an available original image is uploaded again.
- A missing Drive reference (HTTP 404) no longer aborts the whole data-sync conversion; the app preserves the reference and warns that the photo is missing/inaccessible. The order/payroll record is not deleted.
- Photo-gallery errors now explain how to distinguish wrong Drive account from a missing/deleted file.

Important: all devices that need to view the same private images must connect to the same Google Drive account. The Firestore order data may be shared across employee accounts, but Drive files created under one personal account are not automatically visible in another account. Existing references whose file truly does not exist cannot be reconstructed from its ID alone; they need original Base64/device backup or to be re-captured.
