# V25.6.2 — Assignment catalog root fix

- Chia đơn renders the local catalog immediately.
- Cloud push/read is reconciliation only and cannot block lookup.
- Newly added local plants remain visible when Cloud is stale, slow, or permission-denied.
- Matching catalog rows use catalogId; local values win during merge.
- Version: 25.6.2 / versionCode 37.
