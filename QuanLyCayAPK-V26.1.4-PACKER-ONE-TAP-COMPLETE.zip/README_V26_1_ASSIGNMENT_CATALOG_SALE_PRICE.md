# V26.1 — Giao diện phân công và giá bán riêng

- Mục Phân công đóng hàng dùng một ô tìm kiếm/chọn cây-kích thước, giảm thao tác chọn hai lần.
- Combo 1–100 vẫn giữ; 1 cây là cây lẻ, 2–100 là quy cách combo.
- Điều khiển → Danh mục cây có giá nhập/giá vốn và giá bán riêng.
- Checkbox bật/tắt cây xuất hiện trong báo giá.
- PDF/CSV báo giá chỉ lấy giá bán; giá nhập không được xuất.
- Cây chưa có giá bán hoặc bị tắt hiển thị sẽ không xuất hiện trong danh sách chọn báo giá.
- Không thay đổi công thức tiền công theo đơn giá kích thước.
