QUANLYCAYAPK V26.1.0 — GÓI NGUỒN + WORKFLOW BUILD

NỘI DUNG
- Mã nguồn Android và giao diện web của ứng dụng.
- Chức năng chọn giá nhập / giá bán trong mục Báo giá.
- Chức năng chọn cột giá khi xuất danh mục cây trong Điều khiển.
- tools/preflight.py để kiểm tra nguồn.
- .github/workflows/build-apk.yml để chạy GitHub Actions tạo APK debug.

CÁC LỰA CHỌN TRONG BÁO GIÁ
- Kèm giá bán: mặc định bật.
- Kèm giá nhập: mặc định tắt và chỉ Admin được chọn.
- Có thể chọn giá bán, giá nhập hoặc cả hai.
- Không chọn giá nào thì không cho xuất.
- PDF/CSV chỉ hiển thị các cột giá đã chọn.
- Giá nhập không tự động xuất hiện nếu chỉ chọn giá bán.

CÁCH DÙNG
1. Sao lưu repository hiện tại trước khi cập nhật.
2. Giải nén gói này. Đây là bộ file nguồn, KHÔNG phải APK.
3. Đưa nội dung bên trong thư mục này vào thư mục gốc repository QuanLyCayAPK, giữ nguyên cấu trúc thư mục. Đặc biệt phải có:
   - app/build.gradle.kts
   - app/src/main/assets/index.html
   - tools/preflight.py
   - .github/workflows/build-apk.yml
4. Xác nhận app/build.gradle.kts có versionCode = 42 và versionName = "26.1.0".
5. Commit các thay đổi lên nhánh main.
6. Vào GitHub > Actions > Build ROLL CAY CANH V26.1.0 > Run workflow.
7. Chỉ tải artifact QuanLyCayAPK-V26.1.0-debug khi build xanh (Success).
8. Cài thử APK và kiểm tra đăng nhập, phân công, báo giá (3 chế độ giá), xuất PDF/CSV trước khi dùng chính thức.

LƯU Ý AN TOÀN
- Không chép đè hoặc xóa dữ liệu Firebase.
- Không thay Firestore Rules bằng file trong gói này; chức năng dự kiến không yêu cầu đổi rules.
- Gói này không chứa dữ liệu trực tiếp Firestore, tài khoản Firebase Authentication hoặc GitHub Secrets.
- Gói nguồn và workflow chưa phải APK đã build. Cần chạy GitHub Actions thực tế.
- Nếu repository có các file mới hơn/khác biệt chưa nằm trong gói, đừng xóa mù; so sánh trước khi thay thế.
