# V26.1.0 Combined fix v2

Includes:
- Shipment report `Cây / SL` final column.
- Plant name/size fallback to catalog by plant index.
- LocalStorage quota recovery updated: after making an emergency compact cache without embedded data:image payloads, it removes the previous `quanlycay` entry before writing the compact value, addressing WebView implementations that fail replacing an oversized key while the old value is still counted.
- Keeps the full app state in memory and schedules existing CloudSync as before.

Validation: ZIP integrity and JavaScript syntax passed. Android build/device test not run. User should sync Cloud before updating and verify images remain available.
