# V26.1.0 — Chọn cột giá khi xuất danh mục cây

## Thay đổi
- Trong Điều khiển → Danh mục cây, thêm khu vực “Xuất danh sách giá toàn bộ danh mục”.
- Có thể chọn độc lập “Kèm giá bán” và “Kèm giá nhập”.
- Chỉ giá bán: file chỉ có cột giá bán.
- Chỉ giá nhập: file chỉ có cột giá nhập.
- Chọn cả hai: file có cả hai cột.
- Không chọn loại giá nào: hệ thống chặn xuất file.
- Xuất được toàn bộ cây đang hoạt động trong danh mục, không phụ thuộc ô tìm kiếm và không phụ thuộc cài đặt cây có hiện trong báo giá khách hàng hay không.
- Giá nhập chỉ được xuất khi tài khoản có role `admin` và Admin chủ động tick chọn. Báo giá khách hàng thông thường vẫn chỉ dùng giá bán.
- Hỗ trợ xuất PDF theo nền báo giá hiện có và CSV.
- Không đổi cấu trúc dữ liệu danh mục, công thức tính lương, tồn kho, phân công hoặc Firestore Rules.
- Cập nhật `tools/preflight.py` từ phiên bản cũ 26.0.0/code 40 sang V26.1.0/code 42 và thêm các kiểm tra cho chức năng mới.

## Kiểm tra đã chạy
- JavaScript syntax check cho 5 khối script: PASS.
- `tools/preflight.py`: PASS.
- Các kiểm tra xác nhận lựa chọn giá bán/giá nhập/cả hai, chặn bỏ trống và giới hạn xuất giá nhập cho Admin: PASS.

## Giới hạn xác nhận
- Chưa build APK trong môi trường hiện tại vì gói nguồn không có Gradle Wrapper và môi trường hiện tại không có lệnh `gradle` cài sẵn.
- Chưa kiểm thử PDF/CSV trên thiết bị Android thực tế. Cần chạy GitHub Actions, cài APK build được và kiểm tra file xuất trước khi dùng chính thức.
- Gói này không chứa dữ liệu trực tiếp trên Firestore, Firebase Authentication users hoặc GitHub Secrets.
