# ROLL CÂY CẢNH — V26.0.0

## Mục tiêu
V26.0.0 lấy V25.6.14 làm nền ổn định và nâng kiến trúc theo hướng giữ nguyên nghiệp vụ Excel nhưng bổ sung các mô-đun mới.

## Đã tích hợp
- Phân công cây có tìm kiếm nhanh theo tên.
- Lương hợp nhất từ công trực tiếp + đơn phân công đã hoàn tất + điều chỉnh/ứng lương.
- Admin có thể hoàn tất đơn được phân công và ghi nhận tiền công cho đúng nhân viên.
- Bắt buộc 2 ảnh khi hoàn tất đơn.
- Theo dõi vận đơn J&T / Cargo / GHN.
- OCR ảnh vận đơn bằng ML Kit; người dùng có thể sửa mã/đơn vị trước khi lưu.
- Tìm kiếm mã vận đơn và thống kê số đơn theo ngày.
- Gửi nhãn đơn 65×100 sang FlashLabel bằng Android share intent; hỗ trợ package FlashLabel Pro/FlashLabel.
- Giữ báo giá PDF trên nền Roll Garden, in A4 và nhãn 65×100.
- Giữ combo 1–100 cây và logic giá/công theo danh mục.

## Root-cause fix mới
- Sửa callback OCR: Java gọi đúng hàm `__shippingOcrResult(text)` thay vì ghi đè hàm bằng chuỗi OCR.
- Tăng versionCode lên 40 để APK V26 không thể bị Android nhầm với V25.6.14.
- Workflow kiểm tra đúng source V26 trước khi build và yêu cầu đủ 5 JavaScript interfaces.

## Build
Workflow GitHub Actions sẽ build `app-debug.apk` và upload artifact `QuanLyCayAPK-V26.0.0-debug`.


## Shipping OCR carrier distinction
- GHN is recognized from GHN / Giao Hang Nhanh variants.
- J&T Express requires J&T/JNT/J&T plus the word Express.
- J&T Cargo requires J&T/JNT/J&T plus the word Cargo.
- The parser never maps generic J&T to a carrier without the distinguishing word.
- Completed packing orders keep the two proof photos and shipment fields together for transport reporting.
