# QuanLyCayAPK — Chính sách dọn dữ liệu 30 ngày

Bản nguồn này tích hợp cơ chế dọn lịch sử theo ngày vào `app/src/main/assets/index.html`, dùng dữ liệu chung hiện có tại Firestore `/apps/roll-cay-canh` và đơn chuẩn tại `/packingOrders`.

## Quy tắc đã tích hợp

- Khi Admin đăng nhập và đồng bộ được Cloud, hệ thống kiểm tra dữ liệu cũ. Khi ứng dụng đang mở, kiểm tra lại theo chu kỳ 6 giờ và khi ứng dụng trở lại màn hình/online.
- Dữ liệu theo ngày được đưa vào giai đoạn cảnh báo ở mốc 29 ngày. Hệ thống phải ghi nhận đã hiện cảnh báo và chờ đủ tối thiểu 24 giờ mới cho phép dọn; nếu Admin lần đầu mở app khi dữ liệu đã quá hạn, thời gian cảnh báo 24 giờ bắt đầu từ lần kiểm tra đó.
- Chỉ xóa đơn ở trạng thái `completed`. Đơn chưa hoàn tất được giữ lại, không tự xóa đơn đang làm dở.
- Trước khi xóa chi tiết cũ, hệ thống chụp tồn cuối tháng, chuyển tồn của ngày cuối tháng trước thành tồn đầu kỳ tháng mới, chốt tồn nền trước ngày bị dọn, bảo lưu chi tiết tiền công và tiền ứng theo ngày/nhân viên, rồi đồng bộ dữ liệu bảo vệ lên Cloud.
- Sau khi xác nhận đơn cũ đã được xóa khỏi Firestore, bản ghi tiền công được đặt mốc bảo lưu tối thiểu thêm 10 ngày. Chỉ bản ghi đã được Admin xác nhận thanh toán và hết thời gian bảo lưu mới được xóa. Tiền công chưa thanh toán không tự xóa.
- Nếu xóa đơn hoặc đồng bộ bị gián đoạn, hàng đợi hoàn tất còn được lưu để lần kiểm tra sau có thể tiếp tục. Khi dọn đơn, hệ thống chỉ xóa mã chống trùng vận đơn nếu mã đó vẫn thuộc đúng đơn sắp xóa.
- Danh mục cây, đơn giá, thông tin nhân viên, tài khoản và tồn nền không bị xóa bởi cơ chế này.

## Giới hạn vận hành quan trọng

Đây là cơ chế chạy phía ứng dụng, không phải tác vụ nền phía máy chủ. Android/Firebase không tự đánh thức ứng dụng đã đóng: Admin cần mở ứng dụng có mạng để hệ thống hiện cảnh báo và chạy kiểm tra. Khi ứng dụng đóng hoàn toàn, không thể bảo đảm thông báo hệ điều hành đúng giờ nếu chưa triển khai backend lập lịch riêng.

## Kiểm tra đã chạy trên mã nguồn

- `python tools/preflight.py`
- `node tools/retention_logic_test.js` — kiểm tra công thức tồn và chuyển tồn cuối tháng sang đầu kỳ tháng mới; kiểm tra các bất biến về cảnh báo và bảo lưu tiền công.
- `node --check` cho các khối JavaScript nội tuyến.
- Phân tích cú pháp `AndroidManifest.xml` và `styles.xml`.

Chưa chạy build APK Android thực tế trong môi trường chỉnh sửa này; cần chạy workflow GitHub Actions để xác nhận Gradle build và sau đó kiểm tra vận hành trên thiết bị/Firebase thật.
