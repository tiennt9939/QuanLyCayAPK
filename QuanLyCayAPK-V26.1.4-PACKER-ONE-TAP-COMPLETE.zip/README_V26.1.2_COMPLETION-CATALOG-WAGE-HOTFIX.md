# QuanLyCayAPK V26.1.2 — Completion, Catalog Sync, and Wage Hotfix

## Fixed in source
- Adds diagnostic context for permission-denied when completing a TikTok (TT) packing order. A packer can create a tracking claim only for their own assigned, pending TT order; tracking claims remain unique.
- Restricts employee order updates to completion/evidence fields so employees cannot alter assigned plant, size, quantity, or wage snapshot.
- Makes saving plant catalog items and wage rates clearly distinguish local save from successful cloud synchronization. Protects the local dirty flag from localStorage quota exceptions.
- Per-order wage rules: Cẩm tú mai C7 uses 1,600 VND/plant when the same plant+size quantity in one order is >= 5; Cẩm tú mai C9 uses 2,500 VND/plant when quantity is >= 4. Below-threshold orders use the configured rate (C7 2,000 and C9 3,000 in the supplied source data). Manual daily/stock-entry calculations continue to use the configured size-rate table.
- Saves an assigned-rate snapshot on each line and an order wage snapshot, so later rate-table changes do not silently rewrite the wage assigned to an existing order. Existing legacy orders without snapshots continue to use the legacy/configured calculation path.

## Required Firebase deployment step
The APK cannot publish Firestore Rules. Open Firebase Console → Firestore Database → Rules, select the **same Firebase project configured in this APK**, replace the rules with `firestore.rules` in this archive, and click **Publish**. If the live rules remain old, the permission error may continue even after installing a new APK. Do not replace rules in a different Firebase project.

## Checks
GitHub Actions is configured to run `tools/preflight.py`, `tools/retention_logic_test.js`, `tools/packing_wage_rules_test.js`, and JavaScript syntax validation before `assembleDebug`.

Local checks performed for this archive: Python preflight; wage-rule unit tests; retention logic tests; and syntax checks for embedded JavaScript. The archive has **not** been compiled into an APK in this environment because Gradle/Android SDK are not installed here. Firebase Rules have not been validated against a live Firebase project. Use GitHub Actions for the Android build, then retry an assigned TT order after Rules are published.
