# Google Drive evidence photos — v26.1.1

- Completion images must upload to the connected Google Drive account before the order can be marked completed. The app no longer silently falls back to writing new Base64 proof images into Firestore when Drive is disconnected.
- Native upload now verifies that each returned file ID exists, has non-zero size, and belongs to the app's `QuanLyCayAPK_Images` folder before returning success.
- The Google Drive connect flow checks the shared-data push result and records the connected account plus folder ID in the Drive status panel. Admin migration of legacy Base64 order proof images remains enabled.
- Completed-order cards and the shipment report no longer embed `drive://...` in HTML image sources. They show a `Xem ảnh (n)` control; tapping it lazily resolves up to two private images, and tapping either thumbnail opens the existing full-screen image viewer.
- Shipment report gallery covers both proof image 1 (packed parcel) and proof image 2 (shipping label). Orders with a missing image display their current available count rather than a broken image icon.

## Validation notes

Source checks should include `python3 tools/preflight.py`, JavaScript syntax checks for every inline script, Android manifest XML parsing, archive integrity, and Gradle compilation via the repository workflow. Runtime Drive upload depends on OAuth consent being allowed for the connected account and the account being the same one used in the Google Drive app. This source change intentionally fails completion if a required new image cannot be uploaded, rather than silently storing Base64 in Firestore.
