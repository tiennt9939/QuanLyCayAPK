plugins { id("com.android.application") }

android {
    namespace = "com.quanlycay.apk"
    compileSdk = 35

    // Stable DEBUG-only signing. The private keystore is supplied by GitHub Actions secret,
    // never stored in this source archive or committed to the public repository.
    signingConfigs {
        create("stableDebug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            // If the Actions secret is not configured yet, keep the standard debug build working.
            // Once present, subsequent debug APKs use the same stable certificate.
            if (file("debug.keystore").exists()) {
                signingConfig = signingConfigs.getByName("stableDebug")
            }
        }
    }

    defaultConfig {
        applicationId = "com.quanlycay.apk"
        minSdk = 23
        targetSdk = 35
        versionCode = 46
        versionName = "26.1.4"
    }
}


dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.android.gms:play-services-auth:21.3.0")
}
