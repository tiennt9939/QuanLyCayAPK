# ROLL CÂY CẢNH V26.1.4 — Packer One-Tap Completion

## User-flow change
- Admin assigns an order to an employee.
- The order appears immediately in the employee's assigned-order list.
- The employee does not need to press a separate "Nhận đơn" button.
- The employee opens the order card, captures the required evidence photos in the same simple modal layout used by Admin, and confirms completion.
- The packer path calls `CloudSync.state().completePackingOrder(...)`, so it remains authenticated as the currently assigned employee and does not use the Admin-only completion API.

## UI changes
- One list for "ĐƠN ĐƯỢC PHÂN CÔNG" and one for "ĐƠN ĐÃ HOÀN THÀNH".
- Each pending card shows order type, order number, assigned employee, plant/size/quantity lines, base wage, adjustments, total wage, and one "CHỤP ẢNH & HOÀN TẤT ĐƠN" action.
- Photo controls use the same modal pattern as Admin: photo 1, photo 2 when required, OCR state, and a confirmation action.
- The old separate inline packer photo panel remains in the source for backward compatibility but is hidden in the packer view.

## Preserved rules
- TT: two photos, OCR on photo 2 and validated shipment evidence.
- ĐN: two photos, no OCR.
- ĐD: one photo to complete, with label/OCR follow-up on the next workday.
- Only the employee whose UID matches `assignedUid` can complete their assigned order.
- Inventory/payroll calculation rules were not intentionally changed in this UI update.
- New photos still require Google Drive upload confirmation before completion can be submitted.

## Validation
- `tools/packer_assignment_ui_test.js` asserts no accept-order button in the employee list and confirms the modal submits through the packer-scoped completion service.
- `tools/preflight.py` checks version and key workflow wiring.
- GitHub Actions runs the existing retention, wage, and Drive persistence tests plus the new packer UI regression test, syntax checks, APK build and artifact upload.

Build version: `26.1.4`, version code `46`.
