const fs = require('fs');
const path = require('path');
const htmlPath = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
function assert(condition, message) {
  if (!condition) throw new Error(message);
}
const renderStart = html.indexOf('function renderPackerOrders(){');
const renderEnd = html.indexOf('async function acceptAssignedOrder(id){', renderStart);
assert(renderStart >= 0 && renderEnd > renderStart, 'Packer order list function should exist');
const renderer = html.slice(renderStart, renderEnd);
assert(renderer.includes('onclick="openPackerCompleteOrder('), 'Pending assigned order cards should open the completion modal');
assert(!renderer.includes('acceptAssignedOrder('), 'Packer list should not call an accept-order action');
assert(!renderer.includes('NHẬN ĐƠN'), 'Packer UI should not display a separate accept-order step');
assert(renderer.includes('ĐƠN ĐƯỢC PHÂN CÔNG'), 'Packer list should have a single assigned-orders section');
assert(html.includes('function openPackerCompleteOrder(id)'), 'Packer completion modal should exist');
assert(html.includes('async function submitPackerCompleteOrder(id)'), 'Packer modal submit should exist');
assert(html.includes('completePackingOrder(String(id),pendingAdminOrderProof,sh)'), 'Packer must use the packer-scoped completion service');
assert(!html.includes('onclick="acceptAssignedOrder('), 'No visible inline button should require accepting an order');
assert(html.includes('readAdminOrderProof(event,0)') && html.includes('readAdminOrderProof(event,1)'), 'Packer modal should reuse the admin-style two-photo controls');
assert(html.includes("async function completeAssignedOrder(){return submitPackerCompleteOrder(String(selectedOrderId||''))}"), 'Legacy inline action must route into the one-tap completion flow');
console.log('PACKER ONE-TAP COMPLETION UI TEST PASS');
