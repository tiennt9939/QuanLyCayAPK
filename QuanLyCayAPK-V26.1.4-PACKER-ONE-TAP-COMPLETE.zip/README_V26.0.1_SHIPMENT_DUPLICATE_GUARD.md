# V26.0.1 – Shipment OCR Duplicate Guard

## Mục tiêu
Không cho phép hoàn tất một đơn đóng hàng nếu ảnh 2 không OCR được mã vận đơn hợp lệ hoặc mã vận đơn đã được ghi nhận ở một đơn hoàn tất khác.

## Quy tắc mã hợp lệ
- GHN: `VNGH` + 8–12 chữ số.
- J&T Express: đúng 12 chữ số, bắt đầu `862`.
- J&T Cargo: đúng 12 chữ số, bắt đầu `530`.

OCR phải trả về text và mã phải khớp một trong các định dạng trên. Carrier được suy ra theo mã; nếu OCR carrier khác carrier của mã thì chặn hoàn tất.

## Chống trùng
- Kiểm tra các packingOrders đã hoàn tất, cả `shipmentTrackingNo` và dữ liệu cũ `shipment.trackingNo`.
- Tạo claim duy nhất tại `/shipmentTrackingClaims/{trackingNo}`.
- Hoàn tất đơn + claim được ghi trong một Firestore transaction.
- Firestore Rules dùng `getAfter()` để bắt buộc claim thuộc đúng order trong cùng transaction.
- Vì vậy hai thiết bị hoàn tất đồng thời cùng một mã cũng không thể cùng ghi nhận.

## Báo cáo
- Các bản ghi trùng đã tồn tại từ trước vẫn được hiển thị nhưng có nhãn `⚠️ TRÙNG MÃ` để nhận biết.
- Bộ đếm theo ngày tính theo **mã vận đơn duy nhất**, không đếm hai lần cùng một mã.

## Admin
Admin hoàn tất đơn cũng phải qua OCR ảnh 2 + kiểm tra mã hợp lệ + chống trùng, giống nhân viên.

## Phiên bản
- versionName: `26.0.1`
- versionCode: `41`
