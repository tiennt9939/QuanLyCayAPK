# Stable Google Sign-In signing for debug APK

This package keeps the v26.1.1 app behavior and makes debug signing stable across GitHub Actions builds.

## Why
The previous workflow used a fresh GitHub-hosted runner each time, so Android generated a different debug certificate and Google Sign-In returned error 10 (`DEVELOPER_ERROR`). The SHA-1 registered before was `96:A1:F5:69:B6:44:92:C1:D6:38:A9:0F:C7:7C:22:01:18:CA`, while the APK from Actions run #23 was signed with SHA-1 `34:6D:FB:F7:70:2E:85:09:C4:32:EF:E0:A0:F1:34:CE:48:0B:46:6A`. They do not match.

## Required one-time setup
1. In GitHub repository Settings → Secrets and variables → Actions, create secret `DEBUG_KEYSTORE_BASE64`. Its value is the complete content of `DEBUG_KEYSTORE_BASE64_SECRET.txt` supplied separately with this package. Do not put the secret text into the public repository.
2. Replace the root workflow `.github/workflows/QuanLyCayAPK_v26.1.1_build-apk.yml` with the updated workflow provided separately, or ensure it has the step that decodes `DEBUG_KEYSTORE_BASE64` into `app/debug.keystore` before Gradle runs.
3. Add a new Android OAuth client in Google Cloud for package `com.quanlycay.apk` with SHA-1 `A1:99:A4:22:0E:B7:17:49:3A:28:28:B5:CA:8D:F1:C6:78:08:29:F2`. Keep the old client if older installs still need it.
4. Build and install the APK. Because previous Actions APKs used different temporary signing keys, Android may reject it as an update. After confirming the app says data is synchronized, uninstall the old APK and install the stable-signed build. Firestore data remains in the cloud, but unsynced local-only data can be lost.

The included signing certificate is for debug/testing only, not Play Store release signing. Do not use it as a production release key.
