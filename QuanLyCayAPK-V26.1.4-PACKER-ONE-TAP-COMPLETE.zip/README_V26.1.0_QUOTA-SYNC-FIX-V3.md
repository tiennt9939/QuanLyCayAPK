# V26.1.0 quota/sync fix V3

- Includes shipment report final column `Cây / SL`.
- Local cache tries full save, then compact cache without embedded data:image base64 strings.
- If localStorage remains full even after compact retry, the local cache quota error no longer aborts the Cloud Sync flow; current in-memory D remains intact so CloudSync.pushNow can attempt Firestore upload.
- Warning explicitly says do not close app until status says synced.
- This is a guarded fallback, not a long-term replacement for moving embedded images to IndexedDB/cloud storage.

Validation: ZIP integrity and JavaScript syntax only. Android build and live Firestore sync are not tested.
