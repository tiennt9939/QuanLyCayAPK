# V26.1.0 OCR + Plant Quantity Column

Change:
- Added a `Cây / SL` column immediately to the left of the `Đơn` column in the shipment tracking list.
- Displays each plant name, size, quantity, and total plant quantity for multi-item orders.
- Reads order items using the existing `orderItems(r)` helper; no inventory, wage, or order data is modified.

Validation:
- Source text patch applied to `app/src/main/assets/index.html`.
- Confirmed the table header and row renderer both include the new column.
- Android APK build and on-device UI test have not been run by this patch.
