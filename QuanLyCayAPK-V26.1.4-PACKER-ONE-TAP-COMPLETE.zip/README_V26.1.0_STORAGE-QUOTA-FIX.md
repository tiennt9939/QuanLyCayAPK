# V26.1.0 Storage quota fix

- localSaveOnly first attempts the full localStorage save.
- If the browser raises a quota error, it writes an emergency compact cache with embedded `data:image/...;base64` payloads omitted, without mutating the live in-memory app data.
- It preserves plant names, sizes, prices, orders, reports, inventory, and other non-image fields in the cache.
- The normal CloudSync push is still scheduled by the existing save flow.
- The UI warns the user that images may need Cloud sync.
- This is a safety fallback, not a substitute for image storage in IndexedDB/remote storage. Test cloud sync and reload before production use.
