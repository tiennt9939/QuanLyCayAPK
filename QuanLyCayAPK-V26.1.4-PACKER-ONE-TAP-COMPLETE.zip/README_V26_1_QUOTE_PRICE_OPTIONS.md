# V26.1.0 — Chọn giá nhập/giá bán trong mục Báo giá

## Thay đổi
- Thêm hai ô chọn độc lập ngay trong mục Báo giá: `Kèm giá bán` (mặc định bật) và `Kèm giá nhập` (mặc định tắt).
- Chỉ giá bán: danh sách sản phẩm, chi tiết, tổng giá và file PDF/CSV hiển thị giá bán.
- Chỉ giá nhập: hiển thị giá nhập và tổng giá nhập.
- Chọn cả hai: hiển thị giá nhập và giá bán cùng tổng tương ứng riêng biệt.
- Không chọn giá nào: chặn xuất; giao diện tự bật lại giá bán làm mặc định.
- Giá nhập chỉ có thể chọn và xuất bởi Admin; tài khoản không phải Admin không được bật tùy chọn này.
- Danh sách cây trong báo giá phản ánh loại giá đã chọn và vẫn tôn trọng cài đặt `showInQuote`.
- PDF tiếp tục sử dụng nền báo giá hiện có; CSV có cột riêng cho đơn giá và thành tiền từng loại giá.
- Không thay đổi dữ liệu giá trong danh mục, công thức tính lương, tồn kho, phân công, đồng bộ hay Firestore Rules.

## Kiểm tra đã chạy
- Kiểm tra cú pháp Node.js cho cả 5 khối script trong `index.html`: PASS.
- `tools/preflight.py`: PASS, gồm các điều kiện kiểm tra lựa chọn giá trong báo giá.
- ZIP được kiểm tra sau khi đóng gói.

## Giới hạn
- Chưa build APK hoặc kiểm thử file PDF/CSV trên điện thoại Android thật. Cần chạy GitHub Actions và kiểm tra artifact trước khi cài đặt sử dụng chính thức.
