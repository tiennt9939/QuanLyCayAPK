# Google Drive image storage integration (v26.1.1)

This source adds native Google Sign-In authorization for the Drive `drive.file` scope and an Android bridge to create/use the private `QuanLyCayAPK_Images` folder, upload image data, and retrieve private image data. When Drive is connected, the web application stores `drive://FILE_ID` references in Firestore instead of Base64 payloads; existing Base64 images are uploaded during a shared-data push and completed-order listener migration. Older Base64 data remains readable and is not deleted from local cache.

## Runtime requirement

For private images to be visible on all devices without making shipping label photos public, connect the same Google Drive account on each Android device used with this app. Firebase app logins remain unchanged. The first Drive connection requires Google to grant the requested `drive.file` access. Google Drive API must be enabled for the associated Google Cloud project and the Android OAuth client must match application ID `com.quanlycay.apk` plus the signing SHA-1 used by the APK.

## Validation

The source package was checked for JavaScript syntax and archive consistency. Android/Google OAuth runtime authorization and an actual Drive upload/download require running the workflow/build on a signed Android APK and testing with the configured Google account; they are not claimed as verified by this source-only check.
