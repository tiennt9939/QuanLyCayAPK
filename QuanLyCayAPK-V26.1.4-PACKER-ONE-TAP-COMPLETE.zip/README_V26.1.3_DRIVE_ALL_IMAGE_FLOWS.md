# V26.1.3 — Drive-backed image persistence audit

## Goal

All user-captured/imported photos are uploaded to the connected Google Drive account before the app accepts the image-bearing action. Firestore, `localStorage`, the packer-order cache, and exported JSON backups should keep a `drive://<file-id>` reference rather than an embedded Base64 image. Photo data URLs may still exist temporarily in JavaScript memory for preview, ML Kit OCR, and Firestore request conversion; this is not the persistent local format.

## Image paths included in the audit

- Plant catalog photo: camera/gallery -> `readPlantImage` -> `ensureImageUploadedToDrive` -> catalog `image`.
- Admin daily packing proof: camera -> `readAdminPackProofImage` -> Drive upload -> `D.daily[].proofImages`.
- Employee order completion proof: camera -> `readPackProofImage` -> Drive upload -> `packingOrders.completionImage/completionImages`.
- Delivery-label photo/OCR: camera -> `readDeliveryOcrImage` -> Drive upload before OCR/submit.
- Admin completion of an assigned order: `readAdminOrderProof` -> Drive upload before completion.
- Shipment table/report OCR photo: `readShipmentImage` -> Drive upload before OCR.
- Legacy local records and employee cache: `migrateLocalImagesToDrive` scans the main app data and every `ROLL_CAY_PACKER_ORDERS_*` cache.
- Legacy Firestore packing-order photos: startup/connect flow invokes `migrateOrderImagesToDrive` for Admin.
- Backup import uploads embedded images before accepting the imported data; backup export only emits Drive references and refuses to create a Base64-bearing file.

## Persistence guarantees and limits

- `localSaveOnly` converts mapped images to Drive refs. If it detects any image without a confirmed Drive reference, it does not overwrite the last known-good local cache with a larger Base64 snapshot. It queues legacy migration when Drive is connected and asks the user to connect Drive if not.
- Captured images are blocked when Drive is not connected or upload fails. The UI should not report image capture as saved until Drive confirms the upload.
- The Drive hash map stored in `localStorage` contains only image hashes and Drive IDs, not image bytes.
- After successful migration, both `quanlycay` and `ROLL_CAY_PACKER_ORDERS_*` should contain references rather than photo data URLs. Older caches may still contain Base64 until a connected migration completes successfully.
- A `drive://` reference is private to the connected Google account used for upload. Use the same Google account on each device.
- Static APK assets such as logo, login background, quotation background, and label-print background remain packaged in the app. They are not user-created photos and are not stored in `localStorage`.
- Photos can remain temporarily in RAM while a view/OCR operation needs them. This change targets persistent browser storage and Cloud records; it does not attempt to remove every in-memory pixel buffer immediately.

## Verification

Run from the project root:

```bash
python3 tools/preflight.py
node tools/retention_logic_test.js
node tools/packing_wage_rules_test.js
node tools/drive_image_persistence_test.js
node --check <each inline JavaScript block extracted from app/src/main/assets/index.html>
```

The main GitHub Actions workflow also runs these checks, checks the version (`26.1.3`, code `45`), builds `assembleDebug`, verifies the APK, and uploads `QuanLyCayAPK-V26.1.3-DRIVE-ALL-IMAGE-FLOWS-debug`.

A successful static preflight is not a substitute for a device test: on a test device, connect the intended Google account, wait until old-image migration completes, capture one photo in each listed flow, confirm the file appears in `QuanLyCayAPK_Images`, then verify that saved `quanlycay` and packer cache values contain `drive://` rather than `data:image/...;base64,`. Do not clear app data before checking migration.
