
// Fallback để WebView vẫn có cấu hình Firebase nếu file config bị lỗi/không tải được.
if (!window.ROLL_CAY_FIREBASE_CONFIG || !window.ROLL_CAY_FIREBASE_CONFIG.apiKey) {
  window.ROLL_CAY_FIREBASE_CONFIG = {
    apiKey: "AIzaSyB6qZX3FZAnWX0wagxSBbnr-TG7ZK3ASTU",
    authDomain: "roll-cay-canh.firebaseapp.com",
    projectId: "roll-cay-canh",
    storageBucket: "roll-cay-canh.firebasestorage.app",
    messagingSenderId: "311724804563",
    appId: "1:311724804563:web:ae8331367750f508860726",
    measurementId: "G-BZ90BLW5EV"
  };
}
