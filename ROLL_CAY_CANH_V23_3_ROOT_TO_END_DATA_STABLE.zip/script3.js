
// V23.1: Firebase SDK loader chịu lỗi mạng/WebView. Nếu CDN chính tạm thời không tải,
// thử CDN dự phòng; không khóa initPromise vĩnh viễn và không báo sai là "Firebase chưa cấu hình".
let __firebaseSdkPromise=null;
function __loadScript(src){return new Promise((resolve,reject)=>{
  const existing=document.querySelector('script[data-firebase-sdk="'+src+'"]');
  if(existing){existing.addEventListener('load',resolve,{once:true});existing.addEventListener('error',()=>reject(new Error('Không tải được '+src)),{once:true});return}
  const s=document.createElement('script');s.src=src;s.async=false;s.dataset.firebaseSdk=src;
  s.onload=()=>resolve();s.onerror=()=>reject(new Error('Không tải được Firebase SDK: '+src));
  document.head.appendChild(s);
})}
async function ensureFirebaseSdk(){
  if(window.firebase?.auth && window.firebase?.firestore)return true;
  if(__firebaseSdkPromise)return __firebaseSdkPromise;
  __firebaseSdkPromise=(async()=>{
    const hosts=[
      'https://www.gstatic.com/firebasejs/10.14.1/',
      'https://cdn.jsdelivr.net/npm/firebase@10.14.1/',
      'https://cdnjs.cloudflare.com/ajax/libs/firebase/10.14.1/'
    ];
    const files=[
      ['firebase-app-compat.js','firebase-app'],
      ['firebase-auth-compat.js','firebase-auth'],
      ['firebase-firestore-compat.js','firebase-firestore']
    ];
    let last=null;
    for(const base of hosts){
      try{
        if(!window.firebase)await __loadScript(base+files[0][0]);
        if(!window.firebase?.auth)await __loadScript(base+files[1][0]);
        if(!window.firebase?.firestore)await __loadScript(base+files[2][0]);
        if(window.firebase?.auth && window.firebase?.firestore)return true;
      }catch(e){last=e;console.warn('Firebase CDN fallback:',base,e)}
    }
    throw last||new Error('Không tải được Firebase SDK');
  })();
  try{return await __firebaseSdkPromise}
  finally{__firebaseSdkPromise=null}
}
