
// V20.5: Login gate helpers. Giữ màn hình đăng nhập độc lập với giao diện bên trong app.
function showLoginGate(){
  const gate=document.getElementById('loginGate');
  if(gate) gate.classList.remove('hidden');
  const email=document.getElementById('gateEmail');
  const remembered=localStorage.getItem('ROLL_CAY_REMEMBER_EMAIL')||'';
  if(email && !email.value && remembered) email.value=remembered;
  setTimeout(()=>{ if(email && !email.value) email.focus(); },80);
}
function hideLoginGate(){
  const gate=document.getElementById('loginGate');
  if(gate) gate.classList.add('hidden');
  const pass=document.getElementById('gatePass');
  if(pass) pass.value='';
}
function showLoginGateError(msg){
  const el=document.getElementById('gateError');
  if(el) el.textContent=msg||'';
}
function clearLoginGateError(){showLoginGateError('')}
function toggleGatePassword(){
  const el=document.getElementById('gatePass');
  if(!el)return;
  el.type=el.type==='password'?'text':'password';
}
async function gateLogin(){
  const email=(document.getElementById('gateEmail')?.value||'').trim();
  const password=document.getElementById('gatePass')?.value||'';
  const remember=!!document.getElementById('gateRemember')?.checked;
  const btn=document.querySelector('#loginGate .login-btn');
  if(!email||!password){showLoginGateError('Vui lòng nhập tên đăng nhập và mật khẩu');return false}
  clearLoginGateError();
  if(btn){btn.disabled=true;btn.textContent='ĐANG ĐĂNG NHẬP…'}
  try{
    if(typeof CloudSync==='undefined') throw new Error('Cloud chưa khởi tạo');
    const ok=await CloudSync.signIn(email,password,remember);
    if(!ok)return false;
    // onAuthStateChanged sẽ kiểm tra hồ sơ/quyền rồi tự đóng màn hình.
    return true;
  }catch(e){
    showLoginGateError(typeof firebaseError==='function'?firebaseError(e):(e?.message||'Không thể đăng nhập'));
    return false;
  }finally{
    if(btn){btn.disabled=false;btn.textContent='ĐĂNG NHẬP'}
  }
}
function cloudLogin(){showLoginGate()}
document.addEventListener('DOMContentLoaded',()=>{
  ['gateEmail','gatePass'].forEach(id=>{
    const el=document.getElementById(id);
    if(el)el.addEventListener('keydown',e=>{if(e.key==='Enter')gateLogin()});
  });
});
