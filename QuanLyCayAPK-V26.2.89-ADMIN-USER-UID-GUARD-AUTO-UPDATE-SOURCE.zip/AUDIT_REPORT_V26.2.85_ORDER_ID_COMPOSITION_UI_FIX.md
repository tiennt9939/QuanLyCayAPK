# Audit report — ROLL CÂY CẢNH V26.2.85

Date: 2026-10-19
Candidate: `versionName 26.2.85`, `versionCode 137`
Base: source candidate V26.2.84 (build not changed here).

## Problem reproduced from screenshot

The screenshot is on the common product-mapping card for `Ổi Lê Siêu Trái C9`, with three catalog lines assigned under that one product: Ổi Lê C9 ×1, Quỳnh Anh C9 ×2, and Vàng bạc C7 ×2. This is not the editor for a full order composition. The common rule for a non-bundle Ổi Lê product must not learn independent Quỳnh Anh and Nguyệt quế items. The explicit C9–C10 range check correctly rejects a multi-species mapping because it does not represent the product's confirmed size; the visible third row is also not the expected Nguyệt quế C7.

## Root causes addressed

1. `tiktokRelatedMultiProductOrders()` previously excluded every `needs_review` row and every row with a nonempty review reason. That hid the order-composition action exactly when a product mapping/Qty issue needed Admin correction.
2. `openTikTokOrderCompositionEditor()` only accepted `ready` or one narrowly recoverable `daily_import` case, so stale legacy rows could show an apparent action but still fail its status guard.
3. A newly imported label's parser status had previously been overwritten by a staging status in the queue. V26.2.85 keeps parser status and migrates safe legacy queue rows only when there is enough product/ID evidence.
4. The common product map needs clearer separation between product-level reusable rules and one-order multi-product composition.

## Changes

- Add `tiktokOrderCompositionHardBlockReason()` to preserve hard safety blocks for duplicate tracking numbers, unreadable/missing IDs, conflicting Order IDs, and already-existing/linked real orders.
- Add `tiktokCanEditOrderCompositionRow()` so an Admin can open the one-order editor for `ready`, recoverable staging, or `needs_review` multi-product rows when identity/deduplication is sound.
- Expose the order-specific button in both the mapping card and PDF queue when safe, including on rows requiring review.
- Permit an explicit, reasoned and full-list Admin confirmation to resolve mapping/Qty review for the specific order; preserve hard identity blocks. Saved composition remains scoped to matching Order ID + tracking and is the final total, not multiplied by PDF Qty again.
- Rewrite the product-mapping warning to explain not to attach Quỳnh Anh/Nguyệt quế to the reusable Ổi Lê rule; the reset button returns a non-bundle common rule to one plant type.
- Preserve exact Order ID page grouping, SKU-first plant counts, catalog/size checks, outside-TikTok logic, Firestore schema, wages, stock, Drive and barcode flows.

## PDF fixture check

Using `pdftotext -layout` plus `TikTokLabelImport.parsePages()` against the actual `TikTokSeller_1792418463567.pdf` (11 pages):

- Order ID `586670402637104154` groups pages `[10, 11]` into exactly one parsed row.
- Main tracking: `VNGH80293690511`.
- Status: `ready`, no parser review reason.
- Product rows: Combo 2 Quỳnh Anh Qty 1 → 2 plants/unit; Nguyệt quế Thái SKU `2 chậu C7 cao 15–20cm`, Qty 1 → 2 plants/unit; Ổi Lê C9–C10 SKU Mặc định Qty 1 → 1 plant/unit pending a chosen size.
- Qty lines sum to 3; expected plant count from product/SKU text is 5.

This fixture establishes parser-level grouping. The failure seen in the screenshot is the subsequent UI path that uses a reusable product rule where a per-order composition is required.

## Safety

Hard identity blockers remain blocked. Per-order composition requires Admin role, exact Order ID and tracking, unlinked/unexisting order, every selected catalog row active, count between 1 and 100, reason >=6 characters, and explicit confirmation that the list contains all plants. When saving an Admin-confirmed complete composition, only that queue row's review status/reason is updated; no existing order, payroll, stock, Firestore schema or wages are overwritten.

## Verification results

- 76 JavaScript test scripts: PASS.
- `python tools/preflight.py`: PASS.
- Real PDF fixture parsing: target Order ID grouped pages 10 and 11; 3 product lines and 5 expected plants.
- ZIP archive integrity: checked after packaging.
- APK build, device installation, Firebase/Cloud and Google Drive live tests: NOT RUN. Do not describe as verified in production.
