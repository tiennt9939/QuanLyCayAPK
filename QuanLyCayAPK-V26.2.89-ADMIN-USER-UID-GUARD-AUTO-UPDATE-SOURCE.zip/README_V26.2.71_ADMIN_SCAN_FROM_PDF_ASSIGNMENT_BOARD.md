# ROLL CÂY CẢNH V26.2.71 — Admin quét thay trực tiếp trên bảng chia nhãn PDF

## Lỗi được sửa
Ở V26.2.70, nút Admin quét thay được thêm vào thẻ phân công đơn đóng hàng khác, không hiện trên bảng **Chia việc theo nhóm cây** mà Admin đang sử dụng. Đồng thời luồng quét nhãn PDF vẫn so UID Admin với UID nhân viên được giao nên từ chối quét thay.

## Thay đổi
- Mỗi nhãn có trạng thái **ĐÃ GIAO · [nhân viên]**, chưa ghi nhận, được đối chiếu cây và có người hưởng công hợp lệ sẽ hiện nút **ADMIN QUÉT THAY · GHI CÔNG [NHÂN VIÊN]** ngay trên thẻ nhãn.
- Nút mở máy quét cho đúng một mã vận đơn, không mở danh sách không giới hạn.
- Ảnh và báo cáo được gắn với nhân viên đã được giao. UID Admin lưu riêng trong báo cáo/khóa vận đơn để kiểm toán.
- Firebase transaction chỉ cho phép override khi actor có role Admin, UID Admin khớp, UID nhân viên/phiên phân công khớp bản ghi mới nhất và `assignmentRevision` không đổi. Nhân viên khác hoặc đơn bị đổi người giao trong lúc quét vẫn bị chặn.
- Mã đã ghi nhận/đã claim vẫn bị chặn; không tăng tiền công hoặc trừ kho lần hai.
- Bảng phân công, danh mục cây, công thức tiền công, dữ liệu tồn kho và schema Firebase khác được giữ nguyên.

## Kiểm thử
Chạy `node tools/v2671_daily_shipment_admin_delegation_test.js`, các kiểm thử workflow quét PDF, gán nhân viên, chống trùng, reset theo ngày, ảnh/Drive, tiền công và `python tools/preflight.py`.

## Android build
- `versionName`: `26.2.71`
- `versionCode`: `123`
- Package: `com.quanlycay.apk`

Source ZIP không chứa APK đã build. Hãy dùng workflow GitHub Actions để tạo APK. Kiểm thử tĩnh/hồi quy không thay thế bài thử thực tế với Firebase và điện thoại.
