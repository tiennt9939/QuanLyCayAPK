# V26.2.89 — Bản vá màn hình tài khoản Admin

## Triệu chứng
Màn **Điều khiển → Tài khoản & phân quyền** báo `cloud-error: Cannot read properties of undefined (reading 'uid')` sau khi cập nhật Rules và cài bản mới.

## Nguyên nhân được xác định trong source
`renderUserManagementRows()` đọc trực tiếp `s.user.uid` khi dựng từng hàng. Trong lúc WebView/Firebase khôi phục hoặc đổi phiên đăng nhập, object state truyền vào có thể không còn user hợp lệ. Lỗi dựng giao diện nằm chung trong `try/catch` với thao tác tải `/users`, nên lỗi JavaScript bị hiển thị như lỗi Cloud/Rules dù không có mã lỗi Firebase.

## Thay đổi
- Kiểm tra UID trước khi dựng danh sách; nếu session chưa sẵn sàng thì hiển thị thông báo có nút thử lại thay vì ném exception.
- Bỏ qua bản ghi user không có `uid` hợp lệ.
- Sau khi tải danh sách, kiểm tra UID/role hiện tại còn khớp phiên bắt đầu request trước khi render.
- Tách lỗi tải Firestore (`permission-denied`, lỗi mạng, v.v.) khỏi lỗi render UI; không gợi ý sửa Rules khi chỉ có lỗi giao diện.
- Giữ nguyên Firestore Rules và phạm vi bảo mật: `/users` chỉ đọc toàn danh sách với Admin; tài khoản thường chỉ đọc hồ sơ của chính mình.
- Không thay đổi luồng import PDF chung/riêng, payroll, inventory, schema, Google Drive hoặc cách phân công.

## Kiểm tra
- `tools/preflight.py`: PASS.
- Tất cả `tools/*_test.js`: 80/80 PASS (bao gồm test UID guard mới).
- JavaScript nhúng trong HTML: kiểm tra cú pháp PASS.
- `AndroidManifest.xml`, `styles.xml`: XML parse PASS.
- ZIP integrity: PASS.

## Chưa xác minh
Không có Gradle wrapper trong archive và không chạy build APK tại môi trường này. Chưa xác minh Firebase/Auth/Firestore/Google Drive trực tiếp. Cần build bằng GitHub Actions và thử trên thiết bị thật.
