# ROLL CÂY CẢNH V26.2.83 — Audit Admin ghép cây theo đơn và ngoại lệ số lượng

## Phiên bản
- App: `com.quanlycay.apk`
- `versionName`: `26.2.83`
- `versionCode`: `135`
- Nền logic: V26.2.81 candidate (giữ ghép trang theo Order ID); nhận diện cũ và quy tắc nghiệp vụ phải bảo toàn theo bàn giao V26.2.72; tính năng Đơn ngoài đã chấp nhận phải tiếp tục giữ.

## Thay đổi trong source ứng viên

1. **Chỉnh riêng thành phần cây cho một đơn PDF.** Trên mỗi nhãn mới, chưa liên kết/ chưa tạo đơn thật, Admin có thể mở `GỘP / CHỌN THÊM CÂY RIÊNG ĐƠN NÀY`, thêm nhiều dòng danh mục cây + size, đặt số lượng từng dòng, ghi lý do và xác nhận đó là toàn bộ thành phần thật của đơn.
2. **Rào phạm vi của ngoại lệ.** Bản chỉnh riêng được gắn với cả Order ID và mã vận đơn; không tự áp dụng sang đơn/nhãn khác cùng tên. Không cho ghi đè khi đơn đã liên kết/đã tồn tại. Nếu lưu local thất bại, bản chỉnh cũ được khôi phục, không bị xóa nhầm.
3. **Không nhân Qty lần hai.** Trong màn chốt thành phần riêng đơn, con số nhập là số cây cuối cùng của toàn đơn sau khi Qty PDF đã được tính. Khi tạo đơn, `tiktokLabelMappedItems` dùng trực tiếp số lượng đó.
4. **Quy tắc dùng chung được tinh chỉnh riêng.** Quick rule có nhiều dòng cây/size, lấy Product Name thực từ nhãn làm ngữ cảnh; nếu Product Name ghi Combo 2 nhưng SKU ghi sai Combo 4, số cây mỗi đơn vị là 2. Khi Product Name không nói rõ số cây thì tiếp tục dùng SKU/Seller SKU làm nguồn dự phòng. Ngoại lệ số cây dùng chung đòi hỏi Admin chủ động bật và nhập lý do; metadata tiếp tục dùng cấu hình Cloud hiện có, không thay Firestore schema.
5. **Không nới lỏng kiểm tra size.** Dải C9–C10 cần một size cụ thể do quy tắc đã xác nhận/Admin chọn; không ép C11 thành C9. Các kiểm tra size vẫn tách biệt với ngoại lệ đếm cây.
6. Không chủ ý đổi công thức tiền công, snapshot `assignedRate`, tồn kho, phân công, barcode, ảnh Google Drive, schema Firestore hoặc luồng Đơn ngoài.

## Kiểm thử source
- JavaScript tests: **75/75 PASS**.
- `tools/preflight.py`: **PASS**.
- `index.html`: **6/6 khối script nhúng không có lỗi cú pháp**.
- `tiktok-label-import.js`: `node --check` **PASS**.
- PDF regression: đơn `586670402637104154` giữ được ba dòng sản phẩm xuyên hai trang; Qty của các dòng là 1, 1, 1; Product Name Combo 2 + SKU Combo 4 không bị hiểu thành Combo 4; quy đổi theo quy tắc hiện hành là Quỳnh Anh ×2 + Nguyệt quế Thái C7 ×2 + Ổi Lê ×1 = **5 cây**. Kích thước Ổi Lê ghi C9–C10 chưa được tự đoán thành C9.
- Per-order override test: xác minh dữ liệu chỉnh phải khớp Order ID + tracking, bắt buộc xác nhận danh sách đầy đủ/lý do, và không nhân Qty lần nữa.

## Giới hạn xác minh
Đây là **source ứng viên đã qua kiểm thử tự động**. Chưa build APK/Release bằng GitHub Actions và chưa kiểm thử trực tiếp trên điện thoại hoặc với Firebase/Google Drive thật trong phiên này. Không khẳng định đã xác minh ký số APK. Quy tắc/thành phần riêng của đơn nằm ở hàng đợi cục bộ cho đến khi tạo đơn thật; các dòng cây đã chốt được gửi vào đơn khi quy trình tạo đơn gọi `tiktokLabelMappedItems`.
