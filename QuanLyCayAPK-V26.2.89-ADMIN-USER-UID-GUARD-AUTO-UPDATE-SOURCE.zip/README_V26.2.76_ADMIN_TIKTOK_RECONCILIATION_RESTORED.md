# ROLL CÂY CẢNH V26.2.76 — Khôi phục đối chiếu nhãn TikTok Admin

Nền tảng: V26.2.75 (có luồng Đơn ngoài TikTok), kèm lại chức năng đã xuất hiện ở V26.2.73 để Admin xử lý nhãn PDF cần kiểm tra.

## Thay đổi
- Khôi phục nút **QUẢN LÝ / THÊM / SỬA QUY TẮC NHẬN DIỆN** trong màn hình đối chiếu sản phẩm.
- Mỗi mẫu sản phẩm có nút **XÁC NHẬN ĐỐI CHIẾU & DẠY APP CHO LẦN SAU**.
- Hiện rõ số cây/đơn vị, Qty PDF và tổng cây; hỗ trợ sửa số cây/đơn vị khi nhãn/SKU cho biết số lượng rõ.
- Khi không lưu được, hiển thị nguyên nhân cụ thể (dòng cây chưa chọn, số lượng không hợp lệ, tổng cây không khớp hoặc kích thước không khớp) thay cho thông báo chung.
- Khi Firebase/Cloud lỗi, giữ quy tắc cục bộ và nói rõ chưa đồng bộ Cloud; không tuyên bố đồng bộ thành công.
- Bổ sung nhận diện cụm “Combo của tháng” và đưa khoảng chiều cao vào khóa nhận diện để rule cho 20–30cm không lẫn với 15–20cm.
- Giữ các tính năng Đơn ngoài TikTok, điều chỉnh tiền công, một ảnh hoàn tất và báo cáo riêng từ V26.2.75.

## Hạn chế kiểm chứng
Đã chạy các kiểm tra source/preflight/test tự động có sẵn và test tĩnh mới. APK chưa được build trong môi trường này; cần chạy GitHub Actions, cài APK và thử một nhãn cần kiểm tra trên Firebase thật.
