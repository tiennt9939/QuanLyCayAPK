# ROLL CÂY CẢNH V26.2.89 — Audit report

## Scope
- Base: V26.2.88 source.
- Fix the Admin user-list crash reported after the V26.2.88 Rules/source rollout.
- Preserve employee-targeted PDF import and the existing shared PDF import path.
- Package remains `com.quanlycay.apk`; `versionName=26.2.89`, `versionCode=141`.

## Findings
- The observed error `Cannot read properties of undefined (reading 'uid')` is a JavaScript exception, not a Firestore Rules error code.
- `renderUserManagementRows()` read `s.user.uid` without checking whether the session snapshot still had a user. `renderUserManagement()` also caught data-fetch and render errors in the same block, so a UI exception appeared as a generic `cloud-error` and was presented alongside Rules guidance.
- The Rules diff from V26.2.87 to V26.2.88 changes `allow read` to `allow get, list` for `/users`, under the same predicate `isAdmin() || (signedIn() && request.auth.uid == uid)`. These are equivalent read operations for that match. Rules source in this V26.2.89 archive is unchanged from V26.2.88.

## Changes
- Guard the current UID before rendering.
- Skip malformed user-list rows with no UID.
- Re-check that the Admin session UID/role has not changed while awaiting the Firestore request.
- Separate actual Firestore list errors from rendering errors in the UI.
- Do not widen `/users` read permissions.
- Leave common PDF import, employee-specific PDF import, Firestore schema, payroll, inventory, barcode, Drive and outside-order flows unchanged.

## Verification
- `tools/preflight.py`: PASS.
- All `tools/*_test.js`: 80 files, 0 failures.
- Embedded JavaScript syntax check: PASS for all non-empty inline blocks and external parser.
- `AndroidManifest.xml` / `styles.xml`: XML parse PASS.
- ZIP integrity: PASS; SHA-256 file generated.

## Not verified
- No Gradle wrapper/build run here; no APK output is claimed.
- GitHub Actions has not been run from this ZIP.
- No live Firebase Auth/Firestore/Drive test was performed.
- If V26.2.88 Rules are already published to the correct Firebase project, this UI-only fix does not require publishing Rules again. If a true `permission-denied` persists after this version, inspect the actual project and current Rules rather than granting broad `/users` read access.
