# ROLL CÂY CẢNH V26.2.80 — PDF multi-page recognition regression fix

## Nền tảng và mục tiêu

- Giữ source V26.2.79 làm khung tính năng để bảo toàn Đơn ngoài nhiều dòng đã được người dùng xác nhận tốt và giao diện Admin quản lý/quy tắc nhận dạng.
- Bảo toàn tương thích quy tắc/mapKey cũ của V26.2.72; không thay data model, công thức tiền công, tồn kho, schema Firestore, phân công, barcode, ảnh Drive hoặc luồng hoàn tất một ảnh.
- Android: `versionName 26.2.80`, `versionCode 132`, package `com.quanlycay.apk`.

## Lỗi đã sửa

1. **Dòng sản phẩm mất ở trang tiếp nối.** Parser trước đó đánh dấu mọi trang không có tracking + có Order ID + Qty Total là continuation-only, rồi xóa `products`, kể cả khi trang đó có một dòng Product Name/SKU/Qty thật. Sửa điều kiện: chỉ coi trang là footer-only khi không tách được dòng sản phẩm.
2. **Qty Total bị gán nhầm vào cây cuối.** Khi trang tiếp nối có đúng một dòng, parser trước đó có thể đổi Qty của dòng thành Qty Total toàn đơn. Chỉ phục hồi Qty từ Qty Total khi trang có tracking và chỉ có một dòng sản phẩm trên chính trang đó. Trên trang nối, giữ Qty từng dòng rồi reconcile sau khi ghép theo Order ID.
3. **Ngoại lệ Cẩm tú mai C6/C7 bị validator UI chặn.** Bộ matcher đã có quy tắc đặc biệt Combo 5 Cẩm tú mai C6/C7 → Cẩm tú mai C7, nhưng validator giao diện từ chối mọi dòng có nhiều size. Giờ ngoại lệ chỉ được chấp nhận với Combo 5 Cẩm tú mai và đúng một dòng C7; không áp dụng cho C9/C10/C11, cây khác hoặc combo khác.
4. **Quyết định Admin cho dải size trong một Product Name.** `Ổi Lê ... C9-C10` vẫn yêu cầu Admin chọn, không tự đoán size. Khi Admin trực tiếp chọn một dòng có size nằm trong dải và xác nhận, mapping lưu dấu `adminResolvedSizeConflict` trong quy tắc nhận dạng hiện có để quyết định đã xác nhận có thể tái sử dụng. Chỉ áp dụng khi dải size chỉ nằm trong Product Name và SKU/Seller SKU không nêu size độc lập; xung đột size giữa các trường và xung đột chiều cao vẫn cần kiểm tra. Không thêm collection/schema Firestore mới.
5. **Quỳnh Anh quick rule.** Giữ hành vi an toàn: nhãn chỉ ghi `Quỳnh Anh` mà không ghi số lượng vẫn yêu cầu Admin kiểm tra khi rule muốn 4 cây; nhãn thật `Combo của tháng 4 chậu Quỳnh Anh` nhận được con số 4 rõ ràng và test xác nhận 4 × Qty 2 = 8.

## Regression theo PDF đã cung cấp

Với `TikTokSeller_1792418463567.pdf`, trang 10 có `Combo 2 chậu quỳnh anh` Qty 1 và `Nguyệt quế thái ... 2 chậu C7` Qty 1; trang 11 có dòng `Ổi Lê Siêu Trái C9-C10` Qty 1 và `Qty Total: 3`, cùng Order ID. Kết quả source test sau sửa:

- Ghép thành một đơn, source pages 10–11.
- Giữ đủ ba dòng; từng Qty là 1, 1, 1; tổng Qty = 3.
- Plants per unit theo nhãn: Quỳnh Anh 2, Nguyệt quế 2, Ổi Lê 1; tổng dự kiến 5 cây.
- Parser đánh dấu cấu trúc đơn `ready` sau khi ghép QtyTotal=3; điều này chỉ xác nhận các dòng/Qty đã khớp về mặt cấu trúc. Dòng Ổi Lê ghi dải C9-C10 vẫn phải chờ Admin chọn/xác nhận size hoặc quy tắc Admin đã học; không tự đoán C9 hay C10.

## Kiểm tra đã chạy

- `python3 tools/preflight.py`: PASS.
- `node tools/*_test.js`: 73/73 PASS.
- `node --check app/src/main/assets/tiktok-label-import.js`: PASS.
- Inline JavaScript trong `index.html`: syntax check PASS.
- Test riêng cho trang tiếp nối có dòng cây thật: PASS.
- Test riêng cho ngoại lệ C6/C7, Admin-resolved C9-C10, không rò rule sang C11: PASS.
- Audit bằng `pdftotext -layout` + parser source trên 17 PDF mẫu đã nhận: 177 đơn được parser xử lý ở cả baseline V26.2.72 và candidate; các khác biệt có chủ đích chủ yếu là khôi phục dòng Oi Lê ở trang nối, phát hiện được dòng packing list không có tracking để đưa review, giá trị mặc định 1 đơn vị/cây khi nhãn không nêu bundle, và rút gọn mô tả SEO không đổi tên nhận diện cốt lõi. Riêng PDF trọng điểm, đơn ba dòng qua trang 10–11 giữ đủ Qty; packing-list chỉ có Order ID, không có tracking vẫn yêu cầu review.

## Giới hạn xác minh

- Đây là kiểm tra source/parser và bài test Node. Môi trường này không có Android SDK/Gradle wrapper phù hợp để build APK trực tiếp.
- Chưa xác minh GitHub Actions hoàn tất, release APK, certificate SHA-256, updater trên điện thoại hoặc dữ liệu Cloud thật. Không khẳng định APK đã build/chạy thật.
- Không tạo keystore mới hoặc thay đổi khóa ký. Giữ nguyên cơ chế ký hiện tại của repository/workflow.

## Phát hành candidate

ZIP source: `QuanLyCayAPK-V26.2.80-PDF-MULTI-PAGE-RECOGNITION-FIX-AUTO-UPDATE-SOURCE.zip`.
