# ROLL CÂY CẢNH V26.2.84 — Audit ghép Order ID và số lượng SKU

## Phạm vi
- Bản nền: V26.2.83, giữ nguyên các tính năng Đơn ngoài, Admin gộp nhiều cây trong một đơn, Firebase/Firestore schema, tồn kho, tiền công, phân công, barcode và ảnh Drive.
- Version Android ứng viên: `26.2.84`, `versionCode 136`.
- Ca thực tế trọng tâm: `TikTokSeller_1792418463567.pdf`, trang 10–11, Order ID `586670402637104154`.

## Nguyên nhân được xử lý
1. `parsePages()` từng cho phép khác biệt mã vận đơn chặn việc ghép dù Order ID trùng nhau. Nếu bộ đọc tọa độ lấy nhầm một mã tracking ở trang tiếp nối, hai trang có thể thành hai dòng đơn. Nay Order ID chính xác là khóa ghép ưu tiên; mã tracking chỉ dùng làm khóa dự phòng khi không đọc được Order ID. Tracking phụ khác nhau được giữ trong `trackingAliases` để audit, không tạo đơn thứ hai.
2. `parsePageText()` từng thay Qty riêng của dòng sản phẩm bằng `Qty Total` nếu trang có tracking và chỉ nhìn thấy một dòng. Trong trang tiếp nối, việc đó biến Qty 1 của Ổi Lê thành Qty Total 3. Nay Qty của từng dòng được giữ nguyên và `Qty Total` chỉ được đối chiếu sau khi ghép đủ các trang cùng Order ID. Chỉ ca một sản phẩm, một trang, một Order ID hợp lệ mới được điều chỉnh số Qty sau đối chiếu.
3. `expectedPlantsPerSoldUnit()` từng ưu tiên số “Combo N” trong Product Name. Nay ưu tiên số lượng rõ trong SKU, rồi Seller SKU, sau đó mới dự phòng Product Name. Do đó Product Name `Combo 2 chậu cẩm tú mai C9` cùng SKU `Combo 4 chậu cẩm tú mai C9` được tính 4 cây/đơn vị.
4. Giao diện Admin không còn gọi chênh lệch Product Name/SKU là lỗi số lượng khi SKU đã ghi rõ số cây. Cảnh báo ngoại lệ tiếp tục dành cho trường hợp SKU/Seller SKU mâu thuẫn hoặc số cây Admin ghép khác số cây theo nguồn được ưu tiên.

## Kết quả kiểm tra
- **75/75** bài kiểm thử JavaScript: đạt.
- `tools/preflight.py`: PASS.
- Cú pháp JavaScript nhúng trong HTML: kiểm tra bởi preflight.
- 17 PDF đã tải: 181 trang, parser dựng được 177 dòng nhãn/đơn ở chế độ text-layout (`pdftotext -layout`).
- Ca Order ID `586670402637104154`: gom trang 10 và 11 thành **một đơn**, giữ 3 dòng: Quỳnh Anh Qty 1 (2 cây/đơn vị), Nguyệt quế Thái C7 Qty 1 (SKU `2 chậu C7`, 2 cây/đơn vị), Ổi Lê Qty 1 (1 cây/đơn vị). Tổng Qty = 3; tổng cây dự kiến = 5; status parser `ready`.
- Test bổ sung mô phỏng lỗi native extractor trả mã tracking khác ở trang tiếp nối nhưng cùng Order ID; parser vẫn trả một đơn với 3 dòng và không ghi đè Qty 1 của Ổi Lê thành 3.
- Trường hợp Product Name ghi Combo 2 nhưng SKU ghi Combo 4: `expectedPlantsPerSoldUnit` trả **4**, đúng yêu cầu vừa xác nhận.

## Giới hạn xác minh
Đây là kiểm thử source/parser và text-layout của các PDF thật. Môi trường này không có Gradle wrapper/Gradle Android toolchain để build APK; chưa xác minh GitHub Actions, APK, chữ ký cài đặt, Firebase/Drive live hoặc hành vi trên điện thoại. Không tuyên bố đây là APK đã được kiểm thử thực tế.

## Cách phát hành
Đưa ZIP `*AUTO-UPDATE-SOURCE.zip` lên thư mục gốc repo `tiennt9939/QuanLyCayAPK`, branch `main`, để workflow hiện có chọn source ZIP và build. Không thay keystore, package name `com.quanlycay.apk` hoặc schema Firestore.
