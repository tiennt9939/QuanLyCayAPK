# ROLL CÂY CẢNH V26.2.85 — Sửa luồng gộp cây theo Order ID

## Khi một đơn TikTok bị tách ra nhiều trang

PDF `TikTokSeller_1792418463567.pdf` có Order ID `586670402637104154` trên trang 10–11. Parser đã ghép hai trang theo đúng Order ID thành một hàng đợi gồm 3 dòng sản phẩm. Đơn đó tương ứng:

- Ổi Lê Siêu Trái: 1 cây, size C9 đã được Admin xác nhận cho đơn này.
- Quỳnh Anh: 2 cây C9.
- Nguyệt quế Thái: 2 cây C7 (nhãn ghi `2 chậu C7 cao 15–20cm`).

Qty dòng bán vẫn là 1 + 1 + 1 = 3. Tổng cây thực tế là 1 + 2 + 2 = 5.

## Vì sao ảnh trước không lưu được

Ảnh cho thấy màn hình **đối chiếu sản phẩm dùng chung**, không phải màn hình thành phần cây riêng theo Order ID. Nó đang dùng nhãn Ổi Lê `C9–C10` làm khóa quy tắc và cố nhét thêm Quỳnh Anh, Vàng Bạc vào chung một quy tắc. Kiểm tra kích thước C9/C10 vì thế đã từ chối lưu — và đó là điều cần giữ để không học sai quy tắc chung. Dòng thứ ba trong ảnh cũng đang chọn Vàng Bạc C7, trong khi thành phần đúng mà người dùng nêu là Nguyệt quế C7.

Một lỗi UI bổ sung làm tình huống này khó thoát ra: dữ liệu cũ có thể mang trạng thái `needs_review` sau khi parser đã đọc đúng Order ID và đủ ba dòng; bộ lọc trước đây ẩn nút chỉnh thành phần riêng đơn đối với mọi trạng thái review. V26.2.85 mở nút Admin riêng đơn cho các hàng có Order ID, tracking và nhiều dòng sản phẩm đầy đủ, kể cả khi cần xem lại Qty/mapping; vẫn chặn mã vận đơn trùng, thiếu Order ID/tracking, đơn đã gắn hoặc đã tồn tại trên Firestore.

## Luồng đúng để xử lý đơn này

1. Trong thẻ Ổi Lê, chọn **GỘP CÂY RIÊNG ORDER ID ...** hoặc trong hàng đợi PDF chọn **GỘP CÂY THEO ORDER ID RIÊNG ĐƠN NÀY**.
2. Không thêm Quỳnh Anh hay Nguyệt quế vào quy tắc dùng chung của Ổi Lê. Nếu đã thêm nhầm thì dùng nút **SỬA QUY TẮC CHUNG VỀ 1 LOẠI CÂY** để bỏ các dòng ngoài sản phẩm đó.
3. Trong màn hình riêng đơn, chọn đúng dòng danh mục/size và nhập số cây cuối cùng của cả đơn: **Ổi Lê C9 × 1, Quỳnh Anh C9 × 2, Nguyệt quế Thái C7 × 2**. Số nhập là tổng thực tế cả đơn sau Qty PDF; không nhân Qty lần nữa.
4. Nhập lý do xác nhận tối thiểu 6 ký tự, đánh dấu xác nhận toàn bộ thành phần rồi lưu. Override chỉ gắn với cặp Order ID + tracking này, không dạy app rằng mọi nhãn Ổi Lê đều chứa ba loại cây.
5. Nếu muốn dạy quy tắc dùng chung cho Ổi Lê về sau, hãy mở riêng thẻ Ổi Lê và chỉ giữ một dòng Ổi Lê có size mà Admin đã xác nhận. Tên ghi dải C9–C10 không cho phép tự động đoán size.

## Thay đổi kỹ thuật

- Giữ status parser (`ready` / `needs_review`) khi đưa bản ghi vào hàng đợi; không ghi đè bằng trạng thái staging `daily_import`.
- Các hàng multi-product có cảnh báo review không mất nút gộp riêng đơn nếu identity/deduplication còn an toàn.
- Khi Admin lưu thành phần đầy đủ sau khi xác nhận và ghi lý do, các cảnh báo mapping/Qty có thể được giải quyết cho đúng đơn đó; các lỗi identity như mã vận đơn trùng hoặc thiếu Order ID/tracking vẫn bị chặn.
- Bộ nhận diện vẫn gộp trang cùng Order ID trước khi đối chiếu `Qty Total`; SKU vẫn có ưu tiên lấy số cây trước Product Name.

## Phạm vi xác minh

Đã chạy 76 script kiểm thử JavaScript, `tools/preflight.py`, và parser trên PDF thật trang 10–11. Đây là xác minh source/parser. Chưa build APK, chưa kiểm thử trên điện thoại, Firebase hay Cloud rules thực tế.
