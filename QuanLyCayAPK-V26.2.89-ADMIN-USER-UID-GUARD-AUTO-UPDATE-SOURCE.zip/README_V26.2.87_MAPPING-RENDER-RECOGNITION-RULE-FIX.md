# ROLL CÂY CẢNH V26.2.87 — Khôi phục Đối chiếu cây và áp dụng quy tắc Admin

## Mục tiêu
- Khắc phục màn “Đối chiếu cây” có số lượng trên bộ đếm nhưng danh sách trắng.
- Khắc phục lỗi quản lý/quy tắc Admin bị báo `orderRows is not defined` như thể đồng bộ Cloud thất bại.
- Đảm bảo quy tắc Admin đã lưu được chạy lại trên nhãn PDF đã nhập.
- Tuân thủ nguồn đếm số cây đã chốt: SKU → Seller SKU → Product Name dự phòng.

## Thay đổi
1. `renderTikTokProductMappings()` nhận `orderRows` trong destructuring từ `tiktokUniqueProducts()`, trước khi gọi `tiktokRelatedMultiProductOrders`. Điều này ngăn `ReferenceError` khiến cả danh sách không render.
2. Lưu quy tắc Cloud được tách khỏi bước render/refresh UI. Lỗi render sau khi lưu không còn giả dạng lỗi Cloud; trạng thái Cloud được xóa khi ghi thành công.
3. Sau khi lưu một quy tắc Admin, app chạy lại `autoMapTikTokProductMappings()` và làm mới phần đối chiếu, hàng đợi, bảng phân công.
4. Ghép alias cho phép từ khóa có các từ mô tả xen giữa (giữ đúng thứ tự token, tối đa 2 từ xen giữa cho alias từ 4 token trở lên); cụm ngắn vẫn cần khớp nguyên cụm. Tiêu đề quy tắc Admin cũng được dùng làm cụm nhận diện bổ sung cho tương thích quy tắc cũ.
5. Nếu quy tắc hiện có là ánh xạ một dòng và SKU ghi rõ số combo khác với số đã lưu, giữ dòng danh mục đã chọn nhưng dùng số cây theo SKU. Không tự phân bổ lại số lượng cho quy tắc nhiều dòng; trường hợp đó vẫn cần Admin kiểm tra. Nếu SKU và Seller SKU cùng ghi số khác nhau, vẫn dừng để Admin xác minh. Kiểm tra size vẫn chạy riêng.

## Kiểm thử
- 78 file test `tools/*_test.js`: tất cả đạt.
- `tools/preflight.py`: đạt.
- Cú pháp 4 khối JavaScript nhúng trong `index.html`: đạt.
- Regression cụ thể cho `orderRows` trong mapping renderer: đạt.
- Regression cho quy tắc cũ Combo 2 Cẩm tú mai C9 nhưng SKU Combo 4: khi rule đã chọn dòng C9, số lượng được cập nhật thành 4 cây/đơn vị theo SKU.

## Phạm vi xác minh và giới hạn
Đây là kiểm thử source/code. Chưa build APK ở môi trường này; chưa xác minh chạy thực tế trên điện thoại, Firebase/Firestore, Google Drive, updater hoặc chữ ký APK. Sau khi GitHub Actions build thành công, cần kiểm tra tab Đối chiếu cây và phần Quy tắc Admin trong APK mới. Không gỡ ứng dụng hiện tại và không thay khóa ký.
