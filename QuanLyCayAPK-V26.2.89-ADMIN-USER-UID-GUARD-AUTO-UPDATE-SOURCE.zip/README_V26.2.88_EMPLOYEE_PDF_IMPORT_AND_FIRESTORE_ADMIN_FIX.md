# V26.2.88 — Nhập PDF riêng cho nhân viên và khắc phục tài khoản Admin

## Giữ nguyên luồng import chung

Nút **NHẬP PDF NHÃN ĐƠN CHUNG** vẫn gọi `startDailyShipmentPdfImport()` và dùng cùng bộ đọc PDF, parser, mapping và hàng đợi hiện tại. Luồng mới là nút riêng **NHẬP PDF CHO NHÂN VIÊN**; nó không thay thế cũng không đổi chế độ của nút chung.

## Luồng nhập riêng

1. Admin mở **Theo ngày → Vận chuyển → NHẬP PDF CHO NHÂN VIÊN**.
2. Chọn tài khoản có role Nhân viên đóng hàng (`packer`), đang hoạt động và đã liên kết với nhân viên. Sau đó chọn PDF.
3. App vẫn parse và đối chiếu cây theo luồng hiện có; nhãn đủ dữ liệu được đánh dấu bằng `requestedAssigneeUid`, tên và mã nhân viên trong `dailyShipmentOrders`.
4. Mở **Đối chiếu cây** để xử lý nhãn cần xem xét. Sau đó mở **Chia việc**: nhóm nhãn riêng cho nhân viên sẽ xuất hiện; nút giao chỉ cho phép các đơn chưa ghi nhận, chưa giao và đã đối chiếu đầy đủ.
5. Ý định giao chỉ bị xóa trong bản ghi sau khi giao việc đã được Firebase xác nhận. Đơn đã giao, đã ghi, có xung đột hoặc thuộc nhân viên khác không bị tự chuyển.

Không tạo `packingOrder` mới, không ghi tiền công, không trừ tồn kho ngay khi nhập PDF. Những tác vụ đó vẫn chỉ xảy ra trong luồng hoàn tất đã có.

## Sửa mục Tài khoản & phân quyền

- Lỗi danh sách user hiện nêu rõ permission/network và có nút thử tải lại.
- App đọc `/users` trước khi tạo Firebase Auth, vì vậy lỗi `permission-denied` ở bước này sẽ dừng trước khi tạo account.
- Nếu Firebase Auth đã tạo account nhưng việc ghi profile `/users/{uid}` thất bại, app cố xóa account mới tạo. Nếu Firebase từ chối cả thao tác cleanup thì thông báo sẽ nói rõ khả năng còn tài khoản Auth chưa có hồ sơ để Admin kiểm tra trong Firebase Console.
- `firestore.rules` chuẩn hóa role Admin không phân biệt hoa/thường; quyền `list` trên `/users` vẫn chỉ dành cho Admin, còn nhân viên chỉ được đọc hồ sơ của chính mình.

### Bắt buộc publish Firestore Rules thủ công

1. Mở Firebase Console đúng project mà app đang dùng → Firestore Database → Rules.
2. Sao lưu Rules đang chạy trước khi thay đổi.
3. So sánh với `firestore.rules` trong source ZIP này và hợp nhất nếu project có rule tùy chỉnh riêng.
4. Publish Rules. Việc tải ZIP hoặc build APK **không tự đẩy Rules lên Firebase**.
5. Đăng xuất/đăng nhập Admin rồi thử tải danh sách user; sau đó mới thử cấp một tài khoản nhân viên.

Không mở `allow read: if signedIn()` cho toàn bộ `/users` để chữa lỗi. Điều đó sẽ làm lộ danh sách email/nhân viên cho tài khoản thường.

## Bảo toàn dữ liệu

Không thay đổi schema Firestore, công thức tiền công, snapshot đơn giá, tồn kho, barcode, ảnh Drive hoặc luồng Đơn ngoài. Phiên bản app: `26.2.88`, `versionCode 140`, package `com.quanlycay.apk`.

## Giới hạn xác minh

Kiểm thử source và preflight không xác nhận Rules đang publish trong Firebase project, không chứng minh APK đã cài chạy thành công trên điện thoại. Cần build CI và kiểm tra thực tế với project Firebase sau khi publish Rules.
