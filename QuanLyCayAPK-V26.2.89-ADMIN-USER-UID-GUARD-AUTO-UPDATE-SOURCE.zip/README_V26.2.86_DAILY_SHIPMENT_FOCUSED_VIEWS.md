# ROLL CÂY CẢNH V26.2.86 — Tách khu vực vận chuyển và khôi phục công cụ Admin

## Vấn đề được xử lý

Trong source V26.2.85, hàm `renderTikTokLabelImport()` tìm `#tiktokPdfImportPanel` và trả về ngay nếu phần tử này không tồn tại. Trong giao diện rút gọn đang hoạt động, vùng chứa `tiktokPdfImportStatus`, `tiktokProductMappingList` và `tiktokLabelQueue` không được khai báo tại màn hình vận chuyển trong ngày. Vì vậy phần đối chiếu cây và luồng truy cập tới quy tắc nhận diện bị mất khỏi giao diện chính, dù các hàm parser/quy tắc vẫn còn trong source.

Danh sách nhãn PDF cũng đang được vẽ ngay dưới các công cụ khác trong một khu vực kéo dài, nên Admin phải cuộn qua nhiều đơn mới tới được thao tác cần dùng.

## Thay đổi trong V26.2.86 (versionCode 138)

- Thêm điều hướng theo khu vực trên màn hình Vận chuyển trong ngày: **Đơn/ngày**, **Đối chiếu cây**, **Quy tắc Admin**, **Chia việc**, **Đơn ngoài**.
- Tách vùng đối chiếu cây vào `#tiktokPdfImportPanel` thật, chứa trạng thái nhập PDF, danh sách đối chiếu và hàng đợi nhãn. Khi vào khu vực này, ứng dụng dựng lại danh sách và tải quy tắc dùng chung từ Cloud.
- Đưa nút **Kiểm tra / Thêm / Sửa quy tắc nhận diện** vào khu vực Quy tắc Admin; bổ sung đường dẫn riêng tới Công cụ dữ liệu nâng cao và nút quay lại.
- Khi import PDF thành công, chuyển tới Đối chiếu cây mà không tự cuộn xuống bảng Chia việc.
- Khu vực đang chọn được giữ khi màn hình vận chuyển được render lại; các vùng không thuộc khu vực đó được ẩn để giảm chiều dài màn hình.
- Khi người dùng chuyển tab, ứng dụng đánh giá lại quyền Admin cho công cụ quy tắc, phân công và bảo trì; xử lý trường hợp quyền đăng nhập được khôi phục sau lần render đầu.
- Cập nhật số lượng hiển thị trên tab: nhãn trong ngày, mẫu sản phẩm cần đối chiếu/quy tắc và nhãn chưa xử lý.

## Không thay đổi

Không thay đổi schema Firestore, bảng giá, công thức tiền công, tồn kho, `assignedRate`, luồng quét barcode, ảnh Google Drive, chính sách chống quét trùng hay nghiệp vụ Đơn ngoài. Không xóa quy tắc học đã lưu. Công cụ xóa/reset vẫn bị khóa theo quyền Admin và vẫn yêu cầu xem trước/xác nhận.

## Hướng dẫn sử dụng

1. Build source ZIP qua workflow GitHub Actions và cài bản APK mới khi workflow thành công.
2. Mở **Theo ngày → Vận chuyển**. Năm khu vực hiện ngay phía dưới hai nút thao tác PDF/quét.
3. **Đối chiếu cây** hiển thị danh sách sản phẩm PDF cần chọn danh mục cây/size, xác nhận số lượng và dạy app. Đây là nơi sửa nhãn hiện tại.
4. **Quy tắc Admin** mở bộ quy tắc dùng chung trên Cloud để thêm, sửa, bật/tắt/xóa và thử quy tắc cho các nhãn về sau.
5. **Chia việc**, **Đơn ngoài** và **Công cụ dữ liệu nâng cao** có khu vực riêng; không cần kéo qua danh sách tất cả vận đơn để tìm các nút này.

Nếu quy tắc Cloud không tải được, giao diện phải hiển thị cảnh báo và không được báo rằng quy tắc đã đồng bộ thành công.

## Mức xác minh

- 77/77 script test hiện có: PASS.
- `tools/preflight.py`: PASS.
- Bốn khối JavaScript nội tuyến trong `index.html`: `node --check` PASS.
- Đây là xác minh source tĩnh/kiểm thử, chưa phải xác minh APK trên Android/Firebase/Google Drive. Source ZIP phải được build và kiểm tra trên điện thoại trước khi xem là đã xác nhận thực tế.
