# ROLL CÂY CẢNH V26.2.77 — Khôi phục tương thích quy tắc nhận diện cũ

- Android `versionName`: `26.2.77`
- Android `versionCode`: `129`
- Package: `com.quanlycay.apk`
- Nền ứng dụng: source V26.2.76, giữ luồng đơn ngoài TikTok, bảng phân công và quét hàng loạt Admin; bản này tập trung khôi phục tương thích nhận diện, không thay schema Firestore.

## Mục tiêu

Giữ nguyên khóa sản phẩm và quy tắc nhận diện kiểu V26.2.72, đồng thời tiếp tục hỗ trợ khóa mới dùng cho nhận diện bổ sung. Việc tra cứu không tự xóa hay ghi đè các quy tắc Cloud cũ.

## Những gì đã sửa

1. Khóa sản phẩm dùng lại cách làm sạch tên kiểu V26.2.72 để các mapping cũ của PDF không bị coi là mẫu hoàn toàn mới. Trước khi hiển thị trạng thái “Đã đối chiếu / Cần kiểm tra”, `migrateTikTokProductMapKeys()` duyệt toàn bộ hàng đợi và các dòng vận chuyển hằng ngày (kể cả đơn đã ghi, không chỉ ngày đang chọn), chuyển mapKey cũ về khóa ổn định và sao chép mapping sẵn có thay vì bỏ mapping cũ. Khóa cũ vẫn được giữ làm bản phục hồi.
2. Khi tìm quy tắc, parser thử khóa hiện tại trước rồi mới thử các dạng khóa V26.2.72 còn khả dĩ. Nếu nhiều quy tắc cũ khác nhau cùng khớp, app yêu cầu Admin đối chiếu thay vì tự chọn bừa. Loader Cloud bỏ qua các dấu xóa cũ đối với khóa chữ ký V2; nếu bản cục bộ còn quy tắc V2 mà Cloud thiếu, nó ghép lại và lưu trước khi tiếp tục.
3. Các mẫu hồi quy kiểm tra khóa V26.2.72 của Lài trà, Quỳnh Anh và Ruby vẫn ổn định; đồng thời kiểm tra Qty: Lài trà 2 cây/đơn vị × Qty 2 = 4 cây; Quỳnh Anh 4 cây/đơn vị × Qty 2 = 8 cây; Ruby “Combo 4 tặng 1” = 5 cây/đơn vị.
4. Sửa mapping hoặc xác nhận một quy tắc mới không còn tự xóa các quy tắc đã học trước đó. Quy tắc chính xác mới được bổ sung và ưu tiên khi tra cứu; quy tắc V26.2.72 tiếp tục là phương án dự phòng. Chỉ thao tác xóa quy tắc nhanh được Admin xác nhận rõ ràng mới xóa quy tắc đó.
5. Workflow build có trigger `push` khi ZIP source mang hậu tố `AUTO-UPDATE-SOURCE.zip` được thêm/cập nhật trên `main`, đồng thời giữ nút chạy thủ công.

## Kiểm tra trong source

- Preflight: PASS
- Kiểm thử JavaScript: 69/69 PASS, gồm chạy thật hàm di trú mapKey trên nhãn hàng đợi và dòng vận chuyển đã ghi; xác nhận mapping cũ được giữ và việc sửa/đối chiếu không tự tombstone quy tắc V2
- Cú pháp JavaScript: 6 khối script trong `index.html` và parser ngoài đều PASS
- Chưa build APK trong môi trường phát triển này vì không có Android SDK/Gradle wrapper cục bộ.

## Cách kích hoạt build tự động trên GitHub

Tên source ZIP chính xác:

`QuanLyCayAPK-V26.2.77-RESTORE-RECOGNITION-RULES-AUTO-UPDATE-SOURCE.zip`

Workflow phải được commit vào repository tại `.github/workflows/build-apk.yml` trước khi upload source ZIP mới. Một file YAML nằm bên trong ZIP không thể tự kích hoạt workflow của chính nó. Khi workflow đã có trên `main`, thêm ZIP ở trên vào root của repository sẽ kích hoạt build; workflow chọn ZIP có phiên bản cao nhất và chạy lại toàn bộ kiểm thử.

## Tự cập nhật trong ứng dụng

Workflow tạo APK và checksum SHA-256. Chỉ phát hành GitHub Release nếu `DEBUG_KEYSTORE_BASE64` và `EXPECTED_APK_CERT_SHA256` được thiết lập và fingerprint khớp chữ ký APK. Nếu thiếu fingerprint kỳ vọng, workflow chỉ tải Artifact, không phát hành Release; khi đó ứng dụng chưa thể tự phát hiện phiên bản mới qua GitHub Releases. Android vẫn yêu cầu người dùng xác nhận cài đặt APK.
