# ROLL CÂY CẢNH V26.2.68 — Assignment transaction result-scope fix

## Root cause in V26.2.67
`legacyOrderIdsToDelete` and `voidedClaims` were declared with `const` inside the Firestore transaction callback, but the callback referenced them before those declarations and the outer function attempted to return them after commit. This creates a JavaScript temporal-dead-zone `ReferenceError`; it is not caused merely by selecting another PDF date. Previously imported PDFs can trigger the assignment branch that exposes the bug.

## Fix
- Move both result arrays to the outer assignment function scope.
- Reset them at the start of each transaction attempt so Firestore retries cannot leak stale result values.
- Keep legacy-order retirement and claim recovery conditions unchanged; completed/financial/inventory/recorded evidence still aborts safely.
- Keep schema, wages, inventory formulas, catalog/prices and employee accounts unchanged.

## Verification
- Android version: 26.2.68, versionCode 120.
- Regression suite checks result arrays are declared before transaction use and not redeclared in the callback.
- No live Firebase write or APK build is claimed.
