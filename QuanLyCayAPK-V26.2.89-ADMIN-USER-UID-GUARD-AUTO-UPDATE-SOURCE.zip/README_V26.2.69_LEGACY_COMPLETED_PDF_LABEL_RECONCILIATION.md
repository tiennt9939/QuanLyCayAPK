# V26.2.69 — Đối soát nhãn PDF trùng đơn cũ đã có dấu vết

## Vấn đề
Khi Admin phân công nhãn PDF, cùng mã vận đơn có thể trỏ tới tài liệu `packingOrders/tiktok_<tracking>` từ luồng cũ. Nếu đơn cũ đã có dấu vết hoàn tất/tiền công/ảnh/tồn kho, không được xóa đơn hoặc ghi tiền công/tồn kho lần nữa. Tuy nhiên, dừng cả thao tác giao việc bằng một lỗi chung khiến nhãn bị hiểu nhầm là chưa phân công.

## Thay đổi
- Nếu tracking trùng, `Order ID` PDF khớp chính xác với `orderNo` cũ theo quy tắc `TT-` + 8 ký tự cuối của Order ID, và claim (nếu có) không trỏ sang đơn khác, hàng PDF được ghi trạng thái `legacy_linked` (Đã xử lý đơn cũ). Đơn lịch sử, khóa vận đơn, báo cáo, tiền công và tồn kho không bị sửa/xóa.
- Nếu dữ liệu liên kết cũ có bằng chứng nhưng Order ID/tracking không khớp chính xác, hàng được khóa thành `legacy_conflict` để Admin đối soát; không tự đoán và không xóa lịch sử.
- Nếu đã có báo cáo/quét ghi nhận, hàng được khóa ở trạng thái đã ghi; không phân công hoặc ghi nhận lần hai.
- Hàng được đối soát/đã ghi bị loại khỏi luồng quét nhân viên. Bảng giao việc có bộ lọc và huy hiệu riêng; không còn hiện như “Chưa phân công”.
- Giao nhóm có thể bỏ qua các nhãn đã đối soát an toàn và giao các nhãn còn lại. Kết quả hiển thị rõ số đơn đã giao, đã liên kết đơn cũ và cần đối soát.
- Không thay đổi Firestore schema, công thức tiền công, tồn kho, bảng giá, tài khoản nhân viên hoặc ảnh Drive vật lý. Chỉ sử dụng metadata trong document hàng đợi hiện có.

## Kiểm thử
- Test hồi quy `v2669_legacy_completed_pdf_label_reconciliation_test.js`: xác minh không xóa đơn cũ/khóa khi phân loại `legacy_linked`, yêu cầu Order ID khớp chính xác, phân biệt `legacy_conflict`, và chặn nhãn đã đối soát khỏi máy quét.
- Preflight: PASS.
- Toàn bộ `tools/*_test.js`: 64 PASS / 0 FAIL.
- 4 script JavaScript nội tuyến và `tiktok-label-import.js`: cú pháp PASS.
- ZIP integrity: kiểm tra sau khi đóng gói.

## Chưa thực hiện
- Chưa build APK Android.
- Chưa chạy thao tác trên Firebase thật.
