# ROLL CÂY CẢNH V26.2.78 — Sửa tạo đơn ngoài nhiều dòng cây

## Lỗi được xử lý

Một đơn ngoài có nhiều dòng như **2 cây Nguyệt quế C7 + 2 cây Quỳnh Anh C9 + 1 cây Ổi lê C11** có thể bị mất dòng hoặc phân giải nhầm khi các dòng danh mục dùng `catalogId`/`plantId` trùng nhau. Bộ chọn cũ dùng chính mã này làm giá trị `<select>` và hàm đọc đơn cũ ưu tiên mã ID trước khi kiểm tra tên và kích thước.

## Thay đổi

- Bộ chọn cây/size của đơn ngoài dùng token riêng theo từng dòng danh mục, không dựa vào `catalogId` có thể trùng.
- Khi bấm **THÊM CÂY / KÍCH THƯỚC**, dòng vừa thêm được giữ lại, bộ chọn được xóa để người dùng chọn dòng kế tiếp, và hiện thông báo số dòng/tổng cây đã thêm.
- Chỉ cộng số lượng vào dòng hiện có khi đúng cùng dòng danh mục, cùng tên và cùng kích thước; dòng cây khác không bị gộp nhầm.
- Khi tải đơn đã lưu, ưu tiên `plantIndex` nếu nó vẫn khớp tên và kích thước của dòng; nếu index thay đổi thì tìm bằng tổ hợp tên + kích thước, rồi mới dùng catalogId khi duy nhất.
- Không thay đổi công thức tiền công, quy tắc PDF TikTok, dữ liệu tài khoản, Google Drive hoặc luồng hoàn tất một ảnh của đơn ngoài.

## Kiểm tra

- `python3 tools/preflight.py`: PASS.
- 70 bài kiểm thử JavaScript: PASS.
- Bài test mới mô phỏng danh mục có `catalogId` bị trùng và xác nhận đơn giữ đủ 3 dòng: Nguyệt quế C7 × 2, Quỳnh Anh C9 × 2, Ổi lê C11 × 1; tổng 5 cây.
- Cú pháp JavaScript được kiểm tra riêng trước khi build.
- APK chưa được build trong môi trường này; cần chạy GitHub Actions từ source ZIP.

## Phiên bản

- `versionName`: 26.2.78
- `versionCode`: 130
- Package: `com.quanlycay.apk`
