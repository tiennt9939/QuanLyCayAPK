# ROLL CÂY CẢNH V26.2.81 — Ghép trang theo Order ID

- Android version: `26.2.81`, `versionCode 133`; package `com.quanlycay.apk`.
- Nền: giữ source V26.2.80 và các tính năng hiện có.

## Nguyên nhân lỗi trang 10–11

Native PDF reader luôn gửi `tableRows` dạng mảng, kể cả khi dựng ô theo tọa độ thất bại và mảng là `[]`. Parser trước đó vẫn ghi `best.products = structuredProducts`, làm mảng rỗng xóa dòng sản phẩm đọc được từ `visualText`/`text`. Trang 11 vì vậy chỉ còn Qty Total/Order ID; bước ghép không còn dòng Ổi Lê để thêm vào đơn.

## Sửa đổi

1. Chỉ ưu tiên `tableRows` khi đã tách được ít nhất một dòng hợp lệ; nếu mảng rỗng, giữ kết quả text parser.
2. Ghép các trang có cùng Order ID chính xác; khi Order ID vắng mới dùng tracking chính xác làm khóa dự phòng.
3. Chỉ coi tracking là xung đột khi cả hai trang đều có tracking và các mã khác nhau. Trang nối không có barcode không cản trở ghép theo Order ID.
4. Đồng bộ `refreshedByParserVersion` lên 81 để lần nhập lại có thể làm mới nhãn chưa hoàn tất bằng parser mới.

## Case hồi quy bắt buộc

PDF `TikTokSeller_1792418463567.pdf`, trang 10–11, Order ID `586670402637104154`: giữ ba dòng Quỳnh Anh Qty 1, Nguyệt quế C7 Qty 1 và Ổi Lê Qty 1 trong một đơn duy nhất. Tổng Qty bán = 3; số cây quy đổi theo nhãn dự kiến = 5. Size Ổi Lê C9–C10 vẫn cần Admin xác nhận; parser không tự chọn size.

## Giới hạn xác minh

Đây là sửa source. Chỉ được đánh dấu APK build/CI/Firebase/điện thoại hoàn tất sau khi có kết quả workflow và kiểm thử thực tế; không tạo keystore mới.
