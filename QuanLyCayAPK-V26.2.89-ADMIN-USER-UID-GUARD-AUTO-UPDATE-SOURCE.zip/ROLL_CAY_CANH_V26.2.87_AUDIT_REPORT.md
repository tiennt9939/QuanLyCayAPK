# ROLL CÂY CẢNH V26.2.87 — Báo cáo audit

## Vấn đề nhìn thấy trên điện thoại
Ảnh người dùng cho thấy:
- Bộ đếm “Đối chiếu cây” có 12 mẫu nhưng khu vực danh sách không hiển thị.
- Quản lý quy tắc Admin báo `orderRows is not defined`, và giao diện nói Cloud chưa xác nhận đồng bộ.
- Những quy tắc Admin đã lưu xuất hiện trong danh sách nhưng các nhãn tương tự chưa được tự ghép như mong đợi.

## Nguyên nhân xác định trong source V26.2.86
1. `renderTikTokProductMappings()` lấy danh sách qua `tiktokUniqueProducts().map(...)` nhưng chỉ destructure `{key,product}`. Ở bên trong lại gọi `tiktokRelatedMultiProductOrders({orderRows})`. Biến `orderRows` chưa được định nghĩa trong scope, gây `ReferenceError`. Hàm render dừng giữa chừng, nên số lượng badge còn hiển thị nhưng phần danh sách không được dựng.
2. Một số luồng cập nhật quy tắc gọi render và lưu Cloud trong cùng `try/catch`. Nếu lỗi render xảy ra, lỗi giao diện có thể được ghi vào trạng thái lỗi Cloud dù vấn đề thực sự là lỗi JavaScript trong giao diện.
3. Logic quick-rule matching trước đó dựa nhiều vào cụm alias nguyên văn. Nhãn sản phẩm thực tế có từ mô tả xen giữa tên cây/size; đồng thời một số quy tắc cũ có tiêu đề chính xác hơn alias đã lưu.
4. Số lượng đã được chốt theo SKU trước Seller SKU và Product Name dự phòng. Tuy nhiên, một quick rule cũ có thể còn số cây/unit cũ. Khi quy tắc chỉ trỏ một dòng cây, có thể giữ dòng catalog đã xác nhận và cập nhật số cây theo SKU; không thể tự chia lại tổng số lượng cho quy tắc nhiều dòng khi không biết số cây từng loại.

## Các thay đổi trong V26.2.87
- Thêm `orderRows` vào destructuring của renderer.
- Tách lỗi Cloud ra khỏi lỗi render; xóa cảnh báo Cloud cũ khi lưu/tải Cloud thành công.
- Sau khi xác nhận/lưu/tắt/bật/xóa quy tắc, làm mới nhận diện và các panel liên quan; render không còn được xem là bằng chứng ghi Cloud thất bại.
- Cho matching alias dùng cụm title của quy tắc và khớp token có từ mô tả xen giữa với giới hạn hẹp, trong khi vẫn giữ kiểm tra kích thước, xung đột rule và số cây.
- Dùng số lượng SKU rõ ràng cho mapping một dòng. Nếu SKU và Seller SKU cùng ghi số nhưng mâu thuẫn, yêu cầu Admin kiểm tra; nếu rule nhiều dòng không khớp tổng SKU, cũng không tự chia lại.

## Kiểm tra
- 78/78 file test JavaScript đạt.
- Preflight đạt.
- 4/4 khối JavaScript inline trong `index.html` qua `node --check`.
- `tiktok_mapping_render_regression_test.js` đạt: card sản phẩm render và hiển thị hành động riêng Order ID.
- `tiktok_quick_recognition_rules_test.js` đạt: alias có từ xen giữa, Cẩm tú mai C6/C7, quy tắc title C11, và SKU Combo 4 ghi đè số 2 trong Product Name.
- `tiktok_recognition_cloud_persistence_test.js` và `tiktok_admin_multi_plant_and_count_exception_test.js` đạt.
- `tools/preflight.py` xác nhận versionName `26.2.87`, versionCode `139`.

## Chưa xác minh
- Không chạy APK trực tiếp trên điện thoại trong phiên này.
- Không xác minh thao tác Firestore/Cloud thực tế hoặc Google Drive thực tế; các bài test source chỉ kiểm tra luồng và cấu trúc mã.
- Không xác minh APK certificate hoặc GitHub Actions run sau khi upload ZIP.

## Giới hạn an toàn
Không đổi Firestore schema, công thức tiền công, tồn kho, giá, `assignedRate`, barcode, ảnh Drive, anti-duplicate scan hay logic Đơn ngoài. Không tự chọn size khi nhãn ghi dải như C9–C10. Không thay khóa ký APK.
