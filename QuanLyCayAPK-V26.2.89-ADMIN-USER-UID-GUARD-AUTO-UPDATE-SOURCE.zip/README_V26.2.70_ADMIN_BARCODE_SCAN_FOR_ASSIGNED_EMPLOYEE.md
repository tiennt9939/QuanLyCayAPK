# ROLL CÂY CẢNH V26.2.70 — Admin quét mã thay nhân viên

## Mục tiêu
Cho phép Admin quét mã vận đơn và chụp ảnh kiện hàng thay nhân viên đã được giao đơn khi nhân viên cần đóng hàng gấp. Lượt hoàn tất và tiền công vẫn ghi nhận cho nhân viên được giao; hệ thống lưu UID Admin riêng để truy vết thao tác.

## Cách sử dụng
1. Đăng nhập bằng tài khoản Admin và mở **Chia việc / bảng đơn theo nhân viên**.
2. Mở nhóm nhân viên đã được giao đơn; tìm đơn TikTok đã nhập PDF chưa hoàn tất.
3. Bấm **ADMIN QUÉT THAY · GHI CÔNG [tên nhân viên]** trên đúng đơn.
4. Quét mã vận đơn và chụp ảnh kiện hàng ngay trong màn hình máy quét. App tự kiểm tra mã, tải ảnh lên Google Drive và hoàn tất mà không cần bước xác nhận thứ hai.
5. Đợi thông báo hoàn tất trước khi chuyển sang đơn kế tiếp.

## Kiểm soát an toàn
- Chỉ Admin mới vào được luồng quét thay.
- Luồng này chỉ bật cho đơn TikTok nhập PDF đã được giao riêng cho nhân viên; đơn chưa giao hoặc đơn chung cũ không được nhận thay.
- Mã quét phải khớp chính xác cả mã vận đơn và ID đơn đã chọn trên Firebase.
- Trước khi ghi hoàn tất, giao dịch Firestore kiểm tra lại đơn vẫn giao cho đúng UID nhân viên, vẫn chưa hoàn tất, và mã vận đơn chưa bị claim bởi đơn khác.
- Dữ liệu ghi nhận gồm `completedBy` = UID nhân viên được giao, `completionRecordedBy` = UID Admin và `completionMethod` = `admin_barcode_scan_delegate`. Điều này giữ tiền công cho nhân viên và lưu dấu người thao tác.
- Kiểm tra danh mục cây/kích thước, ảnh bằng chứng và tải ảnh Drive vẫn là điều kiện bắt buộc.

## Phiên bản
- Android `versionName`: `26.2.70`
- Android `versionCode`: `122`
- Source kế thừa từ V26.2.69, không khởi tạo lại dự án; giữ nguyên các công thức tiền công, quy tắc kho và schema Firestore hiện có.
- Phần thiết kế nhập/đối soát nhãn vận chuyển PDF riêng được tạm gác theo yêu cầu; thay đổi lần này chỉ thêm thao tác quét thay trên đơn TikTok đã được phân công.

## Kiểm thử
Bộ kiểm thử tĩnh `tools/preflight.py`, toàn bộ `tools/*_test.js`, và kiểm tra cú pháp JavaScript inline được chạy trước khi đóng gói source. Đây là báo cáo kiểm thử source; cần build APK bằng GitHub Actions và thử một đơn test thực tế trước khi dùng ca đóng hàng thật.
