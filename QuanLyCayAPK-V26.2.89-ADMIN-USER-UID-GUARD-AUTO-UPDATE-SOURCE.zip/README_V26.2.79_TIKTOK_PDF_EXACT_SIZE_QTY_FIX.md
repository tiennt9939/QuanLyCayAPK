# ROLL CÂY CẢNH V26.2.79 — TikTok PDF exact-size and Qty fix

## Why this patch exists

Fixes the reported TikTok PDF regression without changing the outside-TikTok order workflow:

1. `Cẩm tú mai VIP C11` must not map to `Cẩm tú mai C9` because a saved/legacy mapping matched a shortened display name.
2. Explicit size validation now includes `rawProductName` from the original PDF cell, not only the cleaned display name, SKU and Seller SKU.
3. Conflicting explicit sizes fail closed and require Admin review; they are not silently treated as compatible.
4. A saved machine mapping is refreshed when the parser's validated catalog row or per-unit count changes. Manually confirmed mappings are not silently overwritten; invalid ones remain visibly needing correction.
5. Qty is applied once: physical plant count is `plantsPerSoldUnit × PDF Qty`. `Mặc định` / no explicit bundle defaults to one plant per sold unit. Explicit `Combo N`, explicit `N cây`/`N chậu`, and known gift bundles keep their count. Example: Cẩm tú mai VIP C11, SKU Mặc định, Qty 2 = 2 plants; Combo 2, Qty 2 = 4 plants.
6. Existing V26.2.72 recognition signature compatibility and the outside-TikTok multi-item order feature remain included.

## Build metadata

- VersionName: `26.2.79`
- VersionCode: `131`
- Package: `com.quanlycay.apk`
- Source ZIP filename ends in `AUTO-UPDATE-SOURCE.zip`.

## Validation performed

- 71/71 JavaScript regression tests passed.
- `tools/preflight.py` passed.
- `node --check` passed for the standalone PDF parser and all inline JavaScript blocks in `index.html`.
- This is source-level validation only. It does not prove Firebase/Drive runtime behavior and is not an APK build.

## Important release note

Keep the existing app signing keystore and expected APK certificate SHA-256 unchanged. This environment has not built an APK or verified the generated APK certificate against the installed app. Do not uninstall the currently installed app to work around a signature mismatch.
