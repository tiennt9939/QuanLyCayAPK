# ROLL CÂY CẢNH V26.2.72 — Admin quét hàng loạt theo nhân viên

## Mục tiêu
Giảm thao tác khi nhân viên đang bận đóng hàng: thay vì phải bấm nút quét thay trên từng nhãn, Admin chọn một nhân viên rồi mở một phiên camera để quét liên tục toàn bộ nhãn đủ điều kiện đã giao cho người đó trong ngày đang chọn.

## Giao diện
Trong bảng **Chia việc theo nhóm cây**, phía trên danh sách nhãn có:
- **Admin quét thay cho nhân viên đã giao** — chọn nhân viên trong danh sách.
- **ADMIN QUÉT HÀNG LOẠT** — bấm một lần để chuẩn bị danh sách, xác nhận số lượng và mở camera.

Nút quét riêng lẻ trên mỗi nhãn đã được bỏ khỏi thẻ nhãn để tránh phải thao tác từng đơn. Các điều khiển giao/đổi người phụ trách vẫn hoạt động như trước.

## Cách chạy
1. Chọn đúng ngày làm việc.
2. Ở mục **Admin quét thay cho nhân viên đã giao**, chọn nhân viên cần hỗ trợ.
3. Bấm **ADMIN QUÉT HÀNG LOẠT**, kiểm tra số đơn hợp lệ và xác nhận.
4. Quét các mã vận đơn trong danh sách phiên. Máy ảnh tự chụp kiện hàng sau khi khớp mã; có thể ngưng phiên bằng nút dừng trên camera.

Phiên quét chỉ đưa vào danh sách các nhãn thuộc đúng UID nhân viên được chọn, đã được giao riêng, đã đối chiếu đủ cây và kích thước, chưa hoàn tất và chưa có claim hợp lệ. Nếu không đủ điều kiện hoặc không xác minh được trạng thái trên Firebase, ứng dụng không mở camera.

## An toàn ghi nhận
- Tiền công và dữ liệu báo cáo ghi cho nhân viên đã được giao, không phải UID Admin.
- Lưu riêng UID Admin thao tác, UID nhân viên hưởng công và `assignmentRevision` tại thời điểm quét.
- Ảnh từ camera vẫn qua hàng đợi bền vững rồi xử lý Drive/Firebase theo luồng hiện có.
- Mã ngoài danh sách phiên, mã đã quét trong phiên, mã đã ghi nhận hoặc claim trùng đều bị chặn.
- Giao diện dữ liệu PDF, danh mục cây, bảng giá, công thức tiền công, tồn kho và schema Firestore hiện có được giữ nguyên.

## Kiểm thử
- `python tools/preflight.py` — PASS.
- `node tools/v2672_admin_batch_scan_test.js` — PASS.
- Tất cả bài kiểm thử `tools/*_test.js`: **66/66 PASS**.
- Kiểm tra cú pháp từng inline JavaScript block: PASS.

Kiểm thử tự động không thay thế việc build APK trong GitHub Actions và thử nghiệm thực tế với tài khoản Firebase/Google Drive trên điện thoại.

## Phiên bản Android
- `versionName`: `26.2.72`
- `versionCode`: `124`
- Package: `com.quanlycay.apk`

Source ZIP không kèm APK đã build.
