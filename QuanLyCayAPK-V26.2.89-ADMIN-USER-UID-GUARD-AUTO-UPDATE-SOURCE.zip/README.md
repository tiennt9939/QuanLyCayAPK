# Bản ứng viên hiện tại — ROLL CÂY CẢNH V26.2.89 (versionCode 141)

**V26.2.89 — Bản vá lỗi danh sách tài khoản Admin:** xử lý an toàn trường hợp phiên đăng nhập thay đổi trong lúc tải danh sách `/users`; không còn dereference `s.user.uid` nếu session chưa sẵn sàng; bỏ qua bản ghi user không có UID hợp lệ; tách lỗi tải Firestore khỏi lỗi dựng giao diện để `Cannot read properties of undefined (reading 'uid')` không bị báo nhầm thành lỗi Rules.

**Luồng nhập PDF:** giữ nguyên luồng import chung và luồng nhập riêng theo nhân viên từ V26.2.88. Không thay đổi quy tắc nhận diện, phân công, tiền công, tồn kho hoặc schema Firestore.

**Firestore Rules:** file `firestore.rules` trong gói giữ nguyên như V26.2.88. Điều kiện `allow get, list` cho `/users` có cùng phạm vi thao tác đọc như `allow read` khi cả hai đều dùng cùng điều kiện Admin/tài khoản của chính mình. Nếu bạn đã publish Rules V26.2.88 lên đúng dự án, bản vá giao diện này không yêu cầu publish Rules lại. Nếu sau bản vá vẫn xuất hiện lỗi `permission-denied` thật, cần kiểm tra đúng Firebase project và quyền Admin; tuyệt đối không mở đọc `/users` cho mọi nhân viên.

**Chưa xác minh:** không build APK hoặc kết nối Firebase/Google Drive thật trong môi trường này. Hãy build qua GitHub Actions và thử lại trên điện thoại trước khi coi lỗi tài khoản đã được khắc phục hoàn toàn.

---
# Bản ứng viên hiện tại — ROLL CÂY CẢNH V26.2.87 (versionCode 139)

**V26.2.87 — Khôi phục đối chiếu cây và áp dụng quy tắc Admin:** sửa lỗi `orderRows is not defined` làm màn Đối chiếu cây trắng dù bộ đếm còn số lượng. Tách lỗi render khỏi kết quả ghi Cloud để không báo nhầm quy tắc chưa đồng bộ; sau khi lưu/tải quy tắc, app chạy lại nhận diện cho nhãn đã nhập. Alias Admin cho phép một số từ mô tả xen giữa mà vẫn giữ thứ tự từ khóa, và dùng tiêu đề quy tắc làm cụm nhận diện bổ sung. Nếu một quy tắc một dòng cũ có số cây khác số Combo ghi rõ trong SKU, app giữ dòng danh mục đã chọn nhưng cập nhật số cây theo SKU; nếu SKU và Seller SKU mâu thuẫn thì vẫn yêu cầu Admin kiểm tra. Kích thước C9/C11 và quy tắc combo nhiều loại cây vẫn có kiểm tra an toàn.

**V26.2.86 — Tách giao diện vận chuyển thành 5 khu vực thao tác độc lập:** các trang có cùng exact Order ID được ghép trước khi đối chiếu Qty Total; trang tiếp nối có tracking trích xuất lệch không tự tách thành đơn mới. Số cây mỗi đơn vị lấy từ SKU trước, Seller SKU kế tiếp, rồi mới dùng Product Name làm dự phòng; vì vậy Product Name “Combo 2 chậu cẩm tú mai C9” cùng SKU “Combo 4 chậu cẩm tú mai C9” được hiểu là 4 cây/đơn vị. Quy tắc chung chỉ dùng cho một sản phẩm hoặc combo thật; nhiều Product Name trong cùng Order ID phải dùng **GỘP CÂY RIÊNG ORDER ID**. Hàng đang cần kiểm tra vẫn có thể mở trình chỉnh thành phần riêng đơn khi ID và mã vận đơn đáng tin cậy. Không đổi schema Firestore, tiền công, tồn kho, phân công, quét barcode, ảnh Drive hay Đơn ngoài.

**Kiểm thử trọng điểm:** PDF `TikTokSeller_1792418463567.pdf`, Order ID `586670402637104154` (trang 10–11) phải thành một đơn có 3 dòng sản phẩm, Qty 1 + 1 + 1 = Qty Total 3; không đổi Qty dòng Ổi Lê thành 3. Nếu chỉ có một sản phẩm trong một trang và Qty Total mâu thuẫn, chỉ điều chỉnh sau khi parser xác nhận không có trang/dòng khác cùng Order ID.
**V26.2.81 — Ghép trang tiếp nối theo Order ID:** If Android returns `tableRows: []` due to coordinate-cell extraction failure, parser retains a valid product row from PDF text. Pages with the same Order ID are merged before Qty Total reconciliation; a missing tracking number on a continuation page is not treated as an order conflict. Retains all V26.2.80 recognition fixes; no change to Firestore schema, payroll formulas, stock or outside-TikTok workflow.

**Source verification V26.2.87:** xem `ROLL_CAY_CANH_V26.2.87_VALIDATION_SUMMARY.txt` và `README_V26.2.87_MAPPING-RENDER-RECOGNITION-RULE-FIX.md`. PDF thật 11 trang có 3 dòng trên trang 10–11, Order ID `586670402637104154`: Quỳnh Anh ×2, Nguyệt quế Thái C7 ×2, Ổi Lê ×1; Qty 3, tổng 5 cây. Thành phần riêng đơn được khóa theo exact Order ID + tracking, yêu cầu Admin xác nhận danh sách đầy đủ/lý do, không nhân Qty lần nữa. Tên Ổi Lê ghi dải C9–C10 vẫn cần chọn size được Admin xác nhận. Đã thêm chuyển khu vực Đơn/ngày, Đối chiếu cây, Quy tắc Admin, Chia việc và Đơn ngoài; nhập PDF tự mở khu vực Đối chiếu cây; loại bỏ auto-scroll dài. Bộ kiểm thử mã nguồn sẽ được chạy lại trước khi đóng gói. APK chưa được xác minh trên điện thoại/Firebase.

**V26.2.78 – Sửa thêm nhiều cây vào đơn ngoài:** Đơn ngoài chọn từng dòng cây bằng chỉ số dòng danh mục riêng, không dùng catalogId có thể trùng; sửa đối chiếu plantIndex theo tên + kích thước để giữ đúng từng dòng.

**V26.2.77 – Khôi phục quy tắc nhận diện cũ:** Khôi phục nút Admin xác nhận đối chiếu và dạy app, nút quản lý quy tắc, sửa Qty theo đơn vị và bộ quy tắc height range; bổ sung thông báo nguyên nhân cụ thể khi không thể xác nhận. Vẫn giữ nguyên luồng đơn ngoài từ V26.2.75.

**Đơn ngoài TikTok:** Admin tạo đơn từ danh mục cây/kích thước, giao trực tiếp cho nhân viên, xem tiền công theo bảng đơn giá hiện có, cộng/trừ tiền công và ghi chú, rồi nhân viên chụp 1 ảnh để hoàn tất. Báo cáo và CSV có mục riêng “Đơn ngoài TikTok”. Source gốc lấy từ V26.2.72 đang vận hành; không thay schema hay luồng TikTok. Xem `README_V26.2.75_OUTSIDE_TIKTOK_ORDERS.md`.

---

# QuanLyCayAPK / ROLL CÂY CẢNH — V26.2.28

V26.2.28 sửa việc tách sai sản phẩm TikTok khi tên/SKU xuống dòng trong PDF. Nhãn `Combo 4 tặng 1` giữ thành một dòng sản phẩm; SKU được giữ nguyên và số cây mỗi đơn vị là 5, trong khi Qty PDF vẫn bằng 1 đơn vị bán. Parser ưu tiên cột Qty thật và không nhầm số `1` ở cuối SKU thành một đơn hàng thứ hai. Bản sửa không thay đổi tiền công, tồn kho hoặc schema Firestore. Nếu nhãn lỗi đã nằm trong hàng đợi tạm từ phiên bản cũ, import lại chính PDF sau khi nâng cấp sẽ cập nhật nhãn tạm chưa phân công; đơn đã liên kết/đã phân công không bị ghi đè.

# QuanLyCayAPK / ROLL CÂY CẢNH — V26.2.24

V26.2.23 sửa hàng đợi nhãn PDF cũ: khi mở mục PDF, ứng dụng đối chiếu nhãn tạm với toàn bộ đơn trên Firestore, bao gồm đơn đã hoàn tất những ngày trước. Nhãn trùng vận đơn với đơn đã có sẽ tự được gỡ khỏi danh sách tạm; đơn thật, lịch sử, tồn kho và tiền công không bị xóa. Tiếp tục giữ chỉ báo đỏ/vàng/xanh khi nhân viên hoàn tất đơn. Build version `26.2.23`, versionCode `75`.

Luồng một ảnh, lưu Google Drive trước khi ghi đơn, xác minh mã vận đơn TT, bảo vệ chống trùng vận đơn, tiền công, tồn kho, nhập PDF TikTok, Firestore schema và cập nhật ứng dụng được giữ nguyên từ V26.2.19.


V26.2.23 bổ sung đối chiếu mã vận đơn theo ID tài liệu `tiktok_<tracking>` đối với đơn TikTok cũ thiếu trường shipmentTrackingNo; các đơn đã hoàn tất vẫn được giữ nguyên.


Bổ sung thao tác Admin `DỌN NHÃN PDF TẠM ĐÃ XỬ LÝ` cho hàng đợi nhãn cũ không còn liên kết chắc chắn với đơn do thiếu metadata lịch sử. Thao tác chỉ xóa queue PDF cục bộ sau khi xác nhận; không xóa dữ liệu đơn/tiền công/kho trên Firebase. Khi Admin hoàn tất đơn, bản mới làm mới snapshot đơn và hàng đợi ngay lập tức để tự gỡ các nhãn có liên kết tracking/ID rõ ràng.


## V26.2.24 — Ghép PDF hôm nay vào hàng dư ĐD đã chốt hôm qua

Khi Admin nhập PDF TikTok Shop, ứng dụng thử ghép nhãn có đủ Order ID + mã vận đơn vào đơn ĐD đã hoàn tất nhưng đang `shipmentOcrPending=true`. Chỉ tự ghép khi danh mục cây, kích thước và tổng số lượng khớp chính xác, và mỗi nhãn/đơn ĐD đều có một cặp duy nhất. Nếu có nhiều ứng viên, Admin chọn thủ công trên dòng nhãn PDF.

Thao tác ghép chỉ bổ sung Order ID, mã vận đơn và metadata liên kết trên bản ghi ĐD đã tồn tại; không tạo đơn đóng hàng mới, không chạy lại quy trình hoàn tất, không thay đổi nhân viên, tiền công, trạng thái hoàn tất, cây/số lượng hay tồn kho. Claim mã vận đơn được ghi trong cùng giao dịch Firestore để chống trùng. Mã đơn TikTok được đưa vào báo cáo tìm kiếm vận đơn. Build version `26.2.24`, versionCode `76`.

## V26.2.71 — Admin quét thay ngay trên bảng chia nhãn PDF

Ở V26.2.70, nút quét thay nằm trong thẻ phân công đơn đóng hàng khác, không hiện trên bảng **Chia việc theo nhóm cây** đang dùng để giao nhãn PDF. V26.2.71 thêm nút **ADMIN QUÉT THAY · GHI CÔNG [tên nhân viên]** ngay tại nhãn đã giao; Firebase đối chiếu lại UID nhân viên, UID Admin, phiên phân công và claim mã vận đơn trước khi ghi. Tiền công vẫn theo nhân viên được giao; UID Admin được lưu riêng để kiểm tra lịch sử.

Hướng dẫn: `README_V26.2.71_ADMIN_SCAN_FROM_PDF_ASSIGNMENT_BOARD.md`. Build version `26.2.71`, versionCode `123`.
## V26.2.72 — Admin quét hàng loạt theo nhân viên

Bỏ thao tác quét thay từng nhãn. Trong bảng **Chia việc theo nhóm cây**, Admin chọn nhân viên tại mục **Admin quét thay cho nhân viên đã giao** rồi bấm **ADMIN QUÉT HÀNG LOẠT**. Ứng dụng chuẩn bị một phiên quét gồm các nhãn hợp lệ đã giao cho đúng UID nhân viên đó trong ngày đang chọn; đơn đã ghi, đã khóa hoặc cần kiểm tra cây sẽ bị bỏ qua. Máy quét nhận mã trong danh sách phiên và tự chụp ảnh, còn tiền công vẫn thuộc nhân viên được giao. Firebase giữ xác minh UID Admin, UID nhân viên, phiên phân công và claim chống trùng.

Hướng dẫn: `README_V26.2.72_ADMIN_BATCH_SCAN_BY_EMPLOYEE.md`. Build version `26.2.72`, versionCode `124`.
