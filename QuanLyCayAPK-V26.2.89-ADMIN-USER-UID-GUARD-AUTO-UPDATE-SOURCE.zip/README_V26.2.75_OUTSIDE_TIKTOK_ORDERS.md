# ROLL CÂY CẢNH — V26.2.75 · Đơn ngoài TikTok

## Nền tảng

Source này được lấy từ baseline **V26.2.72 (versionCode 124)** mà người dùng xác nhận đang vận hành, rồi nâng version lên **V26.2.75 (versionCode 127)** để Android có thể cài bản cập nhật. Không dựng lại ứng dụng; tiếp tục dùng Android WebView, Firebase Authentication, Firestore và Google Drive.

## Tính năng mới: Đơn ngoài TikTok

Trong **Theo ngày → Vận chuyển**, tài khoản Admin thấy thẻ **“Đơn ngoài TikTok · giao việc & tính công”**.

1. Chọn một nhân viên đóng hàng đã hoạt động.
2. Có thể nhập mã đơn ngoài, tên khách và ghi chú (không bắt buộc).
3. Chọn nhiều cây/quy cách từ danh mục hiện tại, nhập số lượng từng dòng; tổng một đơn giới hạn 1–100 cây.
4. Tiền công gốc dùng bảng đơn giá theo kích thước và logic tiền công hiện có của app. Nếu một quy cách chưa có đơn giá, app chặn giao đơn và yêu cầu Admin bổ sung đơn giá thay vì âm thầm ghi 0 đồng.
5. Trước khi giao có thể nhập điều chỉnh dương (cộng) hoặc âm (trừ) và lý do. Sau khi tạo đơn, Admin cũng có thể cộng/trừ thêm qua nút **± ĐIỀU CHỈNH TIỀN CÔNG**; tổng công không được âm.
6. Đơn được tạo dưới `orderType: 'ĐN'`, kèm metadata `sourceSystem: 'outside_tiktok'`, `outsideTikTok: true`, `orderChannel: 'outside_tiktok'`. Đơn hiển thị trong danh sách công việc nhân viên và có nhãn riêng để tra cứu.
7. Nhân viên dùng luồng hoàn tất ĐN hiện có: chụp **một ảnh**; app lưu ảnh lên Drive trước khi xác nhận hoàn tất trên Firebase. Đơn ngoài không yêu cầu OCR hoặc quét mã vận đơn TikTok.
8. Mục báo cáo Admin và file CSV có phần **“Đơn ngoài TikTok”**, thể hiện mã đơn, khách, nhân viên, từng cây/quy cách/số lượng, tình trạng, công gốc, điều chỉnh và tổng công. Phần riêng này chỉ tách chi tiết; tiền công hoàn tất vẫn nằm trong tổng báo cáo chung, không cộng hai lần.

## Bảo toàn luồng hiện có

- Dùng collection `packingOrders` và hàm `createPackingOrder` hiện có, không tạo collection tiền công thứ hai.
- Giữ nguyên danh mục, bảng giá tiền công, logic lương riêng hiện có, ảnh Drive và giao thức hoàn tất một ảnh của loại đơn ĐN.
- Luồng nhập PDF TikTok / quét mã TikTok giữ nguyên; đơn ngoài không cần nhập PDF.

## Kiểm tra

- `python3 tools/preflight.py`: PASS.
- Các bài kiểm thử JavaScript trong `tools/*_test.js`: **67/67 PASS** (66 kiểm thử hồi quy hiện hữu + 1 kiểm thử đơn ngoài TikTok).
- Cả 4 khối JavaScript nội tuyến trong `index.html`: cú pháp PASS.
- **Chưa build APK trong môi trường đóng gói này**: source có Gradle build workflow GitHub Actions nhưng container hiện không có Android SDK/Gradle wrapper. Cần chạy workflow build để tạo APK và kiểm tra thao tác thực tế trên Firebase/điện thoại.

## Build

Cập nhật source này vào repository `tiennt9939/QuanLyCayAPK` và chạy workflow **Build ROLL CAY CANH V26.2.75 — Outside TikTok Orders** trong GitHub Actions. Kiểm tra đúng versionName `26.2.75`, versionCode `127` trước khi phát hành APK.
