# Audit report — ROLL CÂY CẢNH V26.2.86

## Root cause observed in source V26.2.85

The active daily-shipment screen did not declare `tiktokPdfImportPanel`, while `renderTikTokLabelImport()` immediately returned if that element was absent. As a result, its expected mapping status/product-map/label-queue UI did not render in the simplified screen. Recognition code still existed, which made the feature appear to have disappeared rather than fail with an explicit error. At the same time, order cards and Admin actions occupied one long continuous layout, burying key actions down the page.

## Fix implemented in candidate V26.2.86

- Restore the actual `tiktokPdfImportPanel` DOM region with all three expected child IDs.
- Partition the daily-shipment page into 5 mutually exclusive focused views via `data-shipment-view` and `setDailyShipmentView()`.
- Add a visible top-level Admin Rules tab and Admin rule-manager entry point.
- Add a separate Admin maintenance subview with a return path to Admin Rules.
- Keep the PDF import and scan buttons at the top while preventing auto-scroll down to assignment after import.
- Re-evaluate Admin-only view and panel visibility on tab changes, including after authentication state becomes available.
- Update status counters and ensure they still render when the selected date has zero labels.
- Add `tools/daily_shipment_view_navigation_test.js` to guard the view controller, renderer-critical DOM IDs and import-navigation flow.

## Validation

- All 77 `tools/*_test.js` scripts passed.
- `python tools/preflight.py` passed.
- Four inline JavaScript blocks extracted from `index.html` passed `node --check`.
- Dedicated focused view navigation test passed.

## Change scope

Only layout/navigation, rendering lifecycle and source-validation metadata/documents were changed for this candidate. Payroll formulas, inventory, Firestore schema, barcode/scan flow, Drive photo storage, and outside-TikTok order logic were not intentionally changed.

## Not yet verified

No local Android APK build was possible because this environment does not provide the Android SDK or Gradle wrapper. GitHub Actions, release asset/signature, updater compatibility, actual Android UI, Firebase and Google Drive were not tested in this run. This artifact is a source candidate, not a phone-verified release.
