# V26.2.84 — Ghép trang theo Order ID và ưu tiên SKU

## Sửa lỗi ghép PDF
- Ghép theo đúng Order ID trước; không để mã tracking trích xuất lệch ở trang tiếp nối tạo thành đơn riêng.
- Lưu mã tracking khác được trích xuất như alias phục vụ audit, giữ mã tracking chính từ trang nhãn đầy đủ.
- Không thay Qty riêng của một dòng sản phẩm bằng Qty Total tại bước phân tích từng trang. Qty Total chỉ được đối chiếu sau khi đã ghép các trang cùng Order ID.
- Bản fixture từ `TikTokSeller_1792418463567.pdf`, trang 10–11, phải trả một đơn, ba dòng sản phẩm, tổng Qty bằng 3 và tổng cây dự kiến bằng 5.

## Số cây Combo
- Nguồn số lượng ưu tiên: SKU → Seller SKU → Product Name dự phòng.
- Product Name “Combo 2 chậu cẩm tú mai C9” là tên/tiêu đề sản phẩm; nếu SKU ghi “Combo 4 chậu cẩm tú mai C9” thì số cây mỗi đơn vị là 4.
- Nếu hai trường SKU đều ghi số lượng rõ ràng nhưng mâu thuẫn nhau, vẫn cần Admin kiểm tra.
- Qty PDF chỉ được nhân một lần; mọi ngoại lệ khác số lượng SKU cần Admin xác nhận và ghi lý do.

## Phạm vi
Không đổi schema Firestore, quy tắc kích thước C7/C9/C11, công thức tiền công, tồn kho, phân công, barcode, ảnh Drive hay tính năng Đơn ngoài.
