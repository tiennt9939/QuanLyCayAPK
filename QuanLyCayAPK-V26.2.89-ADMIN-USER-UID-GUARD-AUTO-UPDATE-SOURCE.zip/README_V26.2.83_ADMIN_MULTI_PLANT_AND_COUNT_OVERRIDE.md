# V26.2.83 — Admin multi-plant mapping and count exceptions

- Admin can map one combo/product rule to multiple plant/catalog rows and see the total plants per sold unit. Qty PDF is still multiplied once at order-item creation.
- Rule creation can start from the current PDF row and prefill Product Name aliases so the Admin does not have to reconstruct label context. SKU variants that may be incorrect are not added automatically as aliases.
- When Product Name explicitly names its combo quantity, it takes precedence over a conflicting SKU count. If the title does not state a count, legacy SKU/Seller SKU fallback continues to work (including Combo 4 tặng 1).
- Exceptional count differences require explicit Admin opt-in and a reason of at least 6 characters. Size validation remains independent; C9-C10 title ranges still require one selected size, and C11 cannot be coerced to C9.
- Existing V26.2.72 signature semantics are preserved for fallback lookup; no Firestore schema change, no change to payroll formulas, inventory logic, assignment, barcode, Drive photos, or Outside TikTok order flow.


## Chốt thành phần cây riêng cho một đơn

- Từ từng nhãn PDF đang chờ, Admin có thể mở **Gộp / chọn thêm cây riêng đơn này** và thêm nhiều dòng danh mục cây + size vào cùng Order ID.
- Đây là ngoại lệ cục bộ của hàng đợi trên thiết bị, gắn đồng thời với Order ID và mã vận đơn. Nó không ghi đè quy tắc nhận diện dùng chung và không áp dụng cho nhãn/đơn khác.
- Admin phải chọn danh sách đầy đủ và nhập lý do. Số ở mỗi dòng là **số cây cuối cùng của toàn đơn sau khi tính Qty PDF**; khi tạo đơn thực, ứng dụng không nhân Qty thêm lần nữa. Chỉ nhãn chưa được liên kết mới có thể chỉnh; không ghi đè đơn đã tồn tại trên Firestore.
- Khi Product Name và SKU mâu thuẫn về số combo, Product Name ưu tiên. Ví dụ `Combo 2 chậu cẩm tú mai C9` với SKU ghi nhầm `Combo 4` sẽ đọc là 2 cây/đơn vị; nếu Admin muốn xử lý trường hợp khác thường, cần chốt quy tắc dùng chung có lý do hoặc chốt riêng đơn.
