# QuanLyCayAPK V26.2.2 — Performance Optimized

## Mục tiêu
Tối ưu các đường xử lý có khả năng gây lag trên cả thiết bị quản trị và nhân viên, không thay đổi nghiệp vụ đang hoạt động.

## Thay đổi chính
- Ảnh bằng chứng lịch sử của đơn (`completionImage`, `completionImages`) và ảnh chứng minh trong lịch sử đóng cây (`proofImages`) được giữ dưới dạng tham chiếu Drive khi tải dữ liệu. Chỉ tải nội dung ảnh khi người dùng bấm xem ảnh. Ảnh của danh mục cây vẫn xử lý theo luồng hiện tại.
- Gộp các cập nhật `packingOrders` xảy ra sát nhau thành một lượt dựng lại giao diện.
- Hàng đợi di chuyển ảnh Base64 cũ sang Drive chạy tuần tự, có độ trễ; tránh khởi chạy nhiều lượt tải ảnh đồng thời khi listener lần đầu nhận toàn bộ đơn.
- Listener của nhân viên không tự khởi chạy chuyển ảnh Base64 cũ sang Drive mỗi khi ghi cache.
- Cache danh sách tài khoản trong 30 giây và làm mới cache khi có thao tác thay đổi người dùng.
- Giữ nguyên luồng phân công/hoàn tất đơn, quy tắc tiền công, tồn kho, quyền theo vai trò và cấu trúc collection/dữ liệu nghiệp vụ.

## Kiểm tra đã chạy trong môi trường làm việc
- `python3 tools/preflight.py`
- `node tools/admin_direct_completion_test.js`
- `node tools/daily_profit_test.js`
- `node tools/drive_image_persistence_test.js`
- `node tools/order_list_grouping_test.js`
- `node tools/shared_pool_orders_test.js`
- `node tools/packing_wage_rules_test.js`
- `node tools/performance_optimization_test.js`
- `node tools/retention_logic_test.js`
- `node tools/tiktok_label_import_test.js`
- `node tools/tiktok_panel_visibility_test.js`
- `node tools/tiktok_pdf_barcode_flow_test.js`
- `node tools/packer_assignment_ui_test.js`
- Kiểm tra cú pháp JavaScript cho 6 khối script inline.

Tất cả các bài kiểm tra trên đã đạt trong môi trường kiểm tra hiện tại.

## Những điều chưa được xác nhận
- Môi trường làm việc hiện tại không có Android SDK/Gradle, vì vậy chưa tạo APK tại đây.
- Chưa đo benchmark hoặc kiểm thử trực tiếp trên hai điện thoại thực tế; mức cải thiện thực tế cần được xác nhận sau khi cài bản build.
- Không có thao tác xóa hoặc sửa dữ liệu Firebase được thực hiện khi tạo bản source này.

## Phiên bản
- `versionName`: `26.2.2`
- `versionCode`: `54`
- Android package: `com.quanlycay.apk`
