# QuanLyCayAPK V26.1.9 — Giá bán sàn và lợi nhuận ngày

## Mốc phát triển

- Bản nền ổn định theo yêu cầu: **V26.1.8 — Shared Pool Orders**.
- Phiên bản hiện tại: **V26.1.9**, `versionCode = 51`.
- Giữ luồng đơn chung/đơn riêng, phân loại danh sách đơn, hoàn tất đơn, lưu ảnh Drive, đơn ĐN/TT/ĐD, quy tắc tiền công Cẩm tú mai C7/C9, tồn kho và bảng lương.

## Trường giá mới

- Trường **Giá bán** hiện có (`sellPrice`) được giữ nguyên và tiếp tục dùng cho báo giá khách.
- Thêm **Giá bán sàn** (`floorPrice`) — chỉ Admin xem và sửa trong Điều khiển → Danh mục cây.
- `floorPrice` không được đưa vào báo giá PDF/CSV hoặc file xuất danh mục giá.
- Đơn được tạo mới lưu ảnh chụp giá bán sàn và giá nhập/giá vốn theo từng dòng cây nếu giá đã được cấu hình; vì vậy thay đổi giá danh mục sau này không làm đổi giá snapshot của đơn mới.

## Công thức lợi nhuận

Theo khoảng ngày đã chọn:

`Lợi nhuận = Doanh thu theo giá bán sàn − Giá vốn cây đã đóng − Tiền công − Chi phí nguyên liệu`

- Doanh thu theo giá sàn = tổng số cây đã ghi nhận đóng/đơn hoàn tất nhân với giá sàn theo từng dòng cây.
- Giá vốn cây đã đóng = tổng số cây đã ghi nhận đóng/đơn hoàn tất nhân với trường Giá nhập/giá vốn (`price`).
- Tiền công dùng logic tiền công hiện có của ghi nhận theo ngày và đơn hoàn tất, bao gồm quy tắc Cẩm tú mai C7/C9.
- Chi phí nguyên liệu do Admin nhập theo ngày phát sinh; khoản chi phí được lưu trong `materialExpensesByDate` và được trừ vào lợi nhuận đúng ngày.
- Nếu cây chưa có Giá bán sàn, ứng dụng cảnh báo số cây thiếu giá; không tự đoán doanh thu cho các cây đó. Lợi nhuận được ghi là **ước tính**.
- Đơn lịch sử chưa có snapshot giá dùng giá trong danh mục hiện tại làm phương án dự phòng; lợi nhuận lịch sử của các đơn cũ do đó có thể là ước tính lại, không phải giá lịch sử đã chốt.

## Vị trí xem

Vào tab **Báo cáo** bằng tài khoản Admin. Phần “Lợi nhuận shop theo Giá bán sàn” hiển thị doanh thu ước tính, giá vốn cây, tiền công, chi phí nguyên liệu và lợi nhuận cho khoảng ngày đã chọn. Bảng chi tiết từng ngày hiển thị lợi nhuận từng ngày. Tại cùng phần này, Admin chọn ngày, nhập tổng chi phí nguyên liệu/vật tư và ghi chú rồi bấm **Lưu chi phí nguyên liệu**.

Bảng lương và báo cáo hiện có vẫn tiếp tục hoạt động; người dùng không phải Admin không thấy bảng lợi nhuận/ô chi phí nguyên liệu.

## Kiểm tra tự động

Workflow chạy preflight và các test hiện có, cùng `tools/daily_profit_test.js`, kiểm tra:

- phép tính doanh thu, giá vốn, tiền công và chi phí nguyên liệu;
- cảnh báo khi thiếu Giá bán sàn;
- sử dụng snapshot giá của dòng đơn mới;
- trường giá sàn chỉ dành cho Admin;
- Giá bán sàn không xuất hiện trong hàm xuất báo giá PDF/CSV hoặc danh mục giá PDF/CSV.

## Build APK

Workflow: `.github/workflows/build-apk.yml`.

1. Đưa gói mã nguồn `QuanLyCayAPK-V26.1.9-DAILY-PROFIT-FLOOR-PRICE.zip` lên thư mục gốc repository (hoặc đưa các file mã nguồn vào thư mục gốc).
2. Đưa workflow bản mới vào `.github/workflows/build-apk.yml`.
3. Chạy GitHub Actions; chỉ dùng APK khi workflow báo `Success` và có artifact `QuanLyCayAPK-V26.1.9-DAILY-PROFIT-FLOOR-PRICE-debug`.

Không cần thay Firestore Rules hoặc composite index chỉ để thêm trường Giá bán sàn/chi phí nguyên liệu, vì cả hai là trường trong tài liệu dữ liệu dùng chung của ứng dụng, không phải truy vấn collection mới.
