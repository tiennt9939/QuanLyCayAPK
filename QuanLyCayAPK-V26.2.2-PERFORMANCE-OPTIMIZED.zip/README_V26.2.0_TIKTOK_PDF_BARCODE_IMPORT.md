# QuanLyCayAPK V26.2.0 — TikTok PDF label import + barcode lookup

## What changed

This release is based on the provided V26.1.9 source (`versionCode 51`) and increments the Android version to `V26.2.0` / `versionCode 52` for an installable upgrade.

- Admin can select a multi-page TikTok Shop shipping-label PDF on Android.
- Native PDF extraction preserves column spacing, then `tiktok-label-import.js` parses tracking number, Order ID, Product Name, SKU, Seller SKU and Qty.
- Parsing/import creates only a local staging queue. It does not write order, inventory, wage, report, or Firestore data by itself.
- Admin must explicitly map every distinct PDF product/SKU to one or more existing catalog rows. These mappings use stable catalog keys rather than array positions, so later catalog sync/reordering cannot silently point an import at a different plant. Combo conversion is an explicit `plants per sold unit` map; `Qty` from the label is not silently treated as physical plant count. If the product title declares a unit count (e.g. Combo 5), the mapping total must match that count before assignment.
- Admin selects a packing employee. Assignment calls the existing `createPackingOrder` workflow and snapshots the existing wage rate. Imported labels get deterministic `packingOrders` document IDs based on normalized tracking numbers, so repeat/import concurrency cannot create two orders for the same imported tracking number.
- For an imported TikTok PDF order, the employee scans the physical linear barcode and the app reads that one order directly from Firestore by deterministic ID; it checks the current assignment/status and requires the scanned tracking code to exactly match before opening completion. This avoids a full order-list refresh and image hydration on every scan. A legacy/non-imported barcode falls back to the existing assigned-order refresh path.
- Imported TikTok PDF orders still require two proof photos to upload successfully to the existing Drive flow. Only the redundant OCR of photo 2 is skipped for a PDF-import order whose barcode was verified. Completion still uses the existing `completePackingOrder` transaction and `shipmentTrackingClaims` duplicate guard.
- The barcode scanner is restricted to linear formats used on shipping labels (Code 128, Code 39, ITF, Codabar) so it should not choose the unrelated promotional QR code. The Android manifest declares `ocr,barcode_ui` for the relevant on-device modules. If a carrier's label uses another format, scanning returns an error rather than guessing.
- Label staging and product mappings are stored locally on the Admin device. They do not include recipient name, phone, or address. Assigned order information uses the existing Firestore `packingOrders` collection; there is no new collection, no added stored order field, and no destructive migration. Imported order identity is indicated by the deterministic document ID prefix and reuses the existing shipment tracking/carrier fields. `sourceSystem` is only a transient input to `createPackingOrder`; it is not persisted as an added Firestore field.

## Compatibility and safeguards

- Existing non-imported orders retain the original OCR validation behavior.
- Existing Firestore collection names, existing order fields, inventory logic, catalog, wage logic (including Cẩm tú mai C7/C9 thresholds), reports, payroll, Drive image storage, quotes, label printing, and retention logic are not intentionally changed.
- New imported orders use the existing `packingOrders` document shape and reuse `shipmentTrackingNo`, `shipmentCarrier`, `orderNo`, and `note`; the imported marker is inferred from the deterministic document ID rather than a stored schema field.
- The supplied `firestore.rules` and indexes are unchanged. Existing Rules must already be deployed and allow the ordinary assigned TT completion + `shipmentTrackingClaims` path. If the live project has different Rules, the app may reject completion; do not loosen Rules by guesswork.
- PDF import supports up to 200 pages per file and limits extracted text size to 750,000 characters to avoid UI/memory stalls. Scanned/image-only PDFs may not have a text layer; pages that cannot be parsed stay in `needs_review` and must not be assigned.
- Supported tracking formats currently mirror the app's existing rules: J&T Express (`862` + 9 digits), J&T Cargo (`530` + 9 digits), and GHN (`VNGH` + 8–12 digits or `GHVN` + alphanumeric suffix). Unknown formats require review.

## Validation performed in this workspace

- `python tools/preflight.py` — PASS.
- Every existing `tools/*_test.js` test — PASS.
- `node tools/tiktok_label_import_test.js` — PASS.
- `node tools/tiktok_pdf_barcode_flow_test.js` — PASS.
- JavaScript inline source parse (`node --check` on extracted inline script blocks) — PASS.
- The supplied 12-page `TikTokSeller.pdf` was independently checked with `pdftotext -layout`: 12/12 pages produced a unique tracking number, Order ID, and product row in the local parser test. The phone-side PDFBox extraction path itself has not been exercised on a built APK yet.

## Build status

The APK has **not** been built or installed in this workspace. This environment does not have the Android SDK / Gradle executable installed, so local source tests do not prove Android compilation. Upload this project ZIP and the updated `.github/workflows/build-apk.yml` to the repository, run GitHub Actions, and install only the artifact if the action ends successfully. Check that the artifact name is `QuanLyCayAPK-V26.2.0-TIKTOK-PDF-BARCODE-IMPORT-debug`.

## First-use test plan after GitHub Actions build

1. On Admin, import the supplied or current PDF; verify label count and carrier/tracking fields before assigning.
2. Map every distinct product entry. Check combos explicitly against the catalog and packing wage policy; do not make assumptions from text alone.
3. Assign one test order to one employee. Confirm it appears on that employee's phone after sync.
4. Scan the same physical label. Confirm mismatch scans are rejected and the matched order shows the expected plant lines/quantities.
5. Complete with two proof photos. Confirm both photos are visible in the existing gallery, and Firestore says `status=completed` with `shipmentOcrStatus=barcode_verified`.
6. Scan the same label again and try assigning the same label again. Both paths must refuse duplicate completion/assignment.
7. Compare employee pay, daily totals, inventory, report rows, Admin and employee order lists before/after. Only the single completed test order should affect existing calculations.
8. Verify an old non-imported TT order still requires existing OCR. This confirms backward compatibility.

Do not delete old data, clear Firestore, change Firestore Rules, or remove the manual assignment UI until real-device tests pass.
