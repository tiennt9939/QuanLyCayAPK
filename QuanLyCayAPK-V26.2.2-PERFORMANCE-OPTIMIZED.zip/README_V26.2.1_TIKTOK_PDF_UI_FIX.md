# QuanLyCayAPK V26.2.1 — TikTok PDF UI lifecycle fix

## Vì sao người dùng có thể thấy giao diện cũ?

V26.2.0 đã chứa module nhập PDF nhãn và nút quét mã, nhưng bảng Admin được ẩn khi ứng dụng chưa khôi phục xong tài khoản Firebase. Bản trước chỉ gọi render bảng lúc khởi động; `renderAll()` không cập nhật bảng khi người dùng đăng nhập sau đó. Vì vậy, trên một số phiên khởi động, bảng PDF có thể vẫn bị ẩn mặc dù đang dùng source mới. Ngoài ra, nếu chỉ cập nhật workflow mà không đưa source V26.2.x vào repository, GitHub Actions vẫn build source cũ.

## Sửa trong V26.2.1

- Tăng `versionName` lên `26.2.1` và `versionCode` lên `53` để APK mới có thể được nhận diện là bản cập nhật.
- Gọi cập nhật trạng thái bảng nhập PDF trong mỗi lần render giao diện; bảng chỉ hiện với tài khoản Admin đã đăng nhập.
- Làm mới danh sách nhân viên khi Admin đăng nhập lần đầu, sau đó dùng bộ đệm tối đa 30 giây để tránh gọi Firestore lặp không cần thiết.
- Cập nhật bảng khi Firebase xác nhận đăng nhập và khi đăng xuất.
- Giữ nguyên luồng nhập PDF, đối chiếu SKU/quy cách combo, phân công `packingOrders`, xác minh mã vạch, ảnh Drive và công thức tiền công/tồn kho hiện có.
- Bổ sung bài test tĩnh `tools/tiktok_panel_visibility_test.js` để chống hồi quy lỗi panel bị ẩn.

## Vị trí thấy tính năng mới

- **Admin:** đăng nhập Admin → Trang chủ → **Nhập PDF TikTok**; hoặc tab **Đóng hàng** → chế độ **Đóng hàng** → khu vực **Phân công / ghi nhận hoàn tất** → thẻ **TikTok Shop · Nhập PDF nhãn** → nút **CHỌN PDF NHÃN TIKTOK SHOP**.
- **Nhân viên:** đăng nhập tài khoản đóng hàng → màn hình **Đóng hàng** → nút **QUÉT MÃ VẬN ĐƠN · MỞ ĐƠN**.

Nếu không thấy các nhãn/nút trên thì gần như chắc chắn APK đang chạy source cũ, đăng nhập sai vai trò, hoặc bảng chưa được mở ở đúng màn hình. Kiểm tra `versionName` trong APK phải là `26.2.1`; thay workflow riêng không nâng cấp source.

## Kiểm thử và giới hạn

Phải chạy `python3 tools/preflight.py`, các bài test hiện có, `node tools/tiktok_panel_visibility_test.js`, và `node tools/tiktok_pdf_barcode_flow_test.js` trong CI. Môi trường tác giả không có Gradle/Android SDK để tự xác nhận biên dịch APK. Chưa được xem đây là bản kiểm chứng trên thiết bị thật cho tới khi GitHub Actions build thành công và thử nhập PDF/quét mã/chụp ảnh trên điện thoại.
