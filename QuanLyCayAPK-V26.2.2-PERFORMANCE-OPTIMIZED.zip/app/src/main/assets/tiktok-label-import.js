/* Offline TikTok Shop label parser. Stores only order/product identifiers, never recipient address/phone. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.TikTokLabelImport=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';
  function compact(value){return String(value??'').replace(/\s+/g,' ').trim()}
  function normalize(value){return String(value??'').toUpperCase().replace(/[^A-Z0-9]/g,'')}
  function keyForProduct(p){
    const raw=[p?.productName,p?.sku,p?.sellerSku].map(v=>compact(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()).join('|');
    let h=2166136261;
    for(let i=0;i<raw.length;i++){h^=raw.charCodeAt(i);h=Math.imul(h,16777619)}
    return 'ttp_'+(h>>>0).toString(36);
  }
  function expectedPlantsPerSoldUnit(product){
    const text=compact([product?.productName,product?.sku,product?.sellerSku].join(' '));
    const combo=text.match(/\bcombo\s*(?:x\s*)?(\d{1,3})\b/i);
    if(combo)return Number(combo[1])||0;
    const count=text.match(/\b(\d{1,3})\s*(?:cây|chậu)\b/i);
    return count?(Number(count[1])||0):0;
  }
  function extractTracking(text){
    const raw=String(text||'').toUpperCase();
    // Accept occasional spaces/hyphens inserted by PDF text extraction, then normalize the result.
    const patterns=[/\b862(?:[ \t-]?\d){9}\b/g,/\b530(?:[ \t-]?\d){9}\b/g,/\bV[ \t-]*N[ \t-]*G[ \t-]*H(?:[ \t-]?[A-Z0-9]){8,26}\b/g,/\bG[ \t-]*H[ \t-]*V[ \t-]*N(?:[ \t-]?[A-Z0-9]){4,26}\b/g];
    const matches=patterns.flatMap(pattern=>raw.match(pattern)||[]);
    return [...new Set(matches.map(normalize).filter(Boolean))];
  }
  function carrierFor(tracking){
    const t=normalize(tracking);
    if(/^VNGH\d{8,12}$/.test(t)||/^GHVN[A-Z0-9]{4,26}$/.test(t))return 'GHN';
    if(/^862\d{9}$/.test(t))return 'J&T Express';
    if(/^530\d{9}$/.test(t))return 'J&T Cargo';
    return '';
  }
  function parseProductRows(lines, headerIndex, totalIndex){
    const header=lines[headerIndex]||'';
    const skuStart=header.indexOf('SKU');
    const sellerStart=header.indexOf('Seller SKU');
    const qtyStart=header.lastIndexOf('Qty');
    if(skuStart<0||sellerStart<=skuStart||qtyStart<=sellerStart)return [];
    const startCandidates=[];
    for(let i=headerIndex+1;i<totalIndex;i++){
      const line=String(lines[i]||'').replace(/\r/g,'');
      if(!line.trim())continue;
      const qtyText=line.slice(qtyStart).trim();
      if(/^\d{1,3}$/.test(qtyText)&&line.slice(0,qtyStart).trim()){
        const qty=Number(qtyText);
        if(Number.isInteger(qty)&&qty>0&&qty<=1000)startCandidates.push({index:i,qty});
      }
    }
    const products=[];
    for(let n=0;n<startCandidates.length;n++){
      const start=startCandidates[n].index;
      const end=n+1<startCandidates.length?startCandidates[n+1].index:totalIndex;
      const col={name:[],sku:[],seller:[]};
      for(let i=start;i<end;i++){
        const line=String(lines[i]||'');
        if(!line.trim()||/Qty\s*Total\s*:/i.test(line))continue;
        const cells=[line.slice(0,skuStart),line.slice(skuStart,sellerStart),line.slice(sellerStart,qtyStart)];
        ['name','sku','seller'].forEach((field,j)=>{const cell=compact(cells[j]);if(cell)col[field].push(cell)});
      }
      const product={
        productName:compact(col.name.join(' ')),
        sku:compact(col.sku.join(' ')),
        sellerSku:compact(col.seller.join(' ')),
        qty:startCandidates[n].qty
      };
      if(!product.productName&&!product.sku&&!product.sellerSku)continue;
      product.mapKey=keyForProduct(product);
      products.push(product);
    }
    return products;
  }
  function parsePage(page){
    const text=String(page?.text??page??'');
    const pageNumber=Number(page?.page||page?.pageNumber||0)||0;
    const tracks=extractTracking(text);
    const orderIds=[...new Set([...text.matchAll(/\bOrder\s*ID\s*:[ \t]*((?:\d[ \t-]*){12,25})/gi)].map(m=>normalize(m[1])).filter(x=>/^\d{12,25}$/.test(x)))];
    const lines=text.split(/\r?\n/);
    const headerIndex=lines.findIndex(line=>/Product\s*Name/i.test(line)&&/Seller\s*SKU/i.test(line)&&/Qty/i.test(line));
    let totalIndex=lines.findIndex((line,i)=>i>(headerIndex<0?-1:headerIndex)&&/Qty\s*Total\s*:/i.test(line));
    if(totalIndex<0)totalIndex=lines.length;
    const products=headerIndex>=0?parseProductRows(lines,headerIndex,totalIndex):[];
    const reasons=[];
    if(tracks.length!==1)reasons.push(tracks.length?'Có nhiều mã vận đơn khác nhau trên một trang':'Không đọc được mã vận đơn hợp lệ');
    if(orderIds.length!==1)reasons.push(orderIds.length?'Có nhiều Order ID khác nhau trên một trang':'Không đọc được Order ID');
    if(!products.length)reasons.push('Không tách được dòng sản phẩm/SKU/Qty');
    return {
      page:pageNumber,
      trackingNo:tracks.length===1?tracks[0]:'',
      carrier:tracks.length===1?carrierFor(tracks[0]):'',
      orderId:orderIds.length===1?orderIds[0]:'',
      products,
      status:reasons.length?'needs_review':'ready',
      reviewReason:reasons.join('; ')
    };
  }
  function parsePages(pages){
    const rows=(Array.isArray(pages)?pages:[]).map(parsePage);
    const seen=new Map();
    rows.forEach(row=>{if(!row.trackingNo)return;seen.set(row.trackingNo,(seen.get(row.trackingNo)||0)+1)});
    rows.forEach(row=>{if(row.trackingNo&&(seen.get(row.trackingNo)||0)>1){row.status='needs_review';row.reviewReason=[row.reviewReason,'Mã vận đơn trùng trong cùng PDF'].filter(Boolean).join('; ')}});
    return rows;
  }
  return {compact,normalize,keyForProduct,expectedPlantsPerSoldUnit,extractTracking,carrierFor,parseProductRows,parsePage,parsePages};
});
