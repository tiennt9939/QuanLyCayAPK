# ROLL CÂY CẢNH V26.2.125 — Durable local state / quota recovery

**Nền source:** tiếp tục dự án Android WebView hiện có; không dựng lại ứng dụng.  
**Android versionName:** `26.2.125` · **versionCode:** `177` · **Package:** `com.quanlycay.apk`.

## Mục tiêu phát hành

Khắc phục lỗi lặp lại “Bộ nhớ cục bộ đầy” bằng cách chuyển bản dữ liệu nghiệp vụ chính khỏi WebView `localStorage` sang kho tệp riêng tư của Android. Giữ nguyên Firebase Auth, Firestore schema, phân quyền, danh mục cây, công thức tiền công, tồn kho, nhận diện PDF/TikTok và luồng Google Drive.

## Thay đổi trong V26.2.125

- **Kho lưu chính riêng tư của Android:** thêm `loadLocalAppState`, `saveLocalAppState` và `getLocalAppStateSavedAtMs` vào bridge hiện có. Bản dữ liệu chính không còn phụ thuộc giới hạn quota của WebView.
- **Hai slot luân phiên:** trạng thái mới được ghi vào slot không hoạt động; nội dung và SHA-256 được lưu trước khi đổi manifest. Bản trước vẫn tồn tại để phục hồi nếu thao tác bị ngắt giữa chừng.
- **Kiểm tra sau khi ghi:** file được fsync, đối chiếu SHA-256 và đọc xác minh trước khi Java trả kết quả thành công.
- **Tự phục hồi:** nếu manifest bị gián đoạn hoặc slot hiện hành không hợp lệ, ứng dụng tìm slot khác có checksum đúng, khôi phục manifest và dọn các file tạm sau khi đã có bản hợp lệ.
- **Di chuyển từ V123:** lần mở đầu đọc JSON `quanlycay` cũ, lưu sang kho Android và chỉ xóa bản lớn trong `localStorage` sau khi native storage xác nhận lưu thành công. Nếu ghi native thất bại, bản cũ được giữ nguyên.
- **Giữ hàng đợi:** với Android, dữ liệu đơn vận chuyển chính vẫn được lưu nguyên vẹn trong snapshot native; bản sao hàng đợi chỉ được bỏ sau khi snapshot mới đã xác nhận. Không xóa lịch sử đơn, tiền công, tồn kho hay ảnh để lấy dung lượng.
- **Chống ghi đè Cloud:** dấu `quanlycay_dirty` không còn tự động cho phép đẩy bản local cũ lên Cloud. Khi mốc lưu local đã xác minh không mới hơn document Cloud, app ưu tiên reconcile từ Cloud và chỉ xóa dấu dirty sau khi lưu bản hòa giải thành công.
- **Tương thích trình duyệt:** nếu ứng dụng chạy ngoài Android hoặc native storage không khả dụng, nhánh `localStorage` và cơ chế compaction cũ vẫn tồn tại làm dự phòng.

## Kiểm thử trong môi trường hiện tại

- `python3 tools/preflight.py`: PASS.
- `107/107` bài kiểm thử `tools/*_test.js`: PASS.
- Cú pháp JavaScript: 6 khối script nội tuyến và `tiktok-label-import.js`: PASS.
- Hợp đồng gói auto-update: PASS, tên source `ROLL-CAY-CANH-V26.2.125-AUTO-UPDATE-SOURCE.zip` khớp Gradle `26.2.125 / 176`.
- Kiểm thử mới `tools/durable_local_storage_bridge_test.js`: bao phủ native-first, di chuyển JSON cũ, bản sao queue được giữ khi chưa xác minh, xóa bản duplicate sau khi xác minh, fallback khi cả hai kho lỗi, và quy tắc không đẩy dirty local cũ đè Cloud mới.

## Giới hạn xác minh

Môi trường kiểm tra này không có Gradle/Android SDK (`ANDROID_HOME` không được cấu hình), nên **chưa build APK Android** và chưa chạy thử trên thiết bị thật. Chưa có phiên Firebase/Drive có quyền ghi để kiểm tra tải đơn và ảnh thực tế. Những xác minh trên là kiểm thử source/static/regression, không phải bằng chứng vận hành bảy ngày.

## Build và tự cập nhật

- ZIP có cấu trúc project trực tiếp ở thư mục gốc (`settings.gradle.kts`, `app/`, `tools/`, `.github/`), không lồng thêm thư mục dự án.
- Workflow `.github/workflows/build-apk.yml` tự chạy khi file `*AUTO-UPDATE-SOURCE.zip` được commit lên `main`.
- Workflow chỉ phát hành GitHub Release nếu `DEBUG_KEYSTORE_BASE64` và `EXPECTED_APK_CERT_SHA256` giữ đúng chứng thư ký hiện tại. Source không chứa khóa bí mật.
- Sau khi build thực tế, cần xác minh APK signature SHA-256/SHA-1 và thử quy trình nhập PDF → chia đơn → quét → ghi nhận → đồng bộ ảnh trước khi đưa vào vận hành.


## V26.2.125 — Firebase sync timeout protection
- Added explicit timeout boundaries to the shared Firestore read, PDF queue reads/writes, Drive-value preparation, and root document write. Failed/timeout sync leaves the local dirty marker set and shows a failure status rather than claiming success.
- Manual sync now has an outer 55-second UI guard and a duplicate-tap guard. It always releases the UI busy flag and displays that synchronization was not confirmed when timed out.
- Assignment flow still requires an explicit successful Firebase result before showing an assignment as confirmed; existing 25/30-second assignment-stage timeouts remain.
- This is source-level regression-tested; it does not by itself prove live Firebase/network health. APK build and live device test must still be run by GitHub Actions/device.
