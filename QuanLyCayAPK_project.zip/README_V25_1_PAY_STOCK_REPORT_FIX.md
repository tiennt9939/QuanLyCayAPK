# V25.1 — PAY + STOCK + REPORT SURGICAL FIX

Base: V25.1 PAY_ONLY source that already has the working Admin → packer receive → photo → complete flow.

Only the following were changed:
- Show the calculated labor pay on each packer order card.
- Treat completed assigned orders in `packingOrders` as the canonical completed records for labor/pay and stock calculations, with `packerRecords` as fallback.
- Record `completedDate` at completion time.
- Deduct completed assigned-order quantities from plant stock using the completion date.
- Include completed assigned orders in daily/report totals and CSV export.
- Preserve the existing admin manual packing path and all existing UI/permissions/Rules.

No Firebase Rules were changed.
No catalog/rates/inventory-entry/admin assignment UI was intentionally changed.
