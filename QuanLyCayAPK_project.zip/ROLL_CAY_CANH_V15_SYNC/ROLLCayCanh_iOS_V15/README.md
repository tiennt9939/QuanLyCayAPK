# ROLL CÂY CẢNH — iOS V1

Bản iOS đầu tiên giữ giao diện/nghiệp vụ của bản Android V14 và chạy phần web app trong WKWebView.

## Có sẵn
- Nhập kho / Đóng hàng tách riêng
- Tiền công + điều chỉnh cộng/trừ
- Theo dõi cây, tìm kiếm/lọc
- Ảnh cây: camera / thư viện và phóng to
- Báo cáo theo khoảng ngày, gồm chi tiết từng ngày
- Xuất CSV: trên iOS sẽ mở màn hình Files để chọn nơi lưu
- Sao lưu/nhập JSON

## Build
Mở `ROLLCayCanh.xcodeproj` bằng Xcode trên macOS, chọn iPhone thật hoặc Simulator rồi Build/Run.
Để cài lên iPhone thật hoặc phát hành App Store cần Apple Developer signing.
