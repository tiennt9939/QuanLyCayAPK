import SwiftUI
import WebKit
import UniformTypeIdentifiers
import UIKit

struct ContentView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let controller = WKUserContentController()
        controller.add(context.coordinator, name: "saveFile")
        config.userContentController = controller
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.allowsBackForwardNavigationGestures = false

        if let url = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "WebAssets") {
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }
        context.coordinator.webView = webView
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate, UIDocumentPickerDelegate {
        weak var webView: WKWebView?

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.name == "saveFile" else { return }
            guard let body = message.body as? [String: Any],
                  let filename = body["filename"] as? String,
                  let base64 = body["base64"] as? String else { return }

            let mime = (body["mimeType"] as? String) ?? "text/csv"
            guard let data = Data(base64Encoded: base64) else {
                notify(success: false, message: "Không đọc được dữ liệu báo cáo")
                return
            }

            let safe = filename.replacingOccurrences(of: "/", with: "_")
            let url = FileManager.default.temporaryDirectory.appendingPathComponent(safe)
            do {
                try data.write(to: url, options: .atomic)
                let picker = UIDocumentPickerViewController(forExporting: [url])
                picker.delegate = self
                picker.shouldShowFileExtensions = true
                topViewController()?.present(picker, animated: true)
            } catch {
                notify(success: false, message: "Không tạo được file: \(error.localizedDescription)")
            }
            _ = mime
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            notify(success: true, message: "Đã lưu file báo cáo. Bạn có thể mở file bằng Excel.")
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            notify(success: false, message: "Bạn đã hủy lưu file")
        }

        private func notify(success: Bool, message: String) {
            let js = "window.__iosFileSaved && window.__iosFileSaved(\(success ? "true" : "false"), \(jsonString(message)));"
            DispatchQueue.main.async { [weak self] in
                self?.webView?.evaluateJavaScript(js)
            }
        }

        private func jsonString(_ value: String) -> String {
            let data = try! JSONSerialization.data(withJSONObject: [value], options: [])
            let array = String(data: data, encoding: .utf8) ?? "[\"\"]"
            return String(array.dropFirst().dropLast())
        }

        private func topViewController(base: UIViewController? = nil) -> UIViewController? {
            let root = base ?? UIApplication.shared.connectedScenes
                .compactMap { ($0 as? UIWindowScene)?.keyWindow?.rootViewController }
                .first
            if let nav = root as? UINavigationController { return topViewController(base: nav.visibleViewController) }
            if let tab = root as? UITabBarController { return topViewController(base: tab.selectedViewController) }
            if let presented = root?.presentedViewController { return topViewController(base: presented) }
            return root
        }

        func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                     initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
            let alert = UIAlertController(title: "ROLL CÂY CẢNH", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
            topViewController()?.present(alert, animated: true)
        }

        func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                     initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
            let alert = UIAlertController(title: "ROLL CÂY CẢNH", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Hủy", style: .cancel) { _ in completionHandler(false) })
            alert.addAction(UIAlertAction(title: "Đồng ý", style: .default) { _ in completionHandler(true) })
            topViewController()?.present(alert, animated: true)
        }
    }
}
