// ROLL CÂY CẢNH V15 – Firebase config
// Tạo Web App trong Firebase Console rồi điền 6 giá trị bên dưới.
// Không điền mật khẩu ở đây.
window.ROLL_CAY_FIREBASE_CONFIG = {
  apiKey: "DAN_API_KEY_CUA_BAN",
  authDomain: "TEN_PROJECT.firebaseapp.com",
  projectId: "TEN_PROJECT",
  storageBucket: "TEN_PROJECT.firebasestorage.app",
  messagingSenderId: "DAN_MESSAGING_SENDER_ID",
  appId: "DAN_APP_ID"
};
