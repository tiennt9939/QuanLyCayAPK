# ROLL CÂY CẢNH V15 – Android ↔ iPhone Cloud Sync

V15 giữ nguyên giao diện/nghiệp vụ của V14 và bổ sung lớp đồng bộ Cloud dùng Firebase Authentication + Cloud Firestore.

## Chức năng V15
- Đăng ký/đăng nhập bằng email + mật khẩu.
- Một tài khoản dùng được trên Android và iPhone.
- Dữ liệu hiện tại vẫn lưu local khi offline.
- Khi có mạng, dữ liệu được đồng bộ vào Firestore.
- Có nút “Đồng bộ ngay” và trạng thái Cloud trên đầu ứng dụng.
- Dữ liệu được tách theo từng tài khoản Firebase.

## Thiết lập Firebase
1. Tạo project Firebase.
2. Tạo Web App và lấy Firebase config.
3. Bật Authentication → Sign-in method → Email/Password.
4. Tạo Firestore Database.
5. Mở `firebase-config.js` và thay 6 giá trị mẫu bằng config thật.
6. Quy tắc Firestore nên giới hạn mỗi tài khoản chỉ đọc/ghi dữ liệu của chính UID đó.

### Firestore Rules tối thiểu
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid}/apps/{appId} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

## Lưu ý
Bản V15 dùng một tài liệu dữ liệu cho mỗi tài khoản để bảo toàn toàn bộ nghiệp vụ V14. Nếu nhiều thiết bị cùng sửa đúng một lúc, lần đồng bộ sau cùng có thể ghi đè thay đổi trước đó. Bước V15.1 có thể tách dữ liệu thành từng bản ghi/ngày để xử lý hợp nhất chi tiết.

## Firebase project configured
This package is configured for the Firebase project `roll-cay-canh`.
The Android WebView app and iOS WebView asset both use the Firebase Web App configuration in `firebase-config.js`.
Firestore path used by the app: `users/{uid}/apps/roll-cay-canh`.
