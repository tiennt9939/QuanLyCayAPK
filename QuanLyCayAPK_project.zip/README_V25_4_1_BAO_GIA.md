# ROLL CÂY CẢNH V25.4.1 — BÁO GIÁ

## Baseline
Bản này được nâng cấp trực tiếp từ Android V25.4. Không thay đổi luồng đóng hàng, nhập kho, theo dõi cây, báo cáo, phân công đơn và hoàn thành đơn.

## Chức năng mới
- Tab **Báo giá**.
- Chọn cây trực tiếp từ danh mục cây hiện hành trong **Theo dõi cây** / **Điều khiển → Danh mục cây**.
- Tự lấy tên sản phẩm, kích thước, giá và hình ảnh.
- Nhập số lượng cho từng cây.
- Thêm nhiều loại cây vào cùng một báo giá.
- Tự tính thành tiền từng dòng và **TỔNG GIÁ**.
- Xuất **CSV** vào `Tải xuống / ROLL CAY CANH`.
- Xuất **PDF A4** trực tiếp vào `Tải xuống / ROLL CAY CANH`.
- PDF dùng background ROLL GARDEN do người dùng cung cấp: `quote-bg.jpg`.

## Quyền mới: Nhân viên thu mua
Role Firebase: `purchasing`

Chỉ có:
- **Báo giá**.
- **Điều khiển → Danh mục cây**: thêm/sửa/xóa/ẩn cây, giá, kích thước, hình ảnh.

Không hiển thị:
- Tổng quan.
- Theo ngày.
- Nhập kho.
- Theo dõi cây.
- Báo cáo.
- Nhân viên.
- Đơn giá tiền công.
- Tồn đầu kỳ.
- Sao lưu/đồng bộ.
- Tài khoản & phân quyền.
- Phân công đóng hàng.

## An toàn dữ liệu
- Báo giá hiện tại lưu ở localStorage riêng `roll_quote_draft`, không ghi báo giá vào `/packingOrders`.
- Không thay đổi Firestore Rules.
- Không thay đổi cấu trúc dữ liệu sản xuất hiện có.
- Không yêu cầu thay đổi Firebase production để dùng chức năng báo giá.
