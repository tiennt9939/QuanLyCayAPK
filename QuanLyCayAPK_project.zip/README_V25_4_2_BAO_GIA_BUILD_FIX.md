# ROLL CÂY CẢNH V25.4.2 — BÁO GIÁ / BUILD FIX

## Mục tiêu
Bản này tiếp tục từ **Android V25.4** và sửa đúng lỗi build V25.4.1, đồng thời hoàn thiện luồng **Báo giá + Nhân viên thu mua** mà không đụng vào luồng đóng hàng, tồn kho, báo cáo và phân công đơn đang có.

## Lỗi build đã sửa
- Sửa chuỗi Java bị thiếu escape tại `MainActivity.java`, dòng thông báo `Chọn "Lưu dưới dạng PDF"...`.
- Giữ cách xuất PDF bằng `PrintManager`/`WebView.createPrintDocumentAdapter`, không dùng constructor callback nội bộ của Android.
- Tăng version thành **25.4.2 / versionCode 20**.

## Báo giá
- Chọn cây từ danh mục hiện hành.
- Tự lấy tên, kích thước, giá, hình ảnh.
- Nhập số lượng từng loại.
- Thêm nhiều loại cây trong một báo giá.
- Tính thành tiền từng dòng và **TỔNG GIÁ**.
- Xuất **CSV**.
- Xuất **PDF A4**.
- PDF dùng đúng background ROLL GARDEN do người dùng cung cấp (`quote-bg.jpg`). Background được chèn trực tiếp trong vùng in và bật `print-color-adjust` để tăng độ tin cậy khi in/PDF.

## Quyền Nhân viên thu mua
Firebase role: `purchasing`.

Được phép duy nhất:
- **Báo giá**.
- **Điều khiển → Danh mục cây**: thêm/sửa/xóa(ẩn), kích thước, giá, hình ảnh.

Không có quyền/không hiển thị:
- Tổng quan.
- Theo ngày/nhập kho.
- Theo dõi tồn kho.
- Báo cáo.
- Nhân viên/tài khoản.
- Đơn giá tiền công.
- Tồn đầu kỳ.
- Phân công/đóng hàng.
- `/apps/roll-cay-canh`.

## Catalog Cloud an toàn
- Catalog dùng chung được lưu tại `/config/roll-cay-canh/plants/{plantId}`.
- Admin khởi tạo catalog Cloud từ danh mục V25.4 hiện có khi đăng nhập sau khi nâng cấp.
- Nhân viên thu mua chỉ đọc/ghi collection `plants`; không đọc/ghi document `/apps` nên không tiếp cận tồn kho, lịch sử hay đơn hàng.
- Danh mục được tách theo từng cây để tránh dồn nhiều ảnh vào một document Firestore.

## Firebase Rules
`firestore.rules` đã bổ sung:
- role `purchasing` khi Admin cấp tài khoản.
- `purchasing` chỉ được read/write `/config/{configId}/plants/{plantId}`.
- Không cấp quyền `/apps` cho `purchasing`.

**Lưu ý an toàn:** file Rules này không tự động thay đổi Firebase production. Chỉ khi chủ dự án Publish Rules lên Firebase Console thì quyền mới có hiệu lực.

## Kiểm tra đã thực hiện trong môi trường hiện tại
- `index.html`: kiểm tra cú pháp JavaScript bằng `node --check` → PASS.
- Kiểm tra không còn dòng Java có số lượng dấu `"` lẻ → PASS.
- `quote-bg.jpg` có cùng kích thước và nội dung hình ảnh với background người dùng cung cấp → khớp 100% pixel sau khi đọc/chuẩn hóa định dạng.
- Kiểm tra sự hiện diện của tab Báo giá, quyền purchasing, CSV/PDF và vùng in PDF → PASS.
- Kiểm tra Java source sau lỗi quote: không còn lỗi cú pháp chuỗi; `javac` trong môi trường này chỉ dừng ở bước thiếu Android SDK classes, không phải lỗi syntax.

## Xác nhận build thực tế
Môi trường hiện tại không có Android SDK/Gradle cache và không có mạng để tải toolchain, nên không thể chạy `gradle assembleDebug` trực tiếp tại đây. GitHub Actions của dự án vẫn là bước build Android thực tế.
