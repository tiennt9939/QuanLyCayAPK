# V25.4 Build Fix – GitHub Actions

Nguyên nhân lỗi: repository hiện chứa Android project trong thư mục `QuanLyCayAPK_project/`, nhưng workflow cũ chỉ kiểm tra `settings.gradle.kts` ở root rồi chuyển sang tìm `*.zip`. Vì repository không có ZIP ở root nên job dừng tại `Extract Android project`.

Đã sửa workflow để nhận cả 3 cấu trúc:
1. Project nằm trực tiếp ở root.
2. Project nằm trong thư mục con (ví dụ `QuanLyCayAPK_project/`).
3. Repository chỉ có ZIP thì mới giải nén ZIP.

Không thay đổi code app, Firebase Rules hay dữ liệu production.
