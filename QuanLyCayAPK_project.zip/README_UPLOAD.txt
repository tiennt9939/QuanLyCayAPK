ROLL CÂY CẢNH V20 – COMPLETE

Upload QuanLyCayAPK_project.zip to the GitHub repository root.
The included GitHub Actions workflow extracts nested ZIPs and builds the Android APK.

IMPORTANT: Publish the included firestore.rules in Firebase Console -> Firestore Database -> Rules before testing.

V20 changes:
- Employee and Firebase User are separate.
- Existing employee can be linked to an existing Firebase account.
- Admin assignment only shows linked packer accounts.
- Combo 2..100 plants.
- Packer cannot enter quantity.
- Completion requires direct camera photo.
- Only completed orders with proof photo generate pay.
- Packer sees only own assigned orders/reports.
- Admin retains full control.
