ROLL CAY CANH V20.6 — FIX ĐỒNG BỘ + PHÂN CÔNG ĐƠN ĐÓNG HÀNG

1. Upload QuanLyCayAPK_project.zip to the GitHub repository root.
2. In Firebase Console -> Firestore Database -> Rules, REPLACE ALL existing rules with the firestore.rules file in this project, then press Publish.
3. The current app error "Missing or insufficient permissions" occurs when the V20 rules are not published. The new rules explicitly allow /config and /packingOrders while keeping Admin separate from employees.
4. Build from GitHub Actions.
