ROLL CAY CANH V17 – FIREBASE FIXED
Replace the repository file QuanLyCayAPK_project.zip with the included file of the same name, then run GitHub Actions.
