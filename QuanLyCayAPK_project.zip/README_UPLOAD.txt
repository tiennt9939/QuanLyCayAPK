ROLL CÂY CẢNH V17 – ADMIN FIX

Upload ONLY QuanLyCayAPK_project.zip to the root of the GitHub repository.
Keep the existing .github/workflows/build-apk.yml.
Then run Actions -> Build QuanLyCayAPK -> Run workflow.

This build makes tiennt9939@gmail.com an administrator in the app UI even if an older Firestore profile says viewer, and the Firestore rules explicitly recognize the bootstrap admin.
