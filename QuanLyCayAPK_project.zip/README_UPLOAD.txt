ROLL CÂY CẢNH – V17 Firebase + ghi nhớ đăng nhập

Cách đưa lên GitHub:
1. Giải nén gói này.
2. Upload file QuanLyCayAPK_project.zip vào repository (cùng cấp với .github/workflows nếu bạn đang dùng workflow cũ).
3. Nếu repository đã có build-apk.yml của V17, workflow sẽ giải nén QuanLyCayAPK_project.zip và build app-debug.apk.

Đã sửa trực tiếp V17:
- Firebase Web config chính thức của project roll-cay-canh.
- Sửa đúng API key: AIzaSyB6qZX3FZAnWX0wagxSBbnr-TG7ZK3ASTU.
- Thêm fallback Firebase config trong index.html.
- Firebase Auth dùng Persistence.LOCAL để giữ phiên đăng nhập trên thiết bị.
- Có tùy chọn “Ghi nhớ tên đăng nhập trên điện thoại”.
- Không lưu mật khẩu vào localStorage.
