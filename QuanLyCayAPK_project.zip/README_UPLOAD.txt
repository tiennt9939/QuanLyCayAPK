ROLL CAY CANH V17.10 - LOGIN GATE + ADMIN USER FIX

Upload ONLY QuanLyCayAPK_project.zip to the ROOT of the GitHub repository.

Includes:
- Correct Firebase config for project roll-cay-canh
- Correct API key
- Full-screen login gate at startup
- No Sign up / No Forgot password
- Remember email only; password is not stored
- Bootstrap Admin: tiennt9939@gmail.com
- Admin can create users without losing the Admin session
- Updated Firestore Rules allowing Admin to create/read/update user profiles
- Login image asset based on the user's supplied reference

IMPORTANT: After installing/building this version, publish firestore.rules from this project in Firebase Console -> Firestore Database -> Rules.
