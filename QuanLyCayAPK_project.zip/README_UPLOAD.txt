ROLL CAY CANH V17 - Firebase + Ghi nho dang nhap + GitHub build

CACH DUNG:
1. Trong repository GitHub, xoa file ZIP cu.
2. Upload file QuanLyCayAPK_project.zip vao thu muc goc repository.
3. Vao Actions -> Build QuanLyCayAPK -> Run workflow.

Workflow da duoc sua de tu dong ho tro ca:
- source Android nam truc tiep trong repository;
- QuanLyCayAPK_project.zip nam o thu muc goc;
- mot ZIP bao ngoai co ten bat ky;
- ZIP long nhieu lop.

Firebase project: roll-cay-canh
Bootstrap admin: tiennt9939@gmail.com
