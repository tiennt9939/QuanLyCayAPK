// ROLL CÂY CẢNH V15 – Firebase config
window.ROLL_CAY_FIREBASE_CONFIG = {
  apiKey: "AIzaSyB6qZX3FZAnWX0wagxSBbn-rTG7ZK3ASTU",
  authDomain: "roll-cay-canh.firebaseapp.com",
  projectId: "roll-cay-canh",
  storageBucket: "roll-cay-canh.firebasestorage.app",
  messagingSenderId: "311724804563",
  appId: "1:311724804563:web:ae8331367750f508860726",
  measurementId: "G-BZ90BLW5EV"
};
