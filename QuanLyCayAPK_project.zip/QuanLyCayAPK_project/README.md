# ROLL CÂY CẢNH – APK v3

Bản v3 bám sát workbook `Tổng_hợp_sd1_đồng_bộ_danh_mục.xlsx`.

## Công thức
- Ngày 01/09/2026: cột D của Excel là **tồn đầu kỳ/đang có**, cột E là **nhập trong ngày**.
- Từ ngày tiếp theo: Đang có = Tồn cuối ngày trước.
- Bán/Xuất = tổng số cây đóng của 6 nhân viên.
- Tồn cuối = Đang có + Nhập trong ngày – Bán.
- Tiền công từng người = số cây người đó đóng × đơn giá theo kích thước từ bảng F:G của `Danh_Muc_Cay`.
- Chu kỳ trả lương: 7 ngày, bắt đầu 01/09/2026.
- Theo dõi đến 31/12/2027.

## Dữ liệu Excel đã nạp
- 99 dòng danh mục cây.
- 6 nhân viên.
- 6 đơn giá C6/C7/C9/C10/C11/C12.
- Dữ liệu thực có trong workbook được nạp; ngày 01/09/2026 có tồn đầu 500 cây ở dòng cây đầu tiên và 80/50/70 cây đóng bởi Luân lớn/Luân nhỏ/Huy.

Logo ROLL CÂY CẢNH được dùng trong giao diện và biểu tượng APK.
