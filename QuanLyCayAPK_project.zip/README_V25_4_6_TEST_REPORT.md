# V25.4.6 — TEST REPORT

## Scope
Nâng cấp trực tiếp từ `ROLL_CAY_CANH_V25_4_5_BAO_GIA_A4_FINAL.zip`.

## Các điểm đã kiểm tra
- JavaScript inline trong `index.html`: `node --check` PASS.
- Luồng quyền `purchasing`: harness mô phỏng PASS.
  - Chỉ hiện `Báo giá` và `Điều khiển`.
  - Trong `Điều khiển`, chỉ còn card `Danh mục cây`.
  - Các card đồng bộ, tài khoản, nhân viên, đơn giá tiền công, tồn đầu kỳ, sao lưu, phân công... bị ẩn.
- Admin UI smoke harness: PASS; không làm mất các card Điều khiển của Admin.
- Guard quyền catalog: PASS cho mở/sửa, lưu, xóa, ảnh cây.
- Quote CSV/PDF functions vẫn hiện diện.
- `MainActivity.java` không thay đổi.
- `quote-bg.jpg` không thay đổi; SHA-256 giữ nguyên.
- `firestore.rules` không thay đổi; quyền `purchasing` tại `/config/{configId}/plants` đã có sẵn và không cấp `/apps`/`packingOrders`.
- Version Android tăng từ `versionCode 23 / versionName 25.4.5` lên `versionCode 24 / versionName 25.4.6`.

## Giới hạn xác minh
Môi trường hiện tại không có Android SDK/Gradle wrapper để chạy `./gradlew assemble...`, vì vậy chưa thể tuyên bố APK đã build runtime trong môi trường này. Source đã được kiểm tra tĩnh và đóng gói để GitHub Actions build.
