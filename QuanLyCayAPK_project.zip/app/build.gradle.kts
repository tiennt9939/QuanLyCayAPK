plugins { id("com.android.application") }

android {
    namespace = "com.quanlycay.apk"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.quanlycay.apk"
        minSdk = 23
        targetSdk = 35
        versionCode = 18
        versionName = "25.5.0"
    }
}
