package com.quanlycay.apk;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.print.PrintAttributes;
import android.os.Bundle;
import android.print.PrintManager;
import android.content.Context;
import android.widget.Toast;
import android.widget.FrameLayout;
import android.view.View;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;
import android.graphics.pdf.PdfDocument;
import android.util.Base64;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQ = 4101;
    private WebView webView;
    private WebView quotePrintWebView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraOutputUri;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new AppChromeClient());
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
        FrameLayout root = new FrameLayout(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    private class AppChromeClient extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                         FileChooserParams params) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = callback;
            boolean imageOnly = false;
            String[] accepts = params.getAcceptTypes();
            if (accepts != null) {
                for (String a : accepts) {
                    if (a != null && a.toLowerCase().startsWith("image/")) imageOnly = true;
                }
            }

            if (params.isCaptureEnabled() && imageOnly) {
                launchCamera();
            } else {
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType(imageOnly ? "image/*" : "*/*");
                startActivityForResult(pick, FILE_CHOOSER_REQ);
            }
            return true;
        }
    }

    private void launchCamera() {
        try {
            Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME,
                        "ROLL_CAY_CANH_" + System.currentTimeMillis() + ".jpg");
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                values.put(MediaStore.Images.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES + "/ROLL CAY CANH");
                cameraOutputUri = getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
                camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
            startActivityForResult(camera, FILE_CHOOSER_REQ);
        } catch (Exception e) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = null;
            cameraOutputUri = null;
            Toast.makeText(this, "Không thể mở camera", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQ || filePathCallback == null) return;

        Uri result = null;
        if (resultCode == RESULT_OK) {
            if (cameraOutputUri != null) {
                result = cameraOutputUri;
            } else if (data != null) {
                if (data.getData() != null) {
                    result = data.getData();
                } else if (data.getExtras() != null && data.getExtras().get("data") instanceof Bitmap) {
                    result = saveLegacyCameraBitmap((Bitmap) data.getExtras().get("data"));
                }
            }
        }

        filePathCallback.onReceiveValue(result == null ? null : new Uri[]{result});
        filePathCallback = null;
        if (result == null && cameraOutputUri != null) {
            try { getContentResolver().delete(cameraOutputUri, null, null); } catch (Exception ignored) {}
        }
        cameraOutputUri = null;
    }

    private Uri saveLegacyCameraBitmap(Bitmap bitmap) {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME,
                    "ROLL_CAY_CANH_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return null;
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null || !bitmap.compress(Bitmap.CompressFormat.JPEG, 88, out)) return null;
            }
            return uri;
        } catch (Exception e) {
            return null;
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void saveQuotePdf(String jobName, String json) {
            final String safeName = (jobName == null || jobName.trim().isEmpty())
                    ? "Bao-gia-ROLL-GARDEN" : jobName.replaceAll("[^a-zA-Z0-9._-]", "_");
            final String payload = json == null ? "{}" : json;
            Toast.makeText(MainActivity.this, "Đang tạo PDF báo giá A4…", Toast.LENGTH_SHORT).show();
            new Thread(() -> {
                FileOutputStream tempOut = null;
                File temp = null;
                PdfDocument document = null;
                try {
                    JSONObject root = new JSONObject(payload);
                    JSONArray items = root.optJSONArray("items");
                    if (items == null || items.length() == 0) throw new Exception("Báo giá chưa có cây");
                    String customer = root.optString("customer", "").trim();
                    double grandTotal = root.optDouble("total", 0);

                    final int W = 595; // A4 @ 72 dpi
                    final int H = 842;
                    final int LEFT = 18, RIGHT = 18;
                    final int TABLE_TOP = 275;
                    final int ROW_H = 50;
                    final int TABLE_W = W - LEFT - RIGHT;
                    final int[] COL = {28, 78, 145, 68, 52, 96, 96};

                    Bitmap bg = loadAssetBitmap("quote-bg.jpg");
                    Bitmap logo = loadAssetBitmap("logo.png");
                    document = new PdfDocument();
                    int pageCount = (items.length() + 7) / 8;

                    for (int pageIndex = 0; pageIndex < pageCount; pageIndex++) {
                        PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(W, H, pageIndex + 1).create();
                        PdfDocument.Page page = document.startPage(info);
                        Canvas c = page.getCanvas();
                        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                        p.setTypeface(Typeface.create("sans", Typeface.NORMAL));

                        // Nền ROLL GARDEN phủ kín toàn bộ A4, không co nhỏ.
                        c.drawColor(Color.WHITE);
                        if (bg != null) c.drawBitmap(bg, null, new Rect(0, 0, W, H), p);

                        // Vùng nội dung nằm trên phần trắng trung tâm của background.
                        p.setColor(Color.rgb(7, 91, 57));
                        p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                        p.setTextSize(17);
                        p.setTextAlign(Paint.Align.CENTER);
                        c.drawText("BÁO GIÁ CÂY CẢNH", W / 2f, 232, p);
                        p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                        p.setTextSize(8.5f);
                        p.setColor(Color.rgb(82, 99, 91));
                        c.drawText("ROLL GARDEN  •  " + new java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(new java.util.Date())
                                + "  •  Trang " + (pageIndex + 1) + "/" + pageCount, W / 2f, 246, p);
                        if (pageIndex == 0 && !customer.isEmpty()) {
                            p.setTextAlign(Paint.Align.LEFT);
                            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                            p.setTextSize(9);
                            p.setColor(Color.rgb(23, 54, 42));
                            c.drawText("Khách hàng: " + fitText(customer, p, TABLE_W), LEFT, 263, p);
                        }

                        int y = TABLE_TOP;
                        p.setColor(Color.argb(242, 255, 255, 255));
                        c.drawRect(LEFT, y, LEFT + TABLE_W, y + ROW_H * Math.min(8, items.length() - pageIndex * 8 + 1), p);

                        // Header
                        p.setColor(Color.rgb(226, 244, 233));
                        c.drawRect(LEFT, y, LEFT + TABLE_W, y + 30, p);
                        p.setColor(Color.rgb(80, 120, 100));
                        p.setStyle(Paint.Style.STROKE);
                        p.setStrokeWidth(0.7f);
                        c.drawRect(LEFT, y, LEFT + TABLE_W, y + 30, p);
                        int x = LEFT;
                        String[] headers = {"STT", "Hình ảnh", "Tên sản phẩm", "Kích thước", "SL", "Đơn giá", "Thành tiền"};
                        for (int j = 0; j < COL.length; j++) {
                            if (j > 0) c.drawLine(x, y, x, y + 30, p);
                            p.setStyle(Paint.Style.FILL);
                            p.setColor(Color.rgb(23, 54, 42));
                            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                            p.setTextSize(7.3f);
                            p.setTextAlign(Paint.Align.CENTER);
                            c.drawText(headers[j], x + COL[j] / 2f, y + 19, p);
                            x += COL[j];
                            p.setStyle(Paint.Style.STROKE);
                            p.setColor(Color.rgb(80, 120, 100));
                        }

                        int start = pageIndex * 8;
                        int end = Math.min(items.length(), start + 8);
                        for (int i = start; i < end; i++) {
                            JSONObject item = items.getJSONObject(i);
                            int ry = TABLE_TOP + 30 + (i - start) * ROW_H;
                            p.setStyle(Paint.Style.STROKE);
                            p.setColor(Color.rgb(170, 197, 181));
                            p.setStrokeWidth(0.6f);
                            c.drawRect(LEFT, ry, LEFT + TABLE_W, ry + ROW_H, p);
                            int xx = LEFT;
                            for (int j = 1; j < COL.length; j++) {
                                xx += COL[j - 1];
                                c.drawLine(xx, ry, xx, ry + ROW_H, p);
                            }

                            String name = item.optString("name", "");
                            String size = item.optString("size", "");
                            int qty = (int)Math.round(item.optDouble("qty", 0));
                            double price = item.optDouble("price", 0);
                            double lineTotal = price * qty;

                            p.setStyle(Paint.Style.FILL);
                            p.setColor(Color.rgb(23, 54, 42));
                            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                            p.setTextSize(7.8f);
                            p.setTextAlign(Paint.Align.CENTER);
                            c.drawText(String.valueOf(i + 1), LEFT + COL[0] / 2f, ry + 28, p);

                            Bitmap product = loadQuoteBitmap(item.optString("image", ""), logo);
                            if (product != null) {
                                Rect src = fitSrc(product);
                                RectF dst = new RectF(LEFT + COL[0] + 7, ry + 6, LEFT + COL[0] + COL[1] - 7, ry + ROW_H - 6);
                                c.drawBitmap(product, src, dst, p);
                            }

                            int nameX = LEFT + COL[0] + COL[1];
                            p.setTextAlign(Paint.Align.LEFT);
                            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                            p.setTextSize(7.8f);
                            drawWrapped(c, name, p, nameX + 5, ry + 20, COL[2] - 10, 10, 2);

                            int sizeX = nameX + COL[2];
                            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                            p.setTextAlign(Paint.Align.CENTER);
                            c.drawText(fitText(size, p, COL[3] - 8), sizeX + COL[3] / 2f, ry + 28, p);

                            int qtyX = sizeX + COL[3];
                            c.drawText(String.valueOf(qty), qtyX + COL[4] / 2f, ry + 28, p);
                            int priceX = qtyX + COL[4];
                            p.setTextAlign(Paint.Align.RIGHT);
                            c.drawText(formatMoney(price), priceX + COL[5] - 5, ry + 28, p);
                            int totalX = priceX + COL[5];
                            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                            c.drawText(formatMoney(lineTotal), totalX + COL[6] - 5, ry + 28, p);
                        }

                        int usedRows = end - start;
                        int afterTable = TABLE_TOP + 30 + usedRows * ROW_H;
                        if (pageIndex == pageCount - 1) {
                            p.setStyle(Paint.Style.FILL);
                            p.setColor(Color.rgb(7, 91, 57));
                            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                            p.setTextSize(13);
                            p.setTextAlign(Paint.Align.RIGHT);
                            c.drawText("TỔNG GIÁ: " + formatMoney(grandTotal), LEFT + TABLE_W, afterTable + 27, p);
                            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                            p.setTextSize(7.2f);
                            p.setColor(Color.rgb(102, 118, 110));
                            c.drawText("Đơn giá theo danh mục cây hiện hành của ROLL GARDEN.", LEFT + TABLE_W, afterTable + 42, p);
                        }
                        p.setTextSize(7.2f);
                        p.setColor(Color.rgb(107, 123, 115));
                        p.setTextAlign(Paint.Align.RIGHT);
                        c.drawText("ROLL GARDEN  •  Cây đẹp - Không gian xanh - Cuộc sống an lành", W - RIGHT, H - 34, p);
                        document.finishPage(page);
                    }

                    temp = new File(getCacheDir(), safeName + ".pdf");
                    tempOut = new FileOutputStream(temp);
                    document.writeTo(tempOut);
                    tempOut.close(); tempOut = null;
                    document.close(); document = null;

                    final File ready = temp;
                    runOnUiThread(() -> {
                        try {
                            savePdfToDownloads(safeName + ".pdf", ready);
                            Toast.makeText(MainActivity.this, "Đã xuất PDF A4 đầy đủ nền ROLL GARDEN vào Tải xuống/Roll Cây Cảnh", Toast.LENGTH_LONG).show();
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Không thể lưu PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        } finally {
                            try { ready.delete(); } catch (Exception ignored) {}
                        }
                    });
                } catch (Exception e) {
                    if (tempOut != null) try { tempOut.close(); } catch (Exception ignored) {}
                    if (document != null) try { document.close(); } catch (Exception ignored) {}
                    if (temp != null) try { temp.delete(); } catch (Exception ignored) {}
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "Không thể tạo PDF báo giá: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            }).start();
        }

        private void savePdfToDownloads(String fileName, File source) throws Exception {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ROLL CAY CANH");
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("Không tạo được file trong Tải xuống");
                try (InputStream in = new java.io.FileInputStream(source); OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Không mở được file đích");
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                } catch (Exception e) {
                    try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
                    throw e;
                }
                ContentValues done = new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "ROLL CAY CANH");
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Không tạo được thư mục Tải xuống");
                File dst = new File(dir, fileName);
                try (InputStream in = new java.io.FileInputStream(source); OutputStream out = new FileOutputStream(dst)) {
                    byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                }
            }
        }

        private Bitmap loadQuoteBitmap(String value, Bitmap fallback) {
            try {
                if (value == null || value.trim().isEmpty()) return fallback;
                String v = value.trim();
                if (v.startsWith("data:image")) {
                    int comma = v.indexOf(',');
                    if (comma > 0) return BitmapFactory.decodeByteArray(Base64.decode(v.substring(comma + 1), Base64.DEFAULT), 0, Base64.decode(v.substring(comma + 1), Base64.DEFAULT).length);
                }
                if (v.startsWith("file:///android_asset/")) return loadAssetBitmap(v.substring("file:///android_asset/".length()));
                if (!v.startsWith("http://") && !v.startsWith("https://")) {
                    Bitmap a = loadAssetBitmap(v);
                    if (a != null) return a;
                }
                HttpURLConnection con = (HttpURLConnection)new URL(v).openConnection();
                con.setConnectTimeout(5000); con.setReadTimeout(8000); con.setInstanceFollowRedirects(true);
                con.connect();
                try (InputStream in = con.getInputStream()) { Bitmap b = BitmapFactory.decodeStream(in); if (b != null) return b; }
                con.disconnect();
            } catch (Exception ignored) {}
            return fallback;
        }

        private Bitmap loadAssetBitmap(String name) {
            try (InputStream in = getAssets().open(name)) { return BitmapFactory.decodeStream(in); } catch (Exception e) { return null; }
        }

        private Rect fitSrc(Bitmap b) {
            int w=b.getWidth(), h=b.getHeight(); float target=78f/38f, src=(float)w/h;
            if (src > target) { int nw=(int)(h*target); int l=(w-nw)/2; return new Rect(l,0,l+nw,h); }
            int nh=(int)(w/target); int t=(h-nh)/2; return new Rect(0,t,w,t+nh);
        }

        private String formatMoney(double value) {
            return String.format(java.util.Locale.US, "%,.0f đ", value).replace(',', '.');
        }

        private String fitText(String text, Paint p, float maxWidth) {
            if (text == null) return "";
            if (p.measureText(text) <= maxWidth) return text;
            String t = text;
            while (t.length() > 1 && p.measureText(t + "…") > maxWidth) t = t.substring(0, t.length()-1);
            return t + "…";
        }

        private void drawWrapped(Canvas c, String text, Paint p, float x, float y, float maxWidth, float lineHeight, int maxLines) {
            if (text == null) text = "";
            String[] words = text.trim().split("\\s+"); String line=""; int lineNo=0;
            for (String word: words) {
                String test=line.isEmpty()?word:line+" "+word;
                if (p.measureText(test)<=maxWidth) line=test;
                else { if (lineNo<maxLines) { c.drawText(line,x,y+lineNo*lineHeight,p); lineNo++; } line=word; if(lineNo>=maxLines) break; }
            }
            if (lineNo<maxLines && !line.isEmpty()) c.drawText(fitText(line,p,maxWidth),x,y+lineNo*lineHeight,p);
        }

        @JavascriptInterface
        public void printA4Html(String jobName, String html) {
            final String safeName = (jobName == null || jobName.trim().isEmpty())
                    ? "Bao-gia-ROLL-GARDEN" : jobName.replaceAll("[^a-zA-Z0-9._-]", "_");
            final String source = html == null ? "" : html;
            runOnUiThread(() -> {
                try {
                    if (quotePrintWebView != null) {
                        try { quotePrintWebView.stopLoading(); } catch (Exception ignored) {}
                        try {
                            if (quotePrintWebView.getParent() instanceof FrameLayout) {
                                ((FrameLayout) quotePrintWebView.getParent()).removeView(quotePrintWebView);
                            }
                        } catch (Exception ignored) {}
                        try { quotePrintWebView.destroy(); } catch (Exception ignored) {}
                    }
                    quotePrintWebView = new WebView(MainActivity.this);
                    FrameLayout root = (FrameLayout) webView.getParent();
                    if (root != null) {
                        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.MATCH_PARENT,
                                FrameLayout.LayoutParams.MATCH_PARENT);
                        quotePrintWebView.setLayoutParams(lp);
                        quotePrintWebView.setTranslationX(getResources().getDisplayMetrics().widthPixels + 2000f);
                        quotePrintWebView.setVisibility(View.VISIBLE);
                        root.addView(quotePrintWebView);
                    }
                    WebSettings ps = quotePrintWebView.getSettings();
                    ps.setJavaScriptEnabled(false);
                    ps.setDomStorageEnabled(true);
                    ps.setAllowFileAccess(true);
                    ps.setAllowContentAccess(true);
                    ps.setLoadsImagesAutomatically(true);
                    quotePrintWebView.setLayerType(WebView.LAYER_TYPE_SOFTWARE, null);
                    quotePrintWebView.setWebViewClient(new WebViewClient() {
                        @Override public void onPageFinished(WebView view, String url) {
                            view.postDelayed(() -> printLoadedQuote(safeName, view), 900);
                        }
                    });
                    quotePrintWebView.loadDataWithBaseURL(
                            "file:///android_asset/", source, "text/html", "UTF-8", null);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                            "Không thể chuẩn bị PDF báo giá: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        private void printLoadedQuote(String safeName, WebView printView) {
            try {
                PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (printManager == null) throw new Exception("Thiết bị không hỗ trợ in/PDF");
                PrintAttributes attributes = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .setResolution(new PrintAttributes.Resolution("ROLLPDF", "ROLL PDF", 300, 300))
                        .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                        .build();
                printManager.print(safeName, printView.createPrintDocumentAdapter(safeName), attributes);
                Toast.makeText(MainActivity.this,
                        "Đã mở bản in PDF. Chọn 'Lưu dưới dạng PDF'.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(MainActivity.this,
                        "Không thể xuất PDF báo giá: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }

        public void printCurrentPage(String jobName) {
            final String safeName = (jobName == null || jobName.trim().isEmpty()) ? "ROLL-CAY-CANH" : jobName.replaceAll("[^a-zA-Z0-9._-]", "_");
            runOnUiThread(() -> {
                try {
                    PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    if (printManager == null) {
                        Toast.makeText(MainActivity.this, "Thiết bị không hỗ trợ in", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    PrintAttributes attributes = new PrintAttributes.Builder()
                            .setMediaSize(new PrintAttributes.MediaSize("ROLL65X100", "65x100mm", 2560, 3937))
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build();
                    printManager.print(safeName, webView.createPrintDocumentAdapter(safeName), attributes);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Không thể mở chức năng in: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void savePdfFromCurrentPage(String jobName) {
            // Android does not expose the PrintDocumentAdapter callback constructors
            // as a public application API. Use the supported PrintManager flow and
            // let the system's print UI provide "Save as PDF".
            final String safeName = (jobName == null || jobName.trim().isEmpty())
                    ? "Bao-gia-ROLL-GARDEN"
                    : jobName.replaceAll("[^a-zA-Z0-9._-]", "_");
            runOnUiThread(() -> {
                try {
                    PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    if (printManager == null) {
                        throw new Exception("Thiết bị không hỗ trợ in/PDF");
                    }
                    PrintAttributes attributes = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .setResolution(new PrintAttributes.Resolution("ROLLPDF", "ROLL PDF", 300, 300))
                            .build();
                    printManager.print(safeName, webView.createPrintDocumentAdapter(safeName), attributes);
                    Toast.makeText(MainActivity.this,
                            "Chọn \"Lưu dưới dạng PDF\" để lưu báo giá vào thiết bị",
                            Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                            "Không thể xuất PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        public boolean saveFile(String filename, String base64, String mimeType) {
            try {
                String safeName = filename == null ? "bao-cao.csv" : filename.replaceAll("[^a-zA-Z0-9._-]", "_");
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE,
                            mimeType == null ? "text/csv" : mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH,
                            Environment.DIRECTORY_DOWNLOADS + "/ROLL CAY CANH");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) return false;
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("Không mở được file");
                        out.write(bytes);
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "Đã lưu: Tải xuống / ROLL CAY CANH / " + safeName,
                            Toast.LENGTH_LONG).show());
                    return true;
                }

                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) return false;
                File file = new File(dir, safeName);
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(bytes);
                }
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Đã lưu file trong thư mục Tải xuống",
                        Toast.LENGTH_LONG).show());
                return true;
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Không lưu được file: " + e.getMessage(), Toast.LENGTH_LONG).show());
                return false;
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
