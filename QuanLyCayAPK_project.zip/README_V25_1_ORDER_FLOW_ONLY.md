# V25.1 — ORDER FLOW ONLY

Nền tảng gốc: `QuanLyCayAPK_project_V25_1_ROOT_AUDITED.zip` do người dùng cung cấp.

Phạm vi duy nhất đã chỉnh:
1. Admin phân công đơn hàng như cơ chế V25.1 hiện có.
2. Nhân viên chỉ nhìn thấy các đơn được phân công cho chính tài khoản đó.
3. Nhân viên bấm `NHẬN ĐƠN`.
4. Đơn chuyển sang `ĐƠN ĐÃ NHẬN · CẦN HOÀN THÀNH`.
5. Nhân viên chụp ảnh đóng gói thành công.
6. Nhân viên bấm `XÁC NHẬN HOÀN THÀNH ĐƠN`.
7. Hệ thống dùng cơ chế hoàn thành Firestore hiện có để ghi nhận đơn, lưu ảnh và tạo bản ghi tiền công theo `packSize × đơn giá kích thước`.
8. Giao diện nhập/đóng hàng thủ công của Admin được ẩn hoàn toàn đối với tài khoản packer.

Không thay đổi:
- Firebase Rules.
- Catalog/cây/kích thước.
- Đơn giá.
- Nhập kho/tồn kho.
- Báo cáo.
- Giao diện và quyền Admin ngoài phần cần thiết để phân công.
- Cơ chế dữ liệu khác của V25.1.

Lưu ý kỹ thuật:
- Trạng thái `NHẬN ĐƠN` được lưu cục bộ trên thiết bị nhân viên để không phải thay đổi Firebase Rules hiện có.
- Trạng thái `HOÀN THÀNH`, ảnh bằng chứng và bản ghi tiền công vẫn được ghi bằng cơ chế Firestore hiện có.
- Source đã kiểm tra cú pháp JavaScript bằng `node --check`.
- Môi trường hiện tại không có Gradle wrapper trong source nên chưa tạo APK runtime từ source này.
