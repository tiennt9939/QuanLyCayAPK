# ROLL CÂY CẢNH V25.4.5 — BÁO GIÁ A4 FINAL

## Mục tiêu
Bản này nâng cấp trực tiếp từ V25.4.4, chỉ hoàn thiện đường xuất PDF báo giá. Không thay đổi các luồng Đóng hàng, Nhập kho, Theo dõi cây, Báo cáo, Phân công, Hoàn thành đơn, quyền Admin/Packer hoặc dữ liệu nghiệp vụ Firebase.

## Lỗi đã xử lý triệt để
PDF trước đây được đưa qua WebView/Android PrintManager. Trên một số máy Android, WebView print adapter tự co toàn bộ nội dung xuống vùng nhỏ giữa trang A4, dẫn tới preview và file PDF bị thu nhỏ, nền không phủ kín trang.

V25.4.5 chuyển riêng chức năng **Xuất PDF báo giá** sang renderer native `android.graphics.pdf.PdfDocument`. Vì vậy kích thước trang được cố định trực tiếp là **595 × 842 point = ISO A4**, không phụ thuộc zoom, viewport hay scaling của WebView.

## PDF mới
- Nền `quote-bg.jpg` phủ kín toàn bộ A4.
- Bảng báo giá nằm trên vùng trắng trung tâm của background.
- Tên sản phẩm, kích thước, số lượng, đơn giá, thành tiền.
- Hình ảnh cây được lấy từ catalog; hỗ trợ data URL, asset và URL HTTP/HTTPS; nếu ảnh lỗi sẽ dùng logo dự phòng.
- Tự chia trang, tối đa 8 dòng sản phẩm/trang.
- Trang cuối có **TỔNG GIÁ**.
- File lưu trực tiếp vào `Tải xuống/ROLL CAY CANH`, không cần qua màn hình `Lưu dưới dạng PDF`.
- Tên file dạng `Bao-gia-ROLL-GARDEN-...pdf`.

## CSV
Giữ nguyên chức năng CSV hiện có. Không thay đổi dữ liệu báo giá.

## Quyền nhân viên thu mua
Giữ nguyên role `purchasing`: chỉ được **Báo giá** và **Điều khiển → Danh mục cây**.

## An toàn dữ liệu
- Không thay đổi `/packingOrders`.
- Không thay đổi dữ liệu kho/đóng hàng/báo cáo.
- Không thay đổi cơ chế đồng bộ nghiệp vụ.
- Không thay đổi Firebase production Rules trong bản này.
- Draft báo giá vẫn lưu local riêng.

## Kiểm tra offline trong môi trường build hiện tại
- Java braces/parentheses cân bằng.
- HTML/JavaScript của báo giá được giữ nguyên và hook `AndroidBridge.saveQuotePdf` được kiểm tra tồn tại.
- Background có đúng tỷ lệ A4 1087×1536.
- Bản PDF mẫu renderer cùng kích thước A4 đã được kiểm tra: `595.276 × 841.89 pt`, không co nội dung xuống giữa trang.

## Giới hạn
Môi trường Linux hiện tại không có Android SDK/Gradle cache nên không thể chạy `gradle assembleDebug` hay cài APK lên thiết bị Android thật trong phiên này. GitHub Actions của dự án vẫn là bước build Android thật.

## Phiên bản
- versionCode: 23
- versionName: 25.4.5
- compileSdk: 35
- targetSdk: 35
- minSdk: 23
