# ROLL CÂY CẢNH V25.4.4 — BÁO GIÁ A4 LAYOUT FIX

## Mục tiêu
Tiếp tục từ V25.4.3, chỉ xử lý lỗi PDF Báo giá bị co nhỏ/chia trang không hợp lý làm thiếu thông tin khi xem trên điện thoại.

## Điều chỉnh
- Chuẩn hóa trang PDF đúng **A4 dọc 210 × 297 mm**.
- Dùng đúng background ROLL GARDEN người dùng cung cấp, kéo khớp toàn trang A4.
- Bố trí bảng theo chiều rộng A4 cố định, chia tỷ lệ cột để tên cây/kích thước/giá không bị tràn.
- Giảm kích thước ảnh và khoảng đệm bảng để 3–8 dòng có thể hiển thị gọn trên một trang.
- Không để một dòng sản phẩm bị cắt giữa hai trang.
- Nếu báo giá nhiều hơn 8 loại cây, tự chia sang trang A4 kế tiếp; mỗi trang vẫn có background và tiêu đề.
- Tổng giá chỉ xuất ở trang cuối.
- Android tạo Print WebView có viewport thật thay vì WebView rời chưa được đo kích thước, giúp tránh hiện tượng bản xem trước bị co nhỏ.

## Không thay đổi
- Không thay đổi dữ liệu cây, tồn kho, đóng hàng, phân công, báo cáo.
- Không thay đổi Firebase production.
- Không thay đổi quyền purchasing ngoài những gì đã có ở V25.4.x.
- Không thay đổi Android V25.4 Golden Baseline; đây là bản nâng cấp kế thừa cho chức năng Báo giá.

## Kiểm tra tĩnh
- JavaScript trong `index.html`: PASS bằng `node --check` sau khi tách các khối script.
- Background `quote-bg.jpg`: đúng 1087 × 1536 px và khớp 100% với background người dùng cung cấp.
- A4 PDF layout: CSS `@page A4 portrait`, 210 × 297 mm, bảng fixed-layout, chống tách dòng.
- Android Print WebView: có kích thước đo thật trong root FrameLayout.

## Build
Version name: 25.4.4
Version code: 22

Môi trường hiện tại không có Android SDK/Gradle cache đầy đủ để chạy assembleDebug trực tiếp; GitHub Actions là bước build APK thực tế.
