# ROLL CÂY CẢNH V25.4.6 — BÁO GIÁ + PHÂN QUYỀN NHÂN VIÊN THU MUA

Bản này được tạo bằng cách nâng cấp trực tiếp từ V25.4.5 đã ổn định. Không thay đổi giao diện báo giá, logic tính tổng, CSV hoặc renderer PDF A4 native; không thay đổi background `quote-bg.jpg`.

## Thay đổi duy nhất
- Role `purchasing` giữ đúng 2 quyền: `quote` và `catalog`.
- Trong thanh điều hướng, nhân viên thu mua chỉ thấy **Báo giá** và **Điều khiển**.
- Trong **Điều khiển**, nhân viên thu mua **chỉ thấy Danh mục cây**; mọi card khác (đồng bộ, tài khoản, nhân viên, đơn giá tiền công, tồn đầu kỳ, sao lưu, phân công...) bị ẩn tuyệt đối.
- Nhân viên thu mua có thể **Thêm / Sửa / Ẩn cây**, thay giá, kích thước và hình ảnh trong Danh mục cây.
- Các hàm chỉnh sửa Danh mục cây đều có guard `catalog`, tránh thao tác trái quyền kể cả khi được gọi trực tiếp.
- Firestore Rules giữ nguyên quyền: `admin` và `purchasing` được create/update/delete tại `/config/roll-cay-canh/plants`; không cấp quyền `/apps` hay `packingOrders` cho `purchasing`.

## Giữ nguyên
- Giao diện Báo giá V25.4.5.
- Chọn cây lấy Tên / Kích thước / Giá / Hình ảnh từ Danh mục cây.
- Tổng giá = Σ (Đơn giá × Số lượng).
- Xuất CSV.
- Xuất PDF A4 native 595×842 pt với background `quote-bg.jpg`.
- Android V25.4 đang vận hành và dữ liệu nghiệp vụ không bị đổi cấu trúc.

## Android build
- `versionCode = 24`
- `versionName = 25.4.6`
- Giữ nguyên SDK/target và cấu trúc project của V25.4.5.
