# Quản Lý Cây APK

Ứng dụng Android chuyển logic từ Excel sang giao diện điện thoại.

## Chức năng
- Điều khiển: sửa tên nhân viên, đơn giá công đóng hàng, thêm/sửa/xóa danh mục cây.
- Theo dõi theo ngày từ 01/09/2026 đến hết 31/12/2027.
- Không khóa số lượng cây, nhân viên hay danh mục.
- Tính tiền công theo đơn giá kích thước.
- Theo dõi nhập, xuất và tồn.
- Tổng quan theo ngày/tháng/năm và kỳ 7 ngày.
- Dữ liệu lưu ngay trên điện thoại bằng localStorage.
- Xuất/nhập dữ liệu JSON để sao lưu.

## Build APK
GitHub Actions đã được cấu hình. Sau khi đưa project lên GitHub:
Actions -> Build APK -> Run workflow.
Sau khi chạy xong, vào workflow -> Artifacts -> QuanLyCayAPK-debug để tải APK.
