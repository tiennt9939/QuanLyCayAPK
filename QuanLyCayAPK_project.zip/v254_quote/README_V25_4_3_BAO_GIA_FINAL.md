# ROLL CÂY CẢNH Android V25.4.3 — BÁO GIÁ FINAL

## Baseline
- Dựa trực tiếp trên source Android V25.4.2 được cung cấp.
- Không thay đổi luồng đóng hàng, nhập kho, tồn kho, tiền công, phân công đơn, hoàn thành đơn và báo cáo.
- Không thay đổi dữ liệu Firebase production.

## Báo giá
- Giao diện **Báo giá** dùng danh mục cây hiện có.
- Tự lấy đúng: **Tên sản phẩm, Kích thước, Giá, Hình ảnh** từ danh mục cây.
- Có số lượng từng dòng, thành tiền từng dòng và **TỔNG GIÁ** toàn đơn.
- Có tìm kiếm theo tên/kích thước.
- Xuất **CSV**.
- Xuất **PDF A4** thông qua chức năng in/lưu PDF của Android.
- PDF dùng đúng background ROLL GARDEN do người dùng cung cấp (`quote-background.png`, 1087×1536, SHA-256 `9c3965014db664df3caa1b42a85488c9a9c5557685e3c55d8b81625729655251`).
- Đã căn lại vùng nội dung PDF xuống dưới phần logo/sóng đầu trang để không chồng lên artwork.

## Quyền Nhân viên thu mua
Role chuẩn: `procurement` (alias `purchaser` cũ vẫn được nhận diện).
- Được: **Báo giá**.
- Trong **Điều khiển** chỉ được nhìn thấy/thao tác **Danh mục cây**.
- Không hiển thị các chức năng còn lại của Điều khiển.
- Không hiển thị Đóng hàng, Nhập kho, Tồn kho, Báo cáo, Quản lý tài khoản.

## Kiểm thử đã thực hiện trong môi trường build
1. Kiểm tra ZIP và cấu trúc Android project.
2. Kiểm tra background trong source trùng byte với background người dùng cung cấp.
3. Parse syntax toàn bộ JavaScript inline bằng `node --check`.
4. Kiểm tra AndroidManifest/Gradle/source assets tồn tại.
5. Kiểm tra quyền `procurement`/`purchaser` và các quyền quote/catalog.
6. Render thử bố cục PDF A4 bằng engine PDF cục bộ: đúng 1 trang A4, background hiển thị đúng, tiêu đề/nội dung không chồng logo.

## Giới hạn xác nhận
Môi trường hiện tại không có Android SDK/Gradle Android toolchain đầy đủ để chạy `assembleDebug` trực tiếp. Vì vậy không tuyên bố đã cài đặt/chạy APK thật trên thiết bị. Source đã được kiểm tra tĩnh và bố cục PDF đã được render thực tế.
