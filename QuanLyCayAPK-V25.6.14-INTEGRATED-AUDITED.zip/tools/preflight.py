from pathlib import Path
import hashlib, re, json, xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
java=ROOT/'app/src/main/java/com/quanlycay/apk/MainActivity.java'
html=ROOT/'app/src/main/assets/index.html'
manifest=ROOT/'app/src/main/AndroidManifest.xml'
gradle=ROOT/'app/build.gradle.kts'
for f in (java,html,manifest,gradle): assert f.is_file(), f
j=java.read_text(encoding='utf-8')
h=html.read_text(encoding='utf-8')
g=gradle.read_text(encoding='utf-8')
assert len(re.findall(r'@JavascriptInterface',j))==5
assert 'ocrShippingImage' in j and 'sendToFlashLabel' in j
assert 'new PrintDocumentAdapter.LayoutResultCallback' not in j
assert 'new PrintDocumentAdapter.WriteResultCallback' not in j
assert 'versionName = "25.6.14"' in g and 'versionCode = 39' in g
assert 'com.google.mlkit:text-recognition:16.0.1' in g
for token in ['refreshCatalogForAssignment','catalogId:String(x.catalogId||\'\')','adminCompletePackingOrder','completionImages','assignPlantSearch','payrollEntries','saveSalaryAdvance','exportPayrollCsv','sendPackingOrderToFlashLabel','ocrShippingImage','shipmentTracking','shipmentCarrier','J&T','GHN','Cargo']:
    assert token in h, token
assert 'AndroidBridge.sendToFlashLabel' in h
assert 'AndroidBridge.ocrShippingImage' in h
ET.parse(manifest)
print('PREFLIGHT PASS')
print('Version: 25.6.14 / code 39')
print('Native JS bridges: 5')
print('OCR: PASS')
print('FlashLabel handoff: PASS')
print('Assignment catalogId root fix: PASS')
print('Admin assigned-order completion/pay: PASS')
print('Payroll + advance + export: PASS')
print('Shipment tracking J&T/Cargo/GHN: PASS')
