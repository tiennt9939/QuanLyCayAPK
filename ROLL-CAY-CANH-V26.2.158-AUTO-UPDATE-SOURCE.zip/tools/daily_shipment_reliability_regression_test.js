'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert'),{performance}=require('perf_hooks');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8').replace(/\r\n/g,'\n');
const main=fs.readFileSync(path.join(root,'app/src/main/java/com/quanlycay/apk/MainActivity.java'),'utf8');
const start=html.indexOf('  async function recordDailyShipmentScan(report,orderPatch){');
const end=html.indexOf('  async function attachDailyShipmentPhoto(trackingNo,photoRef,expectedScan={}){',start);
assert(start>=0&&end>start,'Could not isolate the production Firestore transaction function');
const transactionSource=html.slice(start,end);
const store=new Map();let failNextCommit=false,lock=Promise.resolve();
const key=(collection,id)=>collection+'/'+id;
function ref(collection,id){return {collection,id,key:key(collection,id),async get(){const d=store.get(key(collection,id));return {exists:d!==undefined,data:()=>d}},};}
const rootRef=ref('apps','roll-cay-canh');store.set(rootRef.key,{dailyShipmentStorageSchema:2,data:{}});
const db={collection(name){return {doc(id){return ref(name,String(id))}}},async runTransaction(work){let release;const prior=lock;lock=new Promise(resolve=>release=resolve);await prior;const writes=[];try{const tx={async get(r){const d=store.get(r.key);return {exists:d!==undefined,data:()=>d}},set(r,value,options){writes.push({r,value,options})},update(r,value){writes.push({r,value,update:true})},delete(r){writes.push({r,delete:true})}};const result=await work(tx);if(failNextCommit){failNextCommit=false;throw new Error('simulated commit interruption')}for(const w of writes){if(w.delete)store.delete(w.r.key);else if(w.update||w.options?.merge)store.set(w.r.key,{...(store.get(w.r.key)||{}),...w.value});else store.set(w.r.key,w.value)}return result}finally{release()}}};
const context={
  console,Date,Math,Number,String,Array,Object,Set,Map,Promise,Error,JSON,RegExp,
  DAILY_SHIPMENT_STORAGE_SCHEMA:2,
  user:{uid:'emp-huy'},profile:{employeeName:'Huy',employeeId:'emp-huy'},
  role:()=> 'packer',db,D:{dailyShipmentOrders:[],dailyShipmentReports:[]},
  normalizeTracking:v=>String(v||'').toUpperCase().replace(/[^A-Z0-9]/g,''),
  cleanDailyShipmentFirestoreValue:v=>v===undefined?null:v&&typeof v==='object'?Array.isArray(v)?v.map(x=>context.cleanDailyShipmentFirestoreValue(x)):Object.fromEntries(Object.entries(v).map(([k,x])=>[k,context.cleanDailyShipmentFirestoreValue(x)])):v,
  shipmentRecordEnvelope:(record,kind)=>({record,recordKind:kind}),sharedRef:()=>rootRef,
  dailyShipmentOrdersRef:()=>db.collection('apps/roll-cay-canh/dailyShipmentOrders'),
  dailyShipmentReportsRef:()=>db.collection('apps/roll-cay-canh/dailyShipmentReports'),
  fmt:()=> '2026-10-31',ensureDailyShipmentStorageMigrated:async()=>{}
};
context.window={__rollDailyShipmentSchemaReady:true};
context.firebase={firestore:{FieldValue:{serverTimestamp:()=>({serverTimestamp:true})}}};
context.sharedRef=context.sharedRef;
vm.createContext(context);vm.runInContext(transactionSource,context,{filename:'production-recordDailyShipmentScan.js'});
function makeOrder(tracking,uid,name,employeeId){
 const order={trackingNo:tracking,carrier:'GHN',orderId:'pdf_'+tracking,source:'pdf_label',products:[{productName:'Test plant',qty:2}],date:'2026-10-31',status:'imported',assignmentRequired:true,assignedUid:uid,assignedEmployeeName:name,assignedEmployeeId:employeeId,assignmentRevision:1};
 store.set(key('apps/roll-cay-canh/dailyShipmentOrders',tracking),{record:order});context.D.dailyShipmentOrders.push(order);return order;
}
function makeReport(order){return {id:'daily_'+order.trackingNo,operationId:'daily_'+order.trackingNo+'_stable_test_operation',actorUid:order.assignedUid,scanRevision:1,trackingNo:order.trackingNo,carrier:'GHN',employee:order.assignedEmployeeName,employeeName:order.assignedEmployeeName,employeeId:order.assignedEmployeeId,laborPay:6000,payAmount:6000,wageRecorded:true,wageStatus:'recorded',photoRef:'local-queue://daily_'+order.trackingNo,items:[{catalogId:'plant-c9',plantName:'Test plant',size:'C9',qty:2}],totalPlantQty:2,date:'2026-10-31',scannedAtMs:Date.now()};}
function makePatch(order){return {trackingNo:order.trackingNo,carrier:'GHN',source:'pdf_label',products:order.products,orderId:order.orderId,date:order.date,assignmentRequired:true,assignedUid:order.assignedUid,assignedEmployeeName:order.assignedEmployeeName,assignedEmployeeId:order.assignedEmployeeId,assignmentRevision:1};}
async function scan(order){context.user={uid:order.assignedUid};context.profile={employeeName:order.assignedEmployeeName,employeeId:order.assignedEmployeeId};return await context.recordDailyShipmentScan(makeReport(order),makePatch(order));}
function doc(collection,tracking){return store.get(key(collection,tracking))}
function validateRecorded(order){const tracking=order.trackingNo,claim=doc('shipmentTrackingClaims',tracking),scan=doc('dailyShipmentScans',tracking),report=doc('apps/roll-cay-canh/dailyShipmentReports',tracking),queue=doc('apps/roll-cay-canh/dailyShipmentOrders',tracking);assert(claim&&scan&&report&&queue,'Atomic scan must write claim, scan, report and queue row');const r=report.record;assert.equal(r.employeeId,order.assignedEmployeeId);assert.equal(r.totalPlantQty,2);assert.equal(r.laborPay,6000);assert.equal(r.photoRef,'local-queue://daily_'+tracking);assert.equal(queue.record.status,'recorded');assert.equal(claim.employeeId,order.assignedEmployeeId);}
(async()=>{
 // Two consecutive labels: both get durable photo references and all four transactional records.
 const first=makeOrder('SIM00000001','emp-huy','Huy','emp-huy'),second=makeOrder('SIM00000002','emp-huy','Huy','emp-huy');
 await scan(first);await scan(second);validateRecorded(first);validateRecorded(second);
 // Failure before commit leaves no partial documents; retry is safe and writes exactly once.
 const retry=makeOrder('SIM00000003','emp-huy','Huy','emp-huy');failNextCommit=true;await assert.rejects(scan(retry),/simulated commit interruption/);assert(!doc('shipmentTrackingClaims',retry.trackingNo)&&!doc('apps/roll-cay-canh/dailyShipmentReports',retry.trackingNo),'Failed transaction must not leave a partial completion');await scan(retry);validateRecorded(retry);
 // Same label twice returns the canonical existing report; no second wage/report is created.
 const duplicate=await scan(retry);assert.equal(duplicate.alreadyRecorded,true);assert.equal([...store.keys()].filter(k=>k==='apps/roll-cay-canh/dailyShipmentReports/'+retry.trackingNo).length,1);assert.equal(doc('apps/roll-cay-canh/dailyShipmentReports',retry.trackingNo).record.laborPay,6000);
 // Offline: no Firestore writes, then durable native outbox survives simulated app restart.
 const offline=makeOrder('SIM00000004','emp-huy','Huy','emp-huy'),priorDb=context.db;context.db=null;await assert.rejects(scan(offline),/Error/);assert(!doc('shipmentTrackingClaims',offline.trackingNo));context.db=priorDb;
 const nativeStore=new Map(),bridge={putOfflineJsonRecord:(name,id,json)=>{nativeStore.set(name+'/'+id,json);return true},listOfflineJsonRecords:name=>JSON.stringify([...nativeStore.entries()].filter(([k])=>k.startsWith(name+'/')).map(([,v])=>JSON.parse(v)))};
 const queueContext={Date,Number,String,Array,JSON,Error,Promise,window:{AndroidBridge:bridge},AndroidBridge:bridge,DAILY_SHIPMENT_OUTBOX_NATIVE_STORE:'daily-shipment-outbox-v1',dailyShipmentOfflineOutbox:null,normalizeTracking:context.normalizeTracking,renderDailyShipmentRetryPanel(){}};
 vm.createContext(queueContext);const qStart=html.indexOf('function dailyShipmentOfflineOutboxRows('),qEnd=html.indexOf('function renderDailyShipmentRetryPanel()',qStart);vm.runInContext(html.slice(qStart,qEnd),queueContext);
 queueContext.dailyShipmentOfflineOutboxSave({trackingNo:offline.trackingNo,path:'native-photo-'+offline.trackingNo,report:makeReport(offline),orderPatch:makePatch(offline),employeeName:'Huy',status:'pending',attempts:0});queueContext.dailyShipmentOfflineOutbox=null;assert.equal(queueContext.dailyShipmentOfflineOutboxRows(true).length,1,'Offline work must survive JS/WebView recreation through the native persistent bridge');
 assert(main.includes('writeSynced(tmp, json.getBytes(StandardCharsets.UTF_8))')&&main.includes('replaceFile(tmp, target)'),'Native offline queue must use the fsynced atomic file store');
 // Two employees process separate assignments; recipient attribution must stay per order.
 const huy=makeOrder('SIM00000005','emp-huy','Huy','emp-huy'),lan=makeOrder('SIM00000006','emp-lan','Lan','emp-lan');await scan(huy);validateRecorded(huy);await scan(lan);validateRecorded(lan);assert.equal(doc('apps/roll-cay-canh/dailyShipmentReports',lan.trackingNo).record.employee,'Lan');
 // Read-only reconciliation flags legacy recorded rows lacking canonical report/payroll without mutating data.
 const helperStart=html.indexOf('function dailyShipmentReconciliationFindings('),helperEnd=html.indexOf('\nasync function previewDailyShipmentRecordedReconciliation()',helperStart);assert(helperStart>=0&&helperEnd>helperStart,'Read-only reconciliation classifier missing');
 const auditContext={normalizeTracking:context.normalizeTracking,Set,String,Number,Array,Object};vm.createContext(auditContext);vm.runInContext(html.slice(helperStart,helperEnd),auditContext);const legacy={trackingNo:'OLD00000001',order:{status:'recorded'},report:null,scan:null,claim:null};const before=JSON.stringify(legacy),finding=auditContext.dailyShipmentReconciliationFindings(legacy);assert(finding.issues.includes('orphan_recorded_status')&&finding.issues.includes('report_missing'));assert.equal(JSON.stringify(legacy),before,'Audit classifier must not mutate inspected production-shaped records');
 const badWage=auditContext.dailyShipmentReconciliationFindings({trackingNo:'OLD00000002',order:{status:'recorded'},report:{status:'recorded',employee:'Huy',employeeId:'emp-huy',items:[{catalogId:'p',qty:1}],photoRef:'local-queue://x'},scan:{status:'recorded'},claim:{status:'recorded'}});assert(badWage.issues.includes('wage_missing_or_invalid'));
 const auditFnStart=html.indexOf('async function previewDailyShipmentRecordedReconciliation()'),auditFnEnd=html.indexOf('\nfunction dailyShipmentRefreshStats',auditFnStart),auditFunction=html.slice(auditFnStart,auditFnEnd);assert(!/\.set\(|\.update\(|\.delete\(|runTransaction\(/.test(auditFunction),'Reconciliation preview must not write to Firebase');
 // Performance/reliability: 200 fake assigned labels exercise the actual transaction function.
 const large=[];for(let i=0;i<200;i++)large.push(makeOrder('BULK'+String(i).padStart(8,'0'),'emp-huy','Huy','emp-huy'));
 const began=performance.now();for(const order of large)await scan(order);const elapsed=performance.now()-began;for(const order of large)validateRecorded(order);assert.equal(large.length,200);assert(elapsed<10000,`200 in-memory Firestore transaction simulation exceeded 10s: ${elapsed.toFixed(1)}ms`);
 console.log(`DAILY SHIPMENT RELIABILITY PASS: 2 labels; mid-transaction retry; duplicate; offline + app restart; 2 employees; read-only legacy audit; 200 labels in ${elapsed.toFixed(1)}ms`);
})().catch(e=>{console.error(e);process.exitCode=1});
