const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const source = fs.readFileSync(path.join(__dirname, '..', 'Code.gs'), 'utf8');
const pick = name => {
  const match = source.match(new RegExp('function ' + name + '\\([\\s\\S]*?\\n}'));
  if (!match) throw new Error('Missing function ' + name);
  return match[0];
};
const payload = '{"trackingNo":"VNGH80255380913","note":"before=after"}';
const cut = payload.indexOf('=');
assert(cut > 0, 'fixture must contain a formula-like legacy chunk');
const chunks = [payload.slice(0, cut), payload.slice(cut)];
const rows = {
  2: { value: chunks[0], formula: '' },
  3: { value: '#ERROR!', formula: '=' + chunks[1] }
};
const sheet = {
  getRange(start, column, rowCount, width) {
    assert.strictEqual(column, 5, 'payload data must remain in column E');
    return {
      getValues() { return Array.from({length: rowCount}, (_, i) => [rows[start + i]?.value ?? '']); },
      getFormulas() { return Array.from({length: rowCount}, (_, i) => [rows[start + i]?.formula ?? '']); }
    };
  }
};
const context = {
  String, Number, Object, Array, Math, JSON,
  fsCompatError_: (code, message) => Object.assign(new Error(message), {code}),
  fsCompatNormalizeDocPath_: value => String(value).replace(/^\/+|\/+$/g, ''),
  fsCompatJoinPayloadChunks_: parts => parts.join(''),
  fsCompatReadPayloadChunks_: null,
  fsCompatReadPayloadFormulaChunks_: null
};
vm.createContext(context);
vm.runInContext(pick('fsCompatReadPayloadChunks_') + '\n' + pick('fsCompatReadPayloadFormulaChunks_') + '\n' + pick('fsCompatMaterializeIndex_'), context);
const metadata = {'apps/roll-cay-canh/dailyShipmentOrders/VNGH80255380913': {
  path: 'apps/roll-cay-canh/dailyShipmentOrders/VNGH80255380913',
  collectionPath: 'apps/roll-cay-canh/dailyShipmentOrders',
  id: 'VNGH80255380913', version: 17, chunkCount: 2,
  chunks: {0: 2, 1: 3}, updatedAtMs: 0, updatedBy: '', deleted: false
}};
const result = context.fsCompatMaterializeIndex_(sheet, metadata, [metadata[Object.keys(metadata)[0]].path]);
const item = result[Object.keys(metadata)[0]];
assert.strictEqual(item.data.trackingNo, 'VNGH80255380913', 'formula-recovered JSON must materialize the original order');
assert.strictEqual(item.data.note, 'before=after', 'formula-recovered JSON must preserve all properties');
assert.strictEqual(item.recoveredFormulaChunkCount, 1, 'recovery must be visible to the read-only diagnostic');
assert.strictEqual(rows[3].value, '#ERROR!', 'recovery must not mutate the damaged spreadsheet cell');
assert.strictEqual(rows[3].formula, '=' + chunks[1], 'recovery must not rewrite the original formula');

const brokenSheet = {
  getRange(start, column, rowCount) {
    return {
      getValues() { return Array.from({length: rowCount}, (_, i) => [start + i === 2 ? '{"a":' : 'broken']); },
      getFormulas() { return Array.from({length: rowCount}, () => ['']); }
    };
  }
};
assert.throws(() => context.fsCompatMaterializeIndex_(brokenSheet, metadata, [metadata[Object.keys(metadata)[0]].path]), /Invalid document JSON/,
  'unrecoverable legacy corruption must still fail closed');
console.log('GAS LEGACY FORMULA-CHUNK RECOVERY REGRESSION: PASS');
