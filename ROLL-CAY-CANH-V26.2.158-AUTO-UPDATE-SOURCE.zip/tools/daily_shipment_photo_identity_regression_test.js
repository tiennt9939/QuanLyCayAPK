const fs = require('fs');
const path = require('path');
const assert = require('assert');
const html = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/index.html'), 'utf8');
const recordStart = html.indexOf('async function recordDailyShipmentScan(');
const attachStart = html.indexOf('async function attachDailyShipmentPhoto(');
const cancelStart = html.indexOf('async function cancelDailyShipmentScan(');
const record = html.slice(recordStart, attachStart);
const attach = html.slice(attachStart, cancelStart);
const captureStart = html.indexOf('async function dailyShipmentProcessCapture(');
const captureEnd = html.indexOf('function dailyShipmentLooksLikeConnectivityFailure', captureStart);
const capture = html.slice(captureStart, captureEnd);
const driveStart = html.indexOf('async function dailyShipmentProcessDrivePhoto(');
const driveEnd = html.indexOf('async function dailyShipmentProcessCapture(', driveStart);
const drive = html.slice(driveStart, driveEnd);
assert(record.includes('const sameOperation=') && record.includes('currentReport.operationId'),
  'Only retry of the same operation may be treated as already recorded');
assert(record.includes('legacyReport') && record.includes('duplicate:true'),
  'Legacy reports without immutable capture identity must fail closed');
assert(attach.includes('expectedOperationId') && attach.includes('expectedScanRevision') && attach.includes('expectedActorUid'),
  'Photo attachment must require operation, revision and actor identity');
assert(attach.includes('prior.operationId') && attach.includes('claim.scanRevision') && attach.includes('d.actorUid') && attach.includes('claim.completedBy') && attach.includes('claim.employeeId'),
  'Photo attachment must verify the exact committed scan identity');
assert(attach.includes('prior.photoRef)!==driveRef'),
  'A different Drive photo must never silently replace an already attached photo');
assert(drive.includes('report.operationId') && drive.includes('report.scanRevision') && drive.includes('report.actorUid'),
  'Online photo worker must pass the exact scan identity');
assert(capture.includes('result?.duplicate&&existing') && capture.includes('không gắn nhầm ảnh'),
  'A duplicate from another capture must retain the new photo for review, not attach it to old report');
assert(record.includes('__rollDailyShipmentSchemaReady!==true'),
  'Shared storage schema preflight must not add a root read for every barcode');
assert(capture.includes('recordDailyShipmentScan(reportDraft,reportOrderPatch),20000'),
  'Firebase scan/wage confirmation must not be abandoned after the old 8-second deadline');
console.log('DAILY SHIPMENT PHOTO IDENTITY REGRESSION: PASS');
