const fs = require('fs');
const path = require('path');
const assert = require('assert');
const gas = fs.readFileSync(path.join(__dirname, '..', 'Code.gs'), 'utf8');
const materialize = gas.slice(gas.indexOf('function fsCompatMaterializeIndex_'), gas.indexOf('function fsCompatBuildIndexForPaths_'));
assert(materialize.includes('JSON.parse(fsCompatJoinPayloadChunks_(parts,item.path))'),
  'Document materialization must decode Base64url chunks and still support legacy JSON chunks');
const diagnostic = gas.slice(gas.indexOf('function diagnoseKnownBrokenRollDocuments'), gas.indexOf('function fsCompatReadCurrentDoc_'));
assert(diagnostic.includes('dailyShipmentOrders/VNGH80255380913'),
  'Read-only diagnostic must include the tracking document currently failing in the app');
assert(diagnostic.includes('parseError') && diagnostic.includes('formulaPresent'),
  'Diagnostic must report parse errors and formula state without writing document data');
assert(diagnostic.includes('formulaCouldRestoreLegacyChunk') && materialize.includes('fsCompatReadPayloadFormulaChunks_'),
  'Diagnostic and reader must detect and recover legacy formula-coerced payload chunks');
assert(materialize.includes('recoveredFormulaChunkCount'),
  'Recovered chunks must be counted for read-only verification without exposing payload contents');
console.log('CURRENT DAILY DOCUMENT DIAGNOSTIC TEST PASS');
