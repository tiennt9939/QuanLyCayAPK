'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const code = fs.readFileSync(require('node:path').join(__dirname, '../Code.gs'), 'utf8');
const start = code.indexOf('function handleFirestoreCompatRequest_(body)');
const end = code.indexOf('function fsCompatResult_(', start);
assert(start >= 0 && end > start, 'Full GAS handler must be present');
const handlerSource = code.slice(start, end);
const authzSource = code.slice(code.indexOf('function fsCompatBuildGetManyResponse_('), code.indexOf('function fsCompatReadLatestMetadata_('));
let identity = {uid:'staff-1',role:'packer',active:true,isAdmin:false,isProcurement:false,profile:{employeeId:'E1'}};
let metadata = {};
let enabledWrites = false;
const properties = {};
const context = {
  console, Date, String, Number, Object, Array, Math, JSON,
  ROLL_FS_COMPAT:{VERSION:'gas-firestore-compat-phase3.3-safe-base64-payload-chunks',MAX_QUERY_DOCS:5000},
  LockService:{getScriptLock:()=>({waitLock(){},releaseLock(){}})},
  PropertiesService:{getScriptProperties:()=>({getProperty:key=>key==='ROLL_ADMIN_UIDS'?'':properties[key]||'',setProperty:(key,value)=>{properties[key]=String(value)}})},
  fsCompatAuthenticate_:()=>identity,
  fsCompatNormalizeDocPath_:path=>String(path).replace(/^\/+|\/+$/g,''),
  fsCompatNormalizeCollectionPath_:path=>String(path).replace(/^\/+|\/+$/g,''),
  fsCompatBuildIndexForPaths_:paths=>Object.fromEntries(paths.filter(p=>docs[p]).map(p=>[p,docs[p]])),
  fsCompatCanReadPath_:(actor,path,data)=>{
    if(actor.isAdmin)return true;
    if(path.startsWith('packingOrders/'))return actor.active&&actor.role==='packer'&&data&&data.assignedUid===actor.uid;
    if(path.startsWith('dailyShipmentScans/')||path.startsWith('shipmentTrackingClaims/'))return !!actor.active;
    if(path.startsWith('users/'))return path==='users/'+actor.uid;
    return false;
  },
  fsCompatResult_:(ok,data,error,message)=>({ok,data,error:error?{code:error,message}:null,version:'test'}),
  fsCompatError_:(code,message)=>Object.assign(new Error(message),{code}),
  fsCompatCutoverCompleted_:()=>false,
  fsCompatWritesEnabled_:()=>enabledWrites,
  fsCompatSheet_:()=>({}),
  fsCompatReadLatestMetadata_:()=>metadata,
  fsCompatMaterializeIndex_:(sheet,meta,paths)=>Object.fromEntries(paths.filter(p=>rootDocs[p]).map(p=>[p,rootDocs[p]])),
  fsCompatRequireMigratedAdminProfile_:(meta,uid,allowlist)=>{
    if((!meta['users/'+uid]||meta['users/'+uid].deleted)&&!allowlist.includes(uid))throw Object.assign(new Error('Missing migrated admin profile'),{code:'FAILED_PRECONDITION'});
    return true;
  }
};
const docs={
 'packingOrders/o1':{path:'packingOrders/o1',id:'o1',data:{assignedUid:'staff-1'},version:2,updatedAtMs:10},
 'packingOrders/o2':{path:'packingOrders/o2',id:'o2',data:{assignedUid:'staff-2'},version:3,updatedAtMs:11},
 'dailyShipmentScans/t1':{path:'dailyShipmentScans/t1',id:'t1',data:{actorUid:'staff-1'},version:4,updatedAtMs:12}
};
const rootDocs={'apps/roll-cay-canh':{path:'apps/roll-cay-canh',id:'roll-cay-canh',data:{data:{catalog:[]}},version:1,updatedAtMs:1}};
vm.createContext(context);
vm.runInContext(authzSource+handlerSource,context);
(async()=>{
  const packerReads=await context.handleFirestoreCompatRequest_({action:'fsCompat',command:'getMany',idToken:'ignored',paths:['packingOrders/o1','dailyShipmentScans/t1']});
  assert.equal(packerReads.ok,true,'active packer transaction reads should not be blocked by Admin-only gate');
  assert.equal(packerReads.data.documents.length,2);
  assert.equal(packerReads.data.documents[0].data.assignedUid,'staff-1');
  identity={uid:'staff-1',role:'packer',active:true,isAdmin:false,isProcurement:false,profile:{employeeId:'E1'}};
  const denied=await context.handleFirestoreCompatRequest_({action:'fsCompat',command:'getMany',idToken:'ignored',paths:['packingOrders/o2']});
  assert.equal(denied.ok,false);
  assert.equal(denied.error.code,'PERMISSION_DENIED');
  identity={uid:'admin-1',role:'admin',active:true,isAdmin:true,isProcurement:false,profile:{}};
  metadata={'users/admin-1':{deleted:false,version:1},'apps/roll-cay-canh':{deleted:false,version:1}};
  const checksum='fnv32x2-0123456789abcdef-docs2-payloadBytes20';
  const finalized=await context.handleFirestoreCompatRequest_({action:'fsCompat',command:'finalizeMigration',idToken:'ignored',report:{verifiedAll:true,totalDocuments:2,verifiedDocuments:2,allDocumentsChecksum:checksum}});
  assert.equal(finalized.ok,true,'migration finalizer must not reference undefined finalIndex');
  assert.equal(finalized.data.cutoverCompleted,true);
  assert.equal(properties.ROLL_GAS_CUTOVER_COMPLETED,'true');
  assert.equal(properties.ROLL_GAS_COMPAT_WRITES_ENABLED,'true');
  console.log('GAS handler: packer getMany authorization + verified migration finalization: PASS');
})().catch(error=>{console.error(error);process.exitCode=1;});
