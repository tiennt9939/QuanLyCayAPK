'use strict';
const fs = require('fs');
const vm = require('vm');
const source = fs.readFileSync('Code.gs', 'utf8');
if (!/JSON\.parse\(fsCompatJoinPayloadChunks_\(parts,item\.path\)\)/.test(source)) {
  throw new Error('materialize reader does not decode payload chunks before JSON.parse');
}
const pick = name => {
  const re = new RegExp('function ' + name + '\\([\\s\\S]*?\\n}');
  const match = source.match(re);
  if (!match) throw new Error('Missing function ' + name);
  return match[0];
};
const Utilities = {
  Charset: { UTF_8: 'UTF-8' },
  base64EncodeWebSafe(value) {
    return Buffer.from(String(value), 'utf8').toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  },
  base64DecodeWebSafe(value) {
    let s = String(value).replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    return Buffer.from(s, 'base64');
  },
  newBlob(bytes) { return { getDataAsString: () => Buffer.from(bytes).toString('utf8') }; }
};
const context = { Utilities, fsCompatError_: (code, message) => Object.assign(new Error(message), { code }) };
vm.createContext(context);
vm.runInContext(pick('fsCompatSplitPayload_') + '\n' + pick('fsCompatJoinPayloadChunks_'), context);
const payload = JSON.stringify({ path: 'apps/roll-cay-canh', greeting: 'Cây cảnh 🌱', payload: 'x'.repeat(50000), edge: '=this must remain text' });
const chunks = context.fsCompatSplitPayload_(payload);
if (chunks.length < 2) throw new Error('Expected multiple chunks for long payload');
if (!chunks.every(x => x.startsWith('~ROLLB64V1~'))) throw new Error('Encoded marker missing');
const reconstructed = context.fsCompatJoinPayloadChunks_(chunks, 'apps/roll-cay-canh');
if (reconstructed !== payload) throw new Error('Base64url round-trip mismatch');
if (JSON.parse(reconstructed).greeting !== 'Cây cảnh 🌱') throw new Error('UTF-8 payload did not survive round-trip');
const legacy = '{"legacy":true,"value":"old raw JSON"}';
if (context.fsCompatJoinPayloadChunks_([legacy], 'legacy/doc') !== legacy) throw new Error('Legacy raw JSON compatibility failed');
let mixedRejected = false;
try { context.fsCompatJoinPayloadChunks_(['~ROLLB64V1~' + chunks[0].slice('~ROLLB64V1~'.length), legacy], 'mixed/doc'); }
catch (e) { mixedRejected = /Mixed legacy and encoded chunks/.test(e.message); }
if (!mixedRejected) throw new Error('Mixed legacy/encoded chunks must fail closed');
console.log('GAS BASE64 PAYLOAD ROUNDTRIP REGRESSION: PASS');
