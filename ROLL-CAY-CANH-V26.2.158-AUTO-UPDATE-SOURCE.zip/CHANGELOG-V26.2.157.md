# ROLL CÂY CẢNH V26.2.157 — versionCode 209

- Keep daily scan/wage commit independent from Google Drive photo upload.
- Bind each photo upload to the exact scan operation, scan revision, actor UID and employee ID.
- Reject stale queued photos after a scan is voided/re-recorded; never replace an already attached different Drive photo.
- Legacy reports without immutable scan identity fail closed for automatic photo attachment and require Admin reconciliation.
- A retry is idempotent only when its operationId matches the committed scan; a different capture of the same tracking number cannot donate its photo to the old report.
- Cache the daily-shipment storage schema preflight per app session, avoiding an extra shared-root read for every barcode. The Firestore transaction still validates assignment and writes the scan, wage and unique claim atomically.
- Firebase confirmation timeout increased from 8 to 15 seconds to reduce false offline queuing while the transaction is still completing.
- No production data, Firestore schema, payroll formula, inventory logic, plant recognition rules or assignment records were modified.
