# V26.2.157 — Photo identity and scan latency audit/fix

## Required behavior
1. Firebase scan/wage commit remains the authoritative completion event.
2. Google Drive upload remains independent and retryable.
3. A photo is attached only to the exact scan operation that captured it.
4. A stale image from an earlier scan revision cannot attach to a later scan of the same tracking number.
5. Existing different Drive evidence is never silently replaced.

## Code changes
- `recordDailyShipmentScan`: only the same `operationId` is an idempotent retry. Different operation IDs are treated as duplicates; legacy records without an operation identity are not auto-attached.
- `attachDailyShipmentPhoto`: requires operationId, scanRevision, actorUid and employeeId; checks current scan/report/claim before writing the Drive reference.
- Online and offline photo workers pass immutable scan identity.
- `dailyShipmentProcessCapture`: retains a different capture's image for Admin review rather than attaching it to an existing report.
- Storage schema preflight is cached per app session, removing one redundant shared-root read per barcode.
- Firebase confirmation timeout increased from 8 to 15 seconds to reduce false offline queuing.

## Safety
- No writes to production Firebase/Sheets/Drive.
- No Firestore schema or security rules changes.
- No changes to payroll formulas, inventory, catalog, plant matching, PDF parsing or assignment logic.
- Old photo queue entries without a complete scan identity will not be attached automatically; Admin reconciliation is required.
