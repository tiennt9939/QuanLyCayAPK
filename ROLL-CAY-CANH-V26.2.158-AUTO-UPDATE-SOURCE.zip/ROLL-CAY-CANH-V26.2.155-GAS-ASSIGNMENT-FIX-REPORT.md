# ROLL CÂY CẢNH V26.2.155 — Sửa lỗi JSON GAS và tối ưu chia đơn PDF

## Thông tin bản source
- `versionName`: `26.2.155`
- `versionCode`: `207`
- Android package: `com.quanlycay.apk`
- Nền tảng: Android WebView + Firebase/Google Apps Script compatibility backend

## Nguyên nhân đã xác minh từ mã nguồn và ảnh lỗi

Backend `Code.gs` cũ chia JSON thành các đoạn văn bản thô 40.000 ký tự rồi ghi bằng `SpreadsheetApp.Range.setValues()`. Tài liệu chính thức Apps Script xác nhận chuỗi bắt đầu bằng `=` được diễn giải là công thức. Vì ranh giới cắt JSON không cố định theo nội dung, một đoạn có thể bắt đầu đúng bằng `=`, khiến Google Sheets lưu kết quả công thức thay vì văn bản JSON. Khi backend ghép các đoạn để đọc, nó báo `Invalid document JSON at ...`. Hai đường dẫn hiển thị trên ảnh là:
- `packingOrders/r8t3lozwndukpcuk73i5`
- `apps/roll-cay-canh/dailyShipmentOrders/VNGH80746660914`

## Các thay đổi trong V26.2.155

### 1. GAS document payload integrity
- Payload mới được mã hóa base64url trước khi chia đoạn và lưu vào sheet; mọi chunk có marker `~ROLLB64V1~`, không thể bị hiểu thành công thức `=`.
- Reader nhận cả chunk mới đã mã hóa và chunk cũ dạng văn bản thô, giữ tương thích ngược.
- Sau khi ghi, GAS đọc lại và so sánh toàn bộ tài liệu vừa ghi trước khi compact/xóa các phiên bản cũ. Nếu xác minh thất bại, các hàng phiên bản cũ được giữ nguyên.
- Cập nhật chuỗi tương thích GAS sang `gas-firestore-compat-phase3.3-safe-base64-payload-chunks`; APK sẽ yêu cầu đúng bản máy chủ này.
- Thêm hàm `diagnoseKnownBrokenRollDocuments()` để kiểm tra chỉ đọc hai tài liệu trong ảnh, báo số đoạn, độ dài và dấu hiệu ô công thức. Hàm không sửa hoặc xóa dữ liệu.

### 2. PDF group assignment performance
- Danh sách nhãn được chọn được chuẩn bị/xác minh một lần trước khi chạy các transaction phân công.
- Loại bỏ thao tác lưu lại cùng một nhóm nhãn bên trong từng transaction chunk.
- Tăng kích thước transaction từ 10 lên 18 nhãn. Mỗi nhãn cần tối đa năm lượt đọc tài liệu; 18 nhãn tương ứng 90 lượt đọc, nằm dưới giới hạn 100 đường dẫn của GAS `getMany`, vẫn chừa chỗ cho lần đọc root trong trường hợp xử lý đơn legacy.
- Transaction vẫn xác minh queue record, tracking claim, scan, đơn cũ, report và trạng thái đã ghi nhận trước khi đổi người phụ trách.
- Các lần chuyển nhân viên vẫn lưu `assignmentHistory` và `assignmentRevision`; thao tác chia đơn không ghi tiền công hoặc tồn kho.

## Kiểm thử thực hiện trên source
- `tools/preflight.py`: PASS.
- 142/142 test JavaScript: PASS.
- 5/5 inline JavaScript blocks: syntax PASS.
- 4/4 external JavaScript assets: syntax PASS.
- `Code.gs` parse/syntax: PASS qua Node syntax parser.
- Kiểm thử round-trip payload base64url với Unicode, JSON lớn, ranh giới chunk đặt đúng trước ký tự `=`: PASS.
- Kiểm tra đọc chunk cũ dạng raw: PASS.
- Kiểm tra phát hiện trường hợp trộn raw/encoded: PASS.

## Giới hạn cần nói rõ
- Source chưa được build thành APK trong môi trường này; không có log build Android hoặc kiểm thử thiết bị thật.
- Chưa triển khai `Code.gs` lên Apps Script production.
- Hai tài liệu GAS đã hỏng từ trước không được tự động tái tạo hoặc xóa. Source mới ngăn phát sinh lỗi tương tự và bổ sung công cụ chẩn đoán chỉ đọc; việc phục hồi nội dung cũ phải dựa vào bản backup hoặc dữ liệu đối chiếu đã xác minh.
- Không có thao tác ghi/xóa dữ liệu production nào được thực hiện trong lần sửa này.

## Giữ nguyên nghiệp vụ
Không thay đổi Firestore collection paths, schema ứng dụng, công thức tiền công, tồn kho, nhận diện cây, quy tắc combo/C7/C9, báo giá, quét mã, hoàn tất đơn hoặc logic phân bổ lương.
