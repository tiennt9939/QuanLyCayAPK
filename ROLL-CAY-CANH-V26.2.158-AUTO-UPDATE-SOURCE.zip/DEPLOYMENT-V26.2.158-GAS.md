# Triển khai riêng Apps Script cho V26.2.158

> Tài liệu này chỉ hướng dẫn triển khai mã. Không chạy migration, repair, cleanup, reset hoặc lệnh xóa dữ liệu.

1. Mở đúng Google Apps Script project đang được Web App của ROLL CÂY CẢNH sử dụng.
2. Sao lưu nội dung `Code.gs` hiện tại vào một bản riêng trước khi thay.
3. Mở `Code.gs` trong source ZIP V26.2.158, sao chép toàn bộ nội dung và thay nội dung file `Code.gs` trong project Apps Script. Không tạo project GAS mới, không thay Script Properties, Spreadsheet ID, Drive folder ID hoặc các quyền hiện có.
4. Save. Mở **Deploy → Manage deployments**. Chọn đúng Web App deployment đang được ứng dụng sử dụng, bấm Edit, chọn **New version**, rồi Deploy. Giữ nguyên loại deployment, quyền chạy và quyền truy cập hiện có.
5. Không chạy hàm sửa dữ liệu nào. Có thể chạy thủ công hàm `diagnoseKnownBrokenRollDocuments()` để chỉ đọc và xem Execution log. Hàm này không ghi/sửa sheet.
6. Kiểm tra trong app trạng thái kết nối/phiên bản GAS. Sau đó dùng một đơn thử nghiệm mới để xác nhận đồng bộ trước khi dùng đơn thật.

Nếu diagnostic cho thấy `recoveredFormulaChunkCount > 0`, tài liệu đã được đọc lại từ công thức gốc còn lưu trong sheet; hàm chẩn đoán không tự ghi nội dung phục hồi trở lại cell. Nếu `parseError` vẫn còn hoặc không có công thức để phục hồi, không tự sửa tay hay xóa row. Khi đó cần phục hồi bản sao lưu chính xác của Spreadsheet hoặc dùng nguồn đơn hàng gốc để đối chiếu.
