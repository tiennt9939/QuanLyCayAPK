# ROLL CÂY CẢNH — Báo cáo hoàn tất source V26.2.158

## Kết luận

Đã tạo source Android đầy đủ **V26.2.158 / versionCode 210** trên nền source V26.2.157, không dựng lại dự án và không thay đổi schema dữ liệu hay nghiệp vụ cốt lõi. Đây là **bản source ứng viên đã qua kiểm thử mã nguồn**; chưa thể gọi là bản đã xác nhận ổn định production vì môi trường thực hiện không có Android SDK/Gradle wrapper, quyền triển khai Apps Script, Firebase/Firestore production hoặc Google Drive production để build APK và chạy kiểm thử thiết bị/live backend.

## Giai đoạn 1 — Khóa baseline và sao lưu

- Đã giữ nguyên source đầu vào V26.2.157 và tạo bản sao làm việc riêng trước khi sửa.
- Đã kiểm tra ZIP đầu vào và cây source giải nén: đầy đủ dự án Android, HTML/JS, Java, Apps Script, Firestore rules, GitHub Actions và các regression tests.
- Không ghi dữ liệu production, không sửa/xóa tài khoản, đơn hàng, danh mục cây, tồn kho, ảnh Drive, bảng công hoặc dữ liệu Firestore.
- Không thay đổi `firestore.rules`, `firestore87.rules`, cấu trúc collection/document hay hợp đồng API GAS.

## Giai đoạn 2 — Rà soát và tối ưu luồng vận hành

- Giữ các tối ưu đã có trong baseline: đọc payload theo cụm hàng liền kề, đường đọc query giới hạn, đồng bộ theo thay đổi thay vì tải toàn bộ dữ liệu, thao tác phân lô có giới hạn, upload ảnh Drive tách khỏi thao tác ghi nhận quét và có hàng đợi thử lại.
- Giữ cơ chế chống ghi trùng theo `operationId` và liên kết ảnh với đúng lượt quét qua `operationId`, `scanRevision`, `actorUid`, `employeeId`; không gán ảnh của lần quét mới vào báo cáo cũ.
- Tăng thời gian chờ xác nhận ghi báo cáo/tiền công từ 8 giây lên 20 giây để giảm tình trạng ứng dụng kết luận quá sớm rằng thao tác ghi thất bại khi backend vẫn đang xử lý. Hàng đợi offline hiện có vẫn được giữ; upload ảnh vẫn chạy nền, không chặn hoàn tất giao diện.
- Không thay đổi cách tính tiền công, giá bán/giá nhập, nhận diện tên cây, quy đổi combo, tồn kho, báo giá, phân quyền hay quy tắc phân đơn.

## Giai đoạn 3 — Xử lý lỗi dữ liệu và tính toàn vẹn ảnh

- Bổ sung nhánh đọc cứu dữ liệu legacy trong `Code.gs`: nếu JSON cũ không parse được, chỉ đọc `getFormulas()` của những hàng payload thuộc tài liệu lỗi; nếu Sheets đã diễn giải chunk bắt đầu bằng `=` thành công thức, thử khôi phục phần text từ chuỗi công thức rồi parse JSON lại.
- Nhánh khôi phục chỉ chạy sau lỗi parse của payload legacy; luồng Base64url mới và đường đọc bình thường không bị thay đổi.
- Không sửa cell, không xóa sheet, không viết lại dữ liệu hỏng. Nếu công thức nguồn không còn hoặc JSON sau khôi phục vẫn không hợp lệ, hệ thống tiếp tục dừng an toàn và báo lỗi `DATA_LOSS`, không đoán dữ liệu.
- Chẩn đoán chỉ đọc `diagnoseKnownBrokenRollDocuments()` được mở rộng cho hai mã vận đơn từng xuất hiện trong log/screenshot: `VNGH80255380913` và `VNGH80746660914`, cùng tài liệu gốc/đơn liên quan. Hàm chỉ ghi log trạng thái/độ dài/có công thức/khả năng phục hồi, không in nội dung đơn và không ghi dữ liệu.
- Cơ sở kỹ thuật: tài liệu Apps Script nêu `setValues()` diễn giải chuỗi bắt đầu bằng `=` thành công thức; `getFormulas()` có thể đọc lại nội dung công thức. Điều này xác nhận cơ chế gây rủi ro có thật, nhưng **chưa xác nhận live row bị lỗi của cửa hàng còn giữ lại công thức gốc**.

## Giai đoạn 4 — Kiểm thử hồi quy và kiểm tra tải mô phỏng

- `python3 tools/preflight.py`: **PASS**.
- Toàn bộ `tools/*_test.js`: **146/146 PASS**.
- JavaScript syntax: **5 inline script blocks + 4 external JS files PASS**.
- Regression riêng về dữ liệu JSON legacy bị chuyển thành công thức: **PASS**; kiểm tra khôi phục đúng JSON, không ghi lại cell gốc, và vẫn fail-closed với dữ liệu không thể cứu.
- Luồng vận đơn: **PASS**; test mô phỏng 200 nhãn hoàn tất trong 21.0 ms trong bộ test cục bộ. Đây là thời gian mô phỏng logic, không phải benchmark mạng/điện thoại thật.
- Photo identity, tích hợp quét + ảnh đóng gói, Firebase timeout, hiệu năng chia PDF và startup/login: **PASS** theo các regression tests hiện có.

## Giai đoạn 5 — Đóng gói source hoàn chỉnh

- ZIP được đóng ở root dự án (không lồng thêm thư mục), đúng tên mà workflow GitHub Actions đang yêu cầu: `ROLL-CAY-CANH-V26.2.158-AUTO-UPDATE-SOURCE.zip`.
- ZIP chứa toàn bộ mã nguồn, workflow, cấu hình, test và báo cáo; không kèm APK, keystore hoặc ZIP source cũ.
- SHA-256 đi kèm trong file `ROLL-CAY-CANH-V26.2.158-SHA256.txt`.

## Các bước còn phải được thực hiện trong môi trường cửa hàng

1. Tải ZIP lên repository `tiennt9939/QuanLyCayAPK` trên nhánh `main`, sau đó chạy workflow `Build ROLL CAY CANH — AUTO-UPDATE SOURCE` và kiểm tra kết quả build, chữ ký APK, artifact.
2. Triển khai riêng `Code.gs` thành **New version** của Apps Script Web App đang dùng. Source ZIP/APK không tự triển khai GAS. Không chạy bất kỳ hàm migration, repair, cleanup hoặc xóa dữ liệu nào.
3. Sau deploy, chạy hàm chỉ đọc `diagnoseKnownBrokenRollDocuments()` trong Apps Script Editor và kiểm tra Logs. Chỉ có thể khôi phục các chunk mà Google Sheets vẫn còn giữ công thức gốc; nếu không thì cần bản sao lưu/nguồn dữ liệu khác.
4. Kiểm thử có kiểm soát trên một tài khoản/đơn thử nghiệm trước khi dùng toàn cửa hàng: tạo/nhận đơn, quét mã, ghi nhận tiền công, chụp ảnh, xác minh ảnh gắn đúng báo cáo, tải báo cáo và thử lại khi mạng chập chờn. Không dùng đơn đang vận hành làm ca thử.

## Giới hạn xác minh

- Không có `gradlew`, Gradle cài cục bộ, Android SDK hoặc thiết bị Android trong môi trường này; do đó không tuyên bố APK đã build thành công hoặc app đã chạy thực tế.
- Không có quyền/credential để đọc bảng Google Sheets, triển khai Apps Script, kiểm tra Firestore production hoặc xác minh ảnh Drive; do đó không tuyên bố dữ liệu đơn `VNGH80255380913` đã được khôi phục trực tiếp.
- Không tự động chuyển đổi employeeId dạng chỉ mục, không migrate schema, không chạm dữ liệu sản xuất.
