# V26.2.158 — Legacy payload recovery and scan commit reliability

- Add a read-only fallback for legacy Google Sheets payload chunks that were mistakenly interpreted as formulas. Recovery reads the formula source and validates the reconstructed JSON before returning it. It never modifies the existing sheet cell.
- Keep the Base64url writer and normal fast read path unchanged; formula reads occur only after a legacy JSON parse failure.
- Improve the read-only diagnostic for the affected tracking document by reporting recoverable formula chunks and recovered chunk count without logging document contents.
- Increase the scan wage/report Firebase confirmation window from 8 seconds to 20 seconds to avoid prematurely queueing an in-flight commit. The Drive photo upload remains a separate retryable background task.
- No changes to Firestore/GAS schemas, plant matching, pricing, payroll formulas, inventory, PDF parsing, assignment rules, or employee identity model.

## Validation boundary

This is source-level recovery code. It can recover legacy cells only when Google Sheets still exposes the original formula text. It cannot reconstruct payload bytes that were permanently overwritten or deleted. The Apps Script `Code.gs` update must be deployed as a new Web App version for the recovery path to run. No live spreadsheet, Firebase, Drive, or employee data was read or modified during this build.
