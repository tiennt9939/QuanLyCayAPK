# ROLL CÂY CẢNH V26.2.156 — versionCode 208

- Daily PDF barcode scanner now decodes QR labels in daily-session mode only.
- A decoded QR is accepted only when its normalized value exactly matches an imported tracking number; promotional/unrelated QR codes remain rejected.
- Normal single-order scanner remains linear-barcode-only.
- Extended the read-only GAS diagnostic to inspect `dailyShipmentOrders/VNGH80255380913`, the document currently reported by the app.
- Preserved the Base64url/legacy JSON read compatibility fix.
- No production Firestore/Sheets data, payroll formulas, inventory logic, plant matching rules, or assignment records were modified.
