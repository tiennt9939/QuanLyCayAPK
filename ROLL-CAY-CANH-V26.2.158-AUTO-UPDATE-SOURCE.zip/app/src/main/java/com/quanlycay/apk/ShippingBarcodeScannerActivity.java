package com.quanlycay.apk;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.text.InputType;
import android.util.Size;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.os.Vibrator;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import androidx.activity.ComponentActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.MeteringPoint;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

/** Fast, on-device shipping-label scanner with continuous autofocus, torch, zoom and manual fallback. */
public final class ShippingBarcodeScannerActivity extends ComponentActivity {
    public static final String EXTRA_RAW_VALUE = "shipping_barcode_raw_value";
    public static final String EXTRA_ERROR = "shipping_barcode_error";
    public static final String EXTRA_PHOTO_PATH = "shipping_barcode_photo_path";
    public static final String EXTRA_DAILY_BATCH = "shipping_daily_batch";
    public static final String EXTRA_DAILY_ASSIGNMENT_MODE = "shipping_daily_assignment_mode";
    public static final String EXTRA_DAILY_ORDERS_JSON = "shipping_daily_orders_json";
    public static final String EXTRA_DAILY_BATCH_RESULTS = "shipping_daily_batch_results";
    public static final String EXTRA_DAILY_CAPTURE_COUNT = "shipping_daily_capture_count";
    public static final String EXTRA_DAILY_EMPLOYEES_JSON = "shipping_daily_employees_json";
    public static final String EXTRA_DAILY_SELECTED_EMPLOYEE = "shipping_daily_selected_employee";
    private static final int CAMERA_PERMISSION_REQ = 4821;
    private static final Pattern GHN_VNGH = Pattern.compile("^VNGH\\d{8,12}$");
    private static final Pattern GHN_GHVN = Pattern.compile("^GHVN[A-Z0-9]{4,26}$");
    private static final Pattern JT_EXPRESS = Pattern.compile("^862\\d{9}$");
    private static final Pattern JT_CARGO = Pattern.compile("^530\\d{9}$");

    private final ExecutorService cameraExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean analyzingFrame = new AtomicBoolean(false);
    private PreviewView previewView;
    private View scanOverlay;
    private TextView statusView;
    private TextView zoomView;
    private Button torchButton;
    private Button zoomOutButton;
    private Button zoomInButton;
    private Button captureButton;
    private Button rescanButton;
    private Button dailyPauseButton;
    private EditText manualInput;
    private Spinner dailyEmployeeSpinner;
    private final List<String> dailyEmployeeNames = new ArrayList<>();
    private String selectedEmployeeName = "";
    private String scannedEmployeeName = "";
    private boolean initializingEmployeeSpinner = false;
    private LinearLayout manualRow;
    private BarcodeScanner barcodeScanner;
    private Camera camera;
    private ImageCapture imageCapture;
    private ProcessCameraProvider cameraProvider;
    private boolean torchEnabled = false;
    private volatile boolean finished = false;
    private volatile boolean capturingPhoto = false;
    private volatile boolean dailyScanPaused = false;
    private volatile String scannedTracking = "";
    private long lastHintAtMs = 0L;
    private boolean dailyBatchMode = false;
    private boolean dailyAssignmentMode = false;
    private final Map<String, JSONObject> dailyExpected = new HashMap<>();
    private final Set<String> dailyCapturedThisSession = new HashSet<>();
    private final JSONArray dailyBatchResults = new JSONArray();
    private int dailyCaptureCount = 0;
    private ToneGenerator scanToneGenerator;
    private String lastRejectedTracking = "";
    private long lastRejectedAtMs = 0L;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(20, 83, 45));
        window.setNavigationBarColor(Color.rgb(15, 23, 42));
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        dailyBatchMode = getIntent() != null && getIntent().getBooleanExtra(EXTRA_DAILY_BATCH, false);
        dailyAssignmentMode = dailyBatchMode && getIntent().getBooleanExtra(EXTRA_DAILY_ASSIGNMENT_MODE, false);
        if (dailyBatchMode) {
            try { scanToneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 85); }
            catch (Exception e) { android.util.Log.w("ShippingBarcode", "Could not initialize scan success tone", e); }
            String employeesRaw = getIntent().getStringExtra(EXTRA_DAILY_EMPLOYEES_JSON);
            try {
                JSONArray employeeRows = new JSONArray(employeesRaw == null ? "[]" : employeesRaw);
                for (int i = 0; i < employeeRows.length(); i++) {
                    String name = employeeRows.optString(i, "").trim();
                    if (!name.isEmpty() && !dailyEmployeeNames.contains(name)) dailyEmployeeNames.add(name);
                }
            } catch (Exception e) { android.util.Log.w("ShippingBarcode", "Could not parse employee list", e); }
            selectedEmployeeName = getIntent().getStringExtra(EXTRA_DAILY_SELECTED_EMPLOYEE);
            if (selectedEmployeeName == null || !dailyEmployeeNames.contains(selectedEmployeeName.trim())) selectedEmployeeName = "";
            else selectedEmployeeName = selectedEmployeeName.trim();
            String raw = getIntent().getStringExtra(EXTRA_DAILY_ORDERS_JSON);
            try {
                JSONArray rows = new JSONArray(raw == null ? "[]" : raw);
                for (int i = 0; i < rows.length(); i++) {
                    JSONObject row = rows.optJSONObject(i);
                    if (row == null) continue;
                    String tracking = normalize(row.optString("trackingNo", ""));
                    // Daily scan trusts the exact normalized labels from the imported PDF queue,
                    // not a hard-coded list of carrier prefixes. Still reject malformed lengths.
                    if (tracking.length() >= 8 && tracking.length() <= 40) dailyExpected.put(tracking, row);
                }
            } catch (Exception e) {
                android.util.Log.w("ShippingBarcode", "Could not parse expected daily tracking list", e);
            }
        }
        buildUi();
        BarcodeScannerOptions.Builder scannerOptions = new BarcodeScannerOptions.Builder();
        // Normal shipping scan remains linear-only to avoid reading promotional QR codes.
        // In daily PDF mode, also decode QR: lockCode() accepts it only when the normalized
        // value exactly matches a tracking number imported into dailyExpected, so a promo
        // QR or unrelated code cannot be accepted as an order.
        if (dailyBatchMode) {
            scannerOptions.setBarcodeFormats(Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39,
                Barcode.FORMAT_CODE_93, Barcode.FORMAT_ITF, Barcode.FORMAT_CODABAR,
                Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A,
                Barcode.FORMAT_UPC_E, Barcode.FORMAT_QR_CODE);
        } else {
            scannerOptions.setBarcodeFormats(Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39,
                Barcode.FORMAT_CODE_93, Barcode.FORMAT_ITF, Barcode.FORMAT_CODABAR,
                Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E);
        }
        barcodeScanner = BarcodeScanning.getClient(scannerOptions.build());
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQ);
        }
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.rgb(8, 15, 24));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(16), dp(12), dp(16), dp(12));
        header.setBackgroundColor(Color.rgb(20, 83, 45));
        TextView title = text("QUÉT MÃ VẬN ĐƠN", 19, Color.WHITE, true);
        header.addView(title);
        TextView subtitle = text(dailyBatchMode
            ? (dailyAssignmentMode ? "Quét liên tục các mã có trong danh sách phiên. Người phụ trách luôn lấy từ phân công đã lưu; không thể đổi người trên camera. Mã ngoài danh sách hoặc đã ghi nhận sẽ bị chặn." : "Toàn bộ đơn PDF ở chung một danh sách. Chọn nhân viên cho từng mã → tự chụp ảnh → quét tiếp. Đơn trùng sẽ báo còi và bị chặn.")
            : "Quét mã trước, sau đó chụp ảnh kiện hàng + nhãn ngay tại đây", 13, Color.rgb(220, 252, 231), false);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(-1, -2);
        subtitleParams.topMargin = dp(4);
        header.addView(subtitle, subtitleParams);
        if (dailyBatchMode && !dailyAssignmentMode) {
            TextView employeeLabel = text("👤 NHÂN VIÊN ĐANG QUÉT (CÓ THỂ ĐỔI TRƯỚC MỖI MÃ)", 12, Color.WHITE, true);
            LinearLayout.LayoutParams employeeLabelParams = new LinearLayout.LayoutParams(-1, -2);
            employeeLabelParams.topMargin = dp(10);
            header.addView(employeeLabel, employeeLabelParams);
            dailyEmployeeSpinner = new Spinner(this);
            dailyEmployeeSpinner.setBackground(roundBackground(Color.WHITE, Color.rgb(187, 247, 208)));
            List<String> spinnerNames = new ArrayList<>();
            spinnerNames.add("— CHỌN NHÂN VIÊN TRƯỚC KHI QUÉT —");
            spinnerNames.addAll(dailyEmployeeNames);
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, spinnerNames);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            dailyEmployeeSpinner.setAdapter(adapter);
            int selectedIndex = selectedEmployeeName.isEmpty() ? 0 : Math.max(0, dailyEmployeeNames.indexOf(selectedEmployeeName) + 1);
            initializingEmployeeSpinner = true;
            dailyEmployeeSpinner.setSelection(selectedIndex, false);
            initializingEmployeeSpinner = false;
            dailyEmployeeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (initializingEmployeeSpinner || finished) return;
                    selectedEmployeeName = position <= 0 ? "" : dailyEmployeeNames.get(position - 1);
                    if (scannedTracking.isEmpty() && !capturingPhoto) {
                        setStatus(selectedEmployeeName.isEmpty()
                            ? "⚠️ Chọn nhân viên trước khi quét mã."
                            : "Đang quét cho: " + selectedEmployeeName + " · Đưa nhãn vào khung.",
                            selectedEmployeeName.isEmpty() ? Color.rgb(180, 83, 9) : Color.rgb(21, 101, 52));
                    }
                }
                @Override public void onNothingSelected(AdapterView<?> parent) { selectedEmployeeName = ""; }
            });
            LinearLayout.LayoutParams employeeSpinnerParams = new LinearLayout.LayoutParams(-1, dp(42));
            employeeSpinnerParams.topMargin = dp(5);
            header.addView(dailyEmployeeSpinner, employeeSpinnerParams);
        }
        page.addView(header, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout cameraArea = new FrameLayout(this);
        cameraArea.setBackgroundColor(Color.BLACK);
        previewView = new PreviewView(this);
        previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        cameraArea.addView(previewView, new FrameLayout.LayoutParams(-1, -1));
        ScanTargetOverlay overlay = new ScanTargetOverlay(this);
        scanOverlay = overlay;
        cameraArea.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        previewView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) focusAt(event.getX(), event.getY());
            return true;
        });
        page.addView(cameraArea, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.VERTICAL);
        footer.setPadding(dp(12), dp(9), dp(12), dp(10));
        footer.setBackgroundColor(Color.rgb(248, 250, 252));
        statusView = text("Đang chuẩn bị camera…", 14, Color.rgb(30, 41, 59), true);
        statusView.setMinHeight(dp(38));
        footer.addView(statusView, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        torchButton = button("🔦 BẬT ĐÈN", Color.rgb(21, 101, 52));
        zoomOutButton = button("−", Color.rgb(51, 65, 85));
        zoomView = text("1.0×", 15, Color.rgb(15, 23, 42), true);
        zoomView.setGravity(Gravity.CENTER);
        zoomInButton = button("+", Color.rgb(51, 65, 85));
        LinearLayout.LayoutParams ctl = new LinearLayout.LayoutParams(0, dp(42), 1.4f);
        ctl.setMargins(0, dp(3), dp(6), dp(5));
        controls.addView(torchButton, ctl);
        LinearLayout.LayoutParams small = new LinearLayout.LayoutParams(0, dp(42), 0.6f);
        small.setMargins(0, dp(3), dp(5), dp(5));
        controls.addView(zoomOutButton, small);
        LinearLayout.LayoutParams zoomLabel = new LinearLayout.LayoutParams(0, dp(42), 0.65f);
        zoomLabel.setMargins(0, dp(3), dp(5), dp(5));
        controls.addView(zoomView, zoomLabel);
        LinearLayout.LayoutParams plus = new LinearLayout.LayoutParams(0, dp(42), 0.6f);
        plus.setMargins(0, dp(3), 0, dp(5));
        controls.addView(zoomInButton, plus);
        footer.addView(controls);

        torchButton.setOnClickListener(v -> toggleTorch());
        zoomOutButton.setOnClickListener(v -> adjustZoom(false));
        zoomInButton.setOnClickListener(v -> adjustZoom(true));

        manualRow = new LinearLayout(this);
        manualRow.setOrientation(LinearLayout.HORIZONTAL);
        manualInput = new EditText(this);
        manualInput.setSingleLine(true);
        manualInput.setTextSize(15);
        manualInput.setHint("Mã vạch khó đọc? Nhập mã vận đơn");
        manualInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        manualInput.setPadding(dp(10), 0, dp(10), 0);
        manualInput.setBackground(roundBackground(Color.WHITE, Color.rgb(203, 213, 225)));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(0, dp(46), 1f);
        inputParams.setMargins(0, dp(2), dp(7), dp(2));
        manualRow.addView(manualInput, inputParams);
        Button useManual = button("XÁC NHẬN MÃ", Color.rgb(5, 150, 105));
        manualRow.addView(useManual, new LinearLayout.LayoutParams(dp(132), dp(46)));
        useManual.setOnClickListener(v -> submitManualCode());
        footer.addView(manualRow);

        captureButton = button("📷 CHỤP ẢNH KIỆN HÀNG + NHÃN", Color.rgb(5, 150, 105));
        captureButton.setVisibility(View.GONE);
        LinearLayout.LayoutParams captureParams = new LinearLayout.LayoutParams(-1, dp(48));
        captureParams.topMargin = dp(5);
        footer.addView(captureButton, captureParams);
        captureButton.setOnClickListener(v -> capturePackagePhoto());

        rescanButton = button("↻ QUÉT LẠI MÃ VẬN ĐƠN", Color.rgb(51, 65, 85));
        rescanButton.setVisibility(View.GONE);
        LinearLayout.LayoutParams rescanParams = new LinearLayout.LayoutParams(-1, dp(40));
        rescanParams.topMargin = dp(4);
        footer.addView(rescanButton, rescanParams);
        rescanButton.setOnClickListener(v -> resetScanState());

        if (dailyBatchMode) {
            dailyPauseButton = button("TẠM DỪNG QUÉT", Color.rgb(71, 85, 105));
            LinearLayout.LayoutParams pauseParams = new LinearLayout.LayoutParams(-1, dp(42));
            pauseParams.topMargin = dp(4);
            footer.addView(dailyPauseButton, pauseParams);
            dailyPauseButton.setOnClickListener(v -> toggleDailyScanPause());
        }

        Button cancel = button(dailyBatchMode ? "■ NGƯNG QUÉT" : "ĐÓNG MÁY QUÉT", dailyBatchMode ? Color.rgb(185, 28, 28) : Color.rgb(71, 85, 105));
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(-1, dp(46));
        cancelParams.topMargin = dp(6);
        footer.addView(cancel, cancelParams);
        cancel.setOnClickListener(v -> { if (dailyBatchMode) finishDailyBatch(); else finishCancelled(); });
        if (dailyBatchMode) {
            captureButton.setVisibility(View.GONE);
            rescanButton.setVisibility(View.GONE);
            manualRow.setVisibility(View.GONE);
            setStatus("Danh sách chung: " + dailyExpected.size() + " đơn. Chọn nhân viên phía trên trước khi đưa mã vào khung.", Color.rgb(21, 101, 52));
        }
        page.addView(footer, new LinearLayout.LayoutParams(-1, -2));
        setContentView(page);
    }

    private void startCamera() {
        setStatus("Đang khởi động camera và bộ đọc mã…", Color.rgb(30, 41, 59));
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            if (finished || isFinishing()) return;
            try {
                cameraProvider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                ImageAnalysis analysis = new ImageAnalysis.Builder()
                    .setTargetResolution(new Size(1280, 720))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build();
                analysis.setAnalyzer(cameraExecutor, this::analyzeFrame);
                imageCapture = new ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setJpegQuality(dailyBatchMode ? 72 : 85)
                    .build();
                cameraProvider.unbindAll();
                camera = cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis, imageCapture);
                torchButton.setEnabled(camera.getCameraInfo().hasFlashUnit());
                if (!camera.getCameraInfo().hasFlashUnit()) torchButton.setText("KHÔNG CÓ ĐÈN");
                setStatus(dailyBatchMode
                    ? (dailyAssignmentMode ? "Đang quét đơn đã giao cho tài khoản này. Mã không thuộc danh sách sẽ bị chặn." : (selectedEmployeeName.isEmpty() ? "⚠️ Chọn nhân viên ở phía trên trước khi quét mã." : "Đang quét cho: " + selectedEmployeeName + " · Căn mã, ảnh kiện hàng sẽ tự chụp."))
                    : "Đang quét liên tục… chạm vào mã để lấy nét, dùng + để phóng to.",
                    dailyBatchMode && !dailyAssignmentMode && selectedEmployeeName.isEmpty() ? Color.rgb(180, 83, 9) : Color.rgb(21, 101, 52));
                updateZoomLabel();
                focusAt(previewView.getWidth() / 2f, previewView.getHeight() / 2f);
            } catch (Exception e) {
                setStatus("Không mở được camera: " + safeMessage(e), Color.rgb(185, 28, 28));
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void analyzeFrame(ImageProxy proxy) {
        if (finished || dailyScanPaused || capturingPhoto || !scannedTracking.isEmpty() || !analyzingFrame.compareAndSet(false, true)) {
            proxy.close();
            return;
        }
        android.media.Image mediaImage = proxy.getImage();
        if (mediaImage == null) {
            proxy.close();
            analyzingFrame.set(false);
            return;
        }
        InputImage input;
        try {
            input = InputImage.fromMediaImage(mediaImage, proxy.getImageInfo().getRotationDegrees());
        } catch (Exception e) {
            proxy.close();
            analyzingFrame.set(false);
            return;
        }
        barcodeScanner.process(input)
            .addOnSuccessListener(barcodes -> {
                for (Barcode barcode : barcodes) {
                    String raw = barcode == null ? "" : barcode.getRawValue();
                    String normalized = normalize(raw);
                    if (isTrackableTracking(normalized)) {
                        lockCode(normalized);
                        return;
                    }
                    String display = barcode == null ? "" : barcode.getDisplayValue();
                    String displayNormalized = normalize(display);
                    if (isTrackableTracking(displayNormalized)) {
                        lockCode(displayNormalized);
                        return;
                    }
                }
                if (!barcodes.isEmpty()) hintOtherBarcode();
            })
            .addOnFailureListener(error -> android.util.Log.w("ShippingBarcode", "Frame decode failed", error))
            .addOnCompleteListener(task -> {
                try { proxy.close(); } catch (Exception ignored) { }
                analyzingFrame.set(false);
            });
    }

    private void hintOtherBarcode() {
        long now = System.currentTimeMillis();
        if (now - lastHintAtMs < 1800 || finished) return;
        lastHintAtMs = now;
        runOnUiThread(() -> {
            if (!finished) setStatus(dailyBatchMode ? "Mã chưa đúng định dạng vận đơn hoặc không có trong danh sách đơn. Căn đúng mã trên nhãn." : "Đã thấy mã khác. Hãy căn mã vận đơn GHN/J&T vào khung xanh.", Color.rgb(146, 64, 14));
        });
    }

    private void focusAt(float x, float y) {
        if (camera == null || previewView == null || previewView.getWidth() <= 0 || previewView.getHeight() <= 0) return;
        try {
            MeteringPoint point = previewView.getMeteringPointFactory().createPoint(x, y);
            FocusMeteringAction action = new FocusMeteringAction.Builder(point,
                FocusMeteringAction.FLAG_AF | FocusMeteringAction.FLAG_AE)
                .setAutoCancelDuration(3, TimeUnit.SECONDS).build();
            camera.getCameraControl().startFocusAndMetering(action);
        } catch (Exception e) {
            android.util.Log.d("ShippingBarcode", "Tap focus unavailable", e);
        }
    }

    private void toggleTorch() {
        if (camera == null || !camera.getCameraInfo().hasFlashUnit()) {
            setStatus("Camera này không có đèn pin. Hãy tăng ánh sáng môi trường.", Color.rgb(146, 64, 14));
            return;
        }
        torchEnabled = !torchEnabled;
        camera.getCameraControl().enableTorch(torchEnabled).addListener(() -> runOnUiThread(() -> {
            torchButton.setText(torchEnabled ? "🔦 TẮT ĐÈN" : "🔦 BẬT ĐÈN");
            torchButton.setBackground(roundBackground(torchEnabled ? Color.rgb(180, 83, 9) : Color.rgb(21, 101, 52), Color.TRANSPARENT));
        }), ContextCompat.getMainExecutor(this));
    }

    private void adjustZoom(boolean zoomIn) {
        if (camera == null) return;
        try {
            androidx.camera.core.ZoomState state = camera.getCameraInfo().getZoomState().getValue();
            if (state == null) return;
            float current = state.getZoomRatio();
            float desired = zoomIn ? current * 1.35f : current / 1.35f;
            desired = Math.max(state.getMinZoomRatio(), Math.min(state.getMaxZoomRatio(), desired));
            camera.getCameraControl().setZoomRatio(desired).addListener(this::updateZoomLabel, ContextCompat.getMainExecutor(this));
            zoomView.setText(String.format(Locale.ROOT, "%.1f×", desired));
        } catch (Exception e) {
            setStatus("Không thể thay đổi mức zoom trên camera này.", Color.rgb(146, 64, 14));
        }
    }

    private void updateZoomLabel() {
        if (camera == null || zoomView == null) return;
        androidx.camera.core.ZoomState state = camera.getCameraInfo().getZoomState().getValue();
        if (state != null) zoomView.setText(String.format(Locale.ROOT, "%.1f×", state.getZoomRatio()));
    }

    private void submitManualCode() {
        String value = normalize(manualInput == null ? "" : manualInput.getText().toString());
        if (!isTrackableTracking(value)) {
            setStatus(dailyBatchMode ? "Mã chưa khớp danh sách PDF đang mở. Kiểm tra lại ký tự." : "Mã không đúng định dạng GHN/J&T đã hỗ trợ. Kiểm tra lại ký tự và thử quét camera.", Color.rgb(185, 28, 28));
            return;
        }
        lockCode(value);
    }

    private void lockCode(String value) {
        final String tracking = normalize(value);
        if (finished || !isTrackableTracking(tracking) || !scannedTracking.isEmpty()) return;
        if (dailyBatchMode) {
            JSONObject expected = dailyExpected.get(tracking);
            long now = System.currentTimeMillis();
            if (expected == null) {
                rejectDailyTracking(tracking, "⚠️ Mã " + tracking + " chưa có trong danh sách đơn đã nhập. Bỏ qua, không chụp ảnh.", now);
                return;
            }
            if (expected.optBoolean("recorded", false) || expected.optBoolean("claimed", false) || dailyCapturedThisSession.contains(tracking)) {
                rejectDailyTracking(tracking, "🚨 TRÙNG ĐƠN " + tracking + " · ĐÃ QUÉT/GHI NHẬN, KHÔNG TÍNH CÔNG LẦN HAI.", now, true);
                return;
            }
            if (dailyAssignmentMode) {
                String assignedUid = expected.optString("assignedUid", "").trim();
                String assignedEmployee = expected.optString("assignedEmployeeName", "").trim();
                if (!expected.optBoolean("assignmentRequired", false) || assignedUid.isEmpty() || assignedEmployee.isEmpty()) {
                    rejectDailyTracking(tracking, "⚠️ Đơn này chưa được Admin giao cho người phụ trách. Không chụp ảnh.", now);
                    return;
                }
                if (!expected.optBoolean("ready", false)) {
                    rejectDailyTracking(tracking, "⚠️ Đơn " + tracking + " chưa đối chiếu đủ cây/kích thước. Kiểm tra danh mục trước khi quét.", now);
                    return;
                }
                scannedEmployeeName = assignedEmployee;
                scannedTracking = tracking;
                if (scanOverlay != null) scanOverlay.invalidate();
                setStatus("✅ Đơn " + tracking + " · giao cho " + assignedEmployee + " · đang tự chụp ảnh…", Color.rgb(5, 120, 65));
                if (previewView != null) focusAt(previewView.getWidth() / 2f, previewView.getHeight() / 2f);
                capturePackagePhoto();
                return;
            }
            if (selectedEmployeeName == null || selectedEmployeeName.trim().isEmpty() || !dailyEmployeeNames.contains(selectedEmployeeName.trim())) {
                rejectDailyTracking(tracking, "⚠️ Hãy chọn nhân viên đang đóng hàng phía trên trước khi quét.", now);
                return;
            }
            if (!expected.optBoolean("ready", false)) {
                rejectDailyTracking(tracking, "⚠️ Đơn " + tracking + " chưa đối chiếu đủ cây/kích thước. Kiểm tra danh mục trước khi quét.", now);
                return;
            }
            scannedEmployeeName = selectedEmployeeName.trim();
            if (dailyEmployeeSpinner != null) dailyEmployeeSpinner.setEnabled(false);
            scannedTracking = tracking;
            if (scanOverlay != null) scanOverlay.invalidate();
            setStatus("✅ Khớp đơn " + tracking + " · đang tự chụp ảnh…", Color.rgb(5, 120, 65));
            if (previewView != null) focusAt(previewView.getWidth() / 2f, previewView.getHeight() / 2f);
            capturePackagePhoto();
            return;
        }
        runOnUiThread(() -> {
            if (finished || capturingPhoto || !scannedTracking.isEmpty()) return;
            scannedTracking = tracking;
            if (manualRow != null) manualRow.setVisibility(View.GONE);
            if (captureButton != null) { captureButton.setVisibility(View.VISIBLE); captureButton.setEnabled(true); }
            if (rescanButton != null) { rescanButton.setVisibility(View.VISIBLE); rescanButton.setEnabled(true); }
            setStatus("✅ Đã đọc mã " + tracking + ". Đưa TOÀN BỘ KIỆN HÀNG và nhãn vào khung rồi chụp ảnh.", Color.rgb(5, 120, 65));
            if (previewView != null) focusAt(previewView.getWidth() / 2f, previewView.getHeight() / 2f);
            if (scanOverlay != null) scanOverlay.invalidate();
        });
    }

    private void rejectDailyTracking(String tracking, String message, long now) {
        rejectDailyTracking(tracking, message, now, false);
    }

    private void rejectDailyTracking(String tracking, String message, long now, boolean duplicateAlarm) {
        if (tracking.equals(lastRejectedTracking) && now - lastRejectedAtMs < 1600) return;
        lastRejectedTracking = tracking;
        lastRejectedAtMs = now;
        runOnUiThread(() -> {
            if (finished) return;
            setStatus(message, duplicateAlarm ? Color.rgb(185, 28, 28) : Color.rgb(180, 83, 9));
            if (duplicateAlarm) playDuplicateScanAlarm();
            try {
                Object service = getSystemService(VIBRATOR_SERVICE);
                if (service instanceof Vibrator) ((Vibrator) service).vibrate(duplicateAlarm ? new long[]{0, 180, 80, 180, 80, 240} : new long[]{0, 65}, -1);
            } catch (Exception ignored) { }
        });
    }

    private void playDuplicateScanAlarm() {
        try {
            if (scanToneGenerator == null) scanToneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);
            scanToneGenerator.startTone(ToneGenerator.TONE_PROP_NACK, 260);
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                try { if (!finished && scanToneGenerator != null) scanToneGenerator.startTone(ToneGenerator.TONE_PROP_NACK, 260); }
                catch (Exception ignored) { }
            }, 330);
        } catch (Exception e) { android.util.Log.w("ShippingBarcode", "Duplicate scan alarm unavailable", e); }
    }

    private void resetScanState() {
        if (finished || capturingPhoto) return;
        scannedTracking = "";
        scannedEmployeeName = "";
        if (dailyEmployeeSpinner != null) dailyEmployeeSpinner.setEnabled(true);
        if (manualInput != null) manualInput.setText("");
        if (manualRow != null) manualRow.setVisibility(View.VISIBLE);
        if (captureButton != null) { captureButton.setVisibility(View.GONE); captureButton.setEnabled(false); }
        if (rescanButton != null) { rescanButton.setVisibility(View.GONE); rescanButton.setEnabled(false); }
        setStatus(dailyBatchMode ? "Đang quét liên tục… căn mã, ảnh kiện hàng sẽ tự chụp." : "Đang quét liên tục… chạm vào mã để lấy nét, dùng + để phóng to.", Color.rgb(21, 101, 52));
        if (scanOverlay != null) scanOverlay.invalidate();
    }

    private void capturePackagePhoto() {
        if (finished || capturingPhoto) return;
        if (scannedTracking.isEmpty()) {
            setStatus("Hãy quét mã vận đơn trước khi chụp ảnh kiện hàng.", Color.rgb(185, 28, 28));
            return;
        }
        if (imageCapture == null) {
            if (dailyBatchMode) { scannedTracking = ""; scannedEmployeeName = ""; if (dailyEmployeeSpinner != null) dailyEmployeeSpinner.setEnabled(true); }
            setStatus("Camera chưa sẵn sàng chụp ảnh. Hãy thử lại.", Color.rgb(185, 28, 28));
            return;
        }
        capturingPhoto = true;
        if (captureButton != null) { captureButton.setEnabled(false); captureButton.setText("⏳ ĐANG CHỤP ẢNH..."); }
        if (rescanButton != null) rescanButton.setEnabled(false);
        setStatus("Đang chụp và nén ảnh kiện hàng + nhãn…", Color.rgb(146, 64, 14));
        File raw = new File(getCacheDir(), "scanner_capture_raw_" + System.currentTimeMillis() + ".jpg");
        ImageCapture.OutputFileOptions options = new ImageCapture.OutputFileOptions.Builder(raw).build();
        imageCapture.takePicture(options, ContextCompat.getMainExecutor(this), new ImageCapture.OnImageSavedCallback() {
            @Override public void onImageSaved(ImageCapture.OutputFileResults output) {
                cameraExecutor.execute(() -> {
                    try {
                        File compressed = compressCapturedPhoto(raw);
                        raw.delete();
                        runOnUiThread(() -> finishWithCodeAndPhoto(compressed));
                    } catch (Exception e) {
                        raw.delete();
                        runOnUiThread(() -> {
                            capturingPhoto = false;
                            if (dailyBatchMode) {
                                scannedTracking = "";
                                scannedEmployeeName = "";
                                if (dailyEmployeeSpinner != null) dailyEmployeeSpinner.setEnabled(true);
                                if (scanOverlay != null) scanOverlay.invalidate();
                                setStatus("Ảnh chưa chụp được; mã này chưa ghi nhận. Đưa mã lại vào khung để thử lại. " + safeMessage(e), Color.rgb(185, 28, 28));
                            } else {
                                if (captureButton != null) { captureButton.setEnabled(true); captureButton.setText("📷 CHỤP LẠI ẢNH KIỆN + NHÃN"); }
                                if (rescanButton != null) rescanButton.setEnabled(true);
                                setStatus("Chưa xử lý được ảnh: " + safeMessage(e) + ". Hãy chụp lại.", Color.rgb(185, 28, 28));
                            }
                        });
                    }
                });
            }
            @Override public void onError(ImageCaptureException error) {
                capturingPhoto = false;
                if (dailyBatchMode) {
                    scannedTracking = "";
                    scannedEmployeeName = "";
                    if (dailyEmployeeSpinner != null) dailyEmployeeSpinner.setEnabled(true);
                    if (scanOverlay != null) scanOverlay.invalidate();
                    setStatus("Ảnh chưa chụp được; mã này chưa ghi nhận. Căn lại kiện và thử quét lại.", Color.rgb(185, 28, 28));
                } else {
                    if (captureButton != null) { captureButton.setEnabled(true); captureButton.setText("📷 CHỤP LẠI ẢNH KIỆN + NHÃN"); }
                    if (rescanButton != null) rescanButton.setEnabled(true);
                    setStatus("Chụp ảnh thất bại: " + safeMessage(error) + ". Hãy thử lại.", Color.rgb(185, 28, 28));
                }
            }
        });
    }

    private File compressCapturedPhoto(File source) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(source.getAbsolutePath(), bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new Exception("Ảnh chụp không hợp lệ");
        int sample = 1;
        while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > 1800) sample *= 2;
        BitmapFactory.Options decode = new BitmapFactory.Options();
        decode.inSampleSize = sample;
        decode.inPreferredConfig = Bitmap.Config.RGB_565;
        Bitmap bitmap = BitmapFactory.decodeFile(source.getAbsolutePath(), decode);
        if (bitmap == null) throw new Exception("Không đọc được ảnh chụp");
        Bitmap scaled = bitmap;
        int max = Math.max(bitmap.getWidth(), bitmap.getHeight());
        if (max > 1280) {
            float scale = 1280f / max;
            scaled = Bitmap.createScaledBitmap(bitmap, Math.max(1, Math.round(bitmap.getWidth() * scale)), Math.max(1, Math.round(bitmap.getHeight() * scale)), true);
            if (scaled != bitmap) bitmap.recycle();
        }
        File output = new File(getCacheDir(), "scanner_capture_" + System.currentTimeMillis() + ".jpg");
        try (FileOutputStream stream = new FileOutputStream(output)) {
            if (!scaled.compress(Bitmap.CompressFormat.JPEG, 72, stream)) throw new Exception("Không nén được ảnh");
            stream.flush();
        } finally {
            if (!scaled.isRecycled()) scaled.recycle();
        }
        // Keep the WebView bridge payload modest so encoding/photo transfer does not add a large wait.
        if (output.length() > 450L * 1024L) {
            BitmapFactory.Options smallerOptions = new BitmapFactory.Options();
            smallerOptions.inSampleSize = 2;
            smallerOptions.inPreferredConfig = Bitmap.Config.RGB_565;
            Bitmap smallerBitmap = BitmapFactory.decodeFile(output.getAbsolutePath(), smallerOptions);
            if (smallerBitmap == null) { output.delete(); throw new Exception("Không nén nhỏ thêm được ảnh"); }
            Bitmap resized = smallerBitmap;
            int secondMax = Math.max(smallerBitmap.getWidth(), smallerBitmap.getHeight());
            if (secondMax > 960) {
                float secondScale = 960f / secondMax;
                resized = Bitmap.createScaledBitmap(smallerBitmap, Math.max(1, Math.round(smallerBitmap.getWidth() * secondScale)), Math.max(1, Math.round(smallerBitmap.getHeight() * secondScale)), true);
                if (resized != smallerBitmap) smallerBitmap.recycle();
            }
            File smallOutput = new File(getCacheDir(), "scanner_capture_" + System.currentTimeMillis() + ".jpg");
            try (FileOutputStream stream = new FileOutputStream(smallOutput)) {
                if (!resized.compress(Bitmap.CompressFormat.JPEG, 64, stream)) throw new Exception("Không nén nhỏ thêm được ảnh");
                stream.flush();
            } finally { if (!resized.isRecycled()) resized.recycle(); }
            output.delete(); output = smallOutput;
        }
        if (output.length() <= 0 || output.length() > 450L * 1024L) {
            output.delete();
            throw new Exception("Ảnh quá lớn sau khi nén. Hãy chụp lại gần hơn");
        }
        return output;
    }

    private File persistDailyPhoto(File compressed, String tracking, String employeeName) throws Exception {
        File dir = new File(getFilesDir(), "daily-shipment-queue");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Không tạo được hàng đợi ảnh an toàn");
        String safeTracking = normalize(tracking).replaceAll("[^A-Z0-9]", "");
        File target = new File(dir, "daily_shipment_" + safeTracking + "_" + System.currentTimeMillis() + ".jpg");
        try (FileInputStream in = new FileInputStream(compressed); FileOutputStream out = new FileOutputStream(target)) {
            byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n); out.flush();
        }
        if (target.length() <= 0 || target.length() > 450L * 1024L) { target.delete(); throw new Exception("Ảnh chưa đạt dung lượng an toàn"); }
        File metadata = new File(dir, target.getName().replaceFirst("\\.jpg$", ".meta.json"));
        try (FileOutputStream metaOut = new FileOutputStream(metadata)) {
            JSONObject meta = new JSONObject();
            meta.put("trackingNo", safeTracking).put("employeeName", employeeName == null ? "" : employeeName.trim())
                .put("employeeId", employeeName == null ? "" : employeeName.trim());
            metaOut.write(meta.toString().getBytes(StandardCharsets.UTF_8)); metaOut.flush();
        } catch (Exception e) { target.delete(); metadata.delete(); throw new Exception("Không lưu được nhân viên gắn với ảnh quét: " + safeMessage(e)); }
        compressed.delete();
        return target;
    }

    private void finishWithCodeAndPhoto(File photo) {
        if (finished) { if (photo != null) photo.delete(); return; }
        if (photo == null || !photo.exists() || photo.length() <= 0) {
            capturingPhoto = false;
            if (dailyBatchMode) { scannedTracking = ""; scannedEmployeeName = ""; if (dailyEmployeeSpinner != null) dailyEmployeeSpinner.setEnabled(true); }
            if (captureButton != null) { captureButton.setEnabled(true); captureButton.setText("📷 CHỤP ẢNH KIỆN HÀNG + NHÃN"); }
            setStatus("Không có ảnh bằng chứng. Hãy căn lại và quét đơn này lần nữa.", Color.rgb(185, 28, 28));
            return;
        }
        if (dailyBatchMode) {
            final String tracking = scannedTracking;
            final JSONObject expected = dailyExpected.get(tracking);
            try {
                File persistent = persistDailyPhoto(photo, tracking, scannedEmployeeName);
                dailyCapturedThisSession.add(tracking);
                dailyCaptureCount++;
                JSONObject captured = new JSONObject();
                captured.put("trackingNo", tracking);
                captured.put("carrier", expected == null ? "" : expected.optString("carrier", ""));
                captured.put("photoPath", persistent.getAbsolutePath());
                captured.put("employeeName", scannedEmployeeName);
                captured.put("employeeId", scannedEmployeeName);
                dailyBatchResults.put(captured);
                MainActivity.dispatchDailyShipmentCapture(tracking, captured.optString("carrier", ""), persistent.getAbsolutePath(), scannedEmployeeName);
                capturingPhoto = false;
                scannedTracking = "";
                scannedEmployeeName = "";
                if (dailyEmployeeSpinner != null) dailyEmployeeSpinner.setEnabled(true);
                if (manualInput != null) manualInput.setText("");
                if (scanOverlay != null) scanOverlay.invalidate();
                setStatus("✅ Đã chụp " + dailyCaptureCount + " đơn · ảnh đang tải Drive nền. Quét đơn kế tiếp.", Color.rgb(21, 101, 52));
                playScanCompleteBeep();
                try {
                    Object service = getSystemService(VIBRATOR_SERVICE);
                    if (service instanceof Vibrator) ((Vibrator) service).vibrate(35);
                } catch (Exception ignored) { }
            } catch (Exception e) {
                photo.delete();
                capturingPhoto = false;
                scannedTracking = "";
                scannedEmployeeName = "";
                if (dailyEmployeeSpinner != null) dailyEmployeeSpinner.setEnabled(true);
                if (scanOverlay != null) scanOverlay.invalidate();
                setStatus("Không xếp được ảnh vào hàng đợi; đơn chưa ghi nhận: " + safeMessage(e), Color.rgb(185, 28, 28));
            }
            return;
        }
        finished = true;
        Intent result = new Intent();
        result.putExtra(EXTRA_RAW_VALUE, scannedTracking);
        result.putExtra(EXTRA_PHOTO_PATH, photo.getAbsolutePath());
        setResult(RESULT_OK, result);
        finish();
    }

    private void playScanCompleteBeep() {
        try {
            if (scanToneGenerator != null) scanToneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP, 120);
        } catch (Exception e) {
            android.util.Log.d("ShippingBarcode", "Scan success tone unavailable", e);
        }
    }

    private void toggleDailyScanPause() {
        if (!dailyBatchMode || finished) return;
        dailyScanPaused = !dailyScanPaused;
        if (dailyPauseButton != null) dailyPauseButton.setText(dailyScanPaused ? "TIẾP TỤC QUÉT" : "TẠM DỪNG QUÉT");
        setStatus(dailyScanPaused
                ? "Đã tạm dừng camera. Ảnh và báo cáo đang xử lý nền; nhấn TIẾP TỤC QUÉT để quét tiếp."
                : "Đang quét liên tục… căn mã, ảnh kiện hàng sẽ tự chụp.",
                dailyScanPaused ? Color.rgb(180, 83, 9) : Color.rgb(21, 101, 52));
    }

    private void finishDailyBatch() {
        if (finished) return;
        finished = true;
        Intent result = new Intent();
        result.putExtra(EXTRA_DAILY_BATCH, true);
        result.putExtra(EXTRA_DAILY_BATCH_RESULTS, dailyBatchResults.toString());
        result.putExtra(EXTRA_DAILY_CAPTURE_COUNT, dailyCaptureCount);
        setResult(RESULT_OK, result);
        finish();
    }

    @Override public void onBackPressed() {
        if (dailyBatchMode) finishDailyBatch(); else finishCancelled();
    }

    private void finishCancelled() {
        if (finished) return;
        finished = true;
        setResult(RESULT_CANCELED, new Intent());
        finish();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != CAMERA_PERMISSION_REQ) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            Intent result = new Intent();
            result.putExtra(EXTRA_ERROR, "Bạn chưa cấp quyền camera nên không thể quét mã. Hãy cấp quyền Camera cho ROLL CÂY CẢNH trong Cài đặt Android.");
            setResult(RESULT_CANCELED, result);
            finished = true;
            finish();
        }
    }

    @Override protected void onDestroy() {
        try { if (cameraProvider != null) cameraProvider.unbindAll(); } catch (Exception ignored) { }
        try { if (barcodeScanner != null) barcodeScanner.close(); } catch (Exception ignored) { }
        try { cameraExecutor.shutdown(); } catch (Exception ignored) { }
        try { if (scanToneGenerator != null) scanToneGenerator.release(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    private void setStatus(String text, int color) {
        runOnUiThread(() -> {
            if (statusView == null || finished) return;
            statusView.setText(text);
            statusView.setTextColor(color);
        });
    }

    private boolean isSupportedTracking(String value) {
        return GHN_VNGH.matcher(value).matches() || GHN_GHVN.matcher(value).matches()
            || JT_EXPRESS.matcher(value).matches() || JT_CARGO.matcher(value).matches();
    }

    private boolean isTrackableTracking(String value) {
        String normalized = normalize(value);
        if (isSupportedTracking(normalized)) return true;
        // In PDF batch mode, accept only an exact match to one of the already-imported labels.
        // This avoids silently skipping valid carrier prefixes absent from the legacy regex list.
        return dailyBatchMode && dailyExpected.containsKey(normalized);
    }

    private String normalize(String value) {
        return value == null ? "" : value.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
    }

    private String safeMessage(Exception e) {
        return e == null || e.getMessage() == null || e.getMessage().trim().isEmpty()
            ? (e == null ? "lỗi chưa rõ" : e.getClass().getSimpleName()) : e.getMessage();
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button button(String label, int color) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(13);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setPadding(dp(5), 0, dp(5), 0);
        button.setBackground(roundBackground(color, Color.TRANSPARENT));
        return button;
    }

    private GradientDrawable roundBackground(int color, int strokeColor) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(10));
        if (strokeColor != Color.TRANSPARENT) shape.setStroke(dp(1), strokeColor);
        return shape;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private final class ScanTargetOverlay extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ScanTargetOverlay(android.content.Context context) { super(context); setClickable(false); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float width = getWidth();
            float height = getHeight();
            boolean photoMode = !dailyBatchMode && !scannedTracking.isEmpty();
            float boxWidth = width * (photoMode ? 0.91f : 0.86f);
            float boxHeight = photoMode ? height * 0.68f : Math.max(dp(88), Math.min(dp(136), height * 0.19f));
            float left = (width - boxWidth) / 2f;
            float top = photoMode ? height * 0.14f : (height - boxHeight) / 2f;
            RectF rect = new RectF(left, top, left + boxWidth, top + boxHeight);
            paint.setColor(Color.rgb(34, 197, 94));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(3));
            canvas.drawRoundRect(rect, dp(10), dp(10), paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setTextSize(dp(12));
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setColor(Color.WHITE);
            canvas.drawText(photoMode ? "ĐƯA KIỆN HÀNG + NHÃN VÀO KHUNG" : "MÃ VẬN ĐƠN", left + dp(8), Math.max(dp(18), top - dp(10)), paint);
        }
    }
}
