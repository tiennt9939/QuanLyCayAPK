# Hướng dẫn triển khai V26.2.155

**Thứ tự bắt buộc:** triển khai GAS trước, sau đó mới cài APK mới.

1. Mở dự án Google Apps Script hiện đang phục vụ ứng dụng.
2. Sao lưu bản `Code.gs` đang chạy, thay toàn bộ nội dung bằng `Code.gs` trong source V26.2.155.
3. Deploy một phiên bản mới của Web App vào cùng dự án/endpoint hiện tại; giữ nguyên Script Properties và quyền truy cập hiện tại. Không tạo dự án GAS mới.
4. Trong Apps Script Editor, chạy thủ công `diagnoseKnownBrokenRollDocuments()`. Đây là hàm chỉ đọc, không thay đổi dữ liệu. Xem Execution log và lưu lại kết quả.
5. Sau khi GAS đã trả về version `gas-firestore-compat-phase3.3-safe-base64-payload-chunks`, tải ZIP source V26.2.155 lên thư mục gốc GitHub repository.
6. Chạy workflow `Build ROLL CAY CANH — AUTO-UPDATE SOURCE` và cài APK tạo ra.

**Không xóa hoặc sửa thủ công** các sheet `fsCompatDocs`, `packingOrders`, `dailyShipmentOrders`, `dailyShipmentReports`, `shipmentTrackingClaims`, `dailyShipmentScans` hay dữ liệu nhân viên. Các tài liệu hỏng cũ phải được chẩn đoán và đối chiếu trước khi khôi phục; hàm chẩn đoán không tự sửa chúng.
