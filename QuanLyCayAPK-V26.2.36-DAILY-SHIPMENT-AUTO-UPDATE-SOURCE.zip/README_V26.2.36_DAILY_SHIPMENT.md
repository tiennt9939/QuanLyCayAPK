# ROLL CÂY CẢNH — V26.2.36: Vận chuyển trong ngày

## Mục tiêu
Bản rút gọn làm trên bản gốc V26.2.35, giữ lại danh mục cây, giá, tồn kho và báo giá; tạm ẩn giao diện phân công và tính lương. Mã nguồn nghiệp vụ cũ không bị xóa khỏi bản này. Luôn giữ ZIP V26.2.35 nguyên bản để khôi phục đầy đủ nếu cần.

## Luồng thao tác
1. Đăng nhập bằng tài khoản Admin, kết nối Google Drive.
2. Chọn ngày trong tab **Theo ngày** → **NHẬP PDF NHÃN ĐƠN**.
3. Kiểm tra danh sách nhãn. Đối chiếu sản phẩm với danh mục cây bên dưới; nhãn thiếu SKU/Qty hoặc không ghép đủ cây sẽ hiện **CẦN KIỂM TRA** và chưa được quét.
4. Chọn **QUÉT + TỰ CHỤP LIÊN TỤC**. Mã không thuộc danh sách/nghi trùng/thiếu ánh xạ bị bỏ qua trước khi chụp. Khi mã khớp, app tự chụp, lưu ảnh vào hàng đợi riêng trong bộ nhớ ứng dụng rồi tiếp tục quét; không chờ Drive tải xong.
5. Hai worker nền tải ảnh lên Drive và ghi báo cáo trong giao dịch Firestore. Ảnh tại máy chỉ bị xóa sau khi Drive có `drive://` và Firestore xác nhận báo cáo. Lỗi mạng giữ ảnh trong hàng đợi; nút thử lại có thể phục hồi cả ảnh còn sót sau khi ứng dụng bị đóng đột ngột.
6. Xem số đơn, đơn vị vận chuyển và ảnh ở **Báo cáo → Báo cáo vận chuyển**. Mã vận đơn được khóa bằng `shipmentTrackingClaims`; báo cáo ghi nhận là nguồn để trừ tồn kho đúng một lần. Không tạo đơn phân công hoặc tiền công từ luồng này.

## Hiệu năng
Luồng máy quét không chờ tải Drive/ghi báo cáo. Ảnh được nén JPEG và lưu cục bộ trước khi máy quét quay lại nhận mã kế tiếp; việc gửi ảnh và ghi báo cáo diễn ra nền, song song tối đa hai tác vụ. **Mốc 2 giây/đơn là mục tiêu tối ưu, chưa phải cam kết đo thực tế**: tốc độ còn phụ thuộc lấy nét, ánh sáng, camera, model điện thoại và cách người dùng đưa kiện hàng vào khung. Cần thử tại shop trên đúng điện thoại và nhãn thật để xác nhận.

## An toàn và giới hạn hiện tại
- Định dạng mã được hỗ trợ trong scanner giữ theo mã nguồn V26.2.35: `GHVN…`, `VNGH…`, mã J&T Express `862…`, mã J&T Cargo `530…`.
- Bộ nhập PDF tái sử dụng parser TikTok Shop đang có của V26.2.35; không tuyên bố hỗ trợ mọi cấu trúc PDF của hãng vận chuyển khác. PDF không đọc ra mã, SKU, Qty hoặc đơn vị vận chuyển sẽ cần xem lại trước khi quét.
- Firebase `shipmentTrackingClaims` là lớp chống trùng cuối cùng xuyên thiết bị. Nếu không kiểm tra được claim trước phiên quét, app không mở scanner.
- Cần giữ tài khoản Drive đang được kết nối có quyền truy cập thư mục ảnh `QuanLyCayAPK_Images`.
- Chưa chạy được build Gradle/Android thực tế trong môi trường biên tập này; preflight, test JavaScript, kiểm tra cú pháp JS và cấu trúc XML được chạy trong gói source. Hãy build bằng workflow GitHub Actions rồi thử cài trên máy thật trước khi dùng tại shop.

## Phiên bản
- `versionName`: `26.2.36`
- `versionCode`: `88`
- Nền tảng: Android WebView + Java, SDK 35; package `com.quanlycay.apk`
- Source gốc để rollback: `QuanLyCayAPK-V26.2.35-AUTO-UPDATE-SOURCE.zip`
