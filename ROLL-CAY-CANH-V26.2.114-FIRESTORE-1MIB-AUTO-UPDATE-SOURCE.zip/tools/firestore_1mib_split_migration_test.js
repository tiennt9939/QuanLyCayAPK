'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const rules = fs.readFileSync(path.join(root, 'firestore.rules'), 'utf8');
const rules87 = fs.readFileSync(path.join(root, 'firestore87.rules'), 'utf8');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/build-apk.yml'), 'utf8');
const preflight = fs.readFileSync(path.join(root, 'tools/preflight.py'), 'utf8');

assert(gradle.includes('versionName = "26.2.114"') && gradle.includes('versionCode = 166'), 'Firestore split must be a new installable Android version');
assert(preflight.includes('firestore_1mib_split_migration_test.js'), 'preflight must require this migration regression test');
assert(workflow.includes('V26.2.114') && workflow.includes('*AUTO-UPDATE-SOURCE.zip'), 'workflow must still build the selected complete auto-update source ZIP');

// Execute the production sizing/checksum/ID helpers in isolation. No Firebase calls are mocked as
// passing tests: these are pure helper tests only; the actual cloud migration needs Firebase access.
const helperStart = html.indexOf('  // V26.2.114: unbounded PDF labels/reports');
const helperEnd = html.indexOf('  async function writeShipmentManifest(manifest)', helperStart);
assert(helperStart >= 0 && helperEnd > helperStart, 'pure shipment storage helpers are missing');
const context = {
  TextEncoder,
  unescape,
  encodeURIComponent,
  normalizeTracking(value) { return String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); },
  cleanDailyShipmentFirestoreValue(value) { return JSON.parse(JSON.stringify(value)); },
};
vm.runInNewContext(html.slice(helperStart, helperEnd) + '\nthis.testApi={shipmentUtf8Bytes,shipmentStableJson,shipmentChecksum,shipmentRecordId,shipmentRecordEnvelope,shipmentRowsFromSnapshot,shipmentRootSizeDiagnostic,shipmentWithoutQueueFields,shipmentRowsEqual};', context);
const api = context.testApi;
assert.strictEqual(api.shipmentUtf8Bytes('Cây cảnh 🍀'), Buffer.byteLength('Cây cảnh 🍀', 'utf8'), 'byte sizing must count UTF-8 bytes, not JS characters');
assert.strictEqual(api.shipmentStableJson({ z: 1, a: { y: 2, b: 3 } }), '{"a":{"b":3,"y":2},"z":1}', 'canonical JSON must sort object keys deterministically');
assert.strictEqual(api.shipmentChecksum({ b: 2, a: 1 }), api.shipmentChecksum({ a: 1, b: 2 }), 'checksums must be independent of object insertion order');
assert.notStrictEqual(api.shipmentChecksum({ a: 1 }), api.shipmentChecksum({ a: 2 }), 'checksums must detect changed values');
assert.strictEqual(api.shipmentRecordId({ trackingNo: '862-652 114050' }), '862652114050', 'record ID must be stable after tracking normalization');
const diagnostic = api.shipmentRootSizeDiagnostic({ data: { dailyShipmentOrders: 'old', catalog: [{ name: 'Nguyệt quế' }] }, dailyShipmentStorageSchema: 1 });
assert(diagnostic.estimatedDocumentBytes > 0 && diagnostic.maxAllowedBytes === 1048576 && diagnostic.writeSafetyLimitBytes === 921600, 'root size diagnostic must retain Firestore hard limit and a lower safety threshold');
assert(diagnostic.largestFields.some(field => field.field === 'data.dailyShipmentOrders'), 'size diagnostic must identify largest data fields');
const compacted = api.shipmentWithoutQueueFields({ catalog: [1], dailyShipmentOrders: [2], dailyShipmentReports: [3], rates: [4] });
assert.deepStrictEqual(JSON.parse(JSON.stringify(compacted)), { catalog: [1], rates: [4] }, 'root compaction must remove only the two split arrays and retain other data');
const orderedDocs = { docs: [{ id: '000002_x', data: () => ({ record: { trackingNo: 'B' } }) }, { id: '000001_x', data: () => ({ record: { trackingNo: 'A' } }) }] };
assert.deepStrictEqual(JSON.parse(JSON.stringify(api.shipmentRowsFromSnapshot(orderedDocs))), [{ trackingNo: 'A' }, { trackingNo: 'B' }], 'backup read-back must sort deterministic backup IDs');

// End-to-end flow coverage by source assertions. These guard the connected readers and writers,
// but do not substitute for Firebase Emulator / live-project acceptance tests.
assert(html.includes("const dailyShipmentOrdersRef=()=>sharedRef().collection('dailyShipmentOrders')"), 'per-label collection is missing');
assert(html.includes("const dailyShipmentReportsRef=()=>sharedRef().collection('dailyShipmentReports')"), 'per-report collection is missing');
assert(html.includes("collection('dailyShipmentMigrationBackups')") && html.includes("collection('dailyShipmentMigrations')"), 'migration must preserve backup rows and a manifest');
assert(html.includes("phase:'prepared'") && html.includes("phase:'committed'"), 'migration needs prepare/commit phases');
assert(html.includes('backupOrders.length!==legacyOrders.length') && html.includes('verifiedOrders.length!==queueRows.length'), 'migration must count/checksum/read-verify backups and target collections before compaction');
assert(html.includes("'data.dailyShipmentOrders':firebase.firestore.FieldValue.delete()") && html.includes("'data.dailyShipmentReports':firebase.firestore.FieldValue.delete()"), 'migration must explicitly delete the old nested array fields instead of relying on merge omission');
assert(html.includes('ref.update(...shipmentDataUpdateArguments(safeData,rootPatch,true,false))') && html.includes('const projectedData={...(currentRoot.data') && html.includes('hasOwnProperty.call(currentRoot,\'packingOrders\')'), 'normal writes must remove migrated nested arrays but not silently delete an unexpected root-level packingOrders field');
assert(html.includes('const [postRootSnap,postOrders,postReports]=await Promise.all'), 'migration must read back and verify after root compaction');
assert(html.includes('rootSizeAfterCompaction:diag') && html.includes('shipmentRootSizeDiagnostic(candidateRoot)'), 'migration and rollback must preflight document size');
assert(html.includes('if(diagnostic.estimatedDocumentBytes>diagnostic.writeSafetyLimitBytes)throw new Error'), 'rollback must refuse to write an oversized legacy array document');
assert(html.includes('Do not delete the record collections or backup: rollback must stay reversible.'), 'rollback must preserve split records and backup copies');
assert(html.includes('dailyShipmentBackupSnapshotRef=(snapshotId,kind)'), 'each immutable backup snapshot must have an isolated path');
assert(html.includes("if(rootPackingOrders.length)await shipmentWriteRows(dailyShipmentBackupSnapshotRef(snapshotId,'legacyPackingOrders')") && html.includes('backupPackingOrders.length!==rootPackingOrders.length'), 'legacy root-level packingOrders must be backed up and reconciled before it is removed');
assert(html.includes('if(Object.prototype.hasOwnProperty.call(currentRoot,\'packingOrders\'))throw new Error'), 'normal root sync must not silently delete an unexpected root-level packingOrders field');
assert(html.includes('freshHasPackingOrders!==source.hasRootPackingOrders') && html.includes('freshPackingOrders)!==source.rootPackingOrdersChecksum'), 'migration must detect concurrent changes to root-level packingOrders');
assert(html.includes("createOnly=false") && html.includes('Migration gặp bản ghi split đã tồn tại nhưng khác nội dung') && html.includes("{leaseId:migrationLeaseId,createOnly:true}"), 'migration must not overwrite concurrent operational changes with stale root rows');
assert(html.includes('const [freshSnap,leaseSnap]=await Promise.all([tx.get(appRef),tx.get(migrationRef)])') && html.includes('leaseData.leaseUntilMs||0)<=Date.now()'), 'root compaction transaction must verify lease ownership atomically');
assert(html.includes('await renewDailyShipmentMigrationLease(rollbackLeaseId);') && html.includes("await writeShipmentManifest({phase:'rolled_back'"), 'rollback must renew lease before restoring root and committing manifest');
assert(html.includes('tx.update(appRef,commitFields)') && html.includes('shipmentChecksum(freshOrders)!==source.ordersChecksum'), 'root compaction must transactionally detect concurrent changes before removing legacy arrays');
assert(html.includes("recoveryManifest.phase!=='prepared'||!recoveryManifest.target||!recoveryManifest.backup"), 'recovery after interrupted root compaction must validate the prepared manifest');
assert(html.includes('const DAILY_SHIPMENT_MIGRATION_LEASE_MS=120000'), 'migration/recovery/rollback must use a bounded lease');
assert(html.includes('async function acquireDailyShipmentMigrationLease(leaseId)') && html.includes('async function renewDailyShipmentMigrationLease(leaseId)') && html.includes('async function releaseDailyShipmentMigrationLease(leaseId)'), 'exclusive migration lease acquire/renew/release functions are required');
assert(html.includes('await acquireDailyShipmentMigrationLease(recoveryLeaseId)') && html.includes('await renewDailyShipmentMigrationLease(recoveryLeaseId)'), 'interrupted migration recovery must take and renew an exclusive lease');
assert(html.includes('await acquireDailyShipmentMigrationLease(rollbackLeaseId)') && html.includes('finally{await releaseDailyShipmentMigrationLease(rollbackLeaseId)}'), 'rollback must hold/release the same migration lease');
assert(html.includes("if(String(manifest.leaseId||'')!==rollbackLeaseId)throw new Error"), 'rollback must check that the lease remains owned before writes');
assert(html.includes('const cloudShipment=await readDailyShipmentCollections(currentRoot.data||{})'), 'push must merge current records before persisting local state');
assert(html.includes('persistDailyShipmentCollections(safeOrders,safeReports,{mergeCloud:true})'), 'admin push must save records separately and idempotently');
assert(html.includes('delete x.dailyShipmentOrders') && html.includes('delete x.dailyShipmentReports') && html.includes('cloudDataSnapshot()'), 'shared root payload must exclude queue and report arrays');
assert(html.includes("where('assignedUid','==',uid).get()"), 'employee loader must query only assigned labels');
assert(html.includes('merge({...sharedAppRootCache,__dailyShipmentOrders:sharedQueueRowsCache,__dailyShipmentReports:sharedReportRowsCache}'), 'realtime listener must hydrate the split collections');

const assignmentStart = html.indexOf('  async function adminAssignDailyShipmentLabels(');
const assignmentEnd = html.indexOf('  async function loadAssignedDailyShipmentLabels(', assignmentStart);
const assignment = html.slice(assignmentStart, assignmentEnd);
assert(assignment.includes('queueRefs=trackingKeys.map') && assignment.includes('reportRefs=trackingKeys.map'), 'assignment transaction must read split queue/report documents');
assert(assignment.includes('tx.set(dailyShipmentOrdersRef().doc(tracking),shipmentRecordEnvelope(row,\'order\'))'), 'assignment transaction must update per-record docs');
assert(assignment.includes('data:nextData') && assignment.includes('shipmentWithoutQueueFields({...data})'), 'assignment must not re-embed queue arrays in root');

const scanStart = html.indexOf('  async function recordDailyShipmentScan(');
const photoStart = html.indexOf('  async function attachDailyShipmentPhoto(', scanStart);
const cancelStart = html.indexOf('  async function cancelDailyShipmentScan(', photoStart);
const deliveryStart = html.indexOf('  async function adminLinkTikTokPdfToDeliveryOrder(', cancelStart);
assert(scanStart > 0 && photoStart > scanStart && cancelStart > photoStart && deliveryStart > cancelStart, 'scan/photo/cancel functions must exist');
const scan = html.slice(scanStart, photoStart);
const photo = html.slice(photoStart, cancelStart);
const cancel = html.slice(cancelStart, deliveryStart);
assert(scan.includes('tx.set(queueRef,shipmentRecordEnvelope(storedUpdatedOrder,\'order\'))') && scan.includes('tx.set(reportRef,shipmentRecordEnvelope(normalizedReport,\'report\'))'), 'scan must atomically write claim, scan, per-label and per-report docs');
assert(photo.includes('tx.set(queueRef,shipmentRecordEnvelope') && photo.includes('tx.set(reportRef,shipmentRecordEnvelope'), 'photo attach must update split docs');
assert(cancel.includes('tx.set(queueRef,shipmentRecordEnvelope(pendingPatch,\'order\'))') && cancel.includes('tx.set(reportRef,shipmentRecordEnvelope(voided,\'report\'))'), 'cancel/void must update split docs instead of root arrays');
assert(!cancel.includes('const sharedData={dailyShipmentOrders:orders}'), 'cancel must not reintroduce the legacy queue array');
assert(html.includes('const appData={...rootData,dailyShipmentOrders:dailyShipmentMergeSharedQueueRows'), 'date reset preview must hydrate per-record collections');
assert(html.includes('data:shipmentWithoutQueueFields(nextData)'), 'date reset root write must exclude queue arrays');
assert(html.includes('const nextData=shipmentWithoutQueueFields(data)'), 'legacy cleanup root write must exclude queue arrays');

for (const ruleText of [rules, rules87]) {
  assert(ruleText.includes('cleanSplitAppUpdate(appId)'), 'Firestore rules must block old clients reintroducing arrays after migration');
  assert(ruleText.includes("match /apps/{appId}/dailyShipmentOrders/{recordId}"), 'Firestore queue record rules missing');
  assert(ruleText.includes("match /apps/{appId}/dailyShipmentReports/{recordId}"), 'Firestore report record rules missing');
  assert(ruleText.includes('dailyShipmentMigrationBackups/{migrationId}/{nested=**}') && ruleText.includes('allow read, write: if appId == \'roll-cay-canh\' && isAdmin()'), 'only Admin should access immutable migration backup paths');
  assert(ruleText.includes('packerCanWriteOwnSplitOrder') && ruleText.includes('packerCanWriteOwnSplitReport'), 'rules must allow tightly scoped packer scan updates only for own assigned records');
  assert(ruleText.includes('request.resource.data.storageRollbackAtMs is number') && ruleText.includes('request.resource.data.dailyShipmentStorageSchema == 1'), 'Admin-only, marked rollback must be allowed by rules without opening legacy writes to normal clients');
  assert(ruleText.includes("!('packingOrders' in request.resource.data)"), 'schema 2 rules must block reintroducing the old root-level packingOrders cache');
}
console.log('FIRESTORE 1 MiB SPLIT/MIGRATION HELPER + FLOW REGRESSION TEST PASS (offline/static; no live Firestore executed)');
