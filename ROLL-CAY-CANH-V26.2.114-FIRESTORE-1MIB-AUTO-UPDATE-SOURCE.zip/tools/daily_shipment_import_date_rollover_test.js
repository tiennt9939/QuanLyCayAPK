const assert=require('assert'),fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8');
const preflight=fs.readFileSync(path.join(root,'tools/preflight.py'),'utf8');
assert(gradle.includes('versionName = "26.2.114"')&&gradle.includes('versionCode = 166'),'V26.2.114 metadata');
assert(preflight.includes('versionName = "26.2.114"')&&preflight.includes('versionCode = 166'),'preflight version metadata');
assert(html.includes('dailyShipmentPreparePdfImportDate();'),'all PDF picker routes must prepare the import date before opening Android picker');
assert(html.includes('Ngày nhập PDF đã tự cập nhật từ'),'stale date rollover notice missing');
const a=html.indexOf('function dailyShipmentPreparePdfImportDate(){');
const b=html.indexOf('\nfunction startTikTokPdfImport(){',a);
assert(a>=0&&b>a,'date rollover helper was not found');
const scenario={today:'2026-10-26',input:{value:'2026-10-25',dataset:{}},toasts:[],requests:[],console:{info:()=>{},warn:()=>{}},
  $:(id)=>id==='dDate'?scenario.input:id==='dailyShipmentStatus'?null:null,
  dailyShipmentToday:()=>scenario.today,fmtDMY:(x)=>{const [y,m,d]=x.split('-');return `${d}/${m}/${y}`;},
  toast:(x)=>scenario.toasts.push(x),requestDailyShipmentCloudRange:(...x)=>scenario.requests.push(x)};
vm.createContext(scenario);vm.runInContext(html.slice(a,b),scenario);
assert.equal(scenario.dailyShipmentPreparePdfImportDate(),'2026-10-26');
assert.equal(scenario.input.value,'2026-10-26');
assert.equal(scenario.requests.length,1);
assert(scenario.toasts[0].includes('25/10/2026')&&scenario.toasts[0].includes('26/10/2026'));
// If Admin explicitly picked a historical day today, keep it; do not overwrite their intent.
scenario.input.value='2026-10-24';scenario.input.dataset.userSelectedDate='2026-10-24';scenario.input.dataset.userSelectedOn='2026-10-26';scenario.toasts=[];scenario.requests=[];
assert.equal(scenario.dailyShipmentPreparePdfImportDate(),'2026-10-24');
assert.equal(scenario.input.value,'2026-10-24');assert.equal(scenario.toasts.length,0);assert.equal(scenario.requests.length,0);
// An explicit historical selection from yesterday becomes stale after midnight and rolls forward.
scenario.input.dataset.userSelectedOn='2026-10-25';
assert.equal(scenario.dailyShipmentPreparePdfImportDate(),'2026-10-26');
assert.equal(scenario.input.value,'2026-10-26');
console.log('V26.2.114 PDF IMPORT DATE ROLLOVER TEST PASS');
