const assert = require('assert');
const fs = require('fs');
const path = require('path');
const parser = require('../app/src/main/assets/tiktok-label-import.js');

const root = path.resolve(__dirname, '..');
const java = fs.readFileSync(path.join(root, 'app/src/main/java/com/quanlycay/apk/MainActivity.java'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');

assert(gradle.includes('versionName = "26.2.114"') && gradle.includes('versionCode = 166'), 'V26.2.114 metadata missing');
assert(gradle.includes('com.google.mlkit:barcode-scanning:17.3.0'), 'Bundled ML Kit barcode dependency missing');
assert(java.includes('import com.google.mlkit.vision.barcode.common.Barcode;'), 'Barcode must be imported from the ML Kit barcode.common package');
assert(!java.includes('import com.google.mlkit.vision.barcode.Barcode;'), 'Obsolete Barcode import package must not return');
assert(java.includes('BarcodeScanning.getClient(pdfBarcodeOptions)'), 'PDF barcode fallback must instantiate ML Kit scanner');
assert(java.includes('pdfBarcodeScanner.process(pdfImage)'), 'PDF barcode fallback must scan the rendered page');
assert(java.includes('renderImageWithDPI(page - 1, 220f, ImageType.RGB)'), 'Fallback render resolution must be high enough for small label text/barcodes');
assert(java.includes('.put("barcodeText", barcodeText)'), 'Native barcode results must be sent to the JS parser');
assert(html.includes('barcodeChars') && html.includes('ocrErrors') && html.includes('barcodeErrors'), 'No-tracking diagnostic must distinguish OCR/barcode failure counters');

// Raster-only page: native PDF text layers are blank. OCR returns order/product fields,
// and the independent linear-barcode channel recovers the exact tracking ID.
const orderId = '586781745208198676';
const page = {
  page: 1,
  text: '',
  fallbackText: '',
  visualText: '',
  ocrText: `Order ID: ${orderId}\nProduct Name SKU Seller SKU Qty\nCẩm tú mai thái C7 1 chậu C7 1000 1\nQty Total: 1`,
  barcodeText: 'VNGH80866350619',
  tableRows: [{ productName: 'Cẩm tú mai thái C7', sku: '1 chậu C7', sellerSku: '1000', qty: 1 }]
};
const parsed = parser.parsePages([page]);
assert.strictEqual(parsed.length, 1, 'One rendered PDF page should produce one parsed label');
assert.strictEqual(parsed[0].trackingNo, 'VNGH80866350619', 'Barcode-only tracking must be recovered');
assert.strictEqual(parsed[0].carrier, 'GHN', 'Recovered tracking must preserve carrier');
assert.strictEqual(parsed[0].orderId, orderId, 'OCR Order ID should remain intact');
assert.strictEqual(parsed[0].products.length, 1, 'OCR/table product rows should remain intact');
assert.strictEqual(parsed[0].status, 'ready', 'A page with tracking, Order ID and a valid product row should be ready');

// Some PDF/OCR outputs break a human-readable tracking ID across lines. The parser must
// still recognize the same canonical ID without guessing a plant or changing quantities.
const broken = parser.extractTracking('V\nN\nG\nH\n8\n0\n8\n6\n6\n3\n5\n0\n6\n1\n9');
assert.deepStrictEqual(broken, ['VNGH80866350619']);
const jt = parser.extractTracking('8\n6\n2\n6\n3\n1\n5\n8\n6\n4\n4\n2');
assert.deepStrictEqual(jt, ['862631586442']);
console.log('V26.2.114 PDF IMAGE + BARCODE TRACKING FALLBACK TEST PASS');
