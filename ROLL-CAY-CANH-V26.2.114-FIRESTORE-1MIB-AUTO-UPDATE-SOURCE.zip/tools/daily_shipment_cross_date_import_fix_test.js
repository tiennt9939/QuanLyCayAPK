const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const preflight = fs.readFileSync(path.join(root, 'tools/preflight.py'), 'utf8');
assert(gradle.includes('versionName = "26.2.114"') && gradle.includes('versionCode = 166'), 'V26.2.114 metadata missing');
assert(preflight.includes('versionName = "26.2.114"') && preflight.includes('versionCode = 166'), 'preflight metadata mismatch');
assert(html.includes('const matches=map.get(tracking)||[],report=dailyShipmentReportByTracking(tracking);'), 'daily import must inspect all rows for a tracking ID');
assert(html.includes('prior.date=date;movedToSelectedDate++'), 'safe unassigned old-date rows must be moved into the selected day');
assert(html.includes('const safePrior=matches.find(row=>dailyShipmentCanRebaseUnassignedPdfLabel(row,report,targetUid))||null;'), 'safe unprocessed staging row must be preferred and concrete processed rows protected');
assert(html.includes('conflictsOtherDate') && html.includes('conflictsOtherEmployee'), 'employee import must report exact conflict categories');

const start = html.indexOf('function dailyShipmentLabelHasProtectedHistory(');
const end = html.indexOf('\nfunction startDailyShipmentPdfImport(){', start);
assert(start >= 0 && end > start, 'cannot isolate daily shipment import helpers');
const code = html.slice(start, end);
const context = {
  D: {dailyShipmentOrders: []},
  $: id => id === 'dDate' ? {value:'2026-10-25'} : null,
  normalizeTracking: t => String(t || '').toUpperCase().replace(/[^A-Z0-9]/g,''),
  dailyShipmentApplyResetMarkers: () => {},
  dailyShipmentReportByTracking: tracking => (context.reports || []).find(r => r.trackingNo === tracking) || null,
  inferShipmentCarrierFromTracking: () => 'J&T',
  save: () => {}, dailyShipmentPersistLocalBackup: () => {}, renderDailyShipmentPanel: () => {},
  dailyShipmentOrdersForSelectedDate: () => context.D.dailyShipmentOrders.filter(r => r.date === '2026-10-25'),
  reports: []
};
vm.createContext(context);
vm.runInContext(code, context);
const parseRow = trackingNo => ({trackingNo, carrier:'J&T', orderId:'ORDER1', page:1, products:[{productName:'Cẩm tú mai C7', qty:1}], status:'ready'});
context.D.dailyShipmentOrders = [{trackingNo:'862631586442', source:'pdf_label', status:'imported', date:'2026-10-24', products:[], assignedUid:'', assignmentRequired:false, assignmentStatus:'unassigned'}];
let res = context.importParsedLabelsIntoDailyShipments([parseRow('862631586442')], {uid:'huy'});
assert.strictEqual(res.movedToSelectedDate, 1, 'safe old staging row must move to current selected date');
assert.strictEqual(context.D.dailyShipmentOrders[0].date, '2026-10-25');
assert.strictEqual(res.updated, 1, 'refreshed parsed product data must update the existing staging row');

context.D.dailyShipmentOrders = [{trackingNo:'862693306442', source:'pdf_label', status:'assigned', date:'2026-10-24', products:[{productName:'existing'}], assignedUid:'staff2', assignmentRequired:true, assignmentStatus:'assigned'}];
res = context.importParsedLabelsIntoDailyShipments([parseRow('862693306442')], {uid:'huy'});
assert.strictEqual(res.movedToSelectedDate, 0, 'assigned row must never move dates');
assert.strictEqual(res.skippedProtectedOtherDate, 1, 'protected cross-date row must be counted');
assert.strictEqual(context.D.dailyShipmentOrders[0].date, '2026-10-24');
assert.strictEqual(res.total, 0, 'protected prior-day row must not appear as a new current-day row');

context.D.dailyShipmentOrders = [];
res = context.importParsedLabelsIntoDailyShipments([parseRow('862600576452')], {uid:'huy'});
assert.strictEqual(res.added, 1, 'truly new tracking should be added');
assert.strictEqual(context.D.dailyShipmentOrders[0].date, '2026-10-25');
console.log('V26.2.114 DAILY SHIPMENT CROSS-DATE IMPORT FIX TEST PASS');
