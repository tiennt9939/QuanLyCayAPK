# ROLL CÂY CẢNH V26.2.114 — Firestore 1 MiB split/migration

**Nền source:** V26.2.113, không dựng lại dự án. **Android versionName:** `26.2.114`; **versionCode:** `166`.

Bản này giữ nguyên Android WebView + Java, Firebase Auth/Firestore, Google Drive, catalog, giá, tồn kho, logic tiền công và luồng nhận diện TikTok PDF. Thay đổi trọng tâm là chuyển nhãn PDF/báo cáo vận chuyển tăng trưởng liên tục ra từng Firestore document riêng để `apps/roll-cay-canh` không còn chứa các mảng này. Dữ liệu được sao lưu theo snapshot, đối soát trước/sau commit, kiểm tra dung lượng theo ngưỡng an toàn và có rollback có điều kiện. Không có thao tác reset Firestore hoặc xóa lịch sử chạy trong gói source này.

## Trước khi dùng

1. **Không clear storage, không reset dữ liệu và không import lại PDF chỉ để xử lý lỗi đồng bộ.** Giữ nguyên dữ liệu trên điện thoại cho đến khi đối chiếu local/cloud.
2. Triển khai rules tương thích mới (`firestore.rules` hoặc bản đúng nhánh đang dùng là `firestore87.rules`) lên đúng Firebase project trước khi cài app mới. Hai file rules đã được cập nhật nhưng **chưa được deploy** từ môi trường này.
3. Build/cài V26.2.114 chỉ sau khi GitHub Actions hoàn tất xanh. Gói ZIP có workflow tự chạy preflight, 102 test JavaScript và kiểm tra cú pháp script; build APK còn yêu cầu secret `DEBUG_KEYSTORE_BASE64` trong repository.
4. Khi Admin chạy bản mới, migration tạo backup theo snapshot, ghi/đọc lại collection nhãn và báo cáo, đối chiếu số lượng/checksum/nội dung rồi mới xóa hai mảng khỏi document gốc. Nếu còn field lớn hoặc có xung đột đồng thời, migration dừng giữ nguyên nguồn và báo lỗi thay vì tự bỏ lịch sử.

## Tài liệu

- `README_V26.2.114_FIRESTORE_SPLIT.md`: thay đổi và trình tự triển khai.
- `ROLL_CAY_CANH_V26.2.114_AUDIT_REPORT.md`: luồng reader/writer, bảo đảm đối soát/rollback, kiểm thử và giới hạn xác minh.
- `tools/firestore_1mib_split_migration_test.js`: test sizing/helper và kiểm tra kết nối các luồng nguồn (offline/static; không thay thế Firebase Emulator hoặc test live).
