# ROLL CÂY CẢNH V26.2.140 — GAS runtime stabilization / transaction repair

- Android `versionName`: `26.2.140`; `versionCode`: `192`.
- Package: `com.quanlycay.apk`.
- Based on V26.2.131; this is a continuation of the current project, not a rebuild from scratch.

## What changed

1. Added app-private, atomic JSON storage APIs for durable per-record offline queues.
2. Persists TikTok PDF staging labels in Android app-private storage, with WebView localStorage retained as a compatibility cache.
3. Adds an offline outbox per daily shipment scan. Each entry retains its tracking code, assigned employee, plant/wage snapshot, assignment revision, operation ID, and native photo path. No Base64 photo is duplicated into the report outbox.
4. Admin bulk scan can use already-cached labels and assignments when cloud refresh or duplicate pre-check cannot be reached. It warns that queued items have not yet been accepted by Firebase.
5. Uses shorter cloud setup timeouts and queues likely connection/time-out failures locally rather than waiting indefinitely.
6. On reconnection/foreground/manual retry, syncs each outbox entry sequentially. Before backend cutover Firestore is the migration source; after the verified server-side cutover the app routes business reads/writes to Apps Script + Sheets. The backend enforces duplicate/assignment checks and operation IDs.
7. Uploads photos to Google Drive separately. A photo is acknowledged/deleted from native pending storage only after Drive upload and Firebase attachment are confirmed.
8. Pending photo metadata keeps up to 1,000 local entries instead of 300; the per-record native outbox is the authoritative recovery path for offline scan reports.

## Important offline behavior

- Offline scanning requires the PDF labels, assignment, plant mapping and employee wage data to have been downloaded and saved on this phone before the network is lost. New remote assignments/orders will not appear until sync.
- Offline-queued scans are not counted as server-confirmed wages or inventory changes until Firebase accepts them.
- If the assignment changed, another device claimed the tracking number, or a conflicting report exists, the item is retained in `needs_review`; it is not silently re-awarded. Admin must inspect it after reconnecting.
- Native per-record queues live in Android app-private storage. They survive a normal app restart/update but can be lost if app data is cleared or the app is uninstalled. Do not clear application data before the queue is empty.
- Firebase Authentication remains the sign-in/token provider. Google Sheets is the business-data backend after the verified cutover, and Google Drive continues to store photos. Payroll formulas, inventory logic, plant recognition, and the existing data model are preserved.

## Verification

- `python3 tools/preflight.py`: PASS.
- All 122 files matching `tools/*_test.js`: PASS.
- Inline JavaScript syntax: 9 script blocks plus all external JS modules and the Apps Script source: PASS.
- GAS auto-cutover gate test: PASS.
- Android APK build: not run in this environment (no Android SDK/Gradle installation or Gradle wrapper in this workspace).
- No live Firebase/Drive acceptance test and no physical-device offline/reconnect test were run. GitHub Actions must build the source, followed by a controlled device test before production use.

## GAS migration and cutover

- The Apps Script source in `Code.gs` adds an admin-only import route that works while ordinary GAS business writes are still disabled. Imported paths are restricted to the app collection roots.
- The migration backs up pre-existing conflicting GAS documents into the `fsCompatMigrationBackup` sheet, copies the current Firestore source-of-truth values over those conflicts, reads back every known document, compares serialized data and computes a checksum. It does not delete or mutate Firestore source records. Conflicts cannot overwrite GAS data until the backup succeeds.
- Only after full verification does Apps Script store the migration report and enable `ROLL_GAS_CUTOVER_COMPLETED` and `ROLL_GAS_COMPAT_WRITES_ENABLED`. The next app load routes business data to GAS.
- If the GAS health check cannot be reached, the app blocks synchronization instead of silently falling back to Firestore.
- Before releasing, replace Apps Script `Code.gs` with the bundled version and redeploy the existing Web App URL. Keep `ROLL_GAS_COMPAT_WRITES_ENABLED=false` before migration; the admin import route is separately gated. Do not set `ROLL_GAS_CUTOVER_COMPLETED` manually.

## GitHub Actions

The source archive must be named exactly `ROLL-CAY-CANH-V26.2.140-AUTO-UPDATE-SOURCE.zip` and must contain the Android project files at the ZIP root. Push it to the repository root on `main` to trigger `.github/workflows/build-apk.yml`. For publishing an in-app update Release, configure repository secrets `DEBUG_KEYSTORE_BASE64` (the stable signing keystore) and `EXPECTED_APK_CERT_SHA256` (the expected signing certificate SHA-256). Without the expected fingerprint, GitHub Actions can still create an APK Artifact but deliberately skips publishing a Release to avoid an incompatible signature.


## Audit patch V26.2.137 (2026-10-29)
- Prevent overlapping Google Drive sign-in launches (avoids SIGN_IN_CURRENTLY_IN_PROGRESS / status 12502 caused by duplicate launches).
- GAS Code.gs included in this source must be deployed as a new Apps Script Web App version before migration retry; do not manually set cutover properties.
- GAS compatibility reads now avoid loading the large operation-result column for document-index reconstruction; operation idempotency lookup uses a targeted search and fetches only the matching result.
- This source still keeps `ROLL_GAS_BACKEND_ENABLED = false` until server-side migration verification confirms cutover.


## Audit hotfix V26.2.137 (2026-10-30)
- Increased the Firestore legacy shipment-storage preparation timeout from 16 seconds to 120 seconds. The previous 16-second Promise.race rejected while the migration task itself could still be running, causing sync to report a false failure and potentially overlap retries. This is a targeted timeout fix only; it does not itself complete the GAS cutover.
- Kept Firestore source data intact; do not delete source records until the migration reports full verification.


## Account directory and assignment recovery V26.2.139 (2026-10-30)
- The admin user directory now reads the active backend and the read-only Google Sheets migration snapshot in parallel, instead of waiting through a sequential 12s + 18s fallback.
- GAS backup profiles are merged by Firebase UID. Existing non-empty values in the active backend always win; only absent email/role/employee link fields can be filled from the migration snapshot.
- The account screen exposes an explicit Admin-only recovery action for missing/incomplete `/users/{uid}` profiles. It rechecks each UID before writing, skips Admin profiles, preserves existing roles and `active:false`, checks duplicate employee links, writes only missing fields, then reads the profile back to verify it.
- Unrestored profiles from the backup are deliberately excluded from employee assignment and employee-specific PDF import. Once restored into the active backend, they become selectable for assignment/import.
- The GAS compatibility API now rebuilds only the requested collection index for ordinary `get`, `query`, and `multiQuery` reads. It reads compact row metadata for the sheet and fetches JSON payload chunks only for the latest document versions in the requested collection, so looking up `users` does not parse thousands of unrelated shipment-history documents.
- Existing Firebase Auth accounts are linked by UID/email profile when a matching saved user record exists; linking an existing email does not create a second Auth identity. Existing locked accounts remain locked.
- This patch is source-tested only. Before using recovery, replace the deployed Apps Script `Code.gs` with this bundle and deploy a new Web App version, then install the GitHub Actions APK. Validate one staff account before running the bulk recovery button. No live Firebase/Apps Script account migration or physical-device acceptance test was available in this environment.

## GAS runtime stabilization V26.2.140 (2026-10-30)
- Replaced one-request-per-document transaction reads with microtask-batched `getMany` requests (up to 100 documents per request). This directly targets multi-order assignment, daily PDF staging, scan and claim transactions that previously generated many serial Apps Script round trips.
- `getMany` is now a normal Firestore-compatible transaction read endpoint. It applies the same per-document read authorization as `get`; active packers can read only their assigned orders and permitted scan/claim records, while other users' profiles and other employees' orders remain denied. Tombstone versions are retained for optimistic concurrency.
- GAS document commits now read compact sheet metadata and materialize only directly affected documents plus the small cross-document set needed by the security checks. They no longer reconstruct all `fsCompatDocs` JSON payloads for each write/import batch.
- Collection queries read only the selected collection's latest payload chunks, and adjacent payload rows are fetched in contiguous ranges. This removes one Apps Script Spreadsheet service call per JSON chunk.
- Migration finalization now validates the Admin profile from the metadata scan directly. It no longer references the undefined `finalIndex` symbol that could stop finalization after the data-copy verification had completed.
- The Cloud settings panel now shows the active business backend and has an Admin-only read-only backend diagnostic for the profile, shared app document, orders, account directory, PDF queue/reports and GAS health. Diagnostics do not change application data.
- The client now requires the exact phase-3.0 GAS compatibility version before using the GAS directory sidecar or accepting a server-confirmed cutover. An older pre-cutover GAS server is clearly flagged while Firestore remains active; an old server that claims cutover causes a fail-closed warning instead of silent split-brain writes.
- Added regression tests for 125 transaction reads batching into two requests, role-scoped bulk reads, tombstone version preservation, migration finalization Admin profile validation, full handler integration for non-Admin packer reads and cutover finalization, and scoped/batched sheet payload retrieval.
- The GAS cutover remains fail-closed: `ROLL_GAS_BACKEND_ENABLED` is not forced on in the client. The app continues on Firestore until the deployed GAS endpoint confirms `cutoverCompleted=true` and `writesEnabled=true`; it must not split writes between Firestore and GAS.
- Validation: `python3 tools/preflight.py` PASS; 121/121 Node tests PASS; 9 inline JavaScript blocks, all external JS assets and `Code.gs` syntax PASS; ZIP integrity PASS. This is source-level and mocked regression coverage only. No live Google Apps Script deployment, Firebase account, Android device acceptance or APK build was available here.
