'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');

assert(gradle.includes('versionName = "26.2.140"') && gradle.includes('versionCode = 192'), 'release metadata must match V26.2.140/code 192');
assert(html.includes('scheduleDailyShipmentSharedRecognitionRepair(allRows,date)'), 'assignment board must schedule recognition-rule refresh asynchronously');
assert(!html.includes('if(actualAdmin)await ensureDailyShipmentSharedRecognitionMappings(allRows,date)'), 'assignment board must not wait for Firebase mapping reads before rendering rows');
assert(html.includes('function syncDailyShipmentQueueForAssignment()'), 'a targeted queue-only Firebase sync must exist');
assert(html.includes('syncDailyShipmentQueueForAssignment,loadAssignedDailyShipmentLabels'), 'targeted queue sync must be exposed through CloudSync state');
assert(html.includes("localStorage.setItem('roll_pdf_queue_local_pending','1')") && html.includes("if(window.__rollPdfQueueOnlyImportSave===true)"), 'clean PDF imports must mark and sync only the PDF queue instead of the full app payload');
assert(html.includes('const queueSync=typeof api.syncDailyShipmentQueueForAssignment===\'function\''), 'assignment must use targeted PDF queue sync when appropriate');
assert(html.includes('const date=String($(\'dDate\')?.value||dailyShipmentToday()),chunkSize=10,totalChunks=Math.ceil(assignments.length/chunkSize)'), 'bulk assignment must be chunked to avoid one oversized transaction');
assert(html.includes('ghi phân công nhóm ${chunkNo}/${totalChunks}'), 'each assignment transaction must have a bounded wait with a labeled stage');
const assignmentStart = html.indexOf('async function applyDailyShipmentAssignments(');
const assignmentEnd = html.indexOf('\nasync function assignPendingEmployeePdfRows(', assignmentStart);
assert(assignmentStart >= 0 && assignmentEnd > assignmentStart, 'bulk assignment function must be present');
const assignment = html.slice(assignmentStart, assignmentEnd);
assert(assignment.includes('ĐANG CHIA ĐƠN') && assignment.includes('CHIA ĐƠN CHƯA HOÀN TẤT'), 'assignment UI must show progress and partial failure rather than silently hang');
assert(assignment.includes('dailyShipmentAwaitWithTimeout(api.syncDailyShipmentQueueForAssignment(),queueSyncTimeoutMs'), 'assignment must sync only the PDF queue with a batch-size-aware timeout');
assert(!assignment.includes('window.CloudSync.pushNow()'), 'PDF assignment must not wait on full-app sync');
assert(html.includes('dailyShipmentAwaitWithTimeout(st.recordDailyShipmentScan(reportDraft') && html.includes('dailyShipmentAwaitWithTimeout(cloud.attachDailyShipmentPhoto(tracking,driveRef)'), 'Firebase record and Drive attachment calls must have visible wait limits');
const processStart = html.indexOf('async function dailyShipmentProcessCapture(payload)');
const committedAt = html.indexOf('dailyShipmentMarkRowRecorded(tracking,committedReport,false)', processStart);
const photoQueueAt = html.indexOf('dailyShipmentQueueDrivePhoto({payload,trackingNo:tracking,carrier,path,photoDataUrl:photo,date,employeeName:employeeSnap.name', processStart);
assert(processStart >= 0 && committedAt > processStart && photoQueueAt > committedAt, 'show Firebase-confirmed scan results before enqueueing photo work');
assert(html.includes('async function dailyShipmentProcessDrivePhoto(job)') && html.includes('dailyShipmentAwaitWithTimeout(window.DriveStorage.toCloudValue(photo,`daily_shipment_${tracking}_${date}`)') && html.includes('dailyShipmentAwaitWithTimeout(cloud.attachDailyShipmentPhoto(tracking,driveRef)'), 'slow Drive uploads and attachments must run in a separate bounded worker');
assert(html.includes('Firebase xác nhận ${p.recorded} đơn') && html.includes('mở bảng hàng đợi để xem và đồng bộ'), 'batch scan completion must provide final confirmed/error counts and a place to inspect pending photos');
assert(html.includes('if(!path){') && html.includes('Máy quét không trả về đường dẫn ảnh.'), 'camera callbacks without image paths must be surfaced, not silently discarded');

// Exercise the real timeout helper with a promise that never settles.
const helperStart = html.indexOf('function dailyShipmentAwaitWithTimeout(');
const helperEnd = html.indexOf('\nfunction save()', helperStart);
assert(helperStart >= 0 && helperEnd > helperStart, 'bounded-wait helper must be present');
const context = {Promise, setTimeout, clearTimeout, Math, Number, String, Error};
vm.createContext(context);
vm.runInContext(html.slice(helperStart, helperEnd), context, {filename:'daily-shipment-timeout-helper.js'});
(async () => {
  await assert.rejects(context.dailyShipmentAwaitWithTimeout(new Promise(() => {}), 12, 'bài kiểm tra'), /Quá 1 giây chờ bài kiểm tra/);
  console.log('V26.2.122 PDF ASSIGNMENT / BATCH SCAN PERFORMANCE REGRESSION TEST PASS');
})().catch(error => { console.error(error); process.exitCode = 1; });
