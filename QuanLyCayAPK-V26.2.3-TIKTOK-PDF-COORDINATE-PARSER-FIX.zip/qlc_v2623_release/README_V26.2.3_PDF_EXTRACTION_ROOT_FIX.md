# V26.2.3 — TikTok PDF coordinate-extraction root fix

## Root cause confirmed from supplied 12-page PDF
The previous fallback parser assumed that Product Name / SKU / Seller SKU / Qty labels were followed by their values in nearby contiguous text lines. This assumption fails for PDFBox output when the PDF content stream interleaves table columns with delivery information. The existing tests used hand-written text samples and did not test all 12 real visual table layouts, so they passed while the phone import could still show `Không tách được dòng sản phẩm/SKU/Qty`.

## Fix
- Added `VisualLayoutPdfTextStripper`, which collects PDF glyph coordinates per page, groups them by visual baseline, sorts each row by X coordinate, and reconstructs spacing so columns remain aligned.
- Android now returns this `visualText` representation alongside the previous two text representations; the original inputs are retained as fallbacks.
- JavaScript now scores the visual, layout-preserving, and standard PDFBox text candidates and uses the candidate containing the most complete product information.
- Added a sanitized regression fixture built from product-table fragments across all 12 pages of the supplied PDF. It includes real product-name wrapping / SKU column patterns but excludes recipient, address, phone, live tracking IDs, and live Order IDs.
- Version is V26.2.3 / versionCode 55 so Android can receive the build as a normal app update.

## Data/business safety
- No Firestore collection/schema, Firestore Rules, catalog, catalog prices, employee access, wage calculation, inventory logic, Drive image handling, or order-completion behavior is changed by this fix.
- PDF import remains a staging workflow. The Admin still explicitly maps SKU/product to catalog items and assigns the label.
- The fix does not create an order, alter inventory, or calculate wages simply by importing a PDF.

## Tests
- `node tools/tiktok_label_import_test.js`
- `node tools/tiktok_pdf_real_layout_regression_test.js` (all 12 sanitized table layouts)
- all existing `tools/*_test.js` checks
- `python3 tools/preflight.py`
- JavaScript syntax checks

## Build/device validation limitation
The Android PDFBox coordinate extractor must still be compiled in GitHub Actions and exercised on the phone with `TikTokSeller.pdf`. Source-level tests validate the JavaScript side and the known visual table layouts, not the Android runtime itself. If the native coordinate extractor fails to compile, do not install the APK; use the workflow diagnostics to correct it first.
