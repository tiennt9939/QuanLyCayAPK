/* Offline TikTok Shop label parser. Stores only order/product identifiers, never recipient address/phone. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.TikTokLabelImport=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';
  function compact(value){return String(value??'').replace(/\s+/g,' ').trim()}
  function normalize(value){return String(value??'').toUpperCase().replace(/[^A-Z0-9]/g,'')}
  function keyForProduct(p){
    const raw=[p?.productName,p?.sku,p?.sellerSku].map(v=>compact(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()).join('|');
    let h=2166136261;
    for(let i=0;i<raw.length;i++){h^=raw.charCodeAt(i);h=Math.imul(h,16777619)}
    return 'ttp_'+(h>>>0).toString(36);
  }
  function expectedPlantsPerSoldUnit(product){
    const text=compact([product?.productName,product?.sku,product?.sellerSku].join(' '));
    const combo=text.match(/\bcombo\s*(?:x\s*)?(\d{1,3})\b/i);
    if(combo)return Number(combo[1])||0;
    const count=text.match(/\b(\d{1,3})\s*(?:cây|chậu)\b/i);
    return count?(Number(count[1])||0):0;
  }
  function extractTracking(text){
    const raw=String(text||'').toUpperCase();
    // Accept occasional spaces/hyphens inserted by PDF text extraction, then normalize the result.
    const patterns=[/\b862(?:[ \t-]?\d){9}\b/g,/\b530(?:[ \t-]?\d){9}\b/g,/\bV[ \t-]*N[ \t-]*G[ \t-]*H(?:[ \t-]?[A-Z0-9]){8,26}\b/g,/\bG[ \t-]*H[ \t-]*V[ \t-]*N(?:[ \t-]?[A-Z0-9]){4,26}\b/g];
    const matches=patterns.flatMap(pattern=>raw.match(pattern)||[]);
    return [...new Set(matches.map(normalize).filter(Boolean))];
  }
  function carrierFor(tracking){
    const t=normalize(tracking);
    if(/^VNGH\d{8,12}$/.test(t)||/^GHVN[A-Z0-9]{4,26}$/.test(t))return 'GHN';
    if(/^862\d{9}$/.test(t))return 'J&T Express';
    if(/^530\d{9}$/.test(t))return 'J&T Cargo';
    return '';
  }
  function parseProductRows(lines, headerIndex, totalIndex){
    const header=String(lines[headerIndex]||'');
    const skuStart=header.indexOf('SKU');
    const sellerStart=header.indexOf('Seller SKU');
    const qtyStart=header.lastIndexOf('Qty');
    if(skuStart<0||sellerStart<=skuStart||qtyStart<=sellerStart)return [];
    const startCandidates=[];
    for(let i=headerIndex+1;i<totalIndex;i++){
      const line=String(lines[i]||'').replace(/\r/g,'');
      if(!line.trim()||/Qty\s*Total\s*:/i.test(line))continue;
      // Do not rely on the Qty header's character offset: PDF exporters sometimes
      // place the value a few columns earlier or omit trailing whitespace entirely.
      const qtyMatch=line.match(/(?:^|\s)(\d{1,3})\s*$/);
      if(qtyMatch){
        const qty=Number(qtyMatch[1]);
        const qtyIndex=qtyMatch.index+qtyMatch[0].lastIndexOf(qtyMatch[1]);
        if(Number.isInteger(qty)&&qty>0&&qty<=1000&&line.slice(0,qtyIndex).trim())
          startCandidates.push({index:i,qty,qtyIndex});
      }
    }
    const products=[];
    for(let n=0;n<startCandidates.length;n++){
      const start=startCandidates[n].index;
      const end=n+1<startCandidates.length?startCandidates[n+1].index:totalIndex;
      const col={name:[],sku:[],seller:[]};
      for(let i=start;i<end;i++){
        const line=String(lines[i]||'').replace(/\r/g,'');
        if(!line.trim()||/Qty\s*Total\s*:/i.test(line))continue;
        const rowStart=i===start?0:0;
        const rowEnd=i===start?startCandidates[n].qtyIndex:line.length;
        const bounded=line.slice(rowStart,rowEnd);
        const cells=[bounded.slice(0,Math.min(skuStart,bounded.length)),
          bounded.slice(Math.min(skuStart,bounded.length),Math.min(sellerStart,bounded.length)),
          bounded.slice(Math.min(sellerStart,bounded.length))];
        ['name','sku','seller'].forEach((field,j)=>{const cell=compact(cells[j]);if(cell)col[field].push(cell)});
      }
      const product={productName:compact(col.name.join(' ')),sku:compact(col.sku.join(' ')),sellerSku:compact(col.seller.join(' ')),qty:startCandidates[n].qty};
      if(!product.productName&&!product.sku&&!product.sellerSku)continue;
      product.mapKey=keyForProduct(product);
      products.push(product);
    }
    return products;
  }
  function parsePageText(text,pageNumber){
    text=String(text??'');
    const tracks=extractTracking(text);
    const orderIds=[...new Set([...text.matchAll(/\bOrder\s*ID\s*:[ \t]*((?:\d[ \t-]*){12,25})/gi)].map(m=>normalize(m[1])).filter(x=>/^\d{12,25}$/.test(x)))];
    const lines=text.split(/\r?\n/);
    let headerIndex=lines.findIndex(line=>/Product\s*Name/i.test(line)&&/Seller\s*SKU/i.test(line)&&/Qty/i.test(line));
    let totalIndex=lines.findIndex((line,i)=>i>(headerIndex<0?-1:headerIndex)&&/Qty\s*Total\s*:/i.test(line));
    if(totalIndex<0)totalIndex=lines.length;
    let products=headerIndex>=0?parseProductRows(lines,headerIndex,totalIndex):[];
    // Fallback for the standard PDFTextStripper mode, which may emit table
    // columns as separate blocks. Read only each label/value block until its blank separator.
    if(!products.length){
      const findLabel=(label,from=0)=>lines.findIndex((v,i)=>i>=from&&new RegExp('^\\s*'+label+'\\s*$','i').test(String(v||'')));
      const blockAfter=index=>{
        if(index<0)return [];
        const values=[];
        for(let i=index+1;i<lines.length;i++){
          const value=String(lines[i]||'').trim();
          if(!value) break
          values.push(value);
        }
        return values;
      };
      const productHeader=findLabel('Product Name');
      const skuHeader=findLabel('SKU',Math.max(0,productHeader+1));
      const sellerHeader=findLabel('Seller SKU',Math.max(0,skuHeader+1));
      const qtyHeader=findLabel('Qty',Math.max(0,sellerHeader+1));
      const totalLine=lines.findIndex((v,i)=>i>Math.max(qtyHeader,sellerHeader)&&/^\s*Qty\s*Total\s*:/i.test(String(v||'')));
      if(productHeader>=0&&skuHeader>productHeader&&sellerHeader>skuHeader&&qtyHeader>sellerHeader&&totalLine>qtyHeader){
        const name=compact(blockAfter(productHeader).join(' '));
        const sku=compact(blockAfter(skuHeader).join(' '));
        const sellerSku=compact(blockAfter(sellerHeader).join(' '));
        const qtyValues=blockAfter(qtyHeader).filter(v=>/^\d{1,3}$/.test(v)).map(Number).filter(v=>v>0&&v<=1000);
        if(name&&qtyValues.length){const product={productName:name,sku,sellerSku,qty:qtyValues[0]};product.mapKey=keyForProduct(product);products.push(product)}
      }
    }
    // Layout-independent fallback for a product row where the quantity column shifts left.
    if(!products.length&&headerIndex>=0){
      const header=String(lines[headerIndex]||'');
      const skuStart=header.indexOf('SKU'),sellerStart=header.indexOf('Seller SKU');
      const fallback=[];
      if(skuStart>=0&&sellerStart>skuStart){
        for(let i=headerIndex+1;i<totalIndex;i++){
          const line=String(lines[i]||'');const m=line.match(/(?:^|\s)(\d{1,3})\s*$/);if(!m)continue;
          const qty=Number(m[1]),end=m.index+m[0].lastIndexOf(m[1]);if(!Number.isInteger(qty)||qty<1||qty>1000)continue;
          const before=line.slice(0,end).trim();if(!before)continue;
          const product={productName:compact(before.slice(0,Math.min(skuStart,before.length))),sku:compact(before.slice(Math.min(skuStart,before.length),Math.min(sellerStart,before.length))),sellerSku:compact(before.slice(Math.min(sellerStart,before.length))),qty};
          if(product.productName||product.sku||product.sellerSku){product.mapKey=keyForProduct(product);fallback.push(product)}
        }
      }
      products=fallback;
    }
    const reasons=[];
    if(tracks.length!==1)reasons.push(tracks.length?'Có nhiều mã vận đơn khác nhau trên một trang':'Không đọc được mã vận đơn hợp lệ');
    if(orderIds.length!==1)reasons.push(orderIds.length?'Có nhiều Order ID khác nhau trên một trang':'Không đọc được Order ID');
    if(!products.length)reasons.push('Không tách được dòng sản phẩm/SKU/Qty');
    return {page:Number(pageNumber||0)||0,trackingNo:tracks.length===1?tracks[0]:'',carrier:tracks.length===1?carrierFor(tracks[0]):'',orderId:orderIds.length===1?orderIds[0]:'',products,status:reasons.length?'needs_review':'ready',reviewReason:reasons.join('; ')};
  }
  function parsePage(page){
    if(!page||typeof page!=='object')return parsePageText(page,page?.page||page?.pageNumber||0);
    const pageNo=page.page||page.pageNumber||0;
    // Android PDFBox can return: (1) a layout-preserving stream, (2) standard stream order,
    // and (3) a visual-coordinate reconstruction. Test all available representations and
    // choose the one with the strongest product evidence instead of trusting the first text.
    const candidates=[page.visualText,page.text,page.fallbackText]
      .filter((value,index,all)=>typeof value==='string'&&value.trim()&&all.indexOf(value)===index)
      .map(value=>parsePageText(value,pageNo));
    if(!candidates.length)return parsePageText('',pageNo);
    const score=row=>{
      const products=Array.isArray(row.products)?row.products:[];
      const evidence=products.reduce((sum,p)=>sum+10+(p.productName?6:0)+(p.sku?4:0)+(Number(p.qty)>0?5:0),0);
      return (row.status==='ready'?1000:0)+evidence+(row.trackingNo?3:0)+(row.orderId?2:0);
    };
    let best=candidates[0];
    for(let i=1;i<candidates.length;i++)if(score(candidates[i])>score(best))best=candidates[i];
    return best;
  }
  function parsePages(pages){
    const rows=(Array.isArray(pages)?pages:[]).map(parsePage);
    const seen=new Map();
    rows.forEach(row=>{if(!row.trackingNo)return;seen.set(row.trackingNo,(seen.get(row.trackingNo)||0)+1)});
    rows.forEach(row=>{if(row.trackingNo&&(seen.get(row.trackingNo)||0)>1){row.status='needs_review';row.reviewReason=[row.reviewReason,'Mã vận đơn trùng trong cùng PDF'].filter(Boolean).join('; ')}});
    return rows;
  }
  return {compact,normalize,keyForProduct,expectedPlantsPerSoldUnit,extractTracking,carrierFor,parseProductRows,parsePage,parsePages};
});
