# QuanLyCayAPK — V26.2.3 TikTok PDF parser root fix

This release is based on the V26.2.2 performance-optimized Android project and changes only the native PDF text extraction and its parser tests, plus the app version/build workflow.

## Build identity
- `versionName`: `26.2.3`
- `versionCode`: `55`
- Android package: `com.quanlycay.apk`
- Build: GitHub Actions manual workflow `.github/workflows/build-apk.yml`

## Root cause and fix
The supplied 12-page TikTok Shop PDF uses visually aligned product table columns. PDFBox's ordinary text stream can interleave table column labels/values with other content, while the previous JavaScript fallback assumed contiguous blocks. That is why the app found tracking numbers and Order IDs but dropped plant/SKU/Qty. This release adds a native coordinate-based text reconstruction and selects the best of three extraction variants before staging the order.

## Safety boundary
The change does not edit Firestore data, Firestore Rules behavior, database schema, catalog or catalog prices, user accounts/permissions, wage formula, inventory calculations, image/Drive storage, or order completion. PDF import still stages labels only; an Admin must explicitly map products to catalog entries and assign labels.

## Verification performed
- `python3 tools/preflight.py`
- Every `tools/*_test.js` test, including `tiktok_pdf_real_layout_regression_test.js`
- JavaScript syntax checks for all inline blocks and `tiktok-label-import.js`
- Sanitized product table fragments from all 12 supplied PDF pages: 12/12 parsed with a product and positive Qty.

## Device validation still required
The Java coordinate extractor has not been compiled in GitHub Actions or exercised on a physical Android device from this environment. Run the included manual build workflow and install/test the resulting APK with the original PDF before using it for live assignments. If Gradle compilation fails, do not install the APK; inspect the workflow diagnostics first.

## GitHub mobile workflow
1. Upload `QuanLyCayAPK-V26.2.3-TIKTOK-PDF-COORDINATE-PARSER-FIX.zip` to the repository root (the ZIP must be uploaded to GitHub; a file kept only on the phone is not visible to Actions).
2. Add the standalone workflow file at `.github/workflows/build-apk.yml` or replace the existing canonical workflow content with the supplied V26.2.3 workflow.
3. Open Actions, choose **Build ROLL CAY CANH V26.2.3 — TikTok PDF Coordinate Parser Fix**, tap **Run workflow**, and keep the source_zip input at the default file name.
4. Only install the APK when the workflow completes successfully and the artifact exists.
