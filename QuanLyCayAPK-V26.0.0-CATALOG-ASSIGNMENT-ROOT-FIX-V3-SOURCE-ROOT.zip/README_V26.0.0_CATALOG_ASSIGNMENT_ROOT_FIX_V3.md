# V26.0.0 — CATALOG ASSIGNMENT ROOT FIX V3

## Root cause addressed
The assignment flow previously allowed a newly-created catalog row to remain local-only while `/packingOrders` was written. That left a race between local catalog state, shared `/apps/roll-cay-canh`, and the assignment write. The UI could show the new plant while the canonical cloud catalog was stale.

## V3 behavior
1. `catalogId` remains the only business identity.
2. Before creating a packing order, every item is resolved strictly by `catalogId` from the canonical local catalog.
3. If catalog data is dirty or the cloud catalog is missing one of the required `catalogId`s, the app automatically publishes the canonical local catalog and verifies it again.
4. Only after catalog verification succeeds is `/packingOrders/{id}` created.
5. If Firebase denies the catalog sync/read, the user gets an explicit error naming `/apps/roll-cay-canh` instead of the generic `Missing or insufficient permissions` toast.
6. No name+size or array-index fallback is used for assignment identity.
7. Firestore `packingOrders` create rules require non-empty canonical `catalogId`, employee, assigned UID and valid pack size.

## Verification
- Catalog Canonical V1 audit: PASS
- Preflight: PASS
- JavaScript syntax: PASS
- Assignment payload: catalogId only
- No active plantIndex business path
