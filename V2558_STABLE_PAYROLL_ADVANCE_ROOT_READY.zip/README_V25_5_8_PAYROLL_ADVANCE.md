# V25.5.8 — Ứng lương

- Thêm `salaryAdvances` vào dữ liệu nghiệp vụ, đồng bộ cùng `/apps/roll-cay-canh`.
- Admin có thể ghi nhận ứng lương theo nhân viên, ngày, số tiền và ghi chú.
- Khoản ứng được trừ khỏi lũy kế thực nhận: `lương gộp - ứng lương`.
- Bảng lương tổng hợp hiển thị Lương gộp, Đã ứng và Thực nhận.
- Chi tiết từng nhân viên hiển thị ứng theo ngày và lũy kế thực nhận.
- Có danh sách khoản ứng trong kỳ và cho phép xóa khoản ứng sai.
- Xuất bảng lương CSV có cột ứng lương, thực nhận và chi tiết ứng.
- Giữ nguyên logic combo: 1 cây/đơn = 1 cây; 2 cây/đơn = 2 cây; ... 100 cây/đơn = 100 cây.
