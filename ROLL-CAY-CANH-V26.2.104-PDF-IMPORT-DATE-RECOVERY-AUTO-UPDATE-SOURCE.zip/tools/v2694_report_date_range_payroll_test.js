const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const preflight = fs.readFileSync(path.join(root, 'tools/preflight.py'), 'utf8');
function must(ok, msg) { if (!ok) throw new Error(msg); }
must(/id="legacyGeneralReportPanel"/.test(html), 'existing report controls must be retained');
must(!/#orderAssignCard[^}]*#legacyGeneralReportPanel[^}]*display:none\s*!important/.test(html), 'report date range panel must not be hidden');
must(/id="rFrom" type="date" onchange="onReportFromChange\(\)"/.test(html), 'from-date change must recalculate report');
must(/id="rTo" type="date" onchange="onReportToChange\(\)"/.test(html), 'to-date change must recalculate report');
must(html.includes('function onReportFromChange()') && html.includes('function onReportToChange()'), 'range change handlers missing');
must(html.includes('const completedRange=completedOrderRecords().filter(r=>r.date>=from&&r.date<=to)'), 'completed orders must be filtered by selected range');
must(html.includes('Tiền công theo nhân viên'), 'payroll totals per employee must remain visible');
must(gradle.includes('versionName = "26.2.104"') && gradle.includes('versionCode = 156'), 'version must be 26.2.104 / code 146');
must(preflight.includes('versionName = "26.2.104"') && preflight.includes('versionCode = 156'), 'preflight version must match');
console.log('V26.2.104 REPORT DATE RANGE PAYROLL TEST PASS');
