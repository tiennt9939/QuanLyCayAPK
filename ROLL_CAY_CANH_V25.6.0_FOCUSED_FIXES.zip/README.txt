# ROLL CAY CANH V25.6.0 — FOCUSED FIX PACKAGE

Base: current V25.5.6.

Scope ONLY:
1. New catalog items can be assigned reliably using stable catalogId.
2. Packing order print uses a dedicated WebView and exact 65x100 mm attributes.
3. Quote export creates a real A4 PDF file in Download/ROLL CAY CANH.

This package intentionally does NOT include the unrelated payroll/salary-advance changes from the uploaded
ROLL_CAY_CANH_V25_6_0_FIX.zip.

FILES
- roll-fixes-focused.js: load immediately before </body> in index.html.
- MainActivity_PRINT_PATCH_FOCUSED.txt: native Java replacement patch.
- apply_patch.py: optional helper for a full source tree; it copies the JS and updates version/workflow,
  but native Java changes should be applied exactly as documented.
- README.txt: this file.

IMPORTANT
Do not replace firestore.rules with the rules from the uploaded V25.6.0 patch package merely for these
three bugs. The requested fixes do not require a Firebase rules rewrite.

After applying:
- run Gradle assembleDebug
- install APK
- test: add a new plant -> assign it -> employee receives order
- test: print one order and batch print; Android print preview must show 65x100 mm
- test: quote -> XUẤT PDF BÁO GIÁ; verify PDF appears in Download/ROLL CAY CANH
