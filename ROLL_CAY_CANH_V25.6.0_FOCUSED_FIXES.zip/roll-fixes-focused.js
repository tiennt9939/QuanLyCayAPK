/* ROLL CAY CANH V25.6.0 — focused fixes
 * Scope: stable catalog identity for assignment, deterministic 65x100 print,
 * and real A4 PDF export. Load immediately before </body>.
 */
(function(){
  'use strict';

  function activeCatalogRows(){
    return (Array.isArray(window.D?.catalog)?window.D.catalog:[])
      .map((p,i)=>({p,i}))
      .filter(x=>x.p && !x.p.deleted);
  }

  function stableCatalogId(p,i){
    const raw=String(p?.catalogId||'').trim();
    if(raw)return raw;
    try { return String(catalogKey(p,i)); } catch(e) {}
    return 'legacy:'+String(i);
  }

  function findByStableId(id){
    const key=String(id||'').trim();
    if(!key)return null;
    return activeCatalogRows().find(x=>stableCatalogId(x.p,x.i)===key)||null;
  }

  function findByNameSizeLocal(name,size){
    const n=String(name||'').trim().toLowerCase();
    const s=String(size||'').trim().toLowerCase();
    return activeCatalogRows().find(x=>
      String(x.p.name||'').trim().toLowerCase()===n &&
      String(x.p.size||'').trim().toLowerCase()===s
    )||null;
  }

  // Stable catalog identity: never trust an old array index when building an order.
  window.addAssignmentItem=function(){
    const plantName=String($('assignPlant')?.value||'').trim();
    const rawIndex=String($('assignSize')?.value||'').trim();
    const idx=Number(rawIndex);
    const qty=Math.floor(Number($('assignItemQty')?.value)||0);
    const p=(Number.isInteger(idx)&&idx>=0)?D.catalog?.[idx]:null;
    if(!plantName||!rawIndex||!p||p.deleted||qty<1||
       String(p.name||'').trim().toLowerCase()!==plantName.toLowerCase()){
      toast('Cây/kích thước chưa hợp lệ. Vui lòng chọn lại cây và kích thước rồi bấm THÊM CÂY.');
      return;
    }
    const catalogId=stableCatalogId(p,idx);
    assignmentItems.push({
      catalogId,
      plantIndex:idx,
      plantKey:catalogId,
      plantName:String(p.name||plantName).trim(),
      size:String(p.size||'').trim(),
      qty
    });
    renderAssignmentItems();
    if($('assignItemQty'))$('assignItemQty').value=1;
    toast(`Đã thêm ${qty} cây · ${p.name||plantName}`);
  };

  window.renderAssignSizes=function(){
    const name=String($('assignPlant')?.value||'').trim();
    const size=$('assignSize');
    if(!size)return;
    const rows=activeCatalogRows().filter(x=>
      String(x.p.name||'').trim().toLowerCase()===name.toLowerCase()
    );
    size.innerHTML=rows.length
      ? '<option value="">-- Chọn kích thước --</option>'+
        rows.map(x=>`<option value="${x.i}" data-catalog-id="${esc(stableCatalogId(x.p,x.i))}">${esc(x.p.size||'Không ghi kích thước')}</option>`).join('')
      : '<option value="">-- Chọn loại cây trước --</option>';
    size.disabled=!rows.length;
  };

  window.fillAssignOptions=async function(){
    const s=CloudSync.state();
    if(!s.user||s.role!=='admin')return;
    try{await s.refreshCatalogForAssignment?.()}catch(e){console.warn('assignment catalog refresh',e)}
    // Always repair IDs before building assignment controls.
    try{
      if(typeof ensureCatalogIds==='function')ensureCatalogIds();
      if(typeof localSaveOnly==='function')localSaveOnly();
    }catch(e){console.warn('catalog identity repair',e)}

    const emp=$('assignEmployee'),plant=$('assignPlant'),ps=$('assignPackSize');
    if(!emp||!plant||!ps)return;
    const oldEmp=emp.value,oldPlant=plant.value,oldPack=ps.value;

    emp.innerHTML='<option value="">Đang tải nhân viên…</option>';
    try{
      const users=await s.listUsers();
      const packers=users.filter(u=>u.role==='packer'&&u.active!==false&&
        u.employeeId!=null&&String(u.employeeName||'').trim());
      emp.innerHTML=packers.length
        ? '<option value="">-- Chọn nhân viên đóng hàng --</option>'+
          packers.map(u=>`<option value="${esc(u.uid)}">${esc(u.employeeName)} · ${esc(u.email||'')}</option>`).join('')
        : '<option value="">Chưa có nhân viên đóng hàng đã liên kết tài khoản</option>';
      if(packers.some(u=>u.uid===oldEmp))emp.value=oldEmp;
    }catch(e){
      console.error('fillAssignOptions users',e);
      emp.innerHTML='<option value="">Không đọc được tài khoản nhân viên</option>';
    }

    const plants=[...new Set(activeCatalogRows().map(x=>String(x.p.name||'').trim()).filter(Boolean))]
      .sort((a,b)=>a.localeCompare(b,'vi'));
    plant.innerHTML=plants.length
      ? '<option value="">-- Chọn loại cây --</option>'+
        plants.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('')
      : '<option value="">Chưa có danh mục cây</option>';
    if(plants.includes(oldPlant))plant.value=oldPlant;

    ps.innerHTML='<option value="">-- Chọn quy cách --</option>'+
      Array.from({length:100},(_,i)=>i+1).map(n=>
        `<option value="${n}">${n===1?'1 cây · không combo':n+' cây / combo'}</option>`).join('');
    if(oldPack)ps.value=oldPack;
    renderAssignSizes();
  };

  window.adminCreateAssignments=async function(){
    if(!CloudSync.requirePerm('users'))return;
    const s=CloudSync.state();
    const assignedUid=$('assignEmployee')?.value||'';
    const fallbackName=String($('assignPlant')?.value||'').trim();
    const fallbackSizeIndex=Number($('assignSize')?.value);
    const packSize=Math.max(1,Math.floor(Number($('assignPackSize')?.value)||0));
    const count=Math.floor(Number($('assignOrderCount')?.value)||0);
    const note=String($('assignNote')?.value||'').trim();

    if(!assignedUid){toast('❌ Chưa chọn nhân viên đóng hàng.');return}
    if(packSize<1||packSize>100){toast('❌ Quy cách đơn phải từ 1 đến 100 cây/đơn.');return}
    if(count<1){toast('❌ Số đơn cần đóng phải ít nhất là 1.');return}

    const users=await s.listUsers();
    const target=users.find(u=>String(u.uid||'')===String(assignedUid)&&
      String(u.role||'').trim().toLowerCase()==='packer'&&u.active!==false&&
      u.employeeId!=null&&String(u.employeeId).trim()!==''&&String(u.employeeName||'').trim()!=='');
    if(!target){
      toast('❌ Tài khoản nhân viên chưa liên kết đúng với nhân viên.');
      return;
    }

    let rawItems=Array.isArray(assignmentItems)?assignmentItems.slice():[];
    if(!rawItems.length&&fallbackName&&Number.isInteger(fallbackSizeIndex)){
      const p=D.catalog?.[fallbackSizeIndex];
      if(p&&!p.deleted&&String(p.name||'').trim().toLowerCase()===fallbackName.toLowerCase()){
        rawItems=[{
          catalogId:stableCatalogId(p,fallbackSizeIndex),
          plantIndex:fallbackSizeIndex,
          plantKey:stableCatalogId(p,fallbackSizeIndex),
          plantName:String(p.name||''),
          size:String(p.size||''),
          qty:packSize
        }];
      }
    }

    const items=rawItems.map(x=>{
      let found=findByStableId(x.catalogId||x.plantKey);
      if(!found)found=findByNameSizeLocal(x.plantName,x.size);
      if(!found){
        const idx=Number(x.plantIndex);
        const p=(Number.isInteger(idx)&&idx>=0)?D.catalog?.[idx]:null;
        if(p&&!p.deleted)found={p,i:idx};
      }
      if(!found)return null;
      const id=stableCatalogId(found.p,found.i);
      return {
        catalogId:id,
        plantIndex:Number(found.i),
        plantKey:id,
        plantName:String(found.p.name||'').trim(),
        size:String(found.p.size||'').trim(),
        qty:Math.max(1,Math.floor(Number(x.qty)||0))
      };
    }).filter(Boolean);

    if(!items.length){
      toast('❌ Chưa có cây hợp lệ trong danh sách phân công.');
      return;
    }

    if(items.length===1)items[0].qty=packSize;
    const totalQty=items.reduce((sum,x)=>sum+x.qty,0);
    if(items.length>1&&totalQty!==packSize){
      toast(`❌ Tổng số cây phải đúng ${packSize} cây/đơn (hiện ${totalQty}).`);
      return;
    }
    if(totalQty<1||totalQty>100){
      toast('❌ Tổng số cây thực tế/đơn phải từ 1 đến 100.');
      return;
    }

    const employee=String(target.employeeName).trim();
    const employeeId=String(target.employeeId).trim();

    try{
      for(let i=0;i<count;i++){
        const now=Date.now();
        const orderPayload={
          assignedUid:String(target.uid),
          employee,
          employeeId,
          plantIndex:Number(items[0].plantIndex),
          plantName:String(items[0].plantName),
          size:String(items[0].size),
          packSize:Number(totalQty),
          items:items.map(x=>({
            catalogId:String(x.catalogId),
            plantIndex:Number(x.plantIndex),
            plantKey:String(x.plantKey),
            plantName:String(x.plantName),
            size:String(x.size),
            qty:Number(x.qty)
          })),
          orderNo:`${String(now).slice(-6)}-${String(i+1).padStart(2,'0')}`,
          status:'pending',
          date:String($('dDate')?.value||START),
          assignedAtMs:now,
          note
        };
        await s.createPackingOrder(orderPayload);
      }
      toast(`✅ Đã phân công ${count} đơn · ${items.length} loại cây · ${totalQty} cây/đơn cho ${employee}`);
      if($('assignNote'))$('assignNote').value='';
      if($('assignOrderCount'))$('assignOrderCount').value=1;
      clearAssignmentItems();
      await renderAssignmentControls();
    }catch(e){
      console.error('adminCreateAssignments V25.6.0',e);
      toast(e?.message||'Không thể phân công đơn');
    }
  };

  function printHtmlSnapshot(){
    const box=$('orderPrintArea')||$('quotePdfPrint');
    if(!box)return '';
    return '<!doctype html><html class="'+document.documentElement.className+'"><head>'+
      document.head.innerHTML+
      '</head><body class="'+document.body.className+'">'+box.outerHTML+
      '</body></html>';
  }

  function cleanupPrint(box){
    if(!box)return;
    box.innerHTML='';
    box.setAttribute('aria-hidden','true');
    document.documentElement.classList.remove('print-order','print-quote');
    document.body.classList.remove('print-order','print-quote');
  }

  window.printPackingOrder=async function(id){
    if(!(await ensureAdminPrintAccess()))return;
    const r=(D.packingOrders||[]).find(x=>String(x.id)===String(id));
    if(!r){toast('Không tìm thấy đơn hàng');return}
    const box=$('orderPrintArea');
    if(!box)return;
    box.innerHTML=buildPackingPrintPage(r);
    box.setAttribute('aria-hidden','false');
    document.documentElement.classList.add('print-order');
    document.body.classList.add('print-order');
    if(window.AndroidBridge?.printA4Page){
      try{
        AndroidBridge.printA4Page(
          'ROLL-CAY-CANH-'+String(r.orderNo||r.id).replace(/[^a-zA-Z0-9_-]/g,'_')
        );
        setTimeout(()=>cleanupPrint(box),12000);
        return;
      }catch(e){console.error('print order',e)}
    }
    try{
      window.print();
      setTimeout(()=>cleanupPrint(box),1800);
    }catch(e){cleanupPrint(box);toast('Thiết bị chưa hỗ trợ in trực tiếp')}
  };

  window.printSelectedPackingOrders=async function(){
    if(!(await ensureAdminPrintAccess()))return;
    const ids=[...document.querySelectorAll('.batch-print-check:checked')].map(x=>x.value);
    const rows=ids.map(id=>batchPrintRows.find(r=>String(r.id)===String(id))).filter(Boolean);
    if(!rows.length){toast('Hãy chọn ít nhất 1 đơn để in');return}
    const box=$('orderPrintArea');
    if(!box)return;
    document.documentElement.classList.add('print-order');
    document.body.classList.add('print-order');
    box.innerHTML=rows.map(buildPackingPrintPage).join('');
    box.setAttribute('aria-hidden','false');
    closeEdit();
    if(window.AndroidBridge?.printA4Page){
      try{
        AndroidBridge.printA4Page(
          'ROLL-CAY-CANH-'+String(rows[0].employee||'NHAN-VIEN').replace(/[^a-zA-Z0-9_-]/g,'_')+'-'+rows.length+'DON'
        );
        setTimeout(()=>cleanupPrint(box),14000);
        return;
      }catch(e){console.error('batch print',e)}
    }
    try{window.print();setTimeout(()=>cleanupPrint(box),1800)}
    catch(e){cleanupPrint(box);toast('Thiết bị chưa hỗ trợ in trực tiếp')}
  };

  window.exportQuotePdf=function(){
    if(!quoteItems.length){toast('Chưa có cây trong báo giá');return}
    const items=quoteItems.map((x,i)=>{
      const p=D.catalog[Number(x.plantIndex)]||{},q=Number(x.qty)||0,t=q*(Number(p.price)||0);
      return {i:i+1,p,q,t};
    });
    const pages=[],PAGE_ROWS=8;
    for(let start=0;start<items.length;start+=PAGE_ROWS){
      const chunk=items.slice(start,start+PAGE_ROWS);
      const rows=chunk.map(r=>`<tr><td style="text-align:center">${r.i}</td><td><img src="${imageSrc(r.p)}" alt=""></td><td><b>${esc(r.p.name||'')}</b></td><td>${esc(r.p.size||'')}</td><td style="text-align:center">${r.q}</td><td style="text-align:right">${money(r.p.price||0)}</td><td style="text-align:right">${money(r.t)}</td></tr>`).join('');
      const meta=start===0?`<div class="quote-pdf-meta"><div><b>Khách hàng:</b> ${esc($('quoteCustomer')?.value||'')}</div><div><b>Ngày:</b> ${quoteDate()}</div><div><b>Số điện thoại:</b> ${esc($('quotePhone')?.value||'')}</div><div><b>Đơn vị:</b> ROLL GARDEN</div></div>`:'';
      const isLast=start+PAGE_ROWS>=items.length;
      const total=isLast?`<div class="quote-pdf-total">TỔNG GIÁ: ${money(quoteTotal())}</div>${$('quoteNote')?.value?`<div class="quote-pdf-note"><b>Ghi chú:</b> ${esc($('quoteNote').value)}</div>`:''}`:'';
      pages.push(`<div class="quote-pdf-page"><img class="quote-pdf-bg" src="quote-background.jpg" alt=""><div class="quote-pdf-content"><h1>BÁO GIÁ CÂY CẢNH</h1>${meta}<table class="quote-pdf-table"><thead><tr><th>STT</th><th>Hình ảnh</th><th>Tên sản phẩm</th><th>Kích thước</th><th>SL</th><th>Đơn giá</th><th>Thành tiền</th></tr></thead><tbody>${rows}</tbody></table>${total}<div class="quote-pdf-footer">ROLL GARDEN · Cây đẹp - Không gian xanh - Cuộc sống an lành</div></div></div>`);
    }
    const box=$('quotePdfPrint');
    if(!box)return;
    box.innerHTML=pages.join('');
    box.classList.add('show');
    document.documentElement.classList.add('print-quote');
    document.body.classList.add('print-quote');

    if(window.AndroidBridge?.exportPdf){
      try{
        AndroidBridge.exportPdf('Bao-gia-ROLL-GARDEN-'+fmt(new Date())+'.pdf');
        setTimeout(()=>cleanupPrint(box),20000);
        return;
      }catch(e){console.error('export pdf',e)}
    }

    try{
      window.print();
      setTimeout(()=>cleanupPrint(box),1800);
    }catch(e){
      cleanupPrint(box);
      toast('Thiết bị chưa hỗ trợ xuất PDF');
    }
  };

  console.log('V25.6.0 focused fixes loaded');
})();
