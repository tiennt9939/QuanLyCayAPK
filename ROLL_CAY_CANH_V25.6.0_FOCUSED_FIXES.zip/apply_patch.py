from pathlib import Path
import shutil, re

ROOT=Path(__file__).resolve().parents[1]
src=Path(__file__).resolve().parent

dst=ROOT/'app/src/main/assets/roll-fixes-focused.js'
shutil.copy2(src/'roll-fixes-focused.js', dst)

gradle=ROOT/'app/build.gradle.kts'
s=gradle.read_text(encoding='utf-8')
s=re.sub(r'versionCode\s*=\s*\d+', 'versionCode = 32', s)
s=re.sub(r'versionName\s*=\s*"[^"]+"', 'versionName = "25.6.0"', s)
gradle.write_text(s,encoding='utf-8')

index=ROOT/'app/src/main/assets/index.html'
h=index.read_text(encoding='utf-8')
if 'roll-fixes-focused.js' not in h:
    marker='</body>'
    if marker not in h: raise SystemExit('Không tìm thấy </body> trong index.html')
    h=h.replace(marker,'<script src="roll-fixes-focused.js"></script>\n</body>',1)
    index.write_text(h,encoding='utf-8')

print('Copied focused JS and updated version. Apply MainActivity_PRINT_PATCH_FOCUSED.txt manually.')
