const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(__dirname, '../app/build.gradle.kts'), 'utf8');
function assert(ok, message) { if (!ok) throw new Error(message); }
assert(gradle.includes('versionCode = 197') && gradle.includes('versionName = "26.2.145"'), 'version must be 26.2.145 / 197');
assert(html.includes('legacyPdfBatchCloseCard'), 'Admin safe PDF close card missing');
assert(html.includes('previewLegacyPdfBatchClose') && html.includes('executeLegacyPdfBatchClose'), 'preview/execute handlers missing');
const start = html.indexOf('async function executeLegacyPdfBatchClose()');
const end = html.indexOf('async function previewLegacyIncompleteOrdersCleanup()', start);
const fn = html.slice(start, end);
assert(fn.includes('syncDailyShipmentQueueForAssignment'), 'must confirm server queue sync before clearing flags');
assert(fn.indexOf('syncDailyShipmentQueueForAssignment') < fn.indexOf("removeItem('roll_pdf_queue_local_pending')"), 'must sync before clearing pending marker');
assert(fn.includes("removeItem('roll_pdf_queue_current_batch_v1')"), 'must clear only local batch index');
assert(!/dailyShipmentOrdersRef\\(\\)\\.doc\\([^)]*\\)\\.delete|dailyShipmentReportsRef\\(\\)\\.doc\\([^)]*\\)\\.delete|dailyShipmentScansRef\\(\\)\\.doc\\([^)]*\\)\\.delete/.test(fn), 'must not delete server labels/reports/scans');
assert(!/D\\.dailyShipmentOrders\\s*=|D\\.dailyShipmentReports\\s*=|D\\.dailyShipmentScans\\s*=/.test(fn), 'must not mutate business data arrays');
assert(fn.includes("if(now.dirtyBefore==='0')localStorage.removeItem('quanlycay_dirty')"), 'must preserve unrelated dirty marker');
console.log('V26.2.145 SAFE PDF BATCH CLOSE: PASS');
