# ROLL CÂY CẢNH V26.2.145 — Safe PDF batch close + CI version-pin repair

## Baseline and release metadata
- Baseline: V26.2.144 source; Android project and business logic retained.
- Android `versionName`: `26.2.145`
- Android `versionCode`: `197`
- Feature: Admin-only "Kết thúc lô PDF cũ – giữ nguyên dữ liệu".

## Safety behavior
1. Preview reads the local batch index and fetches every exact tracking document from the canonical `dailyShipmentOrders` collection through the configured backend.
2. A label is considered verified only if its backend document exists and its date matches the batch date. Missing/mismatched labels block cleanup.
3. Execute repeats the backend read immediately before cleanup and compares the exact preview fingerprint. A changed marker, queue state, or backend record blocks cleanup.
4. Requires Admin, idle scan/photo workers, and exact confirmation text `KET THUC LO PDF CU`.
5. Successful execution removes only these device-local PDF batch markers:
   - `roll_pdf_queue_local_pending`
   - `roll_pdf_queue_current_batch_v1`
   - `roll_pdf_queue_only_import_dirty_before`
6. It marks the queue gate released and records a local completion summary. It preserves `quanlycay_dirty` and schedules the normal sync if unrelated dirty data remains.
7. It does not delete or update any GAS/Firestore orders, reports, scan records, claims, Drive photos, packing orders, payroll, inventory, catalog, prices, or staff profiles.
8. It leaves local photo/outbox data intact. An active scan, worker, or photo queue blocks the operation.

## GAS phase3.2 read-lock preservation
- Integrated the previously verified `Code.gs` read-lock fix (SHA-256 `bcbe80b56996d63e26245e0f0292d20c28c87bd79afcd476799984630efe8d7e`).
- `listUsers`, `get`, `query`, `multiQuery`, and `getMany` remain read-only and no longer wait for the global ScriptLock.
- Mutation/commit paths retain their existing ScriptLock serialization. No storage schema, migration state, token, or Script Properties were changed.

## CI failure shown by the user
The Actions job failed at `daily_shipment_assignment_missing_cloud_label_recovery_test.js` because multiple regression tests were hard-coded to expect V26.2.144 / versionCode 196. The Gradle metadata in the new source correctly declares V26.2.145 / 197. Updated the stale release assertions to V26.2.145 / 197, and aligned the existing safe-close tests with the stronger backend re-verification design.

## Validation performed on the extracted source
- `tools/preflight.py`: PASS.
- Node regression tests: **130/130 PASS**.
- Inline JavaScript: 9/9 script blocks syntax PASS.
- External JavaScript assets: 4/4 syntax PASS.
- ZIP integrity: PASS.
- Tests include the safe-PDF-batch-close safety contract, stale recorded label cleanup, PDF assignment recovery, offline-first outbox, Drive image persistence, GAS compatibility and all existing business regression checks.

## Not yet verified
- No real Android Gradle/APK build was executed in this local environment. GitHub Actions must build the archive.
- No live user GAS/Sheets/Drive data was mutated or cleaned. The new operation only becomes available after installing the built APK; actual device/backend verification remains required.
- Do not use the separate "Dọn đơn cũ chưa hoàn tất" operation for this A-only batch marker cleanup.
