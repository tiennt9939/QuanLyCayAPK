# ROLL CÂY CẢNH V26.2.145 — Safe PDF batch close

## Version
- Android versionName: 26.2.145
- versionCode: 197
- Baseline: V26.2.144 source; no rebuild from scratch.

## Added Admin tool
Location: Theo ngày → Vận chuyển → Công cụ dữ liệu nâng cao.

Tool: “Kết thúc lô PDF cũ – giữ nguyên dữ liệu”.

Workflow:
1. Admin previews the current local PDF batch marker.
2. Execute calls the existing `syncDailyShipmentQueueForAssignment()` path first.
3. It verifies the backend response includes every normalized tracking number from the previewed batch.
4. It re-reads the local batch marker and confirms the date/tracking list did not change during sync.
5. Only then it clears local PDF queue gate/index keys:
   - `roll_pdf_queue_local_pending`
   - `roll_pdf_queue_current_batch_v1`
   - `roll_pdf_queue_only_import_dirty_before`
6. It sets `roll_pdf_queue_synced=1` and records a local close marker.
7. The generic `quanlycay_dirty` marker is cleared only when `roll_pdf_queue_only_import_dirty_before` was `0`, meaning the import was the only dirty change before this batch. If it was `1`, unrelated dirty state is preserved.

## Data protection
- No deletion or mutation of `dailyShipmentOrders`.
- No deletion or mutation of `dailyShipmentReports`.
- No deletion or mutation of `dailyShipmentScans`.
- No deletion or mutation of tracking claims, packing orders, employee profiles, payroll, inventory, catalog, prices, or Drive image files.
- No changes to Firestore schema, GAS schema, payroll formulas, inventory logic, PDF recognition, or employee-folder Drive polling.
- If backend sync fails, returns an incomplete tracking list, or the local batch marker changes during sync, the operation aborts and keeps the pending markers.

## Validation
- `tools/v26145_safe_pdf_batch_close_test.js`: PASS
- `tools/v26145_safe_pdf_batch_close_regression_test.js`: PASS
- `tools/drive_pdf_employee_auto_sync_test.js`: PASS
- `tools/tiktok_pdf_queue_reparse_upgrade_test.js`: PASS
- `tools/v2667_safe_legacy_order_retirement_test.js`: PASS
- `tools/preflight.py`: PASS

The archive contains source only. It has not been deployed to the live GitHub repository or Apps Script, and no APK was built in this environment.
