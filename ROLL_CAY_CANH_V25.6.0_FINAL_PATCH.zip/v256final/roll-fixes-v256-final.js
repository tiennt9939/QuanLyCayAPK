/* ROLL CAY CANH V25.6.0 — ACTIVE INTEGRATION FIX
   Load this file at the very end of index.html, immediately before </body>.
   It intentionally overrides only payroll/report functions and adds salary advances.
*/
(function(){
  'use strict';

  const ADV_COLL = 'salaryAdvances';
  let salaryAdvanceRows = [];

  function st(){ return window.CloudSync?.state?.() || {}; }
  function isAdmin(){ return st().role === 'admin'; }
  function isPacker(){ return st().role === 'packer'; }

  function myEmployeeName(){
    const p = st().profile || {};
    const name = String(p.employeeName || '').trim();
    if(name) return name;
    try { return canonicalEmployeeName(currentPackerName?.() || ''); } catch(e) { return ''; }
  }

  function myEmployeeId(){
    return String(st().profile?.employeeId || '').trim();
  }

  async function loadSalaryAdvances(from,to){
    if(!db || !st().user) return [];
    try{
      let q = db.collection(ADV_COLL).where('date','>=',from).where('date','<=',to);
      if(isPacker()){
        const eid = myEmployeeId();
        if(!eid) return [];
        q = q.where('employeeId','==',eid);
      }else if(!isAdmin()){
        return [];
      }
      const snap = await q.get();
      salaryAdvanceRows = snap.docs.map(d=>({id:d.id,...d.data()}));
      return salaryAdvanceRows.slice();
    }catch(e){
      console.error('loadSalaryAdvances',e);
      toast('Không tải được tạm ứng: '+(e?.message||e?.code||'Lỗi Cloud'));
      return [];
    }
  }

  function advTotal(rows,employee,date){
    const key = canonicalEmployeeName(employee).toLowerCase();
    return (rows||[]).filter(x =>
      canonicalEmployeeName(x.employee||'').toLowerCase() === key &&
      (!date || String(x.date||'') === String(date))
    ).reduce((s,x)=>s+Math.max(0,Number(x.amount)||0),0);
  }

  function advancePanel(){
    if(!isAdmin()) return '';
    const opts = employees().map((e,i)=>'<option value="'+i+'">'+esc(e)+'</option>').join('');
    const today = fmt(new Date());
    return `
      <div class="card salary-advance-card" id="salaryAdvanceCard">
        <div class="section-title">
          <h3>💵 Tạm ứng lương</h3><span class="badge">Admin</span>
        </div>
        <div class="grid2">
          <div class="field"><label>Nhân viên</label><select id="advanceEmployee">${opts}</select></div>
          <div class="field"><label>Ngày tạm ứng</label><input id="advanceDate" type="date" value="${today}"></div>
        </div>
        <div class="grid2">
          <div class="field"><label>Số tiền</label><input id="advanceAmount" type="number" min="1" step="1000" inputmode="numeric" placeholder="500000"></div>
          <div class="field"><label>Ghi chú</label><input id="advanceNote" placeholder="Ví dụ: Tạm ứng tuần này"></div>
        </div>
        <button class="primary" type="button" onclick="addSalaryAdvance()">＋ GHI NHẬN TẠM ỨNG</button>
        <div id="salaryAdvanceList" class="salary-advance-list">
          <div class="tiny muted">Đang tải…</div>
        </div>
      </div>`;
  }

  async function renderSalaryAdvancePanel(){
    if(!isAdmin()) return;
    const control = document.getElementById('control');
    if(!control) return;

    let card = document.getElementById('salaryAdvanceCard');
    if(!card){
      const wrap = document.createElement('div');
      wrap.innerHTML = advancePanel();
      card = wrap.firstElementChild;
      const anchor = document.getElementById('userAdminCard');
      if(anchor && card) anchor.parentNode.insertBefore(card,anchor);
      else if(card) control.prepend(card);
    }

    const from = fmt(new Date(Date.now()-30*86400000));
    const to = fmt(new Date());
    const rows = await loadSalaryAdvances(from,to);
    const list = document.getElementById('salaryAdvanceList');
    if(!list) return;

    const sorted = rows.slice().sort((a,b)=>
      String(b.date||'').localeCompare(String(a.date||'')) ||
      Number(b.createdAtMs||0)-Number(a.createdAtMs||0)
    );

    list.innerHTML = sorted.length ? sorted.slice(0,100).map(x=>`
      <div class="salary-advance-row">
        <div class="meta">
          <b>${esc(x.employee||'Nhân viên')}</b>
          <div class="tiny muted">${esc(x.date||'')}${x.note?' · '+esc(x.note):''}</div>
        </div>
        <div class="amount">${money(x.amount)}</div>
        <button class="danger" type="button" onclick="deleteSalaryAdvance('${String(x.id).replace(/'/g,"\\'")}')">−</button>
      </div>`).join('')
      : '<div class="tiny muted">Chưa có khoản tạm ứng trong 30 ngày gần nhất.</div>';
  }

  async function addSalaryAdvance(){
    if(!isAdmin() || !db){
      toast('Chỉ Admin mới được ghi nhận tạm ứng');
      return;
    }

    const idx = Number(document.getElementById('advanceEmployee')?.value);
    const employee = employees()[idx];
    const date = String(document.getElementById('advanceDate')?.value||'').trim();
    const amount = Math.floor(Number(document.getElementById('advanceAmount')?.value)||0);
    const note = String(document.getElementById('advanceNote')?.value||'').trim();

    if(!employee || !/^\d{4}-\d{2}-\d{2}$/.test(date) || amount<=0){
      toast('Vui lòng nhập đủ nhân viên, ngày và số tiền');
      return;
    }

    try{
      const ref = db.collection(ADV_COLL).doc();
      await ref.set({
        employeeId:String(idx),
        employee:String(employee),
        date,
        amount,
        note,
        createdAt:firebase.firestore.FieldValue.serverTimestamp(),
        createdAtMs:Date.now(),
        createdBy:st().user.uid
      });
      document.getElementById('advanceAmount').value='';
      document.getElementById('advanceNote').value='';
      toast('✅ Đã ghi nhận tạm ứng');
      await renderSalaryAdvancePanel();
      if(document.getElementById('pFrom')?.value) await renderPayroll();
    }catch(e){
      console.error(e);
      toast('Không lưu được tạm ứng: '+(e?.message||e?.code||'Lỗi Cloud'));
    }
  }

  async function deleteSalaryAdvance(id){
    if(!isAdmin() || !db || !id) return;
    if(!confirm('Xóa khoản tạm ứng này?')) return;
    try{
      await db.collection(ADV_COLL).doc(id).delete();
      toast('Đã xóa tạm ứng');
      await renderSalaryAdvancePanel();
      if(document.getElementById('pFrom')?.value) await renderPayroll();
    }catch(e){
      toast('Không xóa được: '+(e?.message||e?.code||'Lỗi Cloud'));
    }
  }

  function payrollEmployeesV256(){
    return isPacker() ? [myEmployeeName()].filter(Boolean) : employees();
  }

  async function renderPayrollV256(){
    if(!window.CloudSync?.can?.('payroll')){
      toast('Tài khoản này không có quyền xem bảng lương');
      return;
    }

    const {from,to}=payrollDateRange();
    if($('pFrom')) $('pFrom').value=from;
    if($('pTo')) $('pTo').value=to;

    const rows=await loadSalaryAdvances(from,to);
    const by=payrollEntries(from,to);
    const days=payrollDays(from,to);
    const emps=payrollEmployeesV256();

    let totalQty=0,totalGross=0,totalAdvance=0,totalNet=0;
    const blocks=[];

    emps.forEach(e=>{
      const v=by[e]||{qty:0,basePay:0,adjustment:0,pay:0,days:{}};
      const adv=advTotal(rows,e);
      const gross=Number(v.pay)||0;
      const net=gross-adv;
      totalQty+=Number(v.qty)||0;
      totalGross+=gross;
      totalAdvance+=adv;
      totalNet+=net;
      blocks.push({e,v,adv,gross,net});
    });

    let html=`
      <div class="card">
        <div class="section-title">
          <h3>📋 Bảng lương tổng hợp</h3>
          <span class="badge">${fmtDMY(from)} – ${fmtDMY(to)}</span>
        </div>
        <div class="grid2">
          <div class="stat"><span>Tổng số cây</span><b>${Math.round(totalQty)}</b></div>
          <div class="stat"><span>Tổng tiền công</span><b>${money(totalGross)}</b></div>
          <div class="stat"><span>Tổng tạm ứng</span><b>${money(totalAdvance)}</b></div>
          <div class="stat"><span>Thực nhận</span><b>${money(totalNet)}</b></div>
        </div>
        <div class="payroll-table-wrap">
          <table class="payroll-table">
            <thead><tr><th>Nhân viên</th><th>Cây</th><th>Tiền công</th><th>Tạm ứng</th><th>Thực nhận</th></tr></thead>
            <tbody>
              ${blocks.map(x=>`
                <tr>
                  <td><b>${esc(x.e)}</b></td>
                  <td>${Math.round(x.v.qty||0)}</td>
                  <td><b>${money(x.gross)}</b></td>
                  <td>${money(x.adv)}</td>
                  <td class="payroll-net"><b>${money(x.net)}</b></td>
                </tr>`).join('')}
            </tbody>
            <tfoot><tr>
              <th>TỔNG</th><th>${Math.round(totalQty)}</th><th>${money(totalGross)}</th>
              <th>${money(totalAdvance)}</th><th>${money(totalNet)}</th>
            </tr></tfoot>
          </table>
        </div>
      </div>`;

    html+=`
      <div class="card">
        <div class="section-title">
          <h3>📅 Cộng dồn theo ngày</h3>
          <span class="badge">${days.length} ngày</span>
        </div>
        <div class="payroll-table-wrap">
          <table class="payroll-table compact">
            <thead><tr>
              <th>Ngày</th><th>Nhân viên</th><th>Cây</th><th>Tiền công</th>
              <th>Tạm ứng</th><th>Thực nhận ngày</th><th>Lũy kế thực nhận</th>
            </tr></thead><tbody>`;

    blocks.forEach(x=>{
      let cumulative=0;
      days.forEach(date=>{
        const d=x.v.days?.[date]||{qty:0,pay:0};
        const advDay=advTotal(rows,x.e,date);
        const netDay=(Number(d.pay)||0)-advDay;
        cumulative+=netDay;
        html+=`<tr>
          <td>${fmtDMY(date)}</td><td>${esc(x.e)}</td><td>${Math.round(d.qty||0)}</td>
          <td>${money(d.pay||0)}</td><td>${money(advDay)}</td>
          <td class="payroll-net">${money(netDay)}</td><td><b>${money(cumulative)}</b></td>
        </tr>`;
      });
    });

    html+=`</tbody></table></div></div>`;
    $('payrollBody').innerHTML=html;
  }

  async function exportPayrollCsvV256(){
    if(!window.CloudSync?.can?.('payroll')) return;

    const {from,to}=payrollDateRange();
    const rows=await loadSalaryAdvances(from,to);
    const by=payrollEntries(from,to);
    const days=payrollDays(from,to);
    const emps=payrollEmployeesV256();
    const lines=[];

    lines.push([csvCell('BẢNG LƯƠNG ROLL CÂY CẢNH')].join(','));
    lines.push([csvCell('Từ ngày'),csvCell(fmtDMY(from)),csvCell('Đến ngày'),csvCell(fmtDMY(to))].join(','));
    lines.push('');
    lines.push(['Ngày','Nhân viên','Số cây','Tiền công theo cây','Điều chỉnh','Tổng tiền công','Tạm ứng','Thực nhận','Lũy kế thực nhận'].map(csvCell).join(','));

    emps.forEach(e=>{
      let cumulative=0;
      days.forEach(date=>{
        const d=by[e]?.days?.[date]||{qty:0,basePay:0,adjustment:0,pay:0};
        const adv=advTotal(rows,e,date);
        const net=(Number(d.pay)||0)-adv;
        cumulative+=net;
        lines.push([
          date,e,Math.round(d.qty||0),Math.round(d.basePay||0),Math.round(d.adjustment||0),
          Math.round(d.pay||0),Math.round(adv),Math.round(net),Math.round(cumulative)
        ].map(csvCell).join(','));
      });
    });

    lines.push('');
    lines.push(['NHÂN VIÊN','TỔNG CÂY','TỔNG TIỀN CÔNG','TẠM ỨNG','THỰC NHẬN'].map(csvCell).join(','));
    emps.forEach(e=>{
      const v=by[e]||{qty:0,pay:0};
      const adv=advTotal(rows,e);
      lines.push([e,Math.round(v.qty||0),Math.round(v.pay||0),Math.round(adv),Math.round((Number(v.pay)||0)-adv)].map(csvCell).join(','));
    });

    downloadText(
      `Bang-luong-ROLL-CAY-CANH-${from}-${to}.csv`,
      '\ufeff'+lines.join('\r\n')
    );
  }

  function exportReportCsvV256(){
    syncReportDateLimits();
    const from=$('rFrom').value||START;
    const to=$('rTo').value||from;
    const lines=[];

    lines.push([csvCell('BÁO CÁO ROLL CÂY CẢNH')].join(','));
    lines.push([csvCell('Từ ngày'),csvCell(fmtDMY(from)),csvCell('Đến ngày'),csvCell(fmtDMY(to))].join(','));

    const daily=D.daily.filter(x=>x.date>=from&&x.date<=to);
    const orders=completedOrderRecords().filter(r=>r.date>=from&&r.date<=to);

    let totalIn=0,totalOut=0,totalPayValue=0;
    daily.forEach(x=>{
      totalIn+=Number(x.in)||0;
      totalOut+=outOf(x);
      totalPayValue+=payOf(x);
    });
    orders.forEach(r=>{
      totalOut+=orderTotalQty(r);
      totalPayValue+=orderTotalPay(r);
    });

    lines.push([
      csvCell('Tổng nhập kho'),Math.round(totalIn),
      csvCell('Tổng đóng hàng'),Math.round(totalOut),
      csvCell('Tổng tiền công'),Math.round(totalPayValue),
      csvCell('Tồn cuối'),Math.round(totalStock(to))
    ].join(','));

    lines.push('');
    lines.push([
      'Ngày','Đơn ID','Cây','Kích thước','Nhân viên','Số cây',
      'Đơn giá/cây','Tiền theo cây','Điều chỉnh','Tổng tiền công','Ghi chú'
    ].map(csvCell).join(','));

    // Packing orders: ALWAYS expand items[]. This fixes multi-item exports.
    orders.forEach(r=>{
      orderItems(r).forEach(it=>{
        const base=Number(it.qty||0)*rate(it.size);
        const adj=Number(r.payAdjustment||0);
        const total=orderTotalPay(r);
        lines.push([
          r.date||'',r.id||'',it.plantName||'',it.size||'',r.employee||'Nhân viên',
          Number(it.qty||0),rate(it.size),base,adj,total,r.payAdjustmentNote||''
        ].map(csvCell).join(','));
      });
    });

    // Legacy/manual daily records.
    daily.forEach(x=>{
      const p=D.catalog[Number(x.plantIndex)];
      if(!p) return;
      const names=new Set([
        ...Object.keys(x.counts||{}),
        ...(x.adjustments||[]).map(a=>a.employee)
      ]);
      if(!names.size) names.add('');

      names.forEach(emp=>{
        const q=Number(x.counts?.[emp])||0;
        const w=rate(p.size);
        const adj=adjustmentsOf(x,emp);
        lines.push([
          x.date,'',p.name,p.size||'',emp,q,w,q*w,adj,q*w+adj,''
        ].map(csvCell).join(','));
      });
    });

    lines.push('');
    lines.push(['Nhân viên','Số cây','Tiền công + điều chỉnh'].map(csvCell).join(','));

    employees().forEach(emp=>{
      let qty=0,pay=0;
      daily.forEach(x=>{
        qty+=Number(x.counts?.[emp])||0;
        pay+=employeePay(x,emp);
      });
      orders.filter(r=>canonicalEmployeeName(r.employee)===canonicalEmployeeName(emp)).forEach(r=>{
        qty+=orderTotalQty(r);
        pay+=orderTotalPay(r);
      });
      lines.push([emp,Math.round(qty),Math.round(pay)].map(csvCell).join(','));
    });

    downloadText(
      `Bao-cao-ROLL-CAY-CANH-${from}-${to}.csv`,
      '\ufeff'+lines.join('\r\n')
    );
  }

  // Permission: employee may view only their own payroll.
  try{
    if(typeof ROLE_PERMS==='object' && ROLE_PERMS.packer && !ROLE_PERMS.packer.includes('payroll')){
      ROLE_PERMS.packer.push('payroll');
    }
  }catch(e){ console.warn('ROLE_PERMS patch',e); }

  window.loadSalaryAdvances=loadSalaryAdvances;
  window.addSalaryAdvance=addSalaryAdvance;
  window.deleteSalaryAdvance=deleteSalaryAdvance;
  window.renderPayroll=renderPayrollV256;
  window.exportPayrollCsv=exportPayrollCsvV256;
  window.exportReportCsv=exportReportCsvV256;

  function boot(){
    try{
      if(isAdmin()) renderSalaryAdvancePanel();
    }catch(e){console.warn('V25.6 boot',e);}
  }

  document.addEventListener('DOMContentLoaded',()=>setTimeout(boot,900));
  setTimeout(boot,1800);
})();

/* ================= V25.6.0 FINAL: ASSIGNMENT + PRINT/PDF ================= */
(function(){
  'use strict';
  const state=()=>window.CloudSync?.state?.()||{};
  const activeRows=()=> (Array.isArray(window.D?.catalog)?window.D.catalog:[])
    .map((p,i)=>({p,i})).filter(x=>x.p&&!x.p.deleted);
  const sid=(p,i)=>String(p?.catalogId||((typeof catalogKey==='function')?catalogKey(p,i):`legacy:${i}`)).trim();
  const findId=id=>activeRows().find(x=>sid(x.p,x.i)===String(id||'').trim())||null;
  const findNameSize=(name,size)=>{
    const n=String(name||'').trim().toLowerCase(), s=String(size||'').trim().toLowerCase();
    return activeRows().find(x=>String(x.p.name||'').trim().toLowerCase()===n && String(x.p.size||'').trim().toLowerCase()===s)||null;
  };

  // Do not force an /apps read while opening the assignment selector.
  // The admin's just-added local catalog is authoritative for this screen;
  // normal schedulePush() continues to sync it in the background.
  window.refreshCatalogForAssignment=async function(){
    try{
      if(typeof ensureCatalogIds==='function') ensureCatalogIds();
      if(typeof repairCanonicalConfig==='function') repairCanonicalConfig();
      if(typeof localSaveOnly==='function') localSaveOnly();
      return true;
    }catch(e){ console.warn('V25.6 local assignment catalog',e); return false; }
  };

  window.renderAssignSizes=function(){
    const name=String($('assignPlant')?.value||'').trim();
    const size=$('assignSize'); if(!size)return;
    const rows=activeRows().filter(x=>String(x.p.name||'').trim().toLowerCase()===name.toLowerCase());
    size.innerHTML=rows.length
      ? '<option value="">-- Chọn kích thước --</option>'+rows.map(x=>`<option value="${x.i}">${esc(x.p.size||'Không ghi kích thước')}</option>`).join('')
      : '<option value="">-- Chọn loại cây trước --</option>';
    size.disabled=!rows.length;
  };

  window.fillAssignOptions=async function(){
    const s=state(); if(!s.user||s.role!=='admin')return;
    try{if(typeof ensureCatalogIds==='function')ensureCatalogIds();}catch(e){}
    const emp=$('assignEmployee'),plant=$('assignPlant'),ps=$('assignPackSize'); if(!emp||!plant||!ps)return;
    const oldEmp=emp.value,oldPlant=plant.value,oldPack=ps.value;
    try{
      const users=await s.listUsers();
      const packers=users.filter(u=>u.role==='packer'&&u.active!==false&&u.employeeId!=null&&String(u.employeeName||'').trim());
      emp.innerHTML=packers.length
        ? '<option value="">-- Chọn nhân viên đóng hàng --</option>'+packers.map(u=>`<option value="${esc(u.uid)}">${esc(u.employeeName)} · ${esc(u.email||'')}</option>`).join('')
        : '<option value="">Chưa có nhân viên đóng hàng đã liên kết tài khoản</option>';
      if(packers.some(u=>u.uid===oldEmp))emp.value=oldEmp;
    }catch(e){
      console.error('fillAssignOptions users',e);
      emp.innerHTML='<option value="">Không đọc được tài khoản nhân viên</option>';
    }
    const names=[...new Set(activeRows().map(x=>String(x.p.name||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'vi'));
    plant.innerHTML=names.length
      ? '<option value="">-- Chọn loại cây --</option>'+names.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('')
      : '<option value="">Chưa có danh mục cây</option>';
    if(names.includes(oldPlant))plant.value=oldPlant;
    ps.innerHTML='<option value="">-- Chọn quy cách --</option>'+Array.from({length:100},(_,i)=>i+1).map(n=>`<option value="${n}">${n===1?'1 cây · không combo':n+' cây / combo'}</option>`).join('');
    if(oldPack)ps.value=oldPack;
    renderAssignSizes();
  };

  window.addAssignmentItem=function(){
    const name=String($('assignPlant')?.value||'').trim(), idx=Number($('assignSize')?.value), qty=Math.floor(Number($('assignItemQty')?.value)||0);
    const p=(Number.isInteger(idx)&&idx>=0)?D.catalog?.[idx]:null;
    if(!name||!p||p.deleted||qty<1||String(p.name||'').trim().toLowerCase()!==name.toLowerCase()){
      toast('Cây/kích thước chưa hợp lệ. Vui lòng chọn lại cây và kích thước.'); return;
    }
    const id=sid(p,idx);
    assignmentItems.push({catalogId:id,plantIndex:idx,plantKey:id,plantName:String(p.name||name).trim(),size:String(p.size||'').trim(),qty});
    renderAssignmentItems(); if($('assignItemQty'))$('assignItemQty').value=1;
    toast(`Đã thêm ${qty} cây · ${p.name||name}`);
  };

  window.adminCreateAssignments=async function(){
    if(!CloudSync.requirePerm('users'))return;
    const s=state(), uid=$('assignEmployee')?.value||'', name=String($('assignPlant')?.value||'').trim(), idx=Number($('assignSize')?.value), pack=Math.max(1,Math.floor(Number($('assignPackSize')?.value)||0)), count=Math.floor(Number($('assignOrderCount')?.value)||0), note=String($('assignNote')?.value||'').trim();
    if(!uid){toast('❌ Chưa chọn nhân viên đóng hàng.');return}
    if(pack<1||pack>100){toast('❌ Quy cách đơn phải từ 1 đến 100 cây/đơn.');return}
    if(count<1){toast('❌ Số đơn cần đóng phải ít nhất là 1.');return}
    const users=await s.listUsers();
    const target=users.find(u=>String(u.uid)===String(uid)&&String(u.role).toLowerCase()==='packer'&&u.active!==false&&u.employeeId!=null&&String(u.employeeName||'').trim());
    if(!target){toast('❌ Tài khoản nhân viên chưa liên kết đúng với nhân viên.');return}
    let raw=Array.isArray(assignmentItems)?assignmentItems.slice():[];
    if(!raw.length&&name&&Number.isInteger(idx)){
      const p=D.catalog?.[idx]; if(p&&!p.deleted&&String(p.name||'').trim().toLowerCase()===name.toLowerCase())raw=[{catalogId:sid(p,idx),plantIndex:idx,plantKey:sid(p,idx),plantName:p.name,size:p.size,qty:pack}];
    }
    const items=raw.map(x=>{
      let hit=findId(x.catalogId||x.plantKey)||findNameSize(x.plantName,x.size);
      if(!hit){const i=Number(x.plantIndex),p=D.catalog?.[i];if(p&&!p.deleted)hit={p,i};}
      if(!hit)return null;
      const id=sid(hit.p,hit.i);
      return {catalogId:id,plantIndex:hit.i,plantKey:id,plantName:String(hit.p.name||'').trim(),size:String(hit.p.size||'').trim(),qty:Math.max(1,Math.floor(Number(x.qty)||0))};
    }).filter(Boolean);
    if(!items.length){toast('❌ Cây mới chưa được nhận diện. Hãy chọn lại cây + kích thước rồi bấm THÊM CÂY.');return}
    if(items.length===1)items[0].qty=pack;
    const total=items.reduce((a,x)=>a+x.qty,0);
    if(items.length>1&&total!==pack){toast(`❌ Tổng số cây phải đúng ${pack} cây/đơn (hiện ${total}).`);return}
    for(let n=0;n<count;n++){
      const now=Date.now(), first=items[0];
      await s.createPackingOrder({assignedUid:String(target.uid),employee:String(target.employeeName).trim(),employeeId:String(target.employeeId).trim(),plantIndex:Number(first.plantIndex),plantName:String(first.plantName),size:String(first.size),packSize:Number(total),items:items.map(x=>({plantIndex:Number(x.plantIndex),plantKey:String(x.plantKey),plantName:String(x.plantName),size:String(x.size),qty:Number(x.qty)})),orderNo:`${String(now).slice(-6)}-${String(n+1).padStart(2,'0')}`,status:'pending',date:String($('dDate')?.value||START),assignedAtMs:now,note:String(note)});
    }
    toast(`✅ Đã phân công ${count} đơn · ${items.length} loại cây · ${total} cây/đơn cho ${target.employeeName}`);
    if($('assignNote'))$('assignNote').value=''; if($('assignOrderCount'))$('assignOrderCount').value=1; clearAssignmentItems(); await renderAssignmentControls();
  };

  function cleanPrint(){
    const b=$('orderPrintArea'),q=$('quotePdfPrint');
    if(b){b.innerHTML='';b.setAttribute('aria-hidden','true')}
    if(q){q.classList.remove('show');q.innerHTML=''}
    document.documentElement.classList.remove('print-order','print-quote');document.body.classList.remove('print-order','print-quote');
  }
  window.printPackingOrder=async function(id){
    if(!(await ensureAdminPrintAccess()))return;
    const rows=Array.isArray(D.packingOrders)?D.packingOrders:[], r=rows.find(x=>String(x.id)===String(id)); if(!r){toast('Không tìm thấy đơn hàng');return}
    const box=$('orderPrintArea');if(!box)return; box.innerHTML=buildPackingPrintPage(r);box.setAttribute('aria-hidden','false');document.documentElement.classList.add('print-order');document.body.classList.add('print-order');
    try{
      if(window.AndroidBridge?.printOrder65x100){AndroidBridge.printOrder65x100('ROLL-CAY-CANH-'+String(r.orderNo||r.id).replace(/[^a-zA-Z0-9_-]/g,'_'));setTimeout(cleanPrint,7000);return}
      if(window.AndroidBridge?.printA4Page){AndroidBridge.printA4Page('ROLL-CAY-CANH-'+String(r.orderNo||r.id).replace(/[^a-zA-Z0-9_-]/g,'_'));setTimeout(cleanPrint,7000);return}
      window.print();setTimeout(cleanPrint,1500);
    }catch(e){console.error(e);cleanPrint();toast('Thiết bị chưa hỗ trợ in trực tiếp')}
  };
  window.printSelectedPackingOrders=async function(){
    if(!(await ensureAdminPrintAccess()))return;
    const ids=[...document.querySelectorAll('.batch-print-check:checked')].map(x=>x.value), rows=ids.map(id=>batchPrintRows.find(r=>String(r.id)===String(id))).filter(Boolean); if(!rows.length){toast('Hãy chọn ít nhất 1 đơn để in');return}
    const box=$('orderPrintArea');if(!box)return; box.innerHTML=rows.map(buildPackingPrintPage).join('');box.setAttribute('aria-hidden','false');document.documentElement.classList.add('print-order');document.body.classList.add('print-order');closeEdit();
    try{
      if(window.AndroidBridge?.printOrder65x100){AndroidBridge.printOrder65x100('ROLL-CAY-CANH-BATCH-'+rows.length);setTimeout(cleanPrint,9000);return}
      if(window.AndroidBridge?.printA4Page){AndroidBridge.printA4Page('ROLL-CAY-CANH-BATCH-'+rows.length);setTimeout(cleanPrint,9000);return}
      window.print();setTimeout(cleanPrint,1500);
    }catch(e){console.error(e);cleanPrint();toast('Thiết bị chưa hỗ trợ in trực tiếp')}
  };
  window.exportQuotePdf=function(){
    if(!quoteItems.length){toast('Chưa có cây trong báo giá');return}
    const items=quoteItems.map((x,i)=>{const p=D.catalog[Number(x.plantIndex)]||{},q=Number(x.qty)||0,t=q*(Number(p.price)||0);return{i:i+1,p,q,t}}),pages=[],PAGE_ROWS=8;
    for(let start=0;start<items.length;start+=PAGE_ROWS){
      const chunk=items.slice(start,start+PAGE_ROWS),rows=chunk.map(r=>`<tr><td style="text-align:center">${r.i}</td><td><img src="${imageSrc(r.p)}" alt=""></td><td><b>${esc(r.p.name||'')}</b></td><td>${esc(r.p.size||'')}</td><td style="text-align:center">${r.q}</td><td style="text-align:right">${money(r.p.price||0)}</td><td style="text-align:right">${money(r.t)}</td></tr>`).join('');
      const meta=start===0?`<div class="quote-pdf-meta"><div><b>Khách hàng:</b> ${esc($('quoteCustomer')?.value||'')}</div><div><b>Ngày:</b> ${quoteDate()}</div><div><b>Số điện thoại:</b> ${esc($('quotePhone')?.value||'')}</div><div><b>Đơn vị:</b> ROLL GARDEN</div></div>`:'';
      const last=start+PAGE_ROWS>=items.length,total=last?`<div class="quote-pdf-total">TỔNG GIÁ: ${money(quoteTotal())}</div>${$('quoteNote')?.value?`<div class="quote-pdf-note"><b>Ghi chú:</b> ${esc($('quoteNote').value)}</div>`:''}`:'';
      pages.push(`<div class="quote-pdf-page"><img class="quote-pdf-bg" src="quote-background.jpg" alt=""><div class="quote-pdf-content"><h1>BÁO GIÁ CÂY CẢNH</h1>${meta}<table class="quote-pdf-table"><thead><tr><th>STT</th><th>Hình ảnh</th><th>Tên sản phẩm</th><th>Kích thước</th><th>SL</th><th>Đơn giá</th><th>Thành tiền</th></tr></thead><tbody>${rows}</tbody></table>${total}<div class="quote-pdf-footer">ROLL GARDEN · Cây đẹp - Không gian xanh - Cuộc sống an lành</div></div></div>`);
    }
    const box=$('quotePdfPrint');if(!box)return;box.innerHTML=pages.join('');box.classList.add('show');document.documentElement.classList.add('print-quote');document.body.classList.add('print-quote');
    const job='Bao-gia-ROLL-GARDEN-'+String(fmt(new Date())).replace(/[^0-9-]/g,'')+'-'+String(Date.now()).slice(-6);
    try{
      if(window.AndroidBridge?.exportPdf){AndroidBridge.exportPdf(job+'.pdf');setTimeout(cleanPrint,10000);return}
      if(window.AndroidBridge?.printA4Page){AndroidBridge.printA4Page(job);setTimeout(cleanPrint,9000);return}
      window.print();setTimeout(cleanPrint,1800);
    }catch(e){console.error(e);cleanPrint();toast('Không thể xuất PDF')}
  };
})();
