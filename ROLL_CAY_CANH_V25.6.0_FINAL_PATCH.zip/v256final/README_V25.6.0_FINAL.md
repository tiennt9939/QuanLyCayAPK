ROLL CÂY CẢNH V25.6.0 — FINAL PATCH

Phạm vi đã chốt:
1) Cây mới thêm phải xuất hiện và dùng được trong Chia/Phân công đơn.
2) In đơn 65x100 mm không đi qua A4.
3) Xuất báo giá thành file PDF thật, A4.
4) Bảng lương tổng theo từng nhân viên + tạm ứng + thực nhận.
5) Tạm ứng lưu thật vào Firestore /salaryAdvances.

QUAN TRỌNG:
- Nền là V25.5.6 hiện tại.
- Không rollback V25.4.x.
- Không thay đổi luồng hoàn thành đơn/2 ảnh ngoài Rules cần thiết.
- Không sửa main cho đến khi build/test branch hoàn thiện thành công.

Các file trong gói:
- roll-fixes-v256-final.js: thêm vào index.html ngay trước </body>.
- firestore.rules-v256-final: Rules cho salaryAdvances, combo 1-100 và khóa dữ liệu khi packer hoàn thành.
- MainActivity_V256_PRINT_PDF_PATCH.txt: patch native in 65x100 + PDF thật.
- app-build.gradle.kts: version 25.6.0 / code 32.
- build-apk-v256.yml: workflow build.

CÁCH ÁP DỤNG TRÊN ĐIỆN THOẠI:
1. Tạo branch mới từ main: v25-6-0-complete-implementation.
2. Upload/replace các file tương ứng.
3. index.html: thêm đúng 1 dòng <script src="roll-fixes-v256-final.js"></script> ngay trước </body>.
4. MainActivity.java: làm patch native theo file hướng dẫn.
5. Thay app/build.gradle.kts bằng app-build-gradle.kts.
6. Thay firestore.rules bằng firestore.rules-v256-final.
7. Thay workflow build-apk.yml bằng build-apk-v256.yml.
8. Commit trên branch, chạy Actions.

TEST BẮT BUỘC:
- Thêm cây mới -> mở Chia đơn -> cây mới phải xuất hiện -> phân công thành công.
- In 1 đơn -> Print Preview phải hiện 65 x 100 mm, không A4.
- Báo giá -> Xuất PDF -> phải có file .pdf trong Tải xuống/ROLL CAY CANH, không mở Print Preview.
- Bảng lương -> chọn cùng ngày Từ/Đến -> đúng dữ liệu.
- Tạm ứng -> ghi nhận -> bảng lương trừ tạm ứng -> thực nhận đúng.
- Nhân viên chỉ xem payroll của mình.
