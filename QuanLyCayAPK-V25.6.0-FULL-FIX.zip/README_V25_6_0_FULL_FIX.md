# ROLL CÂY CẢNH V25.6.0 — FULL FIX

Bản này được tạo từ full source V25.5.9 và có thay đổi thực tế trong source.

## Đã sửa

1. **Chia đơn / cây mới**
   - Dùng `catalogId` làm định danh chính cho dòng danh mục.
   - Dropdown kích thước không còn phụ thuộc index làm khóa chính.
   - Cây vừa thêm được hiển thị từ catalog local ngay lập tức.
   - Firestore refresh chạy nền và không được phép làm mất cây local mới.
   - Payload đơn phân công lưu `catalogId` cùng `plantKey`/`plantIndex` để tương thích dữ liệu cũ.

2. **In đơn 65 × 100 mm**
   - Thêm bridge native `printOrder65x100()`.
   - Đường in đơn không còn gọi nhầm `printA4Page()`.
   - Native PrintAttributes dùng media size 65 × 100 mm.

3. **Xuất báo giá PDF thật**
   - Thêm bridge native `exportPdf()`.
   - PDF được tạo qua `PrintDocumentAdapter`, ghi thành file `.pdf`.
   - Lưu vào `Tải xuống / ROLL CAY CANH` qua MediaStore trên Android 10+.

4. **Lương / tạm ứng**
   - Giữ nguyên logic payroll hiện có.
   - Không viết lại công thức lương đang hoạt động.
   - Tạm ứng tiếp tục được lưu trong `D.salaryAdvances` và đi qua cơ chế `save()`/CloudSync hiện có.

## Kiểm tra

- Version: **25.6.0 / versionCode 35**
- JavaScript syntax: PASS
- Static preflight: PASS
- 65×100 print bridge: PASS
- Native PDF bridge: PASS
- Combo rule: 1..100 cây/đơn
- Salary advance: PASS
- Payroll export: PASS

## Build

Workflow `.github/workflows/build-apk.yml` đã được cập nhật để build artifact:

`QuanLyCayAPK-V25.6.0-STABLE-debug`

Source này không chứa APK đã build. APK phải được tạo bởi GitHub Actions hoặc môi trường Android/Gradle tương ứng.
