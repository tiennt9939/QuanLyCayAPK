# QuanLyCayAPK V25.6.14 — FULL INTEGRATED BUILD

This archive is the complete Android source, not a patch.

Version: 25.6.14 (versionCode 39)

Included:
- Existing V25.6.3 root-cause assignment/payroll/print fixes
- Assignment plant search using stable catalogId
- Admin completion of assigned packing orders with payroll attribution
- Payroll combines direct work pay and completed assigned-order pay
- Salary advance and payroll export
- A4 quotation PDF/print background and 65x100 label print
- FlashLabel handoff bridge for A318 Bluetooth printer
- Shipping-waybill photo OCR using bundled Google ML Kit
- Tracking number search and daily J&T / Cargo / GHN counts
- Existing login, roles, Firestore sync, inventory, quotation and order flows retained

Build:
1. Upload/extract this source as the repository root.
2. GitHub Actions workflow: .github/workflows/build-apk.yml
3. Run the workflow on branch main.
4. Install the generated debug APK artifact.

The local static preflight passes before Android compilation.
