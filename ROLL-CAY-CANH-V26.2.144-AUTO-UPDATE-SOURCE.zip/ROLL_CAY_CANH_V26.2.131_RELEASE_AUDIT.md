# Release audit — V26.2.131

## Change scope
- Based on V26.2.130, versionCode 183.
- Replaced strictly serialized Drive image uploads with a bounded two-upload queue.
- Reuses account-scoped persisted Drive image references instead of downloading each whole image solely to validate the reference after every process start.
- Preserves app-private queue files for captured daily-shipment photos; this patch does not introduce destructive queue cleanup.

## Verification
- `python3 tools/preflight.py`: PASS.
- `node tools/drive_upload_responsiveness_test.js`: PASS.
- All `tools/*_test.js`: 113/113 PASS.
- ZIP integrity and SHA-256: see companion verification files.

## Important limits
- No APK was built here (Android SDK/Gradle unavailable).
- No live account Drive/Firebase test or physical-device background test was run.
- Bounded concurrency and eliminating redundant downloads target upload lag. They do not guarantee uploads continue if Android kills the app. That requires validating a native foreground/background upload worker against the current OAuth and Firestore flow.
