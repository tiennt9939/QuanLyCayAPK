# Release audit — ROLL CÂY CẢNH V26.2.132

## Change scope
- Base: V26.2.131, versionCode 183.
- New version: V26.2.132, versionCode 184.
- Added durable Android-private JSON store APIs and a per-record offline outbox for daily shipment scans.
- Added native durable storage for staged TikTok PDF labels; maintained localStorage compatibility.
- Added reconnect/foreground/manual retry and idempotent report retry using the operationId; Drive photo upload/attachment remains a separate phase.
- Reduced bulk-scan cloud-preflight timeout to enable local fallback without a long spinner.
- No Firestore schema migration and no deletion/reset of business data.

## Verification performed in this workspace
- `python3 tools/preflight.py`: PASS.
- `tools/*_test.js`: 114/114 PASS.
- JavaScript syntax: all 6 inline script blocks and `app/src/main/assets/tiktok-label-import.js` pass `node --check`.
- ZIP integrity is checked after packaging; final ZIP checksum is in the separate delivery note (not embedded in the ZIP to avoid a self-referential checksum).

## Not verified
- No APK build was run here because Android SDK/Gradle are unavailable in this workspace and no Gradle wrapper is included.
- No live Firebase or Drive service test and no physical Android device test were run.
- Offline mode must be validated on the target phone before production use, including duplicate scans, assignment changed while offline, app process death, Drive retry and report/payroll/inventory reconciliation.

## Risk controls
- An offline item is not counted as confirmed wages/inventory until Firebase returns success.
- Conflicts are retained for manual review rather than retrying wage credit blindly.
- Native queue data survives ordinary app restarts/updates but not uninstall/app-data clear; never clear app data while the queue is pending.
