# ROLL CÂY CẢNH V26.2.135 — Migration conflict fix

## Fix included
- The admin migration uses `overwrite:true` for the Firestore-to-GAS import, resolving `A different document already exists in GAS: apps/roll-cay-canh`.
- Before replacing a different pre-existing GAS document, Code.gs archives the old document into `fsCompatMigrationBackup` in chunks. If the archive cannot be written, the migration stops before changing that destination document.
- Every imported source document is read back from GAS and compared with the source value. Firestore remains intact.
- `ROLL_GAS_COMPAT_WRITES_ENABLED` may remain `false` before migration; the server's admin-only import path is separately authorized. Do not set `ROLL_GAS_CUTOVER_COMPLETED` manually.

## Automated checks
- `python tools/preflight.py`: PASS.
- `115/115` JavaScript regression tests: PASS.
- Inline JavaScript blocks and both external migration modules: syntax PASS.
- Apps Script `Code.gs` syntax: PASS with JavaScript parser.
- GAS migration guard test verifies overwrite-enabled import, pre-overwrite archive and gated cutover: PASS.

## Not claimed
- The Apps Script has not been deployed into the user's Google account from this workspace.
- No live data migration or production cutover was run here.
- No APK build/device test is claimed from this workspace. GitHub Actions must build this source package; then the app must run the copy and verification against the actual configured spreadsheet.
