# ROLL CÂY CẢNH V26.2.144 — Safe cleanup of stale PDF labels

## Root cause addressed
The Admin cleanup preview excluded any PDF queue row whose cached `status` string was `recorded`, even when there was no canonical scan/report record. The execute transaction also treated that queue status alone as authoritative. A stale status copied from an old PDF/cache therefore could not be cleaned, and the old label remained visible after the original PDF was deleted.

## Changes
- Cleanup preview now evaluates rows with stale `recorded` status against canonical `dailyShipmentScans`, `dailyShipmentReports`, active `shipmentTrackingClaims`, and linked/completed orders.
- The cleanup transaction no longer blocks solely on the queue row's `status` text. It still blocks when canonical scan evidence exists, a report is recorded, a non-voided tracking claim exists, or a linked completed order exists.
- Existing two-step Admin preview + exact confirmation remains required. No blanket daily reset was added.
- Updated the Admin cleanup explanation to clarify that stale cache status is not scan proof.
- Android metadata: versionName `26.2.144`, versionCode `196`.
- No Firestore schema, payroll formula, inventory logic, catalog, price, staff-account, or GAS source changes.

## Validation
- `tools/preflight.py`: PASS.
- All `tools/*_test.js`: PASS, including `stale_recorded_pdf_cleanup_test.js`.
- Inline JavaScript syntax: 9 blocks PASS.
- `app/src/main/assets/tiktok-label-import.js` syntax: PASS.

## Important limitation
This source fix does not itself delete any live Firebase records. After building/installing V26.2.144, Admin must open the advanced maintenance screen, preview “Dọn đơn cũ chưa hoàn tất”, review the exact counts, and confirm only if the stale test label appears as a candidate. If the label is backed by a canonical scan/report/active claim or completed order, it remains protected. The GAS phase3.1/phase3.2 deployment mismatch is separate and remains to be resolved on the existing Apps Script deployment.
