# V26.2.132 — Ghi nhận quét ngoại tuyến trước, đồng bộ sau

## Mục tiêu
Giảm thời gian chờ khi mất mạng hoặc Google/Firebase phản hồi chậm, nhưng không giả vờ rằng tiền công/tồn kho đã được ghi khi máy chủ chưa xác nhận.

## Cơ chế mới
- Danh sách nhãn PDF đang chờ được lưu vào thư mục riêng của ứng dụng Android bằng ghi tệp tạm + thay thế nguyên tử. localStorage chỉ còn là bản tương thích.
- Mỗi lần quét có một bản ghi outbox riêng theo mã vận đơn, với operationId ổn định và đường dẫn ảnh nội bộ; ảnh Base64 không được nhân đôi vào outbox.
- Khi mất mạng, quét hàng loạt dùng dữ liệu phân công đã cache và ghi nhận `pending` cục bộ. Trạng thái hiển thị rõ là chưa được Firebase xác nhận.
- Khi có mạng, hàng đợi gửi từng lượt theo thứ tự. Firestore tiếp tục thực hiện kiểm tra phân công, assignment revision và khóa chống trùng trong giao dịch hiện có.
- Nếu Firebase đã ghi nhận chính operationId này trước khi phía điện thoại mất kết nối, lần thử lại khớp operationId sẽ tiếp tục luồng ảnh mà không cộng tiền công lần hai. Nếu mã đã có bản ghi khác hoặc phân công đổi, mục sẽ vào `needs_review`.
- Ảnh được tải Drive riêng; file cục bộ chỉ được xác nhận hoàn tất sau khi Firebase xác nhận gắn tham chiếu `drive://`.

## Giới hạn cần hiểu rõ
- Dữ liệu ngoại tuyến chỉ đáng tin cậy với các nhãn PDF, phân công, danh mục cây và dữ liệu nhân viên đã lưu trên máy trước khi mất mạng.
- Bản ghi chờ không có nghĩa là công hoặc tồn kho đã được chốt trên máy chủ.
- Phải kiểm thử bằng điện thoại thật (quét nhiều đơn khi bật/tắt mạng, đóng/mở ứng dụng, đợi đồng bộ xong và đối chiếu từng mã/tiền công/tồn kho/ảnh) trước khi dùng trong vận hành thực tế.
- Không xóa dữ liệu ứng dụng khi còn mục chờ đồng bộ.

## Giữ nguyên
Dự án tiếp tục từ V26.2.131, giữ Firebase/Firestore, Google Drive, nhận diện cây, quy tắc combo/kích thước, dữ liệu giá, công thức tiền công và logic tồn kho hiện tại.
