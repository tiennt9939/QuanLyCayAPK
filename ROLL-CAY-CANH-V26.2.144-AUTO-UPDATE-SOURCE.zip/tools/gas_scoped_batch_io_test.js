'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const code=fs.readFileSync(require('node:path').join(__dirname,'../Code.gs'),'utf8');
const start=code.indexOf('function fsCompatBuildIndex_()');
const end=code.indexOf('function fsCompatFindOperation_(sheet, opId)',start);
assert(start>=0&&end>start,'GAS scoped index helper block must exist');
const left=[
 ['doc','users/u1','users','u1'],
 ['doc','users/u2','users','u2'],
 ['doc','packingOrders/t1','packingOrders','t1'],
 ['op','','',''],
 ['doc','users/u1','users','u1'],
 ['doc','users/u1','users','u1']
];
const right=[
 [0,1,1,100,'admin','FALSE'],
 [0,1,1,101,'admin','FALSE'],
 [0,1,1,102,'admin','FALSE'],
 [0,1,0,103,'admin','FALSE'],
 [0,2,2,104,'admin','FALSE'],
 [1,2,2,104,'admin','FALSE']
];
const payload={
  2:'{"role":"packer","employeeId":"old"}',
  3:'{"role":"packer","employeeId":"3"}',
  4:'{"trackingNo":"SHIP-1"}',
  6:'{"role":"packer","employeeId":"2",',
  7:'"employeeName":"Luan nho"}'
};
const payloadRanges=[];
const sheet={
  getLastRow:()=>7,
  getRange(row,col,numRows,numCols){
    return {
      getValues(){
        if(col===1)return left.slice(row-2,row-2+numRows).map(x=>x.slice(0,numCols));
        if(col===6)return right.slice(row-2,row-2+numRows).map(x=>x.slice(0,numCols));
        if(col===5){payloadRanges.push({row,numRows});const a=[];for(let i=0;i<numRows;i++)a.push([payload[row+i]||'']);return a;}
        throw new Error('Unexpected column '+col);
      }
    };
  }
};
const context={Object,String,Number,Math,Array,JSON,fsCompatSheet_:()=>sheet,
  fsCompatNormalizeCollectionPath_:x=>String(x).replace(/^\/+|\/+$/g,''),
  fsCompatNormalizeDocPath_:x=>String(x).replace(/^\/+|\/+$/g,''),
  fsCompatError_:(code,message)=>Object.assign(new Error(message),{code})};
vm.createContext(context);
vm.runInContext(code.slice(start,end)+'\nthis.byCollection=fsCompatBuildIndexForCollections_;this.byPath=fsCompatBuildIndexForPaths_;this.related=fsCompatRelatedSecurityPaths_;',context);
const users=context.byCollection(['users']);
assert.deepEqual(Object.keys(users).sort(),['users/u1','users/u2']);
assert.equal(users['users/u1'].data.employeeName,'Luan nho','latest multi-chunk version should be reconstructed');
assert(payloadRanges.every(r=>!(r.row<=4&&r.row+r.numRows-1>=4)),'unrelated packingOrders payload was fetched');
assert(payloadRanges.some(r=>r.row===6&&r.numRows===2),'adjacent payload chunks should be fetched as one range');
payloadRanges.length=0;
const one=context.byPath(['users/u2']);
assert.deepEqual(Object.keys(one),['users/u2']);
assert.equal(payloadRanges.length,1);
assert.deepEqual(payloadRanges[0],{row:3,numRows:1});
const dependencies=context.related([{path:'packingOrders/o1',before:{},after:{shipmentTrackingNo:'GHVNABC123'}}]);
assert(dependencies.includes('shipmentTrackingClaims/GHVNABC123'));
assert(dependencies.includes('dailyShipmentScans/GHVNABC123'));
console.log('GAS scoped exact-path reads + batched sheet payload ranges: PASS');
