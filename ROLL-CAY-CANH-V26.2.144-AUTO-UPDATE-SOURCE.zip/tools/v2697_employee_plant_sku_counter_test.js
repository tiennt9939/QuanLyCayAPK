'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const preflight = fs.readFileSync(path.join(root, 'tools/preflight.py'), 'utf8');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/build-apk.yml'), 'utf8');

assert(/versionName\s*=\s*"[0-9]+(?:\.[0-9]+)+"/.test(gradle) && /versionCode\s*=\s*\d+/.test(gradle), 'version should be V26.2.115/code 167');
assert(preflight.includes('version_name_match') && preflight.includes('version_code > 167'), 'preflight metadata should match');
assert(workflow.includes('steps.source_meta.outputs.version_name') && workflow.includes('*AUTO-UPDATE-SOURCE.zip'), 'workflow must retain source ZIP trigger');
assert(html.includes('ontoggle="renderReportEmployeeCounters(this)"'), 'employee row must lazy-open grouped counters');
assert(html.includes('ontoggle="renderReportEmployeeSkuGroupOrders(this)"'), 'plant/SKU counter must lazy-open matching orders');
assert(html.includes('ontoggle="renderReportEmployeeSkuOrderDetail(this)"'), 'order details must remain lazy until an individual order is opened');
assert(!html.includes('.map(reportCompletedOrderDetailHtml).join(\'\')'), 'employee accordion must not render every order detail upfront');

const start = html.indexOf('function reportPlantGroupIdentity(name,size){');
const end = html.indexOf('\nfunction renderReport(){', start);
assert(start >= 0 && end > start, 'report grouping helpers must exist');
const ctx = {
  Array, Map, Set, String, Number, Math,
  D: { catalog: [{ name: 'Cẩm tú mai', size: 'C7' }, { name: 'Cẩm tú mai', size: 'C9' }] },
  orderItems: row => (row.items || []).map((x, i) => ({ ...x, itemIndex: i, plantIndex: Number(x.plantIndex), qty: Number(x.qty) || 0 })),
  orderItemRate: item => Number(item.assignedRate) || (item.size === 'C7' ? 1600 : 2000),
  packerPay: row => Number(row.payAmount) || (row.items || []).reduce((s, x) => s + (Number(x.qty) || 0) * (Number(x.assignedRate) || (x.size === 'C7' ? 1600 : 2000)), 0),
  reportProductSourceRows: row => Array.isArray(row.sourceProducts) ? row.sourceProducts : [],
  reportOrderTrackingNo: row => String(row.trackingNo || row.id || ''),
  completedOrderDate: row => String(row.date || ''),
  fmtDMY: value => String(value || ''),
  money: value => `${Math.round(Number(value) || 0)} đ`,
  esc: value => String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;'),
  reportCompletedOrderDetailHtml: row => `<article>ORDER-DETAIL:${row.id}</article>`,
};
vm.runInNewContext(html.slice(start, end), ctx, { filename: 'employee-plant-sku-counter.js' });
function makeOrder(id, plantName, size, sku, sellerSku, qty=1) {
  return {
    id, trackingNo: id, date: '2026-10-22', employee: 'Luân nhỏ', payAmount: qty * (size === 'C7' ? 1600 : 2000),
    items: [{ plantName, size, plantIndex: size === 'C7' ? 0 : 1, qty, assignedRate: size === 'C7' ? 1600 : 2000 }],
    sourceProducts: sku ? [{ productName: `${plantName} ${size}`, sku, sellerSku, soldQty: qty,
      mappedPlants: [{ plantName, size, qty }] }] : [],
  };
}
const rows = [];
for (let i=1; i<=5; i++) rows.push(makeOrder(`C7-A-${i}`, 'Cẩm tú mai', 'C7', 'SKU-CAM-C7-A', 'SELLER-CAM-C7-A'));
for (let i=1; i<=2; i++) rows.push(makeOrder(`C7-B-${i}`, 'Cẩm tú mai', 'C7', 'SKU-CAM-C7-B', 'SELLER-CAM-C7-B'));
for (let i=1; i<=4; i++) rows.push(makeOrder(`C9-${i}`, 'Cẩm tú mai', 'C9', 'SKU-CAM-C9', 'SELLER-CAM-C9'));
rows.push(makeOrder('OLD-NO-SKU', 'Cẩm tú mai', 'C7', '', ''));

const groups = ctx.buildReportEmployeePlantSkuGroups(rows);
assert.strictEqual(groups.length, 4, 'same plant/size but different SKU must remain separate; unknown legacy SKU gets its own clearly labelled group');
const c7a = groups.find(g => g.size === 'C7' && g.sku === 'SKU-CAM-C7-A');
const c7b = groups.find(g => g.size === 'C7' && g.sku === 'SKU-CAM-C7-B');
const c9 = groups.find(g => g.size === 'C9' && g.sku === 'SKU-CAM-C9');
const unknown = groups.find(g => g.size === 'C7' && !g.sku && !g.sellerSku);
assert(c7a && c7b && c9 && unknown, 'each SKU and unknown-SKU grouping must be identifiable');
assert.strictEqual(c7a.orderCount, 5, 'five same-name+same-size+same-SKU orders must form one counter');
assert.strictEqual(c7a.qty, 5, 'the counter must sum recorded tree quantities');
assert.strictEqual(Math.round(c7a.pay), 8000, 'counter labor total must sum recorded wage amounts');
assert.strictEqual(c7b.orderCount, 2, 'a different SKU must form a different counter');
assert.strictEqual(c9.orderCount, 4, 'C9 must not merge with C7');
assert.strictEqual(unknown.orderCount, 1, 'legacy order without saved SKU evidence should not merge into a known SKU group');

// Same group appearing twice as line items within a single order counts as one order and sums quantities.
const duplicate = [{ id:'DUP', trackingNo:'DUP', date:'2026-10-22', payAmount:3200,
  items:[{plantName:'Cẩm tú mai',size:'C7',plantIndex:0,qty:1,assignedRate:1600,sku:'SKU-DUP'},{plantName:'Cẩm tú mai',size:'C7',plantIndex:0,qty:1,assignedRate:1600,sku:'SKU-DUP'}] }];
const directSkuCtx = { ...ctx, reportProductSourceRows: () => [] };
const duplicateGroups = ctx.buildReportEmployeePlantSkuGroups(duplicate);
assert.strictEqual(duplicateGroups.length, 1);
assert.strictEqual(duplicateGroups[0].orderCount, 1);
assert.strictEqual(duplicateGroups[0].qty, 2);

ctx.employeeRowsForTest = [{ name:'Luân nhỏ', rows }];
vm.runInNewContext('reportEmployeeRowsCache = employeeRowsForTest; reportEmployeePlantSkuGroupsCache = [];', ctx);
const employeeBody = { innerHTML: '' };
const employeeDetails = { open:true, dataset:{ reportEmployeeIndex:'0' }, querySelector:selector => selector === '.report-employee-counter-body' ? employeeBody : null };
ctx.renderReportEmployeeCounters(employeeDetails);
assert(employeeBody.innerHTML.includes('5 đơn · 5 cây · SKU SKU-CAM-C7-A'), 'employee opening must show aggregated plant+SKU counter');
assert(!employeeBody.innerHTML.includes('ORDER-DETAIL:'), 'opening employee should not render order details eagerly');
const c7aIndex = vm.runInNewContext('reportEmployeePlantSkuGroupsCache[0].findIndex(g => g.sku === \"SKU-CAM-C7-A\")', ctx);
const groupBody = { innerHTML: '' };
const groupDetails = { open:true, dataset:{reportEmployeeIndex:'0',reportEmployeeGroupIndex:String(c7aIndex)}, querySelector:selector => selector === '.report-employee-sku-group-orders' ? groupBody : null };
ctx.renderReportEmployeeSkuGroupOrders(groupDetails);
assert.strictEqual((groupBody.innerHTML.match(/class="order-accordion report-employee-sku-order"/g)||[]).length, 5, 'opening the counter should show only its five matching orders');
assert(!groupBody.innerHTML.includes('ORDER-DETAIL:'), 'order detail remains lazy until one order is opened');
const detailBody = { innerHTML:'' };
const orderDetails = { open:true, dataset:{reportEmployeeIndex:'0',reportEmployeeGroupIndex:String(c7aIndex),reportEmployeeOrderIndex:'0'}, querySelector:selector => selector === '.report-employee-sku-order-detail' ? detailBody : null };
ctx.renderReportEmployeeSkuOrderDetail(orderDetails);
assert(detailBody.innerHTML.includes('ORDER-DETAIL:C7-A-5') || detailBody.innerHTML.includes('ORDER-DETAIL:C7-A-1'), 'opening a single order must render only its corresponding details');
console.log('V26.2.115 EMPLOYEE PLANT+SKU COUNTER TEST PASS');
