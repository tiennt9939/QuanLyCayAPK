'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const code=fs.readFileSync(require('node:path').join(__dirname,'../Code.gs'),'utf8');
const start=code.indexOf('function fsCompatBuildIndexForQuery_(querySpec)');
const end=code.indexOf('// Security rules use only these cross-document relationships.',start);
assert(start>=0&&end>start,'limited query helper must exist');
const metadata={
 'apps/root':{collectionPath:'apps',id:'root',deleted:false,chunkCount:1,chunks:{0:2}},
 'apps/t2':{collectionPath:'apps',id:'t2',deleted:false,chunkCount:1,chunks:{0:3}},
 'apps/root':{collectionPath:'apps',id:'t1',deleted:false,chunkCount:1,chunks:{0:4}},
 'apps/t0':{collectionPath:'apps',id:'t0',deleted:true,chunkCount:1,chunks:{0:5}},
 'packingOrders/o1':{collectionPath:'packingOrders',id:'o1',deleted:false,chunkCount:1,chunks:{0:6}}
};
let materialized=[];
const context={Object,String,Number,Array,Math,fsCompatNormalizeCollectionPath_:x=>String(x),fsCompatSheet_:()=>({}),fsCompatReadLatestMetadata_:()=>metadata,fsCompatMaterializeIndex_:(sheet,meta,paths)=>{materialized=paths;return Object.fromEntries(paths.map(path=>[path,{path}]))},fsCompatBuildIndexForCollections_:()=>({FULL:true})};
vm.createContext(context);vm.runInContext(code.slice(start,end)+'\nthis.build=fsCompatBuildIndexForQuery_;',context);
const result=context.build({collectionPath:'apps',filters:[],orderBy:[],limit:1});
assert.deepEqual(materialized,['apps/root']);
assert.equal(result['apps/root'].path,'apps/root');
assert.equal(context.build({collectionPath:'apps',filters:[{fieldPath:['state'],op:'==',value:'ok'}],orderBy:[],limit:1}).FULL,true,'filtered queries retain full scan semantics');
assert.deepEqual(materialized,['apps/root'],'filtered fallback is not executed by the limited fast path fixture');
assert.equal(context.build({collectionPath:'apps',filters:[],orderBy:[],limit:0}).FULL,undefined);
console.log('GAS limit(1) reads only the selected live payload; filtered queries keep the full scan path: PASS');
