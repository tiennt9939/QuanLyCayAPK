const assert=require('assert');
const fs=require('fs');
const parser=require('../app/src/main/assets/tiktok-label-import.js');
const cases=[
 ['VNGH80866350619','VNGH80866350619'],
 ['V\nN\nG\nH\n8\n0\n8\n6\n6\n3\n5\n0\n6\n1\n9','VNGH80866350619'],
 ['V\r\nN\r\nG\r\nH\r\n8\r\n0\r\n8\r\n6\r\n6\r\n3\r\n5\r\n0\r\n6\r\n1\r\n9','VNGH80866350619'],
 ['V\nN\nG\nH\n8\n0\n8\n6\n6\n3\n5\n0\n6\n1\n9\nNext 84TR','VNGH80866350619'],
 ['8\n6\n2\n6\n3\n1\n5\n8\n6\n4\n4\n2','862631586442'],
 ['8\u00a06\u00a02\u00a06\u00a03\u00a01\u00a05\u00a08\u00a06\u00a04\u00a04\u00a02','862631586442'],
 ['GHVN A123456','GHVNA123456'],
 ['G\nH\nV\nN\nA\n1\n2\n3\n4\n5\n6','']
];
for(const [input,expected] of cases){if(expected===''){assert.deepStrictEqual(parser.extractTracking(input),[],`variable-length GHVN split over lines should defer to OCR: ${JSON.stringify(input)}`)}else assert.deepStrictEqual(parser.extractTracking(input),[expected],`tracking must survive line-break/space layout: ${JSON.stringify(input)}`)}
// All supplied actual Seller Center PDF pages must still be readable in the normal text-first path.
const fixture=process.env.ROLL_TEST_PDF_TEXT;
if(fixture){const text=fs.readFileSync(fixture,'utf8');for(const t of ['862631586442','862693306442','862600576452','862656546442','VNGH80799520620','862665876452','862683066452'])assert(text.includes(t),`supplied PDF text must include ${t}`);assert.deepStrictEqual(parser.extractTracking(text).sort(),['862600576452','862631586442','862656546442','862665876452','862683066452','862693306442','VNGH80799520620'].sort())}
console.log('PDF TRACKING WHITESPACE ROOT FIX TEST PASS');
