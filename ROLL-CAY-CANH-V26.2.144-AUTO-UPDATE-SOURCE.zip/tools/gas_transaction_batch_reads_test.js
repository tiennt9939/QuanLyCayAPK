'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const source=fs.readFileSync(require('node:path').join(__dirname,'../app/src/main/assets/gas-firestore-compat.js'),'utf8');
const calls=[];
const context={
  console,
  URL,
  Uint8Array,
  Math,
  Date,
  Map,
  Set,
  Promise,
  JSON,
  Object,
  Array,
  String,
  Number,
  Error,
  setTimeout,
  clearTimeout,
  setInterval:()=>1,
  clearInterval:()=>{},
  crypto:{getRandomValues(bytes){for(let i=0;i<bytes.length;i++)bytes[i]=i+1;return bytes;}}
};
context.window=context;
context.AndroidBridge={postRollGasApi(requestId,requestJson){
  const request=JSON.parse(requestJson);calls.push(request);
  let data;
  if(request.command==='getMany'){
    data={documents:request.paths.map((path,i)=>({path,id:path.split('/').pop(),data:{employeeId:String(i)},version:i+1,updatedAtMs:1000+i}))};
  }else data={committed:true};
  context.__rollGasBridgeResponse(requestId,JSON.stringify({ok:true,data}));
}};
const auth={currentUser:{async getIdToken(){return 'x'.repeat(200);}}};
const firebase={apps:[{}],auth:()=>auth,firestore:function(){return{};}};
vm.createContext(context);
vm.runInContext(source,context);
const db=context.createRollGasFirestoreCompat(firebase,auth,{bridge:context.AndroidBridge,endpoint:'https://script.google.com/macros/s/Abc_123/exec'});
(async()=>{
  const refs=Array.from({length:125},(_,i)=>db.collection('users').doc('u'+i));
  const read=await db.runTransaction(async tx=>{
    const snapshots=await Promise.all(refs.map(ref=>tx.get(ref)));
    assert.equal(snapshots.length,125);
    assert.equal(snapshots[0].data().employeeId,'0');
    assert.equal(snapshots[124].data().employeeId,'24');
    return snapshots.length;
  });
  assert.equal(read,125);
  const getManyCalls=calls.filter(x=>x.command==='getMany');
  assert.equal(getManyCalls.length,2,'125 transaction reads should require 2 requests, not 125');
  assert.deepEqual(getManyCalls.map(x=>x.paths.length),[100,25]);
  assert.equal(calls.filter(x=>x.command==='get').length,0,'transaction reads must not be sent individually');
  console.log('GAS transaction read batching (125 docs / 2 requests): PASS');
})().catch(error=>{console.error(error);process.exitCode=1;});
