const assert=require('assert'),fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8'),gradle=fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8'),pre=fs.readFileSync(path.join(root,'tools/preflight.py'),'utf8');
assert(/versionName\s*=\s*"[0-9]+(?:\.[0-9]+)+"/.test(gradle)&&/versionCode\s*=\s*\d+/.test(gradle),'V26.2.115 metadata');
assert(html.includes('assignmentRequired alone is NOT proof that assignment actually happened'),'assignmentRequired flag regression guard');
const a=html.indexOf('function dailyShipmentLabelHasProtectedHistory('),b=html.indexOf('\nconst dailyShipmentCloudRangeLoadedAt=',a);
assert(a>=0&&b>a,'import/rebase helpers not found');
const ctx={D:{dailyShipmentOrders:[],dailyShipmentReports:[]},reports:[],
  $:id=>id==='dDate'?{value:'2026-10-25'}:null,
  normalizeTracking:t=>String(t||'').toUpperCase().replace(/[^A-Z0-9]/g,''),
  dailyShipmentApplyResetMarkers:()=>{}, dailyShipmentReportByTracking:t=>(ctx.reports||[]).find(r=>r.trackingNo===t)||null,
  inferShipmentCarrierFromTracking:()=> 'GHN', save:()=>{}, dailyShipmentPersistLocalBackup:()=>true,
  renderDailyShipmentPanel:()=>{},dailyShipmentOrdersForSelectedDate:()=>ctx.D.dailyShipmentOrders.filter(r=>r.date==='2026-10-25'),
  compactTikTokStagingQueueFromDailyShipmentState:()=>({removed:0}), saveTikTokLocalState:()=>true,
  localStorage:{setItem:()=>{}},window:{CloudSync:{schedulePush:()=>{}}},dailyShipmentAssignmentIsRecorded:r=>r.status==='recorded'};
vm.createContext(ctx);vm.runInContext(html.slice(a,b),ctx);
const label=t=>({trackingNo:t,carrier:'GHN',orderId:'OID',page:1,products:[{productName:'Cẩm tú mai C7',qty:1}],status:'ready'});
// Main regression: assignmentRequired=true is only a flag. A truly unassigned imported staging row from an older date must move and be markable for the selected employee.
ctx.D.dailyShipmentOrders=[{trackingNo:'VNGH80000000001',source:'pdf_label',status:'imported',date:'2026-10-24',products:[],assignedUid:'',assignmentRequired:true,assignmentStatus:'unassigned'}];
let res=ctx.importParsedLabelsIntoDailyShipments([label('VNGH80000000001')],{uid:'luan'});
assert.equal(res.movedToSelectedDate,1);assert.equal(res.updated,1);assert.equal(ctx.D.dailyShipmentOrders[0].date,'2026-10-25');
let mark=ctx.markDailyShipmentLabelsRequestedForEmployee([label('VNGH80000000001')],{uid:'luan',employeeName:'Luân nhỏ',employeeId:'E1'});
assert.equal(mark.marked,1);assert.equal(ctx.D.dailyShipmentOrders[0].requestedAssigneeUid,'luan');
// Protect anything that has a report/wage/scan; never move or re-record it.
ctx.reports=[{trackingNo:'862600000001',date:'2026-10-24',status:'recorded',wageRecorded:true}];
ctx.D.dailyShipmentOrders=[{trackingNo:'862600000001',source:'pdf_label',status:'imported',date:'2026-10-24',products:[],assignedUid:'',assignmentRequired:true,assignmentStatus:'unassigned'}];
res=ctx.importParsedLabelsIntoDailyShipments([label('862600000001')],{uid:'luan'});
assert.equal(res.movedToSelectedDate,0);assert.equal(res.skippedProtectedRecorded,1);assert.equal(ctx.D.dailyShipmentOrders[0].date,'2026-10-24');
mark=ctx.markDailyShipmentLabelsRequestedForEmployee([label('862600000001')],{uid:'luan',employeeName:'Luân nhỏ',employeeId:'E1'});
assert.equal(mark.marked,0);assert.equal(mark.conflictsRecorded,1);
// Protect active assignments to a different employee and report that as assignment conflict, not an unexplained date mismatch.
ctx.reports=[];ctx.D.dailyShipmentOrders=[{trackingNo:'862600000002',source:'pdf_label',status:'imported',date:'2026-10-24',products:[],assignedUid:'staff2',assignedEmployeeName:'NV khác',assignmentRequired:true,assignmentStatus:'assigned'}];
res=ctx.importParsedLabelsIntoDailyShipments([label('862600000002')],{uid:'luan'});
assert.equal(res.movedToSelectedDate,0);assert.equal(res.skippedProtectedAssigned,1);
mark=ctx.markDailyShipmentLabelsRequestedForEmployee([label('862600000002')],{uid:'luan',employeeName:'Luân nhỏ',employeeId:'E1'});
assert.equal(mark.marked,0);assert.equal(mark.conflictsOtherEmployee,1);
// Fresh tracking IDs still import normally.
ctx.D.dailyShipmentOrders=[];ctx.reports=[];res=ctx.importParsedLabelsIntoDailyShipments([label('VNGH80000000099')],{uid:'luan'});
assert.equal(res.added,1);assert.equal(ctx.D.dailyShipmentOrders[0].date,'2026-10-25');
console.log('V26.2.115 PDF ASSIGNMENT RECOVERY REGRESSION PASS');
