'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const source=fs.readFileSync(require('node:path').join(__dirname,'../app/src/main/assets/gas-firestore-compat.js'),'utf8');
const calls=[];
const context={console,URL,Uint8Array,Math,Date,Map,Set,Promise,JSON,Object,Array,String,Number,Error,setTimeout,clearTimeout,setInterval:()=>1,clearInterval:()=>{},crypto:{getRandomValues(b){b.fill(7);return b;}}};
context.window=context;
context.AndroidBridge={postRollGasApi(id,json){const req=JSON.parse(json);calls.push(req);const docs=(req.paths||[]).map(path=>({path,id:path.split('/').pop(),data:{dailyShipmentStorageSchema:2,ok:true},version:3,updatedAtMs:1234}));context.__rollGasBridgeResponse(id,JSON.stringify({ok:true,data:{documents:docs}}));}};
const auth={currentUser:{async getIdToken(){return 'x'.repeat(200)}}};
const firebase={apps:[{}],auth:()=>auth,firestore:function(){return {}}};
vm.createContext(context);vm.runInContext(source,context);
const db=context.createRollGasFirestoreCompat(firebase,auth,{bridge:context.AndroidBridge,endpoint:'https://script.google.com/macros/s/Abc_123/exec'});
(async()=>{
  const ref=db.collection('apps').doc('roll-cay-canh');
  assert.equal(typeof ref.onSnapshot,'function','GasDocumentReference must expose Firestore-compatible onSnapshot');
  const snap=await new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>reject(new Error('document listener did not emit its initial snapshot')),500);
    const unsubscribe=ref.onSnapshot(value=>{clearTimeout(timer);unsubscribe();resolve(value)},reject);
  });
  assert.equal(snap.exists,true);
  assert.equal(snap.data().dailyShipmentStorageSchema,2);
  assert.equal(calls.filter(x=>x.command==='getMany').length,1,'document listener uses one batched getMany request');
  db._shutdown();
  console.log('GAS DocumentReference onSnapshot initial snapshot + getMany polling: PASS');
})().catch(error=>{console.error(error);process.exitCode=1});
