'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const code = fs.readFileSync(require('node:path').join(__dirname, '../Code.gs'), 'utf8');
function extract(name, nextName) {
  const start = code.indexOf('function ' + name + '(');
  const end = code.indexOf('function ' + nextName + '(', start + 1);
  assert(start >= 0 && end > start, 'Missing helper ' + name);
  return code.slice(start, end);
}
const context = {
  String, Array, Object,
  fsCompatError_: (code, message) => Object.assign(new Error(message), { code }),
  fsCompatCanReadPath_: (actor, path, data) => {
    if (actor.isAdmin) return true;
    if (path.startsWith('packingOrders/')) return !!actor.active && actor.role === 'packer' && data && data.assignedUid === actor.uid;
    if (path.startsWith('dailyShipmentScans/') || path.startsWith('shipmentTrackingClaims/')) return !!actor.active;
    if (path.startsWith('users/')) return !!actor.isAdmin || path === 'users/' + actor.uid;
    return false;
  }
};
vm.createContext(context);
vm.runInContext(
  extract('fsCompatBuildGetManyResponse_', 'fsCompatRequireMigratedAdminProfile_') +
  extract('fsCompatRequireMigratedAdminProfile_', 'fsCompatReadLatestMetadata_'),
  context
);
const packer = { uid: 'staff-1', role: 'packer', active: true, isAdmin: false };
const docs = {
  'packingOrders/order-1': { id: 'order-1', path: 'packingOrders/order-1', data: { assignedUid: 'staff-1' }, version: 8, updatedAtMs: 42 },
  'dailyShipmentScans/ship-1': { id: 'ship-1', path: 'dailyShipmentScans/ship-1', data: { actorUid: 'staff-1' }, version: 3, updatedAtMs: 21 },
  'packingOrders/deleted': { id: 'deleted', path: 'packingOrders/deleted', data: null, deleted: true, version: 9, updatedAtMs: 20 }
};
const rows = context.fsCompatBuildGetManyResponse_(packer,
  ['packingOrders/order-1', 'dailyShipmentScans/ship-1'], docs);
assert.equal(rows[0].version, 8);
assert.equal(rows[1].data.actorUid, 'staff-1');
const tombstone = context.fsCompatBuildGetManyResponse_({uid:'admin-1',role:'admin',active:true,isAdmin:true}, ['packingOrders/deleted'], docs)[0];
assert.equal(tombstone.data, null);
assert.equal(tombstone.version, 9, 'transaction tombstones retain their last version');
assert.throws(() => context.fsCompatBuildGetManyResponse_(packer, ['packingOrders/other'], {
  'packingOrders/other': { id: 'other', path: 'packingOrders/other', data: { assignedUid: 'staff-2' }, version: 1 }
}), e => e.code === 'PERMISSION_DENIED', 'packer must not read another employee order');
assert.throws(() => context.fsCompatBuildGetManyResponse_(packer, ['users/staff-2'], {}),
  e => e.code === 'PERMISSION_DENIED', 'packer must not bulk-read another user profile');
const admin = { uid: 'admin-1', isAdmin: true, role: 'admin', active: true };
assert.equal(context.fsCompatBuildGetManyResponse_(admin, ['users/staff-2'], {})[0], null);
assert.equal(context.fsCompatRequireMigratedAdminProfile_({'users/admin-1': {deleted: false}}, 'admin-1', []), true);
assert.equal(context.fsCompatRequireMigratedAdminProfile_({}, 'bootstrap-admin', ['bootstrap-admin']), true);
assert.throws(() => context.fsCompatRequireMigratedAdminProfile_({}, 'unknown-admin', []),
  e => e.code === 'FAILED_PRECONDITION');
assert.throws(() => context.fsCompatRequireMigratedAdminProfile_({'users/admin-1': {deleted: true}}, 'admin-1', []),
  e => e.code === 'FAILED_PRECONDITION');
assert(!/finalIndex\[['"]users\//.test(code), 'Migration finalization must not reference undefined finalIndex');
console.log('GAS transaction read authorization + migration finalization regression checks: PASS');
