'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
const a=html.indexOf('function localSaveOnly(){'),b=html.indexOf('\nasync function ensureImageUploadedToDrive',a);
assert(a>=0&&b>a,'localSaveOnly must exist');
const store=new Map();const quota=1300;const used=()=>[...store].reduce((n,[k,v])=>n+k.length+String(v).length,0);
const localStorage={get length(){return store.size},key(i){return [...store.keys()][i]||null},getItem(k){return store.has(k)?store.get(k):null},removeItem(k){store.delete(k)},setItem(k,v){k=String(k);v=String(v);const old=store.get(k);if(used()-(old==null?0:old.length)+k.length+v.length>quota){const e=new Error('quota');e.name='QuotaExceededError';throw e}store.set(k,v)}};
store.set('roll_tiktok_label_queue_v1','X'.repeat(900));store.set('roll_tiktok_product_maps_v1','{}');
const notices=[];const ctx={D:{catalog:[{name:'Cây'}],daily:[],dailyShipmentOrders:[{trackingNo:'A',status:'recorded'}],dailyShipmentReports:[{trackingNo:'A',status:'recorded'}]},invalidateInventoryIndexes(){},console,JSON,Date,String,Math,Number,Array,Object,Promise,TextEncoder,localStorage,toast:x=>notices.push(x),localStorageDiagnostics:()=>({keys:[]}),window:{DriveStorage:{connected:()=>true,toLocalCacheValue:v=>v}},tiktokLabelQueue:[{trackingNo:'A'}],compactTikTokStagingQueueFromDailyShipmentState(){this.tiktokLabelQueue=[];return {removed:1}},saveTikTokLocalState(){localStorage.setItem('roll_tiktok_label_queue_v1','[]');return true}};
ctx.window.DriveStorage.toLocalCacheValue=v=>v;
vm.createContext(ctx);vm.runInContext(html.slice(a,b)+';this.runSave=localSaveOnly;',ctx);
// A quota failure must trigger safe compaction and retry, rather than silently abandoning the write.
assert.strictEqual(ctx.runSave(),true,'main cache should save after redundant staging cache is compacted');
assert(store.has('quanlycay'),'main cache was not persisted after recovery');
assert(JSON.parse(store.get('quanlycay')).dailyShipmentOrders.length===1,'canonical shipment records must remain intact');
assert(!store.get('quanlycay').includes('data:image/'),'no image Base64 should be persisted in the main cache');
console.log('LOCAL STORAGE QUOTA RECOVERY PASS: safe staging compaction, one retry, canonical order preservation');
