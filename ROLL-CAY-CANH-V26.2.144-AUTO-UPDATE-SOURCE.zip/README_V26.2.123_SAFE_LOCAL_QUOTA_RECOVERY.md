# ROLL CÂY CẢNH V26.2.123 — Safe local quota recovery

- Base: V26.2.122 source archive, preserving app model, Firebase config, Firestore schema/rules, catalog, payroll, inventory, PDF recognition, scan flows, Drive integration and signing workflow.
- Version: `26.2.123`, versionCode `175`.
- Main fix: on a `localStorage` quota error, attempt one safe compaction of the *redundant TikTok PDF staging cache only*, where already-resolved labels are still represented in canonical daily-shipment records/reports, then retry the main cache write once.
- Data safety: does not delete canonical daily shipment orders/reports, payroll, inventory, employee data, photos, plant mappings, recognition rules, or the recovery backup. If retry still fails, preserve the last known-good `quanlycay` cache and report that the write did not succeed.
- Diagnostic: quota failure logs only the top storage keys and byte sizes, never order payloads or photos.
- Release metadata: updated the HTML `app-version` meta tag and Gradle version metadata together to avoid stale source labels.

## Validation performed

- `python tools/preflight.py`: PASS.
- JavaScript regression tests: 106/106 PASS (105 existing tests plus `local_storage_quota_recovery_test.js`).
- ZIP integrity: checked after packaging.
- Android Gradle build: NOT run in this environment (no Gradle wrapper or installed Gradle).
- Live Android WebView / Firebase / Google Drive test: NOT run. The fix is guarded to preserve data, but cannot be called fully production-verified until built and tested on a device under quota pressure.

## Important limitation

This patch is a safe recovery pass, not a guarantee that arbitrary `localStorage` exhaustion can be resolved. If the canonical main state itself exceeds the WebView quota after redundant staging is compacted, it intentionally keeps the last known-good cache and refuses to delete operational data. A durable IndexedDB-backed primary store is a separate architectural migration and must be designed with startup hydration, crash recovery, and rollback tests before replacing the current synchronous cache.
