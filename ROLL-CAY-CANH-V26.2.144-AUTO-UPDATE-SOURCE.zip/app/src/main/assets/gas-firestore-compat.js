/*
 * ROLL CÂY CẢNH — Firestore-compatible client shim for the GAS/Sheets backend.
 * Deliberately not auto-enabled. Install into the Android asset directory and turn on
 * ROLL_GAS_BACKEND_ENABLED only after the Firestore export is verified and GAS is deployed.
 */
(function (global) {
  'use strict';

  class GasTimestamp {
    constructor(milliseconds) {
      this._ms = Number(milliseconds) || 0;
      this.seconds = Math.floor(this._ms / 1000);
      this.nanoseconds = Math.floor((this._ms - this.seconds * 1000) * 1000000);
    }
    toDate() { return new Date(this._ms); }
    toMillis() { return this._ms; }
    isEqual(other) { return !!other && typeof other.toMillis === 'function' && other.toMillis() === this._ms; }
    valueOf() { return String(this._ms).padStart(16, '0'); }
    toJSON() { return { __gasTimestampMs: this._ms }; }
    static now() { return new GasTimestamp(Date.now()); }
    static fromDate(date) { return new GasTimestamp(date instanceof Date ? date.getTime() : Date.now()); }
  }

  function isPlainObject(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value) && !(value instanceof Date) && !(value instanceof GasTimestamp);
  }
  function clone(value) {
    if (value === undefined) return undefined;
    if (value instanceof GasTimestamp) return new GasTimestamp(value.toMillis());
    if (value instanceof Date) return new Date(value.getTime());
    if (Array.isArray(value)) return value.map(clone);
    if (isPlainObject(value)) { const out = {}; Object.keys(value).forEach(k => { if (value[k] !== undefined) out[k] = clone(value[k]); }); return out; }
    return value;
  }
  function revive(value) {
    if (Array.isArray(value)) return value.map(revive);
    if (isPlainObject(value)) {
      if (Object.prototype.hasOwnProperty.call(value, '__gasTimestampMs')) return new GasTimestamp(value.__gasTimestampMs);
      const out = {}; Object.keys(value).forEach(k => { out[k] = revive(value[k]); }); return out;
    }
    return value;
  }
  function encode(value) {
    if (value instanceof GasTimestamp) return { __gasTimestampMs: value.toMillis() };
    if (value instanceof Date) return { __gasTimestampMs: value.getTime() };
    if (Array.isArray(value)) return value.map(encode);
    if (isPlainObject(value)) {
      if (value.__gasFieldOp) return { __gasFieldOp: value.__gasFieldOp };
      if (Object.prototype.hasOwnProperty.call(value, '__gasTimestampMs')) return { __gasTimestampMs: Number(value.__gasTimestampMs) };
      const out = {}; Object.keys(value).forEach(k => { if (value[k] !== undefined) out[k] = encode(value[k]); }); return out;
    }
    return value;
  }
  function normalizeError(raw) {
    const error = new Error(raw && raw.message ? String(raw.message) : 'GAS backend request failed');
    const code = String(raw && raw.code || 'internal').toLowerCase().replace(/_/g, '-');
    error.code = code.startsWith('firestore/') ? code : 'firestore/' + code;
    return error;
  }
  function makeFieldPath(args) {
    const segments = Array.prototype.slice.call(args).map(String);
    if (!segments.length || segments.some(s => !s)) throw new Error('Invalid FieldPath');
    return { __gasFieldPath: true, segments: segments };
  }
  function pathSegments(path) {
    if (path && path.__gasFieldPath) return path.segments.slice();
    if (path === '__name__') return ['__name__'];
    return String(path).split('.');
  }
  function fieldPathForRequest(path) { return path && path.__gasFieldPath ? path.segments.slice() : String(path) === '__name__' ? ['__name__'] : String(path).split('.'); }
  function getLocalField(data, path, id) {
    const parts = pathSegments(path);
    if (parts.length === 1 && parts[0] === '__name__') return id;
    let value = data;
    for (const part of parts) { if (value == null) return undefined; value = value[part]; }
    return value;
  }
  function randomId() {
    const bytes = new Uint8Array(20);
    if (global.crypto && typeof global.crypto.getRandomValues === 'function') global.crypto.getRandomValues(bytes);
    else for (let i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
    return Array.from(bytes, b => (b % 36).toString(36)).join('').slice(0, 20);
  }
  function canonical(value) {
    if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
    if (value && typeof value === 'object') {
      if (typeof value.toMillis === 'function') return 'timestamp:' + value.toMillis();
      const keys = Object.keys(value).sort();
      return '{' + keys.map(k => JSON.stringify(k) + ':' + canonical(value[k])).join(',') + '}';
    }
    return JSON.stringify(value);
  }

  class GasDocumentSnapshot {
    constructor(ref, raw) {
      this.ref = ref;
      this.id = ref.id;
      this.exists = !!(raw && raw.exists !== false && raw.data != null);
      this._data = this.exists ? revive(raw.data) : undefined;
      this._version = this.exists ? Number(raw.version || 0) : Number(raw && raw.version || 0);
      this.metadata = { fromCache: false, hasPendingWrites: false };
      this.updateTime = this.exists && raw.updatedAtMs ? new GasTimestamp(raw.updatedAtMs) : null;
      this.createTime = this.updateTime;
    }
    data() { return this.exists ? clone(this._data) : undefined; }
    get(fieldPath) { return this.exists ? clone(getLocalField(this._data, fieldPath, this.id)) : undefined; }
    isEqual(other) { return !!other && other.ref && other.ref.path === this.ref.path && other._version === this._version; }
  }
  class GasQuerySnapshot {
    constructor(query, docs, changes) {
      this.query = query;
      this.docs = docs || [];
      this.size = this.docs.length;
      this.empty = this.size === 0;
      this.metadata = { fromCache: false, hasPendingWrites: false };
      this._changes = changes || null;
    }
    forEach(callback, thisArg) { this.docs.forEach(callback, thisArg); }
    docChanges() {
      if (this._changes) return this._changes;
      return this.docs.map(doc => ({ type: 'added', doc, oldIndex: -1, newIndex: this.docs.indexOf(doc) }));
    }
    isEqual(other) { return !!other && canonical(this.docs.map(d => [d.id, d._version])) === canonical(other.docs.map(d => [d.id, d._version])); }
  }

  function createRollGasFirestoreCompat(firebase, auth, options) {
    options = options || {};
    if (!firebase || !auth) throw new Error('Firebase Auth must be initialized before the GAS adapter');
    const bridge = options.bridge || global.AndroidBridge;
    const endpoint = String(options.endpoint || 'https://script.google.com/macros/s/AKfycbyUJaEPNEb5v45Ew0Fjk9Mh17JWtZ9j8V7Ai4QaMW4xe349nSUq5C7mhjhuqRsxzhPD/exec');
    if (!/^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(endpoint)) throw new Error('GAS endpoint must be a deployed Apps Script /exec URL');
    let nextRequestId = 1;
    const pending = new Map();
    const activeWatchers = new Set();
    const activeDocumentWatchers = new Set();
    let watcherTimer = null;
    let watcherPollInFlight = false;
    const adapterState = { active: true, endpoint: endpoint };
    global.__rollGasCompatPending = pending;
    global.__rollGasBridgeResponse = function (requestId, responseText) {
      const item = pending.get(String(requestId));
      if (!item) return;
      pending.delete(String(requestId));
      if (item.timer) global.clearTimeout(item.timer);
      let parsed;
      try { parsed = typeof responseText === 'string' ? JSON.parse(responseText) : responseText; }
      catch (_) { item.reject(new Error('The GAS backend returned invalid JSON')); return; }
      if (!parsed || parsed.ok !== true) { item.reject(normalizeError(parsed && parsed.error)); return; }
      item.resolve(parsed.data);
    };

    async function request(command, payload) {
      if (!adapterState.active) throw new Error('GAS adapter has been closed');
      if (!bridge || typeof bridge.postRollGasApi !== 'function') throw new Error('GAS backend requires the updated AndroidBridge in the Android app');
      const user = auth.currentUser;
      if (!user || typeof user.getIdToken !== 'function') throw normalizeError({ code: 'UNAUTHENTICATED', message: 'Please sign in again' });
      const idToken = await user.getIdToken(false);
      const requestId = 'r' + (nextRequestId++) + '_' + Date.now().toString(36);
      const requestBody = Object.assign({ action: 'fsCompat', command: command, idToken: idToken }, payload || {});
      return new Promise((resolve, reject) => {
        const timeoutMs = command === 'commit' || command === 'importBatch' || command === 'finalizeMigration' ? 65000 : 45000;
        const timer = global.setTimeout(() => {
          const item = pending.get(requestId);
          if (!item) return;
          pending.delete(requestId);
          const error = new Error('Quá ' + Math.round(timeoutMs / 1000) + ' giây chờ Google Sheets xử lý yêu cầu ' + command + '. Dữ liệu chưa được xác nhận ghi; hãy thử đồng bộ lại khi mạng ổn định.');
          error.code = 'firestore/deadline-exceeded';
          reject(error);
        }, timeoutMs);
        pending.set(requestId, { resolve, reject, timer });
        try { bridge.postRollGasApi(requestId, JSON.stringify(encode(requestBody))); }
        catch (error) { pending.delete(requestId); global.clearTimeout(timer); reject(error); }
      });
    }

    function makeSnapshot(ref, raw) { return new GasDocumentSnapshot(ref, raw); }
    function randomOpId() { return 'gas_' + Date.now().toString(36) + '_' + randomId(); }

    function querySpec(query) {
      return { collectionPath: query._collectionPath, filters: query._filters, orderBy: query._orders, limit: query._limit };
    }
    function notifyWatcherError(watcher, err) {
      if (watcher.closed) return;
      if (typeof watcher.error === 'function') {
        try { watcher.error(err); } catch (callbackError) { if (global.console && console.error) console.error(callbackError); }
      }
      const code = String(err && err.code || '').toLowerCase();
      if (code.indexOf('permission-denied') >= 0 || code.indexOf('unauthenticated') >= 0 || code.indexOf('invalid-argument') >= 0) {
        watcher.closed = true;
        activeWatchers.delete(watcher);
        activeDocumentWatchers.delete(watcher);
      }
    }
    function applyWatcherSnapshot(watcher, raw) {
      if (watcher.closed) return;
      const docs = (raw && raw.documents || []).map(item => makeSnapshot(new GasDocumentReference(item.path), {
        exists: true, data: item.data, version: item.version, updatedAtMs: item.updatedAtMs
      }));
      const currentMap = new Map(docs.map(doc => [doc.id, doc]));
      const changes = [];
      docs.forEach((doc, newIndex) => {
        const prior = watcher.oldMap.get(doc.id);
        if (!prior) changes.push({ type: 'added', doc: doc, oldIndex: -1, newIndex: newIndex });
        else if (prior._version !== doc._version || canonical(prior.data()) !== canonical(doc.data())) {
          changes.push({ type: 'modified', doc: doc, oldIndex: Array.from(watcher.oldMap.keys()).indexOf(doc.id), newIndex: newIndex });
        } else {
          const oldIndex = Array.from(watcher.oldMap.keys()).indexOf(doc.id);
          if (oldIndex !== newIndex) changes.push({ type: 'modified', doc: doc, oldIndex: oldIndex, newIndex: newIndex });
        }
      });
      watcher.oldMap.forEach((doc, id) => {
        if (!currentMap.has(id)) changes.push({ type: 'removed', doc: doc, oldIndex: Array.from(watcher.oldMap.keys()).indexOf(id), newIndex: -1 });
      });
      const currentCanonical = canonical(docs.map(doc => [doc.id, doc._version, doc.data()]));
      if (watcher.first || currentCanonical !== watcher.oldCanonical) {
        watcher.first = false;
        watcher.oldMap = currentMap;
        watcher.oldCanonical = currentCanonical;
        try { watcher.next(new GasQuerySnapshot(watcher.query, docs, changes)); }
        catch (callbackError) { if (global.console && console.error) console.error(callbackError); }
      }
    }
    function ensureWatcherTimer() {
      if (watcherTimer !== null) return;
      const requested = Number(options.snapshotPollMs) > 0 ? Number(options.snapshotPollMs) : 12000;
      watcherTimer = global.setInterval(pollAllWatchers, Math.max(8000, Math.min(60000, requested)));
    }
    function closeWatcherTimerIfIdle() {
      if (activeWatchers.size === 0 && activeDocumentWatchers.size === 0 && watcherTimer !== null && !watcherPollInFlight) {
        global.clearInterval(watcherTimer); watcherTimer = null;
      }
    }
    async function pollDocumentWatchers() {
      const list = Array.from(activeDocumentWatchers).filter(w => !w.closed);
      for (let start = 0; start < list.length; start += 100) {
        const chunk = list.slice(start, start + 100);
        try {
          const raw = await request('getMany', { paths: chunk.map(w => w.ref.path) });
          const docs = raw && Array.isArray(raw.documents) ? raw.documents : [];
          if (docs.length !== chunk.length) throw new Error('GAS getMany returned an incomplete document-listener read set');
          chunk.forEach((watcher, index) => {
            if (watcher.closed) return;
            const item = docs[index] || null;
            const snapshot = new GasDocumentSnapshot(watcher.ref, item && item.data != null
              ? { exists: true, data: item.data, version: item.version, updatedAtMs: item.updatedAtMs }
              : { exists: false, version: item && item.version || 0 });
            const signature = canonical([snapshot.exists, snapshot._version, snapshot.data()]);
            if (watcher.first || signature !== watcher.lastSignature) {
              watcher.first = false; watcher.lastSignature = signature;
              try { watcher.next(snapshot); }
              catch (callbackError) { if (global.console && console.error) console.error(callbackError); }
            }
          });
        } catch (err) { chunk.forEach(watcher => notifyWatcherError(watcher, err)); }
      }
    }
    async function pollAllWatchers() {
      if (watcherPollInFlight || (activeWatchers.size === 0 && activeDocumentWatchers.size === 0)) return;
      watcherPollInFlight = true;
      try {
        const list = Array.from(activeWatchers).filter(w => !w.closed);
        for (let start = 0; start < list.length; start += 25) {
          const chunk = list.slice(start, start + 25);
          try {
            const raw = await request('multiQuery', { queries: chunk.map(w => querySpec(w.query)) });
            const snapshots = raw && raw.snapshots || [];
            chunk.forEach((watcher, index) => applyWatcherSnapshot(watcher, snapshots[index]));
          } catch (err) { chunk.forEach(watcher => notifyWatcherError(watcher, err)); }
        }
        if (activeDocumentWatchers.size) await pollDocumentWatchers();
      } finally { watcherPollInFlight = false; closeWatcherTimerIfIdle(); }
    }
    function addWatcher(watcher) { activeWatchers.add(watcher); ensureWatcherTimer(); pollAllWatchers(); }
    function addDocumentWatcher(watcher) { activeDocumentWatchers.add(watcher); ensureWatcherTimer(); pollAllWatchers(); }
    function isRef(obj) { return obj instanceof GasDocumentReference; }

    class GasDocumentReference {
      constructor(path) { this.path = normalizePath(path, true); this.id = this.path.split('/').pop(); this.firestore = db; this.parent = new GasCollectionReference(this.path.split('/').slice(0, -1).join('/')); }
      collection(name) { return new GasCollectionReference(this.path + '/' + normalizeSegment(name)); }
      async get() { const raw = await request('get', { path: this.path }); const doc = raw && raw.document; return makeSnapshot(this, doc ? { exists: true, data: doc.data, version: doc.version, updatedAtMs: doc.updatedAtMs } : { exists: false, version: raw && raw.version || 0 }); }
      onSnapshot(next, error) {
        if (typeof next !== 'function') throw new Error('onSnapshot requires a callback');
        const watcher = { ref: this, next: next, error: error, closed: false, first: true, lastSignature: '' };
        addDocumentWatcher(watcher);
        return () => { watcher.closed = true; activeDocumentWatchers.delete(watcher); closeWatcherTimerIfIdle(); };
      }
      async set(data, optionsArg) { const opts = optionsArg || {}; return commitWrites([{ type: 'set', path: this.path, data: encode(data), merge: !!opts.merge }]); }
      async update() { return commitWrites([makeUpdateWrite(this.path, arguments)]); }
      async delete() { return commitWrites([{ type: 'delete', path: this.path }]); }
      isEqual(other) { return !!other && other.path === this.path; }
      toString() { return 'gasfirestore:///' + this.path; }
    }
    class GasQuery {
      constructor(collectionPath, filters, orders, maxResults) { this._collectionPath = normalizePath(collectionPath, false); this._filters = filters || []; this._orders = orders || []; this._limit = maxResults == null ? null : Number(maxResults); }
      where(field, op, value) {
        const allowed = ['==','!=','<','<=','>','>=','in','not-in','array-contains','array-contains-any'];
        if (allowed.indexOf(op) < 0) throw new Error('Unsupported where operator: ' + op);
        if (['in','not-in','array-contains-any'].indexOf(op) >= 0 && (!Array.isArray(value) || !value.length || value.length > 30)) throw new Error('The value for ' + op + ' must be an array of 1–30 items');
        const next = this._filters.concat([{ fieldPath: fieldPathForRequest(field), op: op, value: encode(value) }]);
        return new GasQuery(this._collectionPath, next, this._orders.slice(), this._limit);
      }
      orderBy(field, direction) {
        direction = direction || 'asc'; if (direction !== 'asc' && direction !== 'desc') throw new Error('Invalid orderBy direction');
        return new GasQuery(this._collectionPath, this._filters.slice(), this._orders.concat([{fieldPath:fieldPathForRequest(field),direction:direction}]), this._limit);
      }
      limit(count) { count = Number(count); if (!Number.isInteger(count) || count < 0) throw new Error('limit() expects a non-negative integer'); return new GasQuery(this._collectionPath,this._filters.slice(),this._orders.slice(),count); }
      async get() {
        const raw = await request('query', { collectionPath:this._collectionPath, filters:this._filters, orderBy:this._orders, limit:this._limit });
        const docs = (raw && raw.documents || []).map(item => makeSnapshot(new GasDocumentReference(item.path), {exists:true,data:item.data,version:item.version,updatedAtMs:item.updatedAtMs}));
        return new GasQuerySnapshot(this, docs);
      }
      onSnapshot(next, error) {
        if (typeof next !== 'function') throw new Error('onSnapshot requires a callback');
        const watcher = { query: this, next: next, error: error, closed: false, first: true, oldMap: new Map(), oldCanonical: '' };
        addWatcher(watcher);
        return () => {
          watcher.closed = true;
          activeWatchers.delete(watcher);
          if (activeWatchers.size === 0 && watcherTimer !== null && !watcherPollInFlight) {
            global.clearInterval(watcherTimer);
            watcherTimer = null;
          }
        };
      }
    }
    class GasCollectionReference extends GasQuery {
      constructor(path) { super(path, [], [], null); this.id = this._collectionPath.split('/').pop(); this.path = this._collectionPath; this.parent = this._collectionPath.includes('/') ? new GasDocumentReference(this._collectionPath.split('/').slice(0, -1).join('/')) : null; }
      doc(id) { return new GasDocumentReference(this.path + '/' + (id == null ? randomId() : normalizeSegment(id))); }
      async add(data) { const ref = this.doc(); await ref.set(data); return ref; }
      isEqual(other) { return !!other && other.path === this.path; }
    }
    class GasWriteBatch {
      constructor() { this._writes=[]; this._committed=false; }
      _append(write) { if(this._committed)throw new Error('This batch has already been committed'); if(this._writes.length>=500)throw new Error('A WriteBatch may contain at most 500 writes'); this._writes.push(write); return this; }
      set(ref,data,opts) { requireRef(ref); return this._append({type:'set',path:ref.path,data:encode(data),merge:!!(opts&&opts.merge)}); }
      update(ref) { requireRef(ref); return this._append(makeUpdateWrite(ref.path,Array.prototype.slice.call(arguments,1))); }
      delete(ref) { requireRef(ref); return this._append({type:'delete',path:ref.path}); }
      async commit() { if(this._committed)throw new Error('This batch has already been committed'); this._committed=true; return commitWrites(this._writes); }
    }
    class GasTransaction {
      constructor() {
        this._preconditions = new Map();
        this._writes = [];
        this._wrote = false;
        this._pendingReads = [];
        this._readCache = new Map();
        this._readFlushScheduled = false;
      }
      get(ref) {
        if(this._wrote)return Promise.reject(new Error('Firestore transactions must read documents before writing'));
        if(ref instanceof GasQuery && !(ref instanceof GasDocumentReference))return Promise.reject(new Error('GAS compatibility transactions currently support document reads only; query reads are intentionally rejected to avoid phantom-write races'));
        try { requireRef(ref); } catch(error) { return Promise.reject(error); }
        if(this._readCache.has(ref.path))return this._readCache.get(ref.path).then(snapshot=>snapshot);
        const promise=new Promise((resolve,reject)=>{
          this._pendingReads.push({ref,resolve,reject});
          if(!this._readFlushScheduled){
            this._readFlushScheduled=true;
            Promise.resolve().then(()=>this._flushPendingReads());
          }
        });
        this._readCache.set(ref.path,promise);
        return promise;
      }
      async _flushPendingReads() {
        this._readFlushScheduled=false;
        if(!this._pendingReads.length)return;
        const pendingReads=this._pendingReads.splice(0);
        // Firestore transactions commonly call Promise.all(refs.map(tx.get)). Send
        // those reads as one getMany request (max 100 refs) instead of one HTTP/GAS
        // round trip per document. This is critical for multi-order assignment/scans.
        for(let start=0;start<pendingReads.length;start+=100){
          const chunk=pendingReads.slice(start,start+100);
          try{
            const raw=await request('getMany',{paths:chunk.map(item=>item.ref.path)});
            const docs=raw&&Array.isArray(raw.documents)?raw.documents:[];
            if(docs.length!==chunk.length)throw new Error('GAS getMany returned an incomplete transaction read set');
            chunk.forEach((item,index)=>{
              const doc=docs[index]||null;
              const version=Number(doc&&doc.version||0);
              this._preconditions.set(item.ref.path,version);
              item.resolve(makeSnapshot(item.ref,doc?{exists:doc.data!=null,data:doc.data,version:version,updatedAtMs:doc.updatedAtMs}:{exists:false,version:0}));
            });
          }catch(error){chunk.forEach(item=>item.reject(error));}
        }
      }
      set(ref,data,opts) { requireRef(ref);this._wrote=true;this._writes.push({type:'set',path:ref.path,data:encode(data),merge:!!(opts&&opts.merge)});return this; }
      update(ref) { requireRef(ref);this._wrote=true;this._writes.push(makeUpdateWrite(ref.path,Array.prototype.slice.call(arguments,1)));return this; }
      delete(ref) { requireRef(ref);this._wrote=true;this._writes.push({type:'delete',path:ref.path});return this; }
    }
    function requireRef(ref) { if (!(ref instanceof GasDocumentReference)) throw new Error('Expected a document reference from the GAS adapter'); }
    function makeUpdateWrite(path, argsLike) {
      const args=Array.prototype.slice.call(argsLike);let patches=[];
      if(args.length===1&&isPlainObject(args[0])) {
        Object.keys(args[0]).forEach(k=>patches.push({fieldPath:k.split('.'),value:encode(args[0][k])}));
      } else {
        if(args.length===0||args.length%2!==0)throw new Error('update() must receive a map or field/value pairs');
        for(let i=0;i<args.length;i+=2)patches.push({fieldPath:fieldPathForRequest(args[i]),value:encode(args[i+1])});
      }
      return {type:'update',path:path,patches:patches};
    }
    function normalizeSegment(value) { const v=String(value);if(!v||v.indexOf('/')>=0||v.length>1500)throw new Error('Invalid document or collection ID');return v; }
    function normalizePath(path, isDocument) {
      const p=String(path||'').replace(/^\/+|\/+$/g,'');const seg=p.split('/');
      if(!p||seg.some(s=>!s)||p.length>1500||(isDocument?seg.length%2!==0:seg.length%2!==1))throw new Error('Invalid Firestore path: '+p);
      return p;
    }
    async function commitWrites(writes, preconditions) {
      if (!writes || !writes.length) return { committed: true, writes: 0 };
      return request('commit', { operationId:randomOpId(), writes:writes, preconditions:(preconditions||[]).map(p=>({path:p.path,version:p.version})) });
    }
    const db = {
      collection: path => new GasCollectionReference(path),
      doc: path => new GasDocumentReference(path),
      batch: () => new GasWriteBatch(),
      async _importLegacyBatch(documents, operationId, overwrite) {
        if (!Array.isArray(documents) || !documents.length || documents.length > 100) throw new Error('Migration batches must contain 1–100 documents');
        return request('importBatch', { documents:documents.map(d=>({path:d.path,data:encode(d.data)})), operationId:String(operationId||randomOpId()), overwrite:overwrite===true });
      },
      async _getManyCompat(paths) {
        if (!Array.isArray(paths) || paths.length > 100) throw new Error('getMany supports at most 100 document paths');
        const raw=await request('getMany',{paths:paths}); return (raw&&raw.documents||[]).map(doc=>doc?{path:doc.path,id:doc.id,data:revive(doc.data),version:doc.version}:null);
      },
      async _listUsersCompat() {
        const raw=await request('listUsers',{});
        const docs=(raw&&raw.documents||[]).map(item=>makeSnapshot(new GasDocumentReference(item.path),{exists:true,data:item.data,version:item.version,updatedAtMs:item.updatedAtMs}));
        return {docs:docs,size:docs.length,empty:docs.length===0,diagnostics:raw&&raw.diagnostics||null};
      },
      async runTransaction(updateFunction, transactionOptions) {
        if(typeof updateFunction!=='function')throw new Error('runTransaction requires a callback');
        const attempts = Math.max(1,Math.min(8,Number(transactionOptions&&transactionOptions.maxAttempts)||5));
        let lastError;
        for(let attempt=0;attempt<attempts;attempt++){
          const tx=new GasTransaction();
          try {
            const result=await updateFunction(tx);
            if(tx._writes.length){const preconditions=Array.from(tx._preconditions.entries()).map(([path,version])=>({path,version}));await commitWrites(tx._writes,preconditions);}
            return result;
          } catch(error) {
            lastError=error;
            const code=String(error&&error.code||'').toLowerCase();
            if((code==='firestore/aborted'||code==='aborted')&&attempt+1<attempts)continue;
            throw error;
          }
        }
        throw lastError||new Error('Transaction failed');
      },
      async _health() { return request('health', {}); },
      async _finalizeMigration(report) { return request('finalizeMigration', {report: report || {}}); },
      _gasCompat: true,
      _shutdown() { adapterState.active=false; pending.forEach(p=>{if(p.timer)global.clearTimeout(p.timer);p.reject(new Error('Adapter shutdown'));}); pending.clear(); activeWatchers.forEach(w=>{w.closed=true;}); activeWatchers.clear(); activeDocumentWatchers.forEach(w=>{w.closed=true;}); activeDocumentWatchers.clear(); if(watcherTimer!==null){global.clearInterval(watcherTimer);watcherTimer=null;} }
    };
    // Make the SDK namespace expose this adapter's sentinels while preserving Firebase Auth.
    function FieldPath() { const path=makeFieldPath(arguments); this.segments=path.segments; this.__gasFieldPath=true; }
    FieldPath.documentId = () => makeFieldPath(['__name__']);
    const fieldValue = {
      serverTimestamp: () => ({__gasFieldOp:'serverTimestamp'}),
      delete: () => ({__gasFieldOp:'delete'})
    };
    const fieldPathNamespace = FieldPath;
    function firestoreFactory() { return db; }
    firestoreFactory.FieldValue = fieldValue;
    firestoreFactory.FieldPath = fieldPathNamespace;
    firestoreFactory.Timestamp = GasTimestamp;
    firestoreFactory._gasCompat = true;
    firebase.firestore = firestoreFactory;
    return db;
  }

  createRollGasFirestoreCompat.Timestamp = GasTimestamp;
  global.createRollGasFirestoreCompat = createRollGasFirestoreCompat;
})(window);
