# ROLL CÂY CẢNH V26.2.133 — GAS migration validation

## Automated checks run in this environment
- ZIP extraction/integrity: PASS
- `node --check app/src/main/assets/gas-firestore-compat.js`: PASS
- `node --check app/src/main/assets/gas-firestore-migration.js`: PASS
- Existing JavaScript regression tests: 114/114 PASS

## What this proves
These checks validate JavaScript syntax and the existing local regression tests. They do not prove that the deployed Apps Script has every compatible action, that migration succeeds against the user's live Firestore/Sheets, or that an Android APK was built and tested on a device.

## Current migration gates
- `window.ROLL_GAS_BACKEND_ENABLED` remains `false` by design.
- Do not enable `ROLL_GAS_COMPAT_WRITES_ENABLED` until the server-side import/commit/query actions have been verified against the deployed Apps Script and security checks.
- Firestore remains the source of truth. Migration is additive and should not delete or mutate source documents.
- Adapter transaction query reads are unsupported. Business operations that use query reads inside `runTransaction` must be redesigned safely or remain on Firestore until reviewed.
- The Android APK build was not run in this environment because the Android SDK/Gradle toolchain is unavailable.

## Required live validation before cutover
1. Confirm deployed GAS has `fsCompat` dispatch and implements `health`, `get`, `query`, `multiQuery`, `getMany`, `commit`, and `importBatch` with admin authorization for bulk import and server-side role checks for all other operations.
2. Test the migration with admin account on a staging/test dataset first; verify document counts and the migration checksum. Do not import over existing rows unless overwrite behavior has been reviewed.
3. Test the app's real transactions for duplicate shipment scans, order completion, assignment, payroll, inventory, and photo metadata.
4. Build the APK using the repository's GitHub Actions workflow and smoke-test on an Android device.
5. Only after successful verification, make a separate reviewed change to switch reads/writes to GAS. Keep Firestore backup/rollback available.

## Version facts
- Android versionName: 26.2.133
- Android versionCode: 185
- This is a migration-preparation source, not a completed backend cutover.
