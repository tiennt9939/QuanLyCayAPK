# ROLL CÂY CẢNH V26.2.135 — GAS migration/cutover

- Android version: 26.2.135; versionCode 187.
- The reported `A different document already exists in GAS: apps/roll-cay-canh` is handled by the admin migration using `overwrite:true`.
- Code.gs snapshots any conflicting target document to `fsCompatMigrationBackup` before replacement. The backup is chunked and retained; if backup fails the conflicting document is not overwritten.
- Firestore is kept unchanged. Every source document is copied and read back for value verification before server-side cutover. Business writes remain gated until finalization.
- Deploy the bundled Code.gs as a new version of the existing Apps Script Web App at the same URL. Keep all existing Script Properties and set `ROLL_GAS_COMPAT_WRITES_ENABLED=false` until migration; the admin-only `importBatch` path is separately allowed.
- Upload `ROLL-CAY-CANH-V26.2.135-AUTO-UPDATE-SOURCE.zip` to repository root on branch `main`. GitHub Actions is configured to build source ZIPs with this filename pattern.
- Install the resulting version 26.2.135/code 187 APK, log in as the admin, pause employee scanning/order entry, then run `Chuyển sang GAS (sao chép + đối chiếu)` once. Wait for the final verified count/checksum and automatic reload.
- Do not manually set `ROLL_GAS_CUTOVER_COMPLETED` or delete the backup tab. If migration fails, Firestore remains intact and the message in the app should guide diagnosis.
