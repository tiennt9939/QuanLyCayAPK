# ROLL CÂY CẢNH V26.2.135 — GAS auto-cutover

- Android version: 26.2.135 (versionCode 186).
- Firestore remains the read source only until an administrator runs the one-time copy from the admin Cloud screen.
- GAS migration writes are admin-only and allowed while normal business writes are disabled.
- Every copied document is read back in batches and compared with the Firestore source.
- When every document matches and the required app root exists, the server atomically records the migration report and enables the GAS business-write gate.
- On the next load, the app checks authenticated server health and routes business reads/writes to GAS. If the health check fails, it blocks sync rather than silently falling back to Firestore.
- Firestore source records are never deleted or modified by this migration.

## Deployment
1. Replace the Apps Script project `Code.gs` with the bundled `Code.gs` and deploy a new Web App version at the existing URL. Keep the existing Script Properties. Leave `ROLL_GAS_COMPAT_WRITES_ENABLED=false`; the migration route is separately admin-gated.
2. Build/install this Android source. Sign in as the configured administrator. Stop staff order entry/scanning during migration.
3. Open Cloud Sync and choose **Chuyển sang GAS (sao chép + đối chiếu)**. The app first pushes local dirty data, copies known app collections, reads back every document, verifies values, then marks cutover complete server-side. It reloads into GAS automatically.
4. Confirm the app reports connected and test one non-destructive read in catalog, orders, and payroll before normal use. Retain Firestore as the backup; it is not used by the app after the server cutover flag is set.

If migration/verification fails, the source Firestore is preserved and business writes remain disabled on GAS. Retry is idempotent for already matching documents. Do not set `ROLL_GAS_CUTOVER_COMPLETED` manually.
