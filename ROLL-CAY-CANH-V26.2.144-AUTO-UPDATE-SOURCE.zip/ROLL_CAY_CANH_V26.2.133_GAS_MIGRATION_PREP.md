# V26.2.133 (versionCode 185) — GAS migration preparation

This is a migration-preparation source build, not a completed Firestore cutover.

## Preserved behavior
- The existing Android business logic and Firestore backend remain the default.
- `window.ROLL_GAS_BACKEND_ENABLED` is intentionally `false`.
- Firebase Auth and the existing app data path are not replaced by this build.

## Added
- Native asynchronous HTTPS bridge (`AndroidBridge.postRollGasApi`) that forwards Firebase ID tokens to a fixed Apps Script endpoint; no shared `ROLL_API_TOKEN` is packaged.
- Firestore-style GAS client adapter: CRUD, queries, batch, document transactions with server-side version preconditions, and batched `onSnapshot` polling.
- Admin-only “Sao chép Firestore → Sheets” action, which copies and verifies known app collections while keeping Firestore unchanged.
- Separate GAS module uses `fsCompatDocs`; it does not overwrite the current `records`, `operations`, or `photos` sheets.
- Version bump to numeric `26.2.133` / code `185` for the current GitHub Actions source selector.

## Do not cut over yet
The Apps Script project still needs `FirestoreCompat.gs` and the `doPost(e)` dispatch branch from `patches/Code.gs.doPost.patch.txt`, then a new Web App deployment. The migration import/write gate is fail-closed unless Script Property `ROLL_GAS_COMPAT_WRITES_ENABLED=true` is explicitly enabled. After copy, verify document counts/checksums and audit all security-rule paths, order-completion/anti-duplicate transactions, payroll, catalog, offline queue, and Drive photos. Transaction query-reads are explicitly unsupported by the adapter until a safe equivalent is implemented.

Only after those checks should a separate reviewed source change enable GAS reads/writes. This prep build does not auto-enable GAS, delete Firestore, or claim live migration success.
