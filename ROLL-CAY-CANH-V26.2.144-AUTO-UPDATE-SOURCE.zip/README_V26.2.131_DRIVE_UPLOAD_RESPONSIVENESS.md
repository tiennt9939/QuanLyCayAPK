# ROLL CÂY CẢNH V26.2.131 — Drive upload responsiveness

- Android versionName: `26.2.131`; versionCode: `183`.
- Baseline: V26.2.130; no project rebuild from scratch.
- Drive uploads use a bounded concurrency of 2 instead of a single serialized upload chain. This avoids blocking all later photo uploads behind one slow upload while avoiding an unbounded burst that can trigger Drive rate limits.
- The Drive image map is already scoped to the connected account. A cached `drive://` reference is reused without downloading the entire image merely to validate it on each app launch. Actual viewing still downloads the image and surfaces missing/inaccessible references; deleted Drive files are not recreated automatically unless the original image bytes are available.
- The native daily scanner already writes compressed photos to an app-private persistent queue before returning to scanning. This release does not delete queued photos on upload failure.
- Verification: 113 JavaScript regression test files passed; preflight passed; ZIP structure and SHA-256 verified.
- Limitations: Android APK build and live Google Drive/Firebase testing were not available in this environment. True upload continuity after the Android app is backgrounded/killed is not claimed as verified; that requires a native foreground/background worker and on-device testing. This release reduces upload queue waiting and unnecessary photo downloads, but does not prove background execution under all Android battery policies.
