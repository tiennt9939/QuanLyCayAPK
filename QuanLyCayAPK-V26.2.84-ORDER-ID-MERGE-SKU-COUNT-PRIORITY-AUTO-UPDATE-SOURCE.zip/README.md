# Bản ứng viên hiện tại — ROLL CÂY CẢNH V26.2.84 (versionCode 136)

**V26.2.84 — Ghép trang theo Order ID và ưu tiên số lượng SKU:** exact Order ID là khóa ghép chính cho các trang trong cùng PDF; một mã vận đơn bị trích xuất lệch ở trang tiếp nối không tự tách thành đơn mới. Qty Total chỉ được đối chiếu sau khi ghép đủ trang, không được ghi đè Qty riêng của một dòng ở trang tiếp nối. Số cây mỗi đơn vị bán lấy từ SKU trước, Seller SKU kế tiếp, rồi mới dự phòng Product Name; vì vậy Product Name “Combo 2 chậu cẩm tú mai C9” cùng SKU “Combo 4 chậu cẩm tú mai C9” được hiểu là 4 cây/đơn vị. Không đổi schema Firestore, tiền công, tồn kho, phân công, quét barcode, ảnh Drive hay Đơn ngoài.

**Kiểm thử trọng điểm:** PDF `TikTokSeller_1792418463567.pdf`, Order ID `586670402637104154` (trang 10–11) phải thành một đơn có 3 dòng sản phẩm, Qty 1 + 1 + 1 = Qty Total 3; không đổi Qty dòng Ổi Lê thành 3. Nếu chỉ có một sản phẩm trong một trang và Qty Total mâu thuẫn, chỉ điều chỉnh sau khi parser xác nhận không có trang/dòng khác cùng Order ID.
**V26.2.81 — Ghép trang tiếp nối theo Order ID:** Nếu Android trả `tableRows: []` do không dựng được ô bảng theo tọa độ, parser vẫn giữ dòng sản phẩm hợp lệ từ văn bản PDF. Các trang có cùng Order ID được ghép trước khi đối chiếu Qty Total; tracking trống ở trang tiếp nối không bị xem là xung đột. Giữ toàn bộ sửa nhận diện và tính năng của V26.2.80; không thay schema Firestore, công thức tiền công, tồn kho hoặc luồng Đơn ngoài.

**Kiểm tra source:** 75/75 bài kiểm thử JavaScript, preflight và cú pháp cả 6 khối JavaScript nhúng đều đạt. Bộ test gồm PDF thật có 3 dòng qua trang 10–11 (Order ID `586670402637104154`): Quỳnh Anh ×2, Nguyệt quế Thái C7 ×2, Ổi Lê ×1; tổng 3 đơn vị bán và 5 cây dự kiến. Có test riêng xác nhận bản override theo đơn chỉ dùng đúng Order ID + mã vận đơn, yêu cầu Admin xác nhận toàn bộ danh sách + lý do, và số nhập là tổng cuối cùng (không nhân Qty lần hai). Ổi Lê ghi dải C9-C10 vẫn cần Admin chọn/xác nhận một size nếu chưa có quy tắc đã học; parser `ready` không đồng nghĩa mọi dòng đã đối chiếu danh mục. Đây mới là xác minh parser/source; APK chưa build và chưa chạy kiểm thử thực tế trên điện thoại/Firebase.

**V26.2.78 – Sửa thêm nhiều cây vào đơn ngoài:** Đơn ngoài chọn từng dòng cây bằng chỉ số dòng danh mục riêng, không dùng catalogId có thể trùng; sửa đối chiếu plantIndex theo tên + kích thước để giữ đúng từng dòng.

**V26.2.77 – Khôi phục quy tắc nhận diện cũ:** Khôi phục nút Admin xác nhận đối chiếu và dạy app, nút quản lý quy tắc, sửa Qty theo đơn vị và bộ quy tắc height range; bổ sung thông báo nguyên nhân cụ thể khi không thể xác nhận. Vẫn giữ nguyên luồng đơn ngoài từ V26.2.75.

**Đơn ngoài TikTok:** Admin tạo đơn từ danh mục cây/kích thước, giao trực tiếp cho nhân viên, xem tiền công theo bảng đơn giá hiện có, cộng/trừ tiền công và ghi chú, rồi nhân viên chụp 1 ảnh để hoàn tất. Báo cáo và CSV có mục riêng “Đơn ngoài TikTok”. Source gốc lấy từ V26.2.72 đang vận hành; không thay schema hay luồng TikTok. Xem `README_V26.2.75_OUTSIDE_TIKTOK_ORDERS.md`.

---

# QuanLyCayAPK / ROLL CÂY CẢNH — V26.2.28

V26.2.28 sửa việc tách sai sản phẩm TikTok khi tên/SKU xuống dòng trong PDF. Nhãn `Combo 4 tặng 1` giữ thành một dòng sản phẩm; SKU được giữ nguyên và số cây mỗi đơn vị là 5, trong khi Qty PDF vẫn bằng 1 đơn vị bán. Parser ưu tiên cột Qty thật và không nhầm số `1` ở cuối SKU thành một đơn hàng thứ hai. Bản sửa không thay đổi tiền công, tồn kho hoặc schema Firestore. Nếu nhãn lỗi đã nằm trong hàng đợi tạm từ phiên bản cũ, import lại chính PDF sau khi nâng cấp sẽ cập nhật nhãn tạm chưa phân công; đơn đã liên kết/đã phân công không bị ghi đè.

# QuanLyCayAPK / ROLL CÂY CẢNH — V26.2.24

V26.2.23 sửa hàng đợi nhãn PDF cũ: khi mở mục PDF, ứng dụng đối chiếu nhãn tạm với toàn bộ đơn trên Firestore, bao gồm đơn đã hoàn tất những ngày trước. Nhãn trùng vận đơn với đơn đã có sẽ tự được gỡ khỏi danh sách tạm; đơn thật, lịch sử, tồn kho và tiền công không bị xóa. Tiếp tục giữ chỉ báo đỏ/vàng/xanh khi nhân viên hoàn tất đơn. Build version `26.2.23`, versionCode `75`.

Luồng một ảnh, lưu Google Drive trước khi ghi đơn, xác minh mã vận đơn TT, bảo vệ chống trùng vận đơn, tiền công, tồn kho, nhập PDF TikTok, Firestore schema và cập nhật ứng dụng được giữ nguyên từ V26.2.19.


V26.2.23 bổ sung đối chiếu mã vận đơn theo ID tài liệu `tiktok_<tracking>` đối với đơn TikTok cũ thiếu trường shipmentTrackingNo; các đơn đã hoàn tất vẫn được giữ nguyên.


Bổ sung thao tác Admin `DỌN NHÃN PDF TẠM ĐÃ XỬ LÝ` cho hàng đợi nhãn cũ không còn liên kết chắc chắn với đơn do thiếu metadata lịch sử. Thao tác chỉ xóa queue PDF cục bộ sau khi xác nhận; không xóa dữ liệu đơn/tiền công/kho trên Firebase. Khi Admin hoàn tất đơn, bản mới làm mới snapshot đơn và hàng đợi ngay lập tức để tự gỡ các nhãn có liên kết tracking/ID rõ ràng.


## V26.2.24 — Ghép PDF hôm nay vào hàng dư ĐD đã chốt hôm qua

Khi Admin nhập PDF TikTok Shop, ứng dụng thử ghép nhãn có đủ Order ID + mã vận đơn vào đơn ĐD đã hoàn tất nhưng đang `shipmentOcrPending=true`. Chỉ tự ghép khi danh mục cây, kích thước và tổng số lượng khớp chính xác, và mỗi nhãn/đơn ĐD đều có một cặp duy nhất. Nếu có nhiều ứng viên, Admin chọn thủ công trên dòng nhãn PDF.

Thao tác ghép chỉ bổ sung Order ID, mã vận đơn và metadata liên kết trên bản ghi ĐD đã tồn tại; không tạo đơn đóng hàng mới, không chạy lại quy trình hoàn tất, không thay đổi nhân viên, tiền công, trạng thái hoàn tất, cây/số lượng hay tồn kho. Claim mã vận đơn được ghi trong cùng giao dịch Firestore để chống trùng. Mã đơn TikTok được đưa vào báo cáo tìm kiếm vận đơn. Build version `26.2.24`, versionCode `76`.

## V26.2.71 — Admin quét thay ngay trên bảng chia nhãn PDF

Ở V26.2.70, nút quét thay nằm trong thẻ phân công đơn đóng hàng khác, không hiện trên bảng **Chia việc theo nhóm cây** đang dùng để giao nhãn PDF. V26.2.71 thêm nút **ADMIN QUÉT THAY · GHI CÔNG [tên nhân viên]** ngay tại nhãn đã giao; Firebase đối chiếu lại UID nhân viên, UID Admin, phiên phân công và claim mã vận đơn trước khi ghi. Tiền công vẫn theo nhân viên được giao; UID Admin được lưu riêng để kiểm tra lịch sử.

Hướng dẫn: `README_V26.2.71_ADMIN_SCAN_FROM_PDF_ASSIGNMENT_BOARD.md`. Build version `26.2.71`, versionCode `123`.
## V26.2.72 — Admin quét hàng loạt theo nhân viên

Bỏ thao tác quét thay từng nhãn. Trong bảng **Chia việc theo nhóm cây**, Admin chọn nhân viên tại mục **Admin quét thay cho nhân viên đã giao** rồi bấm **ADMIN QUÉT HÀNG LOẠT**. Ứng dụng chuẩn bị một phiên quét gồm các nhãn hợp lệ đã giao cho đúng UID nhân viên đó trong ngày đang chọn; đơn đã ghi, đã khóa hoặc cần kiểm tra cây sẽ bị bỏ qua. Máy quét nhận mã trong danh sách phiên và tự chụp ảnh, còn tiền công vẫn thuộc nhân viên được giao. Firebase giữ xác minh UID Admin, UID nhân viên, phiên phân công và claim chống trùng.

Hướng dẫn: `README_V26.2.72_ADMIN_BATCH_SCAN_BY_EMPLOYEE.md`. Build version `26.2.72`, versionCode `124`.
