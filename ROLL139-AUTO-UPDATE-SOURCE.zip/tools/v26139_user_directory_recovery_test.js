const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const code=fs.readFileSync(path.join(root,'Code.gs'),'utf8');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8');
assert(gradle.includes('versionName = "26.2.139"')&&gradle.includes('versionCode = 191'),'release metadata');
assert(code.includes("VERSION: 'gas-firestore-compat-phase2.3.2-scoped-query-index'"),'GAS compatibility version');
assert(code.includes('function fsCompatBuildIndexForCollections_(collectionPaths)'),'scoped collection index exists');
const scoped=code.slice(code.indexOf('function fsCompatBuildIndexForCollections_'),code.indexOf('function fsCompatBuildIndexFromSheet_'));
assert(scoped.includes('getRange(2,1,count,4).getValues()'),'scoped index reads A:D metadata only');
assert(scoped.includes('getRange(2,6,count,6).getValues()'),'scoped index reads F:K metadata only');
assert(scoped.includes('wanted[collectionPath]'),'unrelated collections are skipped before payload reads');
assert(scoped.includes('sheet.getRange(rowNo,5).getValue()'),'payload chunks are read only for the requested collection');
assert(code.includes("function fsCompatReadCurrentDoc_(path) { var clean=fsCompatNormalizeDocPath_(path),parts=clean.split('/');parts.pop();var index=fsCompatBuildIndexForCollections_([parts.join('/')]);return index[clean]||null; }"),'auth profile lookup uses the scoped user collection');
const handler=code.slice(code.indexOf("if (command === 'get' || command === 'query'"),code.indexOf("if (command === 'importBatch')"));
assert(handler.includes('fsCompatBuildIndexForCollections_([documentsQuery.collectionPath])'),'normal collection reads avoid full-sheet JSON index reconstruction');
assert(handler.includes('fsCompatBuildIndexForCollections_(queryCollections)'),'multiQuery uses only required collections');
assert(!handler.includes('var index = fsCompatBuildIndex_();'),'read path no longer rebuilds every collection');
assert(html.includes('window.__rollGasDirectoryDb=candidate;'),'pre-cutover GAS account snapshot retained read-only');
assert(html.includes("readUsersCollection(recoveryDb,11000,'bản sao Google Sheets')")&&html.includes('Promise.allSettled(tasks)'),'account list reads the GAS migration snapshot in parallel');
assert(html.includes('function mergeUserDirectoryRows(primaryRows,gasRows)')&&html.includes('mergeUserDirectoryRows(primaryRows,gasRows)'),'active and backup user profiles are merged by UID');
assert(html.includes('merged._rollNeedsGasRepair=true'),'missing profile fields from GAS are surfaced for explicit repair');
assert(html.includes('async function restoreMissingStaffProfilesFromGas()'),'admin recovery operation exists');
assert(html.includes("if(!Object.prototype.hasOwnProperty.call(current,'active'))patch.active=row.active!==false"),'account lock state is preserved during recovery');
assert(html.includes('!u._rollRecoveredFromGas&&!u._rollNeedsGasRepair'),'unrestored profiles are not assigned until copied into the active backend');
assert(html.includes("error.code='deadline-exceeded'"),'account list request has a bounded timeout');
assert(html.includes("if(existingByEmail){")&&html.includes('profileRef(existingByEmail.uid).set(relinkPatch,{merge:true})'),'existing registered email is linked by admin profile update without second Auth registration');
assert(html.includes("if(!password){toast('Email này chưa có hồ sơ tài khoản để liên kết."),'password is required only for new Auth accounts');
assert(html.includes('u.employeeName||u.displayName||u.name||\'\''),'legacy employee name aliases are normalized');
assert(html.includes('&&!u._rollRecoveredFromGas&&!u._rollNeedsGasRepair'),'packing assignment selector waits until profile restoration is complete');
const outsideSelector=html.slice(html.indexOf('function renderOutsideOrderEmployeeOptions'),html.indexOf('// Use the catalog row index',html.indexOf('function renderOutsideOrderEmployeeOptions')));
assert(outsideSelector.includes('!u._rollRecoveredFromGas&&!u._rollNeedsGasRepair'),'outside TikTok assignment selector uses only restored profiles');
const pdfSelector=html.slice(html.indexOf('async function loadTikTokAssignees'),html.indexOf('function tiktokLabelCompositionOverrideItems'));
assert(pdfSelector.includes('!u._rollRecoveredFromGas&&!u._rollNeedsGasRepair'),'staff PDF import selector uses only restored profiles');

const mergeStart=html.indexOf('function mergeUserDirectoryRows(primaryRows,gasRows)');
const mergeEnd=html.indexOf('async function readUsersCollection',mergeStart);
assert(mergeStart>=0&&mergeEnd>mergeStart,'pure account-directory merge helper exists');
const mergeCtx={Map,String,Array};require('vm').createContext(mergeCtx);
require('vm').runInContext(html.slice(mergeStart,mergeEnd)+'\nthis.merge=mergeUserDirectoryRows;',mergeCtx);
const merged=mergeCtx.merge(
  [{uid:'u1',role:'packer',active:false,employeeId:'',employeeName:'',email:'worker@example.com',_rollRoleMissing:false}],
  [{uid:'u1',role:'packer',active:true,employeeId:'3',employeeName:'Luân nhỏ',email:'worker@example.com'},
   {uid:'u2',role:'packer',active:true,employeeId:'4',employeeName:'Huy',email:'huy@example.com'}]
);
assert(merged.rows.find(x=>x.uid==='u1').employeeId==='3'&&merged.rows.find(x=>x.uid==='u1')._rollNeedsGasRepair,'existing profile receives only missing employee fields');
assert(merged.rows.find(x=>x.uid==='u1').active===false,'existing locked account stays locked');
assert(merged.rows.find(x=>x.uid==='u2')._rollRecoveredFromGas,'GAS-only profile is surfaced for explicit restoration');


const scopedStart=code.indexOf('function fsCompatBuildIndexForCollections_');
const scopedEnd=code.indexOf('function fsCompatBuildIndexFromSheet_',scopedStart);
const payloadRows={2:'{"role":"packer","employeeId":"2"}',3:'{"trackingNo":"SHIP-1"}'};
const payloadReads=[];
const metadataRows=[
  ['doc','users/u1','users','u1',0,1,1,100, 'admin', false],
  ['doc','shipmentTracking/t1','shipmentTracking','t1',0,1,1,200, 'admin', false]
];
const sheetMock={getLastRow:()=>3,getRange:(row,col,numRows,numCols)=>({getValues:()=>col===1?metadataRows.map(r=>r.slice(0,4)):metadataRows.map(r=>r.slice(4,10)),getValue:()=>{payloadReads.push(row);return payloadRows[row]||''}})};
const scopedCtx={Object,String,Number,Math,fsCompatNormalizeCollectionPath_:x=>String(x).replace(/^\/+|\/+$/g,''),fsCompatSheet_:()=>sheetMock,fsCompatError_:(code,msg)=>Object.assign(new Error(msg),{code})};
require('vm').createContext(scopedCtx);
require('vm').runInContext(code.slice(scopedStart,scopedEnd)+'\nthis.build=fsCompatBuildIndexForCollections_;',scopedCtx);
const scopedIndex=scopedCtx.build(['users']);
assert(Object.keys(scopedIndex).join(',')==='users/u1','scoped GAS query returns only requested collection documents');
assert(payloadReads.length===1&&payloadReads[0]===2,'unrelated shipment-history payload chunks are never fetched for users query');

console.log('V26.2.139 account directory recovery + scoped GAS query regression: PASS');
