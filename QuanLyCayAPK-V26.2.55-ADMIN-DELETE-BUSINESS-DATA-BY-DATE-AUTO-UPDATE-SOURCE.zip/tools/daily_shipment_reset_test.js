const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const rules = fs.readFileSync(path.join(root, 'firestore.rules'), 'utf8');
const must = (condition, message) => { if (!condition) throw new Error(message); };
must(gradle.includes('versionName = "26.2.55"') && gradle.includes('versionCode = 107'), 'date-selectable business reset version metadata missing');
must(html.includes('id="dailyBusinessResetDate" type="date"'), 'Admin must be able to choose a date');
must(html.includes('function previewDailyBusinessReset()') && html.includes('function executeDailyBusinessReset()'), 'date-selectable preview/execute UI missing');
must(html.includes('function resetValidBusinessDate(value)'), 'calendar dates must be validated');
must(html.includes("if(String(confirmationText||'').trim()!==expectedPhrase)"), 'date-specific destructive confirmation guard missing');
must(html.includes("db.collection('dailyShipmentScans').where('date','==',date)"), 'scan scope must be restricted to the selected date');
must(html.includes("resetDailyRowsForDate(appData.daily,date)"), 'manual inventory/payroll records must be scoped to the selected date');
must(html.includes('resetTargetPdfRows(appData.dailyShipmentOrders,date)'), 'PDF queue deletion must be date-scoped');
must(html.includes('resetCompletedOrderOnDate'), 'completed-order deletion must be date-scoped');
must(html.includes("k.startsWith(String(date)+'|')"), 'payroll settlements must be date-scoped');
must(html.includes('nextData.payrollArchives=(Array.isArray(appData.payrollArchives)?appData.payrollArchives:[]).filter(r=>String(r?.date||\'\')!==date)'), 'payroll archive removal must match the selected day only');
must(html.includes('if(protectedBase&&String(date)<=protectedBase)') || html.includes("if(protectedBase&&String(date)<=protectedBase)"), 'reset must block dates already folded into the stock baseline');
must(html.includes('resetBusinessConfirmPhrase(date)'), 'date-specific confirmation phrase missing');
must(html.includes('dailyShipmentResetAudit') && html.includes("scope:'full_business_day'"), 'date reset audit entry must be preserved');
must(html.includes('dailyShipmentResetDates') && html.includes('dailyShipmentApplyResetMarkers'), 'stale cache guard must remain');
must(rules.includes('match /dailyShipmentScans/{trackingNo}') && rules.includes('allow delete: if isAdmin();'), 'existing Admin scan-delete rule not available');
must(rules.includes('match /packingOrders/{orderId}') && rules.includes('allow delete: if isAdmin();'), 'existing Admin completed-order delete rule not available');
// The signature excludes volatile synchronization timestamps but includes date-scoped data.
must(html.includes("if(['updatedAt','updatedAtMs','lastSeenAtMs','syncedAtMs'].includes(k))return;"), 'fingerprint should exclude volatile sync metadata');
must(html.includes('D.stockBaseDate') || html.includes('appData.stockBaseDate'), 'stock baseline safety check missing');
must(html.includes('Dữ liệu ngày khác được giữ lại'), 'reset must state that other dates are preserved');
// Cache regression: old rows before marker disappear/reset, a fresh scan remains visible.
const vm = require('vm');
const helperStart = html.indexOf('function dailyShipmentDateWasReset(date)');
const helperEnd = html.indexOf('async function previewDailyShipmentReset18()', helperStart);
must(helperStart >= 0 && helperEnd > helperStart, 'date-reset cache marker helper block missing');
const sandbox = { D: { dailyShipmentResetDates: { '2026-10-18': 1000 }, dailyShipmentReports: [
 { id:'daily_old', trackingNo:'OLD', date:'2026-10-18', source:'daily_shipment_scan', status:'recorded', scannedAtMs:900 },
 { id:'daily_new', trackingNo:'NEW', date:'2026-10-18', source:'daily_shipment_scan', status:'recorded', scannedAtMs:1100 },
 { id:'daily_other', trackingNo:'OTHER', date:'2026-10-17', source:'daily_shipment_scan', status:'recorded', scannedAtMs:800 }
 ], dailyShipmentOrders:[
 { trackingNo:'OLD', date:'2026-10-18', source:'pdf_label', status:'recorded', recordedAtMs:900, employee:'Old employee' },
 { trackingNo:'NEW', date:'2026-10-18', source:'pdf_label', status:'recorded', recordedAtMs:1100, employee:'New employee' }
 ] }, invalidateInventoryIndexes() {} };
vm.runInNewContext(html.slice(helperStart, helperEnd) + `this.testMarker=()=>{dailyShipmentApplyResetMarkers();return {reports:D.dailyShipmentReports,orders:D.dailyShipmentOrders};};`,sandbox);
const out=sandbox.testMarker();must(out.reports.length===2&&out.reports.some(r=>r.trackingNo==='NEW')&&out.reports.some(r=>r.trackingNo==='OTHER'),'reset marker must preserve fresh scans and other dates');
must(out.orders.find(r=>r.trackingNo==='OLD').status==='imported','stale cache must not revive an old recorded state');
must(out.orders.find(r=>r.trackingNo==='NEW').status==='recorded','new scans after reset must remain visible');
console.log('Daily business date-reset regression test PASS');
