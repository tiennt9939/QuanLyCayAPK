# ROLL CÂY CẢNH — V26.2.47

## Mục tiêu
Bản này dựa trực tiếp trên V26.2.46. Giữ nguyên hàng đợi quét chung, máy quét liên tục, cảnh báo trùng, nhận dạng PDF, quy tắc tiền công nhân viên, và upload ảnh Google Drive nền.

## Thay đổi trong V26.2.47

1. **Admin là lựa chọn quét không tính công**
   - Thêm lựa chọn `Admin — KHÔNG TÍNH CÔNG` vào bộ chọn nhân viên mặc định và danh sách nhân viên trên camera.
   - Tại lúc nhận mã, ứng dụng chụp snapshot đúng người đang chọn.
   - Khi chọn Admin, báo cáo vận chuyển và tồn kho vẫn được ghi nhận, nhưng `laborPay = 0`, `payAmount = 0`, `wageRecorded = false`, `wageStatus = not_applicable`.
   - Bộ tổng hợp tiền công chỉ lấy báo cáo có `wageRecorded === true`. Giao dịch Firebase cũng áp đặt mức công bằng 0 cho bản ghi không tính công.

2. **Bảo vệ danh sách PDF đã nhập**
   - Lưu bản dự phòng cục bộ của `dailyShipmentOrders` và `dailyShipmentReports`.
   - Khi đồng bộ Cloud/local, ghép theo mã vận đơn đã chuẩn hóa để tránh tạo trùng đơn, giữ dữ liệu chi tiết cũ nếu bản Cloud thiếu danh sách sản phẩm và ưu tiên trạng thái mới hơn khi có dữ liệu trực tiếp.
   - Khi đã có danh sách live nhưng chưa có bản backup cũ, tạo bản backup từ dữ liệu hiện tại.
   - Hộp chọn nhân viên hiển thị số đơn của ngày đang chọn, số đơn sẵn sàng quét và số đã ghi nhận, để biết ngay danh sách vẫn còn trong bộ dữ liệu dù hộp thoại đang che màn hình.

3. **Hiệu năng**
   - Không chạy lại bảng lương khi đổi nhân viên.
   - Bản backup chỉ được ghi theo các lần import, khôi phục hoặc cập nhật trạng thái quét; không thêm vòng lặp Firebase cho từng mã.
   - Máy quét tiếp tục kiểm tra claim theo lô và giới hạn xử lý ảnh nền tối đa hai worker.

## Phiên bản Android
- `versionName`: `26.2.47`
- `versionCode`: `99`

## Kiểm tra đã thực hiện
- `python tools/preflight.py`: PASS.
- 48/48 script kiểm thử JavaScript: PASS.
- Đã xác nhận cú pháp các khối JavaScript nhúng trong `index.html`.
- Chưa chạy được Gradle build/APK tại môi trường này vì không có Gradle/Gradle Wrapper/Android SDK. Cần dùng GitHub Actions để build và thử trên điện thoại thật.

## Build qua GitHub Actions
1. Upload ZIP `QuanLyCayAPK-V26.2.47-ADMIN-NO-WAGE-QUEUE-RECOVERY-AUTO-UPDATE-SOURCE.zip` lên thư mục gốc repository `tiennt9939/QuanLyCayAPK`.
2. Mở **Actions**, chọn workflow **Build ROLL CAY CANH V26.2.47 — Admin No-Wage Scan + Queue Recovery** và bấm **Run workflow**.
3. Để `source_zip` trống nếu ZIP mới là gói `AUTO-UPDATE-SOURCE.zip` có phiên bản cao nhất trong repository; hoặc chọn đúng tên ZIP vừa tải.
4. Chỉ cài APK sau khi workflow thành công. Giữ lại APK V26.2.46 làm bản dự phòng đến khi thử xong thao tác nhập PDF, đổi nhân viên, quét Admin không tính công, quét trùng và bảng lương.

## Lưu ý về đơn đã mất khỏi cả nguồn
Bản backup giúp bảo vệ và khôi phục các đơn còn trên máy hoặc có trong bản backup cục bộ nếu snapshot Cloud cũ ghi đè dữ liệu. Nó không thể tự tái tạo các mã vận đơn nếu danh sách đã bị xóa khỏi cả Cloud, bộ nhớ máy và bản backup. Nếu hộp chọn hiện `0 đơn` dù đã nhập 46 đơn, hãy chưa nhập lại vội; kiểm tra ngày đang chọn và trạng thái Cloud trước để tránh tạo đơn trùng.
