# V26.2.46 — Danh sách quét chung, chọn nhân viên theo từng mã và còi cảnh báo trùng

Phát triển trực tiếp từ source V26.2.45. Giữ nguyên bộ đọc PDF, quy tắc nhận dạng cây, công thức `orderItemRate()`, tiền công, kho, Firebase Authentication/Firestore schema và luồng upload ảnh nền. Không tạo hệ thống phân công/chia đơn mới.

## Luồng làm việc đúng cho cửa hàng

1. Admin nhập PDF đơn vận chuyển trong ngày. Tất cả mã hợp lệ được đưa vào **một danh sách chờ quét chung**; không chia hoặc chỉ định đơn cho từng nhân viên.
2. Bấm `QUÉT + TỰ CHỤP LIÊN TỤC`. Trên chính màn hình camera có danh sách `NHÂN VIÊN ĐANG QUÉT`. Chọn người đang đóng hàng trước từng mã; có thể chuyển người ngay trong phiên camera sau khi ảnh mã trước được xếp vào hàng đợi.
3. Tại thời điểm mã được nhận diện, nhân viên được chọn được chụp thành snapshot gắn với ảnh và bản ghi. Nếu app bị đóng bất ngờ trước khi WebView xử lý sự kiện, file `.meta.json` đi cùng ảnh giúp khôi phục đúng người.
4. Firebase vẫn là nơi chốt mã duy nhất, nhân viên và tiền công. Quét bình thường không thêm truy vấn Firebase cho từng thao tác chọn nhân viên. Danh sách claim được kiểm tra một lượt trước khi mở camera; giao dịch ghi nhận vẫn là lớp bảo vệ cuối cùng khi hai máy quét cùng lúc.

## Cảnh báo quét trùng

- Nếu mã đã ghi công, đã bị claim bởi một giao dịch khác, hoặc đã quét trong cùng phiên: camera hiển thị cảnh báo đỏ, phát **hai tiếng còi khác biệt**, rung điện thoại và không chụp ảnh/ghi công lần thứ hai.
- Nếu hai thiết bị quét đồng thời và Firebase báo trùng sau lần chụp, WebView cũng phát cảnh báo và loại bỏ bản ghi trùng.
- Mã không thuộc PDF và mã chưa đối chiếu đủ cây/kích thước bị chặn như trước.

## Chức năng giữ lại

- `HỦY GHI NHẬN / CHO PHÉP QUÉT LẠI` dành cho Admin, giữ lịch sử điều chỉnh và chỉ cho phép quét lại khi trạng thái hủy đã được Firebase xác nhận.
- Tiền công dùng lại quy tắc và mức giá hiện hữu. Ảnh tải Drive ở nền; ảnh local và thông tin nhân viên được giữ khi cần thử lại.
- Hai worker xử lý ảnh tối đa vẫn giữ nguyên; không render toàn bộ ứng dụng sau từng mã.

## Phiên bản

- Android package: `com.quanlycay.apk`
- `versionName`: `26.2.46`
- `versionCode`: `98`

## Kiểm tra đã thực hiện

- `python tools/preflight.py` — PASS.
- Toàn bộ `tools/*_test.js` — PASS (bao gồm kiểm thử mới về danh sách chung, nhân viên theo từng mã, hàng đợi ảnh và âm báo trùng).
- Kiểm tra cú pháp 6 khối JavaScript nhúng HTML thông qua preflight — PASS.
- Chưa thể xác nhận APK compile trên môi trường này vì không có Gradle/Gradle Wrapper hoặc Android SDK được cài sẵn. Cần chạy GitHub Actions và cài thử APK trên điện thoại trước khi đưa vào vận hành.
