
'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8');
assert(/versionName\s*=\s*"26\.2\.66"/.test(gradle)&&/versionCode\s*=\s*118/.test(gradle),'version metadata must be 26.2.66 / 118');
const start=html.indexOf('async function adminAssignDailyShipmentLabels('),end=html.indexOf('async function loadAssignedDailyShipmentLabels(',start);
assert(start>=0&&end>start,'assignment transaction must exist');
const fn=html.slice(start,end);
assert(fn.includes('const hasRecordedEvidence='),'recorded evidence must be checked separately');
assert(fn.includes("if(hasRecordedEvidence)throw new Error"),'recorded report/scan must remain protected');
assert(fn.includes("if(oldOrder)throw new Error"),'legacy linked order must remain protected');
assert(fn.includes("claimStatus==='recorded'||claimStatus!==''||!allowedStaleIds.has(claimOrderId)"),'only empty-status orphan claims linked to deterministic stale IDs may be recovered');
assert(fn.includes("status:'voided'")&&fn.includes("source:'assignment_orphan_claim_recovery'"),'orphan claim recovery must be audited as voided');
assert(fn.includes('recoveredFromOrderId'),'recovery must retain prior linked order ID for audit');
assert(fn.includes('shipmentTrackingClaims'),'claim protection remains active');
console.log('V26.2.66 STALE CLAIM ASSIGNMENT FIX PASS');
