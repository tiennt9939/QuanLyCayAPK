# AUDIT REPORT — ROLL CÂY CẢNH V26.2.114

**Ngày:** 26/10/2026  
**Baseline:** source ZIP V26.2.113 (versionCode 165)  
**Bản source đã sửa:** V26.2.114 (versionCode 166)  
**Phạm vi:** Firestore 1 MiB khi import PDF/chia đơn, gồm read/write, migration, integrity reconciliation, rollback và regression test.

## 1. Lỗi đầu vào đã xác nhận

Lỗi trong bàn giao là document `projects/roll-cay-canh/databases/(default)/documents/apps/roll-cay-canh` có kích thước khi ghi là **1,054,875 bytes**, giới hạn **1,048,576 bytes**, vượt **6,299 bytes**. Bàn giao ghi lỗi tại tab Theo ngày → Chia việc ngày 26/10/2026 với 107 nhãn PDF. Đây là lỗi dung lượng document; không có đủ bằng chứng để quy lỗi cho logic nhận diện cây hoặc kích thước PDF.

## 2. Kết quả audit luồng dữ liệu

| Điểm trong source | Rủi ro trước sửa | Bảo vệ/luồng sau sửa |
|---|---|---|
| `sharedRef()` / `apps/roll-cay-canh` | Nhiều dữ liệu cùng ngày và lịch sử nằm trong một blob `data`. | Catalog, rates, payroll và dữ liệu dùng chung khác vẫn giữ ở schema hiện hành; chỉ tách nhãn PDF/báo cáo tăng trưởng. Root preflight đo byte và liệt kê field lớn. |
| `cloudDataSnapshot()` / `pushNowUnlocked()` | Mọi lần sync có thể ghi lại mảng lớn vào một document. | Payload loại hai mảng; sync đọc root/collection mới nhất, persist + read-back verify split records trước root update; xóa mảng cũ bằng field path `FieldValue.delete()` tường minh thay vì chỉ bỏ key khỏi `set(merge:true)`. |
| `ensureDailyShipmentStorageMigrated()` | Migration ngây thơ có thể xóa nguồn trước khi đối soát hoặc ghi đè khi thiết bị khác thay đổi đồng thời. | Manifest có phase `copying` → `prepared` → `committed`; backup riêng từng snapshot; so số lượng/checksum/canonical JSON; lease Admin 120 giây được lấy/gia hạn/nhả; root compact trong transaction kiểm tra đồng thời lease, mảng nguồn và root `packingOrders`. |
| `dailyShipmentOrders` | Bảng giao/nhãn nằm trong blob chung, các transaction có thể tiếp tục viết mảng. | Collection con mỗi tracking ID; assignment, transfer, cleanup, loader và listener đã nối vào collection này. |
| `dailyShipmentReports` | Báo cáo quét, tiền công, trạng thái và reference ảnh tăng dung lượng blob. | Collection con riêng mỗi tracking ID; scan, ảnh Drive, void/rescan, date reset/preview và report hydration đã nối vào collection này. |
| claim/scan | Nếu chỉ chuyển chỗ ghi, chống trùng/tiền công có thể bị lệch. | Scan transaction tiếp tục kiểm tra claim/scan và ghi split order/report cùng giao dịch; giữ điều kiện người được phân công, actor, status và khóa tiền công. |
| Root-level `packingOrders` | Field legacy bị xóa bởi đồng bộ cũ có thể chứa bản sao không được lưu đúng trong migration backup. | Nếu field có mặt, backup riêng theo snapshot và xác minh trước khi compact. Sync thông thường không tự xóa field bất thường nếu nó xuất hiện lại; rules schema 2 chặn việc đưa field này trở lại. |
| Firestore Rules | Nếu app mới sử dụng collection mới nhưng rules cũ, các thao tác sẽ `permission-denied`; nếu rules quá rộng, packer có thể xem/sửa nhãn người khác. | Cập nhật cả `firestore.rules` và `firestore87.rules`: quyền split order/report, query filter cho packer, scan `getAfter`/claim ownership, Admin-only migration backup/manifest, và nhánh rollback có marker chỉ Admin được phép. |

### Những luồng đã rà soát

- đọc snapshot dùng chung, reconcile và đồng bộ bình thường;
- bootstrap/migration và recovery sau gián đoạn;
- import PDF vào state, giao nhóm, chuyển nhân viên, Admin quét thay;
- tải danh sách nhãn được phân công cho packer;
- quét/hoàn tất, chống quét trùng, khóa vận đơn/claim;
- cập nhật ảnh Drive lên order/report;
- hủy lượt quét nhầm và cho phép quét lại theo điều kiện hiện hành;
- preview và reset nghiệp vụ theo ngày (chỉ feature được Admin xác nhận chủ động, không chạy khi migration);
- cleanup đơn cũ, tombstone chống nhãn cũ hồi sinh;
- listener realtime Admin và hydrate state giao diện.

Các mảng `D.dailyShipmentOrders` / `D.dailyShipmentReports` vẫn được giữ làm state tương thích UI và được hydrate từ collection mới. Chúng không còn là nơi lưu trữ chuẩn trên document chung sau khi migration committed. Không thay đổi catalog, giá, tồn kho, công thức lương hay nhận diện cây/size trong bản sửa này.

## 3. Thiết kế migration, đối soát và rollback

### Schema lưu trữ

- Queue/nhãn: `/apps/roll-cay-canh/dailyShipmentOrders/{normalizedTracking}`.
- Báo cáo: `/apps/roll-cay-canh/dailyShipmentReports/{normalizedTracking}`.
- Manifest: `/apps/roll-cay-canh/dailyShipmentMigrations/schema_v2_20261026`.
- Backup bất biến: `/apps/roll-cay-canh/dailyShipmentMigrationBackups/schema_v2_20261026/snapshots/{snapshotId}/{kind}/{recordId}`. Snapshot ID có tính xác định từ nội dung nguồn; snapshot nguồn khác nhau có đường dẫn khác nhau, backup cũ không bị ghi đè.

Mỗi record có metadata tìm kiếm (tracking/date/assigned UID/employee/status/source), nội dung `record`, và fingerprint. Tracking ID chuẩn hóa là ID chính; fallback dùng ID ổn định hoặc fingerprint, không suy đoán cây/size từ mã vận đơn.

### Trình tự

1. Admin đọc root và manifest; nếu schema đã 2 nhưng thiếu manifest hoặc có field/shape bất thường thì fail-closed.
2. Tạo snapshot backup riêng cho queue, report và field root `packingOrders` nếu field này tồn tại; từng backup doc chỉ được bổ sung nếu chưa có, bản có sẵn phải khớp nội dung.
3. Ghi từng nhãn/báo cáo vào document riêng. Batch có giới hạn 350 writes **và** ước tính không quá 5 MiB request; mỗi document record vượt 900 KiB bị chặn.
4. Đọc lại backup/collection đích, đối soát count, checksum và canonical record contents.
5. Ghi manifest `prepared`, tính root size sau compact. Ngưỡng an toàn nội bộ **921,600 bytes (900 KiB)**, thấp hơn giới hạn cứng 1 MiB.
6. Trong Firestore transaction, đọc lại document root, so checksum các mảng nguồn và `packingOrders` với snapshot. Nếu một thiết bị đã thay đổi nguồn trong lúc migration, transaction dừng và không xóa gì.
7. Nếu kích thước dự kiến an toàn, compact bằng `FieldValue.delete()` tường minh với hai field nested; xóa field root `packingOrders` chỉ sau backup xác minh.
8. Đọc lại root và split collections, xác nhận schema, root size, IDs/nội dung nguồn; chỉ khi đúng mới ghi manifest `committed`.
9. Nếu app/process chết sau compact nhưng trước manifest commit, lần chạy sau lấy lease độc quyền, đọc lại root/manifest/collections, chỉ phục hồi commit khi backup khớp và mọi target ID vẫn hiện diện. Các trường hợp không có đủ bằng chứng đều dừng. Rollback cũng sử dụng cùng lease và gia hạn trước các lần ghi quan trọng.

### Rollback

- Chỉ Admin, manifest phải ở phase hỗ trợ rollback và backup phải khớp.
- Hợp nhất bản backup với collection split hiện tại để không làm mất nhãn/report mới phát sinh sau migration.
- Khôi phục root-level `packingOrders` chỉ nếu source snapshot xác nhận field đó từng tồn tại.
- Ước lượng root khi khôi phục; nếu lớn hơn 900 KiB thì từ chối rollback, không xóa/ghi đè split/backup.
- Đọc lại root sau rollback và so sánh arrays. Không xóa collections/backup sau rollback.
- Rules cho phép restore schema 1 chỉ khi Admin và có `storageRollbackAtMs`; client thường không thể đưa arrays cũ trở lại.

## 4. Kiểm thử đã chạy trong môi trường hiện tại

| Kiểm tra | Kết quả |
|---|---:|
| Bộ regression JavaScript hiện có | **102/102 PASS, 0 FAIL, 0 timeout** sau các sửa đổi cuối cùng; chạy song song có timeout từng test |
| `tools/firestore_1mib_split_migration_test.js` | **PASS** — UTF-8 size, canonical JSON, checksum/ID, 900 KiB safety threshold, migration/readers/writers/rules guard assertions, lease/recovery/rollback guards, stale-write protection |
| `tools/shared_daily_shipment_cloud_sync_test.js` | **PASS** |
| `python tools/preflight.py` | **PASS** — asset, Java bridge, metadata V26.2.114/versionCode 166, regression guards |
| Cú pháp 4 khối `<script>` inline (trong 6 thẻ script) ở `index.html` và `tiktok-label-import.js` | **PASS** với `node --check` |
| Cú pháp `tiktok-label-import.js` | **PASS** — `node --check app/src/main/assets/tiktok-label-import.js` chạy cục bộ thành công; workflow cũng kiểm tra lại |
| Firebase Security Rules compile / Emulator | **Chưa chạy** — không có Firebase CLI/Emulator trong môi trường hiện tại |
| Migration / đọc lại / rollback với Firestore project thật | **Chưa chạy** — không có credentials hoặc kết nối xác thực project của người dùng |
| Android APK assemble/signature | **Chưa chạy** — không có Gradle/Gradle wrapper, Android SDK hoặc keystore secret trong môi trường hiện tại; cần GitHub Actions |

Lưu ý: 102 test là test JavaScript/regression cục bộ; test mới có phần sizing/helper và static flow assertions. Nó không mô phỏng đầy đủ Firestore Emulator, không chứng minh rules compile và không khẳng định migration đã chạy trên Cloud.

## 5. Việc phát hành và giới hạn còn lại

1. Dùng source ZIP hoàn chỉnh `ROLL-CAY-CANH-V26.2.114-FIRESTORE-1MIB-AUTO-UPDATE-SOURCE.zip` trên nhánh `main`; workflow sẽ chạy lại preflight, toàn bộ test, cú pháp JS và build APK. Không khẳng định APK xanh cho tới khi artifact thực sự xuất hiện.
2. Deploy đúng file rules đang được Firebase project sử dụng **trước** khi dùng app mới; ZIP không tự deploy rules. Hai biến thể rules được cập nhật nhưng không thể tự xác định biến thể nào đang áp dụng ở project thật.
3. Khi Admin chạy migration, xem manifest + số lượng/size/checksum trước khi cho nhân viên tiếp tục import/quét. Nếu hiện `permission-denied`, thiếu manifest/backup, mismatch, hoặc root vượt 900 KiB, dừng và giữ nguyên local data; không retry sync liên tục, không clear app storage và không import PDF lại.
4. Cần kiểm thử acceptance có Firebase Emulator/project test trước khi triển khai rộng trên dữ liệu thật: migration interrupted tại từng phase, concurrent edit, packer assigned query, scan/photo/void/reset, 2 thiết bị offline/stale cache, rules permissions, rollback sau khi có nhãn mới.

## 6. Kết luận trung thực

Source đã được sửa và bộ kiểm thử cục bộ hiện có chạy xanh. Thiết kế mới tạo backup/manifest và kiểm tra đối soát trước khi compact, nhưng **chưa có bằng chứng live Firestore** rằng dữ liệu thật đã được migration hoặc rollback thành công, và **chưa có APK build artifact** trong phiên này. Không có thao tác nào trong phiên này ghi/xóa dữ liệu trên project Firestore thật.
