# ROLL CÂY CẢNH V26.2.115 — Audit tối ưu đồng bộ và nhận diện PDF

**Ngày:** 26/10/2026  
**Source nền:** V26.2.114 (`versionCode 166`)  
**Bản source mới:** V26.2.115 (`versionCode 167`)  
**Ứng dụng:** Android WebView + Java, Firebase Auth/Firestore, Google Drive  
**Mục tiêu:** Giảm thời gian đồng bộ Firestore và nhận diện nhãn PDF nhưng giữ nguyên nghiệp vụ, dữ liệu, quy tắc nhận diện, chống trùng và xác nhận tiền công.

## 1. Những điểm chậm được xác định trong source nền

1. `pushNowUnlocked()` tải collection `dailyShipmentOrders` và `dailyShipmentReports` cho mỗi lượt đẩy. Sau đó writer lại tải/cập nhật/đối soát các collection với số lượng lịch sử có thể tăng dần. Khi listener Admin đã có snapshot xác nhận từ server, lượt sync không cần tải toàn bộ lịch sử thêm lần nữa.
2. `persistDailyShipmentCollections()` được gọi sau khi `pushNowUnlocked()` đã kiểm tra migration nhưng vẫn gọi lại `ensureDailyShipmentStorageMigrated()`, gây thêm lượt đọc root/manifest không cần thiết.
3. `DriveStorage.toCloudValue()` được gọi riêng để chuyển các mảng PDF/báo cáo trong `pushNowUnlocked()`; writer trước đây lại chuyển đổi cùng các mảng lần nữa.
4. Handler nhập PDF dùng `loadTikTokRecognitionRulesFromCloud(true)`, buộc tải quy tắc nhận diện từ Cloud ở mọi lần import dù vừa tải xong.
5. `autoMapTikTokProductMappings()` và `tiktok-label-import.js` xây dựng/chuẩn hóa dữ liệu danh mục lặp lại khi đối chiếu nhiều sản phẩm trong cùng PDF.
6. Java `MainActivity.parseTikTokPdfStream()` thực hiện thêm lượt `PDFTextStripper` chuẩn trên từng trang, ngay cả khi hai bộ trích xuất chính và dòng sản phẩm tọa độ đã đủ bằng chứng nhãn native-text.

## 2. Thay đổi thực hiện

### Đồng bộ Firestore

- Admin listener vẫn nhận các snapshot realtime từ server. Hai cờ `sharedQueueCacheServerReady` và `sharedReportCacheServerReady` chỉ cho phép tái sử dụng snapshot khi dữ liệu không đến từ cache offline và không có pending writes.
- `readDailyShipmentCollections(..., {preferListenerCache:true})` tái sử dụng snapshot server đã nhận được trong các lượt sync thường. Nếu listener chưa sẵn sàng, source vẫn dùng truy vấn server như trước.
- Với snapshot listener, các nhãn/báo cáo khác với bản snapshot chỉ được kiểm tra freshness theo document ID bằng truy vấn `in`, chia khối 10 ID theo giới hạn tương thích SDK cũ. Những ID thay đổi được hợp nhất theo quy tắc hiện có trước khi ghi.
- Nếu một record từng quan sát được đã biến mất trên server trong lúc cache đang cập nhật, quá trình dừng fail-closed và báo lỗi; không tự khôi phục bản cũ từ cache.
- Chỉ ghi document khác nội dung; chỉ đọc lại đối soát các document thực sự được ghi. Không tải lại toàn bộ lịch sử lần thứ hai sau khi viết.
- Bỏ lần gọi `ensureDailyShipmentStorageMigrated()` trùng trong writer nội bộ; caller duy nhất `pushNowUnlocked()` đã thực hiện kiểm tra migration/schema trước đó.
- Không thay đổi các collection dữ liệu đơn, catalog, giá, tồn kho, tiền công hay schema nghiệp vụ. Luồng migration/backup/rollback 1 MiB được giữ lại.

### Nhận diện cây và quy cách

- Quy tắc nhận diện Cloud được cache trong 30 giây. Khi cache còn hạn, import PDF kế tiếp không phải chờ một lần đọc Cloud không cần thiết; khi hết hạn, source vẫn đọc quy tắc mới từ Cloud. Luồng lưu quy tắc Admin cập nhật mốc cache sau khi lưu thành công.
- `tiktokCatalogMatcherRows()` tái sử dụng index theo fingerprint catalog.
- `tiktok-label-import.js` lưu tokens tên/size đã chuẩn hóa trong `WeakMap` cho mảng catalog đang dùng. Fingerprint được kiểm tra để phát hiện thay đổi tại chỗ của khóa, tên, size, chỉ số và cờ deleted; cache được dựng lại nếu các giá trị đó thay đổi. Điều này giữ tính đúng đắn khi Admin sửa danh mục tại chỗ.
- Mỗi lần auto-map lấy một snapshot matcher catalog và đưa cho từng sản phẩm, tránh dựng lại các dòng danh mục trong vòng lặp sản phẩm.
- Không thay đổi mặc định C7, ưu tiên SKU/size tường minh, luật chiều cao Nguyệt quế, quy tắc combo/tặng cây, ánh xạ nhân viên hoặc công thức tiền công.

### Đọc PDF native-text

- `MainActivity` chỉ bỏ qua lượt `PDFTextStripper` chuẩn thứ ba khi trang đã có dòng sản phẩm tọa độ và ít nhất một trong hai bộ trích xuất native đã xác nhận tracking, Order ID và các cột tiêu đề Product Name / Seller SKU / Qty.
- Các trang không đủ bằng chứng vẫn chạy fallback text. OCR ML Kit và barcode scanner vẫn hoạt động cho trang không tìm thấy tracking native; không loại bỏ đường đọc PDF ảnh.
- Các mẫu regex cho đường nhanh được compile một lần. Kết quả trả về có thêm thời gian trích xuất và số trang dùng fast path, fallback text, OCR, barcode. UI import hiện hiển thị thời gian đọc PDF và xử lý trong app khi native bridge cung cấp thời gian.

## 3. Kết quả kiểm thử cục bộ

- **103/103 bài test JavaScript PASS, 0 FAIL, 0 timeout.** Danh sách cụ thể nằm trong `ROLL_CAY_CANH_V26.2.115_TEST_RESULTS.txt`.
- `python tools/preflight.py`: PASS; version `26.2.115 / 167`.
- Cú pháp `tiktok-label-import.js`, test mới và cả 4 khối JavaScript nội tuyến trong `index.html`: PASS.
- `tools/performance_optimization_v26115_test.js`: PASS.
- Benchmark catalog matcher trong môi trường Node kiểm thử: 99 dòng catalog, 150 sản phẩm mẫu, median 7 lượt. Source V26.2.114 gốc: **184.00 ms**; source tối ưu: **18.78 ms**; nhanh hơn khoảng **9.80×** cho microbenchmark này. Bộ kết quả `matchCatalogProduct()` của hai source giống hệt nhau trên cùng dữ liệu kiểm thử. Kết quả được lưu trong `ROLL_CAY_CANH_V26.2.115_RECOGNITION_BENCHMARK.json`.

Benchmark này kiểm tra CPU matcher trên Node, **không phải** số đo Android, thời gian nhập PDF đầy đủ hoặc thời gian Firestore thật.

## 4. Trạng thái chưa xác minh

- Chưa biên dịch APK: môi trường không có `ANDROID_HOME`, `gradle` command hoặc `gradlew`/Gradle Wrapper. Không được tuyên bố APK build thành công trước khi GitHub Actions thực sự xanh.
- Chưa kết nối Firebase Emulator hoặc project Firebase thật: chưa đo thời gian sync mạng thực tế, chưa kiểm chứng rules/permissions Cloud đang được publish.
- Lượt đầu tiên hoặc lượt sync khi listener chưa có snapshot server xác nhận vẫn truy vấn collection theo cách fallback. Lợi ích lớn nhất áp dụng cho các lượt sync sau khi Admin listener đã hoạt động.
- Trang PDF quét ảnh vẫn phải dùng OCR/barcode khi không có chữ native; không thể bảo đảm cùng mức tăng tốc đối với PDF ảnh.

## 5. Bất biến bảo vệ

Không có thao tác xóa/reset Firestore được thực hiện trong quá trình này. Không xóa nhãn ngày 26/10/2026 hoặc lịch sử; không đặt tồn kho về 0; không reset tiền công; không tự đoán cây/size từ mã vận đơn. Migration và nguồn backup hiện có được giữ nguyên, chỉ thêm tối ưu luồng đồng bộ/nhận diện.

## 6. Files trọng tâm thay đổi

- `app/src/main/assets/index.html` — cache listener/server, freshness check theo ID, diff writes, TTL nhận diện và timing PDF.
- `app/src/main/assets/tiktok-label-import.js` — tiền xử lý token danh mục có kiểm tra invalidation.
- `app/src/main/java/com/quanlycay/apk/MainActivity.java` — native PDF fast path có điều kiện và số đo thời gian.
- `app/build.gradle.kts` — versionName `26.2.115`, versionCode `167`.
- `.github/workflows/build-apk.yml`, `tools/preflight.py` và bài test regression — cập nhật metadata/CI và kiểm chứng hiệu năng.
