# V26.2.114 — Tách nhãn PDF khỏi document Firestore 1 MiB

## Vì sao sửa

Bàn giao 26/10/2026 ghi nhận lần ghi `apps/roll-cay-canh` có kích thước 1,054,875 bytes, vượt giới hạn 1,048,576 bytes 6,299 bytes. Thao tác xảy ra trong luồng Theo ngày → Chia việc sau khi import PDF. Bản ghi lỗi là document dữ liệu chung quá lớn; bằng chứng chưa cho thấy bộ nhận diện cây/size PDF là nguyên nhân.

## Thay đổi chính

- Nhãn/đơn phân công: `apps/roll-cay-canh/dailyShipmentOrders/{normalizedTracking}`.
- Báo cáo quét/tiền công/ảnh Drive: `apps/roll-cay-canh/dailyShipmentReports/{normalizedTracking}`.
- Migration manifest: `apps/roll-cay-canh/dailyShipmentMigrations/schema_v2_20261026`.
- Backup bất biến phân theo snapshot: `apps/roll-cay-canh/dailyShipmentMigrationBackups/schema_v2_20261026/snapshots/{snapshotId}/{orders|reports|legacyPackingOrders}/{recordId}`.
- `dailyShipmentOrders` và `dailyShipmentReports` không còn nằm trong `apps/roll-cay-canh.data` sau khi migration commit. `packingOrders` top-level (nếu có) cũng được sao lưu theo snapshot trước khi compact; sync bình thường không tự xóa lại field bất thường nếu field này xuất hiện trở lại.
- ID nhãn dựa tracking number chuẩn hóa; không có mã tracking thì dùng ID ổn định hoặc fingerprint nội dung. Ghi lặp dùng cùng ID để tránh nhân đôi do import/retry.

## Kiểm soát an toàn

- Ngưỡng cứng Firestore: 1,048,576 bytes; ngưỡng an toàn nội bộ: 921,600 bytes (900 KiB) để chừa overhead.
- Kiểm tra document dự kiến và liệt kê field lớn nhất trước khi ghi root.
- Mỗi document nhãn/báo cáo bị chặn nếu kích thước ước tính vượt 900 KiB; batch giới hạn cả số ghi lẫn ước tính tổng byte.
- Backup được đọc lại, so số lượng/checksum/nội dung canonical. Root chỉ compact trong transaction sau khi đọc lại và kiểm tra checksum các mảng cũ cùng `packingOrders` không thay đổi kể từ snapshot.
- Sau compact, đọc lại root và collection tách; manifest chỉ thành `committed` sau khi xác minh.
- Nếu tiến trình chết trong khe root đã compact nhưng manifest còn `prepared`, lần chạy sau chỉ phục hồi trạng thái khi backup và các ID đích được kiểm chứng; nếu thiếu bằng chứng thì dừng.
- Rollback chỉ khi backup khớp manifest và root cũ dự kiến vẫn dưới 900 KiB. Khi rollback, hợp nhất backup với bản ghi split đang tồn tại để giữ nhãn phát sinh sau migration. Nếu không vừa hoặc checksum không khớp, rollback từ chối và giữ nguyên schema mới, mọi collection và backup.
- Rules chặn client thường đưa mảng cũ trở lại sau schema 2; chỉ Admin có dấu `storageRollbackAtMs` mới được phép rollback schema 1.

## Những luồng đã được nối tới collection tách

| Luồng | Cách đọc/ghi sau thay đổi |
|---|---|
| Đồng bộ/reconcile chung | Root payload bỏ hai mảng; Admin lưu/đọc lại collection tách trước khi commit metadata gốc. |
| Migration/bootstrap | Backup → ghi collection đích → read-back verify → transaction kiểm tra mảng nguồn không đổi → compact root → read-back verify → commit manifest. |
| Bảng phân công PDF và chuyển nhân viên | Transaction đọc claim/scan và document nhãn theo tracking; ghi document nhãn riêng, không nhét mảng vào root. |
| Danh sách nhân viên | Query `assignedUid == uid`, không tải toàn bộ nhãn của người khác. |
| Quét/chốt tiền công/chống trùng | Claim + scan + nhãn + báo cáo cập nhật bằng transaction; không ghi hai mảng vào root. |
| Gắn ảnh Drive | Cập nhật tài liệu nhãn/báo cáo riêng; giữ nguyên quyền sở hữu lượt quét. |
| Hủy quét nhầm/cho quét lại | Ghi trạng thái void/history vào report và hàng đợi riêng, giữ khóa claim và điều kiện khóa payroll/tồn. |
| Đối soát/cleanup đơn cũ | Đọc/hydrate từ collection tách; giữ tombstone/điều kiện không xóa đơn đã ghi công. |
| Reset nghiệp vụ theo ngày | Preview và transaction đọc các document mục tiêu theo ngày; feature reset chỉ thực thi khi Admin chủ động xác nhận, không chạy trong migration. |
| Listener realtime Admin | Root, queue và report có listener riêng; hợp nhất vào state/UI hiện tại. |
| Rollback | Đối chiếu snapshot backup/manifest; giữ collection tách và backup, không tự xóa chúng. |

## Rules và phát hành

Cả `firestore.rules` và `firestore87.rules` được cập nhật theo quyền hiện có, gồm read filter dành cho packer, ghi split record gắn với scan thuộc đúng nhân viên, Admin-only backup/manifest và nhánh rollback Admin-only. Chưa chạy deploy rules từ môi trường này; phải dùng đúng bản rules đang áp dụng cho Firebase project thực tế.

**Chưa xác nhận APK build hoặc migration trên Firebase thật.** Môi trường kiểm thử hiện tại không có `firebase` CLI, không có `gradle`/Gradle wrapper trong source, không có Android SDK, và không có thông tin đăng nhập vào project Firestore của người dùng. Xem báo cáo audit để biết chính xác test đã chạy.
