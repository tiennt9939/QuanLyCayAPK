'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8');
const preflight=fs.readFileSync(path.join(root,'tools/preflight.py'),'utf8');
const workflow=fs.readFileSync(path.join(root,'.github/workflows/build-apk.yml'),'utf8');
assert(gradle.includes('versionName = "26.2.99"')&&gradle.includes('versionCode = 151'),'must be V26.2.99 / code 151');
assert(preflight.includes('shared_pdf_product_mapping_cloud_repair_test.js'),'preflight must include this regression test');
assert(workflow.includes('V26.2.99')&&workflow.includes('*AUTO-UPDATE-SOURCE.zip'),'workflow must keep the auto-update source ZIP trigger');
assert(html.includes('await ensureDailyShipmentSharedRecognitionMappings(allRows,date)'),'assignment board must hydrate shared recognition before deciding that a label is unscannable');
assert(html.includes('await loadTikTokRecognitionRulesFromCloud(true)'),'repair must force-refresh shared rules when the selected day has unmapped rows');
assert(html.includes('autoMapTikTokProductMappings();'),'repair must rebuild the same per-product mapping cache from saved recognition rules');
assert(html.includes('const sourceRows=selectedRows.map(shared=>{'),'unique product mapping must include shared Cloud rows even if local staging queue is empty');
assert(html.includes('if(stableKey&&stableKey!==savedKey){'),'missing/legacy product map keys must be normalized safely');
assert(!html.includes("collection('dailyShipmentOrders')"),'must not add another Firestore collection');

// Unit test: a secondary device has shared dailyShipmentOrders but an empty local TikTok staging queue.
const uniqueStart=html.indexOf('function tiktokUniqueProducts(){');
const uniqueEnd=html.indexOf('\nfunction tiktokProductLooksLikeBundle(',uniqueStart);
assert(uniqueStart>=0&&uniqueEnd>uniqueStart,'tiktokUniqueProducts block must exist');
const row1={trackingNo:'862605200772',date:'2026-10-24',orderId:'ORDER-A',products:[{mapKey:'camtu-combo5',productName:'Combo 5 cây cẩm tú mai thái C6, C7',rawProductName:'Combo 5 cây cẩm tú mai thái C6, C7',sku:'CAM-TU-MAI-COMBO5',sellerSku:'',qty:1}]};
const row2={trackingNo:'862605200773',date:'2026-10-24',orderId:'ORDER-B',products:[{mapKey:'camtu-combo5',productName:'Combo 5 cây cẩm tú mai thái C6, C7',rawProductName:'Combo 5 cây cẩm tú mai thái C6, C7',sku:'CAM-TU-MAI-COMBO5',sellerSku:'',qty:1}]};
const ctx={
  Array,Map,Set,String,Number,Math,Date,JSON,
  D:{dailyShipmentOrders:[row1,row2]},tiktokLabelQueue:[],tiktokProductMaps:{},tiktokRecognitionRules:{},
  window:{TikTokLabelImport:{keyForProduct:p=>String(p.mapKey||p.sku||p.productName||'')}},
  migrateTikTokProductMapKeys(){},normalizeTikTokQueueImportStatuses(){},normalizeTracking:x=>String(x||'').replace(/\D/g,''),
  $:id=>id==='dDate'?{value:'2026-10-24'}:null,dailyShipmentToday:()=> '2026-10-24',
};
vm.runInNewContext(html.slice(uniqueStart,uniqueEnd),ctx,{filename:'tiktok-unique-products-shared-source.js'});
const unique=ctx.tiktokUniqueProducts();
assert.strictEqual(unique.length,1,'same product identity from shared rows must produce one mapping group');
assert.strictEqual(unique[0].key,'camtu-combo5');
assert.strictEqual(unique[0].orderRows.length,2,'two shared orders must be available to the mapping pass despite an empty local staging queue');
assert.strictEqual(unique[0].product.mapKey,'camtu-combo5','the stable per-product key must survive into the scanner lookup');

// Unit test: the Admin assignment view loads shared rules once for unresolved shared rows, then auto-maps.
const repairStart=html.indexOf('let dailyShipmentRecognitionRepairStamp=');
const repairEnd=html.indexOf('\nasync function renderDailyShipmentAssignmentBoard(){',repairStart);
assert(repairStart>=0&&repairEnd>repairStart,'shared recognition repair helper block must exist');
let loads=0,maps=0,migrations=0;
const repairCtx={
  Array,Map,Set,String,Number,Date,JSON,console,
  window:{CloudSync:{state:()=>({role:'admin',user:{uid:'admin-uid'}})},TikTokLabelImport:{keyForProduct:p=>String(p.mapKey||p.sku||'')}},
  dailyShipmentAssignmentIsRecorded:()=>false,
  dailyShipmentAssignmentProductInfo:row=>({allMapped:row.testMapped===true}),
  normalizeTracking:x=>String(x||'').replace(/\D/g,''),
  loadTikTokRecognitionRulesFromCloud:async force=>{loads++;assert.strictEqual(force,true);return true},
  migrateTikTokProductMapKeys:()=>{migrations++},autoMapTikTokProductMappings:()=>{maps++;return true},
};
vm.runInNewContext(html.slice(repairStart,repairEnd),repairCtx,{filename:'shared-pdf-recognition-repair.js'});
(async()=>{
  const rows=[{trackingNo:'862605200772',date:'2026-10-24',products:[{mapKey:'camtu-combo5',sku:'CAM-TU-MAI-COMBO5'}],testMapped:false}];
  const did=await repairCtx.ensureDailyShipmentSharedRecognitionMappings(rows,'2026-10-24');
  assert.strictEqual(did,true,'repair should run for an unresolved shared queue');
  assert.strictEqual(loads,1);assert.strictEqual(migrations,1);assert.strictEqual(maps,1);
  const second=await repairCtx.ensureDailyShipmentSharedRecognitionMappings(rows,'2026-10-24');
  assert.strictEqual(second,false,'same unresolved queue fingerprint must not trigger a repeated Cloud read immediately');
  assert.strictEqual(loads,1,'avoid repeated Cloud reads/render-driven loops');
  console.log('V26.2.99 SHARED PDF PRODUCT MAPPING CLOUD REPAIR TEST PASS');
})().catch(e=>{console.error(e);process.exitCode=1});
