'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const source = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/index.html'), 'utf8');

// Live order snapshots must not download every historical completion photo.
assert(source.includes('async function fromCloudValueSkippingHistoryImages(value,key=\'\')'),
  'lazy Drive hydration helper is missing');
assert(source.includes("new Set(['completionImage','completionImages','proofImages'])"),
  'history evidence image fields are not protected from eager hydration');
assert(source.includes('window.DriveStorage.fromCloudValueSkippingHistoryImages(rawRows)'),
  'Firestore order listener must use lazy image hydration');
assert(!source.includes('window.DriveStorage.fromCloudValue(rawRows).then(rows=>'),
  'admin live listener still eagerly downloads images for every order');
assert(source.includes('scheduleLegacyOrderImageMigration(rows)'),
  'legacy Base64 migration must run through the throttled background queue');
assert(source.includes('function scheduleLegacyOrderImageMigration(rows)'),
  'bounded background migration queue is missing');
assert(source.includes('persistPackerOrderCache(safeRows,uid,{deferLegacyMigration:true})'),
  'employee live listener must not upload every legacy photo during cache writes');
assert(source.includes('function openDailyProofImage('),
  'daily proof images need an explicit lazy viewer');
assert(source.includes('let usersListCache=null,usersListCacheAt=0,usersListFetchPromise=null'),
  'Admin user list needs a time-bounded request cache');
assert(source.includes('Date.now()-usersListCacheAt<30000'),
  'Admin user list cache lifetime should avoid repeated Firestore reads during rendering');
assert(source.includes('function invalidateUserManagementUI()'),
  'explicit user-management changes must invalidate the UI cache');
assert(source.includes('const ORDER_LOCAL_CACHE_DAYS=30;'),
  'local order cache must have a bounded completed-history window');
assert(source.includes('function retainOperationalOrderRows(rows,now=Date.now())'),
  'operational cache pruning helper is missing');
assert(source.includes('localSnapshot.packingOrders=localSnapshot.packingOrders.filter(row=>!isCompletedOrderOlderThanCacheWindow(row))'),
  'old completed orders must be pruned from local cache snapshots only');
assert(source.includes("ordersRef().where('status','==','pending').onSnapshot"),
  'Admin live listener must be scoped to active orders');
assert(source.includes("ordersRef().where('completedAtMs','>=',recentCutoff).onSnapshot"),
  'Admin live listener must scope completed orders to a recent window');
assert(!source.includes("const unsub=ordersRef().onSnapshot(snap=>"),
  'Admin must not attach a whole-collection realtime listener');

// Verify cache retention boundaries without mutating the caller-owned array.
const cacheStart=source.indexOf('const ORDER_LOCAL_CACHE_DAYS=30;');
const cacheEnd=source.indexOf('function localSaveOnly(){',cacheStart);
assert(cacheStart>=0&&cacheEnd>cacheStart,'could not isolate order cache retention helpers');
const cacheCtx={Date,Number,String,Array};vm.createContext(cacheCtx);
vm.runInContext(source.slice(cacheStart,cacheEnd)+'\nthis.retain=retainOperationalOrderRows; this.old=isCompletedOrderOlderThanCacheWindow;',cacheCtx);
const now=Date.parse('2026-10-12T12:00:00Z');
const cacheInput=[
  {id:'pending-old',status:'pending',createdAtMs:now-365*86400000},
  {id:'completed-recent',status:'completed',completedAtMs:now-10*86400000},
  {id:'completed-old',status:'completed',completedAtMs:now-90*86400000},
  {id:'completed-unknown-date',status:'completed'}
];
assert.deepStrictEqual(Array.from(cacheCtx.retain(cacheInput,now)).map(x=>x.id),['pending-old','completed-recent','completed-unknown-date'],
  'cache should keep all pending, recent completed, and undated legacy orders, pruning only dated old completed rows');
assert.strictEqual(cacheInput.length,4,'cache pruning must not mutate the live array');

// Exercise the exact lazy hydration helper in isolation with a fake Drive downloader.
const helperStart = source.indexOf("async function fromCloudValueSkippingHistoryImages(value,key='')");
const helperEnd = source.indexOf('  async function connect()', helperStart);
assert(helperStart >= 0 && helperEnd > helperStart, 'could not isolate lazy hydration helper');
const helperSource = source.slice(helperStart, helperEnd).trim();
const ctx = {
  LAZY_HISTORY_IMAGE_KEYS: new Set(['completionImage','completionImages','proofImages']),
  fromCloudValue: async value => `hydrated:${value}`,
  Promise, Set, String, Object, Array
};
vm.createContext(ctx);
vm.runInContext(`${helperSource}\nthis.lazyHydrate=fromCloudValueSkippingHistoryImages;`, ctx);
(async () => {
  const input = {
    catalog: [{ image: 'drive://plant-photo' }],
    daily: [{ proofImages: { 'Nhan Vien': 'drive://daily-proof' } }],
    orders: [{ completionImage: 'drive://order-photo', completionImages: ['drive://photo-1','drive://photo-2'], name: 'order' }]
  };
  const result = await ctx.lazyHydrate(input);
  assert.strictEqual(result.catalog[0].image, 'hydrated:drive://plant-photo',
    'catalog plant pictures should retain existing hydration behavior');
  assert.strictEqual(result.daily[0].proofImages['Nhan Vien'], 'drive://daily-proof',
    'daily proof must remain a reference until explicitly opened');
  assert.strictEqual(result.orders[0].completionImage, 'drive://order-photo',
    'order photo must remain a reference until explicitly opened');
  assert.deepStrictEqual(Array.from(result.orders[0].completionImages), ['drive://photo-1','drive://photo-2'],
    'order photo array must remain references');

  // Exercise the render coalescer: repeated listener bursts schedule only one full redraw.
  const renderStart = source.indexOf('let orderSnapshotRenderTimer=0;');
  const renderEnd = source.indexOf('\nfunction renderAll(){', renderStart);
  assert(renderStart >= 0 && renderEnd > renderStart, 'could not isolate order snapshot render coalescer');
  const timers = [];
  let renders = 0;
  const renderCtx = { setTimeout: fn => { timers.push(fn); return timers.length; }, renderAll: () => { renders++; }, console };
  vm.createContext(renderCtx);
  vm.runInContext(source.slice(renderStart, renderEnd), renderCtx);
  renderCtx.scheduleOrderSnapshotRender();
  renderCtx.scheduleOrderSnapshotRender();
  renderCtx.scheduleOrderSnapshotRender();
  assert.strictEqual(timers.length, 1, 'snapshot burst must schedule only one timer');
  timers[0]();
  assert.strictEqual(renders, 1, 'snapshot burst must produce one full redraw');
  console.log('PERFORMANCE OPTIMIZATION TEST PASS: lazy historical images, bounded legacy migration, and coalesced snapshot renders');
})().catch(err => { console.error(err); process.exitCode = 1; });
