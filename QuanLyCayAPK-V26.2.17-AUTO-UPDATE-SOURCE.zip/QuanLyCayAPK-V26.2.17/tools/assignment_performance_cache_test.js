#!/usr/bin/env node
'use strict';
const fs=require('fs'),assert=require('assert');
const source=fs.readFileSync(require('path').join(__dirname,'../app/src/main/assets/index.html'),'utf8');
assert(source.includes('let assignmentOrdersCacheAt=0,assignmentOrdersFetchPromise=null;'),'assignment list request cache missing');
assert(source.includes('now-assignmentOrdersCacheAt<15000'),'assignment cache must suppress repeated full reads while selecting/filtering');
assert(source.includes('const rows=await getAdminAssignmentRows(s);'),'assignment UI must use cached loader');
assert(source.includes('// Update only the assignment panel; a full renderAll redraws unrelated reports, stock and quote tabs.'),'bulk assignment should not redraw unrelated tabs');
assert(source.includes('await renderAssignmentControls();\n  if(failed.length)'),'bulk assignment still refreshes assignment panel after writes');
console.log('ASSIGNMENT PERFORMANCE CACHE TEST PASS');
