package com.quanlycay.apk;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PageRange;
import android.print.PrintDocumentInfo;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.auth.UserRecoverableAuthException;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;
import org.json.JSONObject;
import org.json.JSONArray;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.text.TextPosition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONTokener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.regex.Pattern;
import java.util.List;

import android.util.Base64;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQ = 4101;
    private static final int DRIVE_SIGN_IN_REQ = 4102;
    private static final int TIKTOK_PDF_PICK_REQ = 4103;
    private static final String DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.file";
    private static final String DRIVE_FOLDER_NAME = "QuanLyCayAPK_Images";
    private static final ExecutorService DRIVE_EXECUTOR = Executors.newFixedThreadPool(3);
    private static final ExecutorService PDF_EXECUTOR = Executors.newSingleThreadExecutor();
    private static final ExecutorService UPDATE_EXECUTOR = Executors.newSingleThreadExecutor();
    private static final String GITHUB_LATEST_RELEASE_API = "https://api.github.com/repos/tiennt9939/QuanLyCayAPK/releases/latest";
    private static final String GITHUB_RELEASE_DOWNLOAD_PREFIX = "/tiennt9939/QuanLyCayAPK/releases/download/";
    private static final int UPDATE_INSTALL_PERMISSION_REQ = 4104;
    private File pendingUpdateApkFile;
    private String pendingDriveCallbackId = "";
    private String pendingTikTokPdfCallbackId = "";
    private static final long PRINT_CAPTURE_TIMEOUT_MS = 12000L;

    private WebView webView;
    private FrameLayout root;
    private WebView activePrintWebView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraOutputUri;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        try { PDFBoxResourceLoader.init(getApplicationContext()); } catch (Exception e) { android.util.Log.w("QuanLyCayAPK", "PDFBox init deferred", e); }
        root = new FrameLayout(this);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new AppChromeClient());
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AppChromeClient extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                         FileChooserParams params) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = callback;
            boolean imageOnly = false;
            String[] accepts = params.getAcceptTypes();
            if (accepts != null) {
                for (String a : accepts) {
                    if (a != null && a.toLowerCase().startsWith("image/")) imageOnly = true;
                }
            }

            if (params.isCaptureEnabled() && imageOnly) {
                launchCamera();
            } else {
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType(imageOnly ? "image/*" : "*/*");
                startActivityForResult(pick, FILE_CHOOSER_REQ);
            }
            return true;
        }
    }

    private void launchCamera() {
        try {
            Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME,
                        "ROLL_CAY_CANH_" + System.currentTimeMillis() + ".jpg");
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                values.put(MediaStore.Images.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES + "/ROLL CAY CANH");
                cameraOutputUri = getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
                camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
            startActivityForResult(camera, FILE_CHOOSER_REQ);
        } catch (Exception e) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = null;
            cameraOutputUri = null;
            Toast.makeText(this, "Không thể mở camera", Toast.LENGTH_SHORT).show();
        }
    }

    private String explainDriveSignInError(Exception e) {
        Throwable current = e;
        while (current != null) {
            if (current instanceof ApiException) {
                int statusCode = ((ApiException) current).getStatusCode();
                if (statusCode == 10) {
                    return "Google từ chối đăng nhập Drive (mã 10 / DEVELOPER_ERROR). "
                        + "Cần đăng ký SHA-1 và SHA-256 của APK đang cài cho ứng dụng Android "
                        + "com.quanlycay.apk trong Firebase/Google Cloud OAuth. "
                        + "Không phải lỗi ảnh hay Firestore.";
                }
                return "Google Sign-In lỗi mã " + statusCode + ": "
                    + (current.getMessage() == null ? current.getClass().getSimpleName() : current.getMessage());
            }
            current = current.getCause();
        }
        return e == null ? "Lỗi Google Drive" : String.valueOf(e.getMessage());
    }

    private String driveErrorJsonOuter(Exception e) {
        try { return new JSONObject().put("ok", false).put("error", explainDriveSignInError(e)).toString(); }
        catch (Exception ignored) { return "{\"ok\":false,\"error\":\"Lỗi Google Drive. Kiểm tra cấu hình OAuth và kết nối mạng.\"}"; }
    }
    private void deliverDriveResultOuter(String callbackId, String resultJson) {
        final String cb = callbackId != null && callbackId.matches("[A-Za-z0-9_]{1,80}") ? callbackId : "__driveBridgeInvalidCallback";
        final String payload = resultJson == null ? "{}" : resultJson;
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("if(window.__driveBridgeResponse)window.__driveBridgeResponse(" + JSONObject.quote(cb) + "," + JSONObject.quote(payload) + ");", null); });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == TIKTOK_PDF_PICK_REQ) {
            final String callback = safeJsCallback(pendingTikTokPdfCallbackId, "__tiktokPdfImportResult");
            pendingTikTokPdfCallbackId = "";
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                JSONObject cancelled = new JSONObject();
                try { cancelled.put("ok", false).put("cancelled", true).put("error", "Bạn đã hủy chọn file PDF."); } catch (Exception ignored) { }
                deliverTikTokPdfResult(callback, cancelled);
                return;
            }
            final Uri pdfUri = data.getData();
            try { getContentResolver().takePersistableUriPermission(pdfUri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            PDF_EXECUTOR.execute(() -> {
                try (InputStream input = getContentResolver().openInputStream(pdfUri)) {
                    if (input == null) throw new Exception("Không mở được file PDF đã chọn.");
                    try (PDDocument document = PDDocument.load(input)) {
                        int pagesCount = document.getNumberOfPages();
                        if (pagesCount < 1) throw new Exception("PDF không có trang.");
                        if (pagesCount > 200) throw new Exception("PDF có " + pagesCount + " trang. Vui lòng chia nhỏ file (tối đa 200 nhãn/lượt) để tránh treo máy.");
                        PDFTextStripper stripper = new LayoutPreservingPdfTextStripper();
                        // Keep the standard PDFBox text order as a compatibility fallback.
                        PDFTextStripper fallbackStripper = new PDFTextStripper();
                        fallbackStripper.setSortByPosition(true);
                        fallbackStripper.setShouldSeparateByBeads(false);
                        fallbackStripper.setLineSeparator("\n");
                        // Important root fix: PDFBox can emit table columns in content-stream order,
                        // not visual row order. Collect character coordinates and reconstruct rows
                        // left-to-right/top-to-bottom so the parser sees Product/SKU/Seller SKU/Qty
                        // on the same aligned line, including wrapped product names and SKU values.
                        VisualLayoutPdfTextStripper visualStripper = new VisualLayoutPdfTextStripper();
                        JSONArray pages = new JSONArray();
                        int totalChars = 0;
                        for (int page = 1; page <= pagesCount; page++) {
                            stripper.setStartPage(page);
                            stripper.setEndPage(page);
                            String text = stripper.getText(document);
                            fallbackStripper.setStartPage(page);
                            fallbackStripper.setEndPage(page);
                            String fallbackText = fallbackStripper.getText(document);
                            String visualText = visualStripper.extractVisualPage(document, page);
                            totalChars += (text == null ? 0 : text.length())
                                + (fallbackText == null ? 0 : fallbackText.length())
                                + (visualText == null ? 0 : visualText.length());
                            if (totalChars > 1_500_000) throw new Exception("PDF có quá nhiều nội dung văn bản; vui lòng chia file nhỏ hơn (giới hạn 1.500.000 ký tự/lượt).");
                            pages.put(new JSONObject().put("page", page).put("text", text == null ? "" : text)
                                .put("fallbackText", fallbackText == null ? "" : fallbackText)
                                .put("visualText", visualText == null ? "" : visualText));
                        }
                        JSONObject payload = new JSONObject().put("ok", true).put("pageCount", pagesCount).put("pages", pages);
                        deliverTikTokPdfResult(callback, payload);
                    }
                } catch (Exception e) {
                    android.util.Log.e("QuanLyCayAPK", "TikTok label PDF extraction failed", e);
                    JSONObject error = new JSONObject();
                    try { error.put("ok", false).put("error", "Không đọc được PDF: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage())); } catch (Exception ignored) { }
                    deliverTikTokPdfResult(callback, error);
                }
            });
            return;
        }
        if (requestCode == DRIVE_SIGN_IN_REQ) {
            String callback = pendingDriveCallbackId;
            pendingDriveCallbackId = "";
            try {
                GoogleSignInAccount account = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class);
                if (account == null) throw new Exception("Không nhận được tài khoản Google");
                DRIVE_EXECUTOR.execute(() -> {
                    try {
                        AndroidBridge driveBridge = new AndroidBridge();
                        String token = driveBridge.getDriveAccessToken(account);
                        String folderId = driveBridge.ensureDriveFolder(token, account.getEmail());
                        getSharedPreferences("drive_store", MODE_PRIVATE).edit()
                            .putString("account_email", account.getEmail() == null ? "" : account.getEmail())
                            .putString("folder_id_" + (account.getEmail() == null ? "default" : account.getEmail().toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9_-]", "_")), folderId)
                            .apply();
                        deliverDriveResultOuter(callback, new JSONObject().put("ok", true)
                            .put("email", account.getEmail() == null ? "" : account.getEmail())
                            .put("folderId", folderId).toString());
                    } catch (Exception e) {
                        deliverDriveResultOuter(callback, driveErrorJsonOuter(e));
                    }
                });
            } catch (Exception e) {
                deliverDriveResultOuter(callback, driveErrorJsonOuter(e));
            }
            return;
        }
        if (requestCode == UPDATE_INSTALL_PERMISSION_REQ) {
            File apk = pendingUpdateApkFile;
            pendingUpdateApkFile = null;
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || getPackageManager().canRequestPackageInstalls()) {
                if (apk != null && apk.isFile() && apk.length() > 0) installDownloadedUpdate(apk);
                else Toast.makeText(this, "Không tìm thấy APK tải về. Hãy kiểm tra cập nhật lại.", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Bạn chưa cấp quyền cài ứng dụng từ nguồn này. Chưa có gì được cài đặt.", Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (requestCode != FILE_CHOOSER_REQ || filePathCallback == null) return;

        Uri result = null;
        if (resultCode == RESULT_OK) {
            if (cameraOutputUri != null) {
                result = cameraOutputUri;
            } else if (data != null) {
                if (data.getData() != null) {
                    result = data.getData();
                } else if (data.getExtras() != null && data.getExtras().get("data") instanceof Bitmap) {
                    result = saveLegacyCameraBitmap((Bitmap) data.getExtras().get("data"));
                }
            }
        }

        filePathCallback.onReceiveValue(result == null ? null : new Uri[]{result});
        filePathCallback = null;
        if (result == null && cameraOutputUri != null) {
            try { getContentResolver().delete(cameraOutputUri, null, null); } catch (Exception ignored) {}
        }
        cameraOutputUri = null;
    }

    private void deliverAppUpdateResult(String callbackName, JSONObject payload, boolean installCallback) {
        final String fallback = installCallback ? "__appUpdateInstallResult" : "__appUpdateCheckResult";
        final String cb = safeJsCallback(callbackName, fallback);
        final String json = payload == null ? "{}" : payload.toString();
        runOnUiThread(() -> {
            if (webView != null) {
                webView.evaluateJavascript("if(window[" + JSONObject.quote(cb) + "])window[" + JSONObject.quote(cb) + "](" + json + ");", null);
            }
        });
    }

    private static String readUtf8(InputStream in, int maxBytes) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int count, total = 0;
        while ((count = in.read(buffer)) != -1) {
            total += count;
            if (total > maxBytes) throw new Exception("Phản hồi máy chủ vượt giới hạn an toàn.");
            out.write(buffer, 0, count);
        }
        return out.toString("UTF-8");
    }

    private HttpURLConnection openHttpsConnection(String rawUrl, int connectTimeout, int readTimeout) throws Exception {
        URL url = new URL(rawUrl);
        if (!"https".equalsIgnoreCase(url.getProtocol())) throw new Exception("Chỉ chấp nhận kết nối HTTPS.");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(connectTimeout);
        connection.setReadTimeout(readTimeout);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("User-Agent", "ROLL-CAY-CANH-Android-Updater/1.0");
        connection.setRequestProperty("Accept", "application/vnd.github+json, application/octet-stream, text/plain");
        return connection;
    }

    private boolean isAllowedReleaseAssetUrl(String rawUrl) {
        try {
            URL url = new URL(rawUrl);
            return "https".equalsIgnoreCase(url.getProtocol())
                && "github.com".equalsIgnoreCase(url.getHost())
                && url.getPath() != null
                && url.getPath().startsWith(GITHUB_RELEASE_DOWNLOAD_PREFIX)
                && !url.getPath().contains("..")
                && url.getUserInfo() == null;
        } catch (Exception ignored) { return false; }
    }

    private static int compareDottedVersions(String first, String second) {
        String a = first == null ? "" : first.replaceFirst("(?i)^v", "").trim();
        String b = second == null ? "" : second.replaceFirst("(?i)^v", "").trim();
        String[] aa = a.split("\\.", -1), bb = b.split("\\.", -1);
        int length = Math.max(aa.length, bb.length);
        for (int i = 0; i < length; i++) {
            long x = 0, y = 0;
            try { if (i < aa.length) x = Long.parseLong(aa[i].replaceAll("[^0-9].*$", "")); } catch (Exception ignored) { }
            try { if (i < bb.length) y = Long.parseLong(bb[i].replaceAll("[^0-9].*$", "")); } catch (Exception ignored) { }
            if (x < y) return -1;
            if (x > y) return 1;
        }
        return 0;
    }

    private JSONObject fetchLatestRelease() throws Exception {
        HttpURLConnection connection = openHttpsConnection(GITHUB_LATEST_RELEASE_API, 12000, 15000);
        try {
            int status = connection.getResponseCode();
            if (status != 200) {
                String detail = "";
                try { detail = readUtf8(connection.getErrorStream(), 12000); } catch (Exception ignored) { }
                throw new Exception(status == 404
                    ? "Chưa có GitHub Release công khai. Hiện GitHub Actions mới tạo APK Artifact; workflow chưa phát hành Release vì chưa xác minh được khóa ký ổn định. Hoàn tất thiết lập khóa ký rồi phát hành Release để bật cập nhật trong ứng dụng."
                    : "GitHub trả về HTTP " + status + (detail.isEmpty() ? "" : ": " + detail));
            }
            return new JSONObject(readUtf8(connection.getInputStream(), 2 * 1024 * 1024));
        } finally { connection.disconnect(); }
    }

    private JSONObject inspectLatestRelease() throws Exception {
        JSONObject release = fetchLatestRelease();
        String tag = release.optString("tag_name", "").trim();
        String latestVersion = tag.replaceFirst("(?i)^v", "");
        if (latestVersion.isEmpty()) throw new Exception("Bản phát hành không có tag phiên bản hợp lệ.");
        JSONArray assets = release.optJSONArray("assets");
        JSONObject apkAsset = null;
        if (assets != null) {
            // Prefer a versioned app asset, but allow any APK for this single-app repository.
            for (int i = 0; i < assets.length(); i++) {
                JSONObject asset = assets.optJSONObject(i);
                String name = asset == null ? "" : asset.optString("name", "");
                if (name.toLowerCase(Locale.ROOT).endsWith(".apk")) {
                    apkAsset = asset;
                    if (name.equalsIgnoreCase("QuanLyCayCanh-" + latestVersion + ".apk")
                        || name.equalsIgnoreCase("QuanLyCayAPK-V" + latestVersion + ".apk")) break;
                }
            }
        }
        String body = release.optString("body", "");
        int releaseCode = -1;
        java.util.regex.Matcher codeMatcher = Pattern.compile("(?i)version\\s*code(?:\\s*[:=]\\s*|\\s+)(\\d+)").matcher(body);
        if (codeMatcher.find()) { try { releaseCode = Integer.parseInt(codeMatcher.group(1)); } catch (Exception ignored) { } }
        boolean newer = releaseCode > 0 ? releaseCode > BuildConfig.VERSION_CODE
            : compareDottedVersions(latestVersion, BuildConfig.VERSION_NAME) > 0;
        JSONObject result = new JSONObject()
            .put("ok", true)
            .put("currentVersion", BuildConfig.VERSION_NAME)
            .put("currentVersionCode", BuildConfig.VERSION_CODE)
            .put("latestVersion", latestVersion)
            .put("latestVersionCode", releaseCode)
            .put("hasUpdate", newer)
            .put("releaseName", release.optString("name", "V" + latestVersion))
            .put("releaseNotes", body)
            .put("releasePageUrl", release.optString("html_url", "https://github.com/tiennt9939/QuanLyCayAPK/releases"))
            .put("publishedAt", release.optString("published_at", ""));
        if (newer) {
            if (apkAsset == null) throw new Exception("Có bản " + latestVersion + " nhưng GitHub Releases chưa có tệp APK. Hãy chạy workflow phát hành trước.");
            String apkUrl = apkAsset.optString("browser_download_url", "");
            String apkName = apkAsset.optString("name", "");
            if (!isAllowedReleaseAssetUrl(apkUrl)) throw new Exception("Đường dẫn APK phát hành không hợp lệ hoặc không an toàn.");
            JSONObject checksumAsset = null;
            String expectedName = apkName + ".sha256";
            if (assets != null) for (int i = 0; i < assets.length(); i++) {
                JSONObject asset = assets.optJSONObject(i);
                if (asset != null && expectedName.equalsIgnoreCase(asset.optString("name", ""))) { checksumAsset = asset; break; }
            }
            if (checksumAsset == null) throw new Exception("Bản APK mới chưa có file SHA-256 để kiểm tra tính toàn vẹn. Chưa thể cài đặt an toàn.");
            String checksumUrl = checksumAsset.optString("browser_download_url", "");
            if (!isAllowedReleaseAssetUrl(checksumUrl)) throw new Exception("Đường dẫn SHA-256 không hợp lệ.");
            result.put("apkName", apkName).put("apkUrl", apkUrl).put("checksumUrl", checksumUrl);
        }
        return result;
    }

    private String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(file)) {
            byte[] buffer = new byte[65536];
            int count;
            while ((count = in.read(buffer)) != -1) digest.update(buffer, 0, count);
        }
        StringBuilder result = new StringBuilder(64);
        for (byte b : digest.digest()) result.append(String.format(Locale.ROOT, "%02x", b & 0xff));
        return result.toString();
    }

    private String downloadSmallText(String url) throws Exception {
        HttpURLConnection connection = openHttpsConnection(url, 15000, 30000);
        try {
            int status = connection.getResponseCode();
            if (status != 200) throw new Exception("Không tải được SHA-256 (HTTP " + status + ").");
            return readUtf8(connection.getInputStream(), 4096);
        } finally { connection.disconnect(); }
    }

    private File downloadVerifiedUpdate(String apkUrl, String checksumUrl) throws Exception {
        if (!isAllowedReleaseAssetUrl(apkUrl) || !isAllowedReleaseAssetUrl(checksumUrl))
            throw new Exception("Đường dẫn tải không thuộc GitHub Releases của ứng dụng.");
        String checksumText = downloadSmallText(checksumUrl).trim();
        java.util.regex.Matcher hashMatcher = Pattern.compile("(?i)(?:^|\\s)([a-f0-9]{64})(?:\\s|$)").matcher(checksumText + " ");
        if (!hashMatcher.find()) throw new Exception("File SHA-256 của bản phát hành không hợp lệ.");
        String expectedHash = hashMatcher.group(1).toLowerCase(Locale.ROOT);
        File directory = new File(getCacheDir(), "updates");
        if (!directory.exists() && !directory.mkdirs()) throw new Exception("Không tạo được thư mục tải bản cập nhật.");
        File temporary = new File(directory, "roll-cay-update.apk.part");
        File output = new File(directory, "roll-cay-update.apk");
        if (temporary.exists()) temporary.delete();
        HttpURLConnection connection = openHttpsConnection(apkUrl, 15000, 45000);
        long total = 0L;
        long contentLength = -1L;
        try {
            int status = connection.getResponseCode();
            if (status != 200) throw new Exception("Tải APK thất bại (HTTP " + status + ").");
            contentLength = connection.getContentLength();
            if (contentLength > 150L * 1024L * 1024L) throw new Exception("APK vượt quá giới hạn 150 MB.");
            try (InputStream in = connection.getInputStream(); FileOutputStream out = new FileOutputStream(temporary)) {
                byte[] buffer = new byte[65536];
                int count;
                while ((count = in.read(buffer)) != -1) {
                    total += count;
                    if (total > 150L * 1024L * 1024L) throw new Exception("APK tải về vượt giới hạn 150 MB.");
                    out.write(buffer, 0, count);
                }
                out.getFD().sync();
            }
        } finally { connection.disconnect(); }
        if (total <= 0L || (contentLength > 0L && total != contentLength)) {
            temporary.delete(); throw new Exception("File APK tải về không đầy đủ.");
        }
        String actualHash = sha256(temporary);
        if (!expectedHash.equals(actualHash)) { temporary.delete(); throw new Exception("SHA-256 không khớp. Đã chặn cài APK bị lỗi hoặc thay đổi."); }
        if (output.exists() && !output.delete()) { temporary.delete(); throw new Exception("Không thay thế được APK cũ trong bộ nhớ tạm."); }
        if (!temporary.renameTo(output)) { temporary.delete(); throw new Exception("Không hoàn tất được file APK tải về."); }
        return output;
    }

    private void startInstallerPermissionOrInstall(File apk) {
        if (apk == null || !apk.isFile() || apk.length() <= 0) {
            Toast.makeText(this, "Không tìm thấy APK cập nhật.", Toast.LENGTH_LONG).show(); return;
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !getPackageManager().canRequestPackageInstalls()) {
                pendingUpdateApkFile = apk;
                Intent settings = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
                startActivityForResult(settings, UPDATE_INSTALL_PERMISSION_REQ);
                deliverAppUpdateResult("__appUpdateInstallResult", new JSONObject()
                    .put("ok", true).put("status", "permission_required")
                    .put("message", "Hãy bật quyền cho phép ứng dụng cài đặt ứng dụng không rõ nguồn gốc, rồi quay lại để tiếp tục."), true);
                return;
            }
            installDownloadedUpdate(apk);
        } catch (Exception e) {
            JSONObject error = new JSONObject();
            try { error.put("ok", false).put("status", "error")
                .put("error", "Không mở được trình cài đặt: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage())); }
            catch (Exception ignored) { }
            deliverAppUpdateResult("__appUpdateInstallResult", error, true);
        }
    }

    private void installDownloadedUpdate(File apk) {
        try {
            Uri contentUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apk);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(contentUri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            deliverAppUpdateResult("__appUpdateInstallResult", new JSONObject().put("ok", true)
                .put("status", "installer_opened")
                .put("message", "Đã mở trình cài đặt Android. Hãy kiểm tra phiên bản và xác nhận Cài đặt."), true);
        } catch (Exception e) {
            JSONObject error = new JSONObject();
            try {
                error.put("ok", false)
                    .put("status", "error")
                    .put("error", "Android không mở được file APK: " +
                        (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
            } catch (Exception ignored) { }
            deliverAppUpdateResult("__appUpdateInstallResult", error, true);
        }
    }

    private String safeJsCallback(String value, String fallback) {
        return value != null && value.matches("[A-Za-z_$][A-Za-z0-9_$]{0,79}") ? value : fallback;
    }

    private void deliverTikTokPdfResult(String callbackName, JSONObject payload) {
        final String cb = safeJsCallback(callbackName, "__tiktokPdfImportResult");
        final String json = payload == null ? "{}" : payload.toString();
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript("if(window[" + JSONObject.quote(cb) + "])window[" + JSONObject.quote(cb) + "](" + json + ");", null);
        });
    }

    private void deliverTikTokBarcodeResult(String callbackName, JSONObject payload) {
        final String cb = safeJsCallback(callbackName, "__tiktokBarcodeResult");
        final String json = payload == null ? "{}" : payload.toString();
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript("if(window[" + JSONObject.quote(cb) + "])window[" + JSONObject.quote(cb) + "](" + json + ");", null);
        });
    }

    /** Keeps column gaps from the PDF so the offline parser can split Product / SKU / Seller SKU / Qty.
     * This matters because plain PDFTextStripper output often collapses tabular columns into one phrase. */
    private static final class LayoutPreservingPdfTextStripper extends PDFTextStripper {
        LayoutPreservingPdfTextStripper() throws java.io.IOException {
            super();
            setSortByPosition(true);
            setShouldSeparateByBeads(false);
            setLineSeparator("\n");
        }

        @Override
        protected void writeString(String text, List<TextPosition> positions) throws java.io.IOException {
            if (positions == null || positions.isEmpty()) {
                super.writeString(text);
                return;
            }
            StringBuilder aligned = new StringBuilder(text == null ? 64 : text.length() + 32);
            float previousEnd = -1f;
            for (TextPosition position : positions) {
                if (position == null) continue;
                String unicode = position.getUnicode();
                if (unicode == null || unicode.isEmpty()) continue;
                float x = position.getXDirAdj();
                float width = Math.max(0f, position.getWidthDirAdj());
                if (previousEnd >= 0f && !unicode.trim().isEmpty()) {
                    float gap = x - previousEnd;
                    float spaceWidth = Math.max(1.5f, position.getWidthOfSpace());
                    // Natural word gaps are already represented as spaces; add more only for distinct columns.
                    if (gap > spaceWidth * 2.2f) {
                        int count = Math.min(100, Math.max(1, Math.round(gap / spaceWidth)));
                        for (int i = 0; i < count; i++) aligned.append(' ');
                    }
                }
                aligned.append(unicode);
                previousEnd = x + width;
            }
            super.writeString(aligned.toString());
        }
    }

    /**
     * Reconstructs each PDF page as visual text rows from glyph coordinates. Unlike the
     * ordinary PDFTextStripper output, this does not assume that the PDF content stream
     * was saved in reading order (TikTok labels often interleave table columns with other text).
     */
    private static final class VisualLayoutPdfTextStripper extends PDFTextStripper {
        private static final class Glyph {
            final String text;
            final float x, y, width, spaceWidth;
            Glyph(String text, float x, float y, float width, float spaceWidth) {
                this.text = text; this.x = x; this.y = y; this.width = width; this.spaceWidth = spaceWidth;
            }
        }
        private static final class VisualLine {
            final List<Glyph> glyphs = new ArrayList<>();
            float ySum;
            int yCount;
            float y() { return yCount == 0 ? 0f : ySum / yCount; }
            void add(Glyph glyph) { glyphs.add(glyph); ySum += glyph.y; yCount++; }
        }

        private final List<Glyph> glyphs = new ArrayList<>();

        VisualLayoutPdfTextStripper() throws java.io.IOException {
            super();
            setSortByPosition(true);
            setShouldSeparateByBeads(false);
            setSuppressDuplicateOverlappingText(true);
        }

        @Override
        protected void processTextPosition(TextPosition position) {
            if (position != null) {
                String unicode = position.getUnicode();
                if (unicode != null && !unicode.isEmpty()) {
                    float x = position.getXDirAdj();
                    float y = position.getYDirAdj();
                    float width = Math.max(0f, position.getWidthDirAdj());
                    float spaceWidth = Math.max(1.5f, position.getWidthOfSpace());
                    glyphs.add(new Glyph(unicode, x, y, width, spaceWidth));
                }
            }
            super.processTextPosition(position);
        }

        String extractVisualPage(PDDocument document, int page) throws java.io.IOException {
            glyphs.clear();
            setStartPage(page);
            setEndPage(page);
            getText(document); // processTextPosition populates glyphs; returned stream order is intentionally ignored.
            return buildVisualText();
        }

        private String buildVisualText() {
            if (glyphs.isEmpty()) return "";
            // PDF pages contain repeated barcodes in the same visual location. De-duplicate only
            // identical glyphs at effectively identical coordinates, never equal text elsewhere.
            Set<String> seen = new HashSet<>();
            List<Glyph> unique = new ArrayList<>(glyphs.size());
            for (Glyph g : glyphs) {
                String key = Math.round(g.x * 2f) + "|" + Math.round(g.y * 2f) + "|" + g.text;
                if (seen.add(key)) unique.add(g);
            }
            unique.sort(Comparator.comparingDouble((Glyph g) -> g.y).thenComparingDouble(g -> g.x));

            List<VisualLine> lines = new ArrayList<>();
            for (Glyph g : unique) {
                VisualLine line = lines.isEmpty() ? null : lines.get(lines.size() - 1);
                // A 2.8pt baseline tolerance joins characters from the same printed row while
                // keeping adjacent rows (normally 8pt or more apart) separate.
                if (line == null || Math.abs(g.y - line.y()) > 2.8f) {
                    line = new VisualLine();
                    lines.add(line);
                }
                line.add(g);
            }

            StringBuilder output = new StringBuilder(unique.size() + lines.size() * 8);
            for (VisualLine line : lines) {
                line.glyphs.sort(Comparator.comparingDouble(g -> g.x));
                float previousEnd = -1f;
                float previousSpaceWidth = 3f;
                for (Glyph g : line.glyphs) {
                    if (previousEnd >= 0f && !g.text.trim().isEmpty()) {
                        float gap = g.x - previousEnd;
                        float spaceWidth = Math.max(1.5f, Math.max(previousSpaceWidth, g.spaceWidth));
                        if (gap > spaceWidth * 0.45f) {
                            int spaces = Math.min(100, Math.max(1, Math.round(gap / spaceWidth)));
                            for (int i = 0; i < spaces; i++) output.append(' ');
                        }
                    }
                    output.append(g.text);
                    previousEnd = Math.max(previousEnd, g.x + g.width);
                    previousSpaceWidth = g.spaceWidth;
                }
                output.append('\n');
            }
            return output.toString();
        }
    }

    private Uri saveLegacyCameraBitmap(Bitmap bitmap) {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME,
                    "ROLL_CAY_CANH_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return null;
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null || !bitmap.compress(Bitmap.CompressFormat.JPEG, 88, out)) return null;
            }
            return uri;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Capture only the prepared print area + the page <head>. This avoids sending the
     * entire live WebView DOM into Android's print engine and avoids re-running the app
     * scripts in the print WebView.
     */
    private static final String CAPTURE_PRINT_HTML_JS =
            "(function(){" +
            "var ids=['orderPrintArea','quotePdfPrint'];" +
            "var el=null;" +
            "for(var i=0;i<ids.length;i++){var x=document.getElementById(ids[i]);" +
            "if(x&&x.innerHTML&&((x.getAttribute('aria-hidden')==='false')||x.classList.contains('show'))){el=x;break;}}" +
            "if(!el)return '';" +
            "function attrs(node){var s='';for(var i=0;i<node.attributes.length;i++){var a=node.attributes[i];" +
            "s+=' '+a.name+'=\\\"'+String(a.value).replace(/&/g,'&amp;').replace(/\\\"/g,'&quot;')+'\\\"';}return s;}" +
            "return '<!doctype html><html'+attrs(document.documentElement)+'><head>'+document.head.innerHTML+'</head><body'+attrs(document.body)+'>'+el.outerHTML+'</body></html>';" +
            "})()";

    private String decodeJavascriptString(String raw) throws Exception {
        Object value = new JSONTokener(raw == null ? "null" : raw).nextValue();
        if (!(value instanceof String)) return "";
        return (String) value;
    }

    private String sanitizePrintHtml(String html) {
        if (html == null) return "";
        return Pattern.compile("<script\\b[^>]*>.*?</script>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL)
                .matcher(html).replaceAll("");
    }

    private PrintAttributes buildPrintAttributes(boolean orderLabel) {
        if (orderLabel) {
            return new PrintAttributes.Builder()
                    .setMediaSize(new PrintAttributes.MediaSize(
                            "ROLL_GARDEN_65X100", "65 x 100 mm", 2559, 3937))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();
        }
        return new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build();
    }

    private void cleanupPrintWebView(WebView printView) {
        if (printView == null) return;
        try { printView.stopLoading(); } catch (Exception ignored) {}
        try { printView.setWebViewClient(null); } catch (Exception ignored) {}
        try { printView.destroy(); } catch (Exception ignored) {}
        if (root != null) {
            try { root.removeView(printView); } catch (Exception ignored) {}
        }
        if (activePrintWebView == printView) activePrintWebView = null;
    }

    private void startIsolatedPrint(String jobName, String html, PrintAttributes attributes) {
        if (html == null || html.trim().length() < 50) {
            Toast.makeText(this, "Không lấy được nội dung để in", Toast.LENGTH_SHORT).show();
            return;
        }
        if (activePrintWebView != null) {
            cleanupPrintWebView(activePrintWebView);
        }

        final WebView printView = new WebView(this);
        activePrintWebView = printView;
        printView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        WebSettings ps = printView.getSettings();
        ps.setJavaScriptEnabled(false);
        ps.setDomStorageEnabled(false);
        ps.setAllowFileAccess(true);
        ps.setAllowContentAccess(true);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(2, 2);
        lp.leftMargin = 1;
        lp.topMargin = 1;
        root.addView(printView, lp);

        final boolean[] started = {false};
        final Runnable start = () -> {
            if (started[0] || activePrintWebView != printView) return;
            started[0] = true;
            try {
                PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (printManager == null) {
                    cleanupPrintWebView(printView);
                    Toast.makeText(this, "Thiết bị không hỗ trợ in", Toast.LENGTH_SHORT).show();
                    return;
                }
                PrintDocumentAdapter delegate = printView.createPrintDocumentAdapter(jobName);
                if (delegate == null) {
                    cleanupPrintWebView(printView);
                    Toast.makeText(this, "Không thể tạo tài liệu in", Toast.LENGTH_SHORT).show();
                    return;
                }
                printManager.print(jobName, new ReleaseAfterPrintAdapter(delegate, printView), attributes);
            } catch (Throwable e) {
                cleanupPrintWebView(printView);
                Toast.makeText(this, "Không thể mở chức năng in: " + safeError(e), Toast.LENGTH_LONG).show();
            }
        };

        printView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                mainHandler.postDelayed(start, 250);
            }
        });

        printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        mainHandler.postDelayed(() -> {
            if (!started[0]) start.run();
        }, 3500);
        mainHandler.postDelayed(() -> {
            if (activePrintWebView == printView && !started[0]) {
                cleanupPrintWebView(printView);
                Toast.makeText(this, "Không thể chuẩn bị nội dung in. Vui lòng thử lại.", Toast.LENGTH_LONG).show();
            }
        }, PRINT_CAPTURE_TIMEOUT_MS);
    }

    private String safeError(Throwable e) {
        String m = e == null ? "" : e.getMessage();
        if (m == null || m.trim().isEmpty()) return e == null ? "Lỗi không xác định" : e.getClass().getSimpleName();
        return m;
    }

    private class ReleaseAfterPrintAdapter extends PrintDocumentAdapter {
        private final PrintDocumentAdapter delegate;
        private final WebView printView;
        ReleaseAfterPrintAdapter(PrintDocumentAdapter delegate, WebView printView) {
            this.delegate = delegate;
            this.printView = printView;
        }
        @Override public void onStart() { delegate.onStart(); }
        @Override public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                                       android.os.CancellationSignal cancellationSignal,
                                       LayoutResultCallback callback, Bundle extras) {
            delegate.onLayout(oldAttributes, newAttributes, cancellationSignal, callback, extras);
        }
        @Override public void onWrite(android.print.PageRange[] pages, android.os.ParcelFileDescriptor destination,
                                      android.os.CancellationSignal cancellationSignal, WriteResultCallback callback) {
            delegate.onWrite(pages, destination, cancellationSignal, callback);
        }
        @Override public void onFinish() {
            try { delegate.onFinish(); } finally { cleanupPrintWebView(printView); }
        }
    }

    private void startPdfExport(String jobName, String html) {
        if (html == null || html.trim().length() < 50) {
            Toast.makeText(this, "Không lấy được nội dung báo giá", Toast.LENGTH_SHORT).show();
            return;
        }

        // Android PrintDocumentAdapter.LayoutResultCallback and WriteResultCallback
        // constructors are package-private. We must NOT instantiate them directly.
        // Use Android's public PrintManager pipeline instead; the system print UI
        // can then save the prepared A4 document as PDF.
        startIsolatedPrint(jobName, html, buildPrintAttributes(false));
    }

    private void savePdfToDownloads(String jobName, File tmp) throws Exception {
        String name=(jobName==null||jobName.trim().isEmpty()?"Bao-gia-ROLL-GARDEN":jobName).replaceAll("[^a-zA-Z0-9._-]","_");
        if(!name.toLowerCase().endsWith(".pdf"))name+=".pdf";
        if(Build.VERSION.SDK_INT>=29){
            ContentValues values=new ContentValues(); values.put(MediaStore.Downloads.DISPLAY_NAME,name); values.put(MediaStore.Downloads.MIME_TYPE,"application/pdf"); values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/ROLL CAY CANH"); values.put(MediaStore.Downloads.IS_PENDING,1);
            Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values); if(uri==null)throw new Exception("Không tạo được file trong Tải xuống");
            try(InputStream in=new FileInputStream(tmp); OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception("Không mở được file đích"); byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)out.write(buf,0,n);}
            ContentValues done=new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING,0); getContentResolver().update(uri,done,null,null);
        } else {File dir=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);if(!dir.exists()&&!dir.mkdirs())throw new Exception("Không tạo được thư mục Tải xuống");try(FileInputStream in=new FileInputStream(tmp);FileOutputStream out=new FileOutputStream(new File(dir,name))){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}}
        Toast.makeText(this,"✅ Đã xuất PDF: Tải xuống / ROLL CAY CANH / "+name,Toast.LENGTH_LONG).show();
        if(webView!=null)webView.evaluateJavascript("window.finishQuotePdfExport&&window.finishQuotePdfExport(true)",null);
    }
    public class AndroidBridge {
        @JavascriptInterface
        public String getAppVersionInfo() {
            try { return new JSONObject().put("versionName", BuildConfig.VERSION_NAME)
                .put("versionCode", BuildConfig.VERSION_CODE).toString(); }
            catch (Exception ignored) { return "{\"versionName\":\"unknown\",\"versionCode\":0}"; }
        }

        @JavascriptInterface
        public void checkForAppUpdates(String callbackId) {
            final String cb = safeJsCallback(callbackId, "__appUpdateCheckResult");
            UPDATE_EXECUTOR.execute(() -> {
                JSONObject result;
                try { result = inspectLatestRelease(); }
                catch (Exception e) {
                    result = new JSONObject();
                    try { result.put("ok", false).put("currentVersion", BuildConfig.VERSION_NAME)
                        .put("error", e.getMessage() == null ? "Không kiểm tra được bản cập nhật." : e.getMessage()); }
                    catch (Exception ignored) { }
                }
                deliverAppUpdateResult(cb, result, false);
            });
        }

        @JavascriptInterface
        public void downloadAndInstallAppUpdate(String apkUrl, String checksumUrl, String callbackId) {
            final String cb = safeJsCallback(callbackId, "__appUpdateInstallResult");
            UPDATE_EXECUTOR.execute(() -> {
                try {
                    File apk = downloadVerifiedUpdate(apkUrl == null ? "" : apkUrl, checksumUrl == null ? "" : checksumUrl);
                    runOnUiThread(() -> startInstallerPermissionOrInstall(apk));
                } catch (Exception e) {
                    JSONObject result = new JSONObject();
                    try { result.put("ok", false).put("status", "error")
                        .put("error", e.getMessage() == null ? "Tải bản cập nhật thất bại." : e.getMessage()); }
                    catch (Exception ignored) { }
                    deliverAppUpdateResult(cb, result, true);
                }
            });
        }
        @JavascriptInterface
        public boolean isDriveConnected() {
            GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(MainActivity.this);
            if (account == null || account.getEmail() == null) return false;
            return GoogleSignIn.hasPermissions(account, new Scope(DRIVE_SCOPE));
        }

        @JavascriptInterface
        public void connectGoogleDrive(String callbackId) {
            final String cb = safeCallbackId(callbackId);
            runOnUiThread(() -> {
                try {
                    pendingDriveCallbackId = cb;
                    GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestEmail().requestScopes(new Scope(DRIVE_SCOPE)).build();
                    GoogleSignInClient client = GoogleSignIn.getClient(MainActivity.this, options);
                    startActivityForResult(client.getSignInIntent(), DRIVE_SIGN_IN_REQ);
                } catch (Exception e) {
                    deliverDriveResult(cb, driveErrorJson(e));
                }
            });
        }

        @JavascriptInterface
        public void uploadDriveImage(String dataUrl, String fileName, String callbackId) {
            final String cb = safeCallbackId(callbackId);
            DRIVE_EXECUTOR.execute(() -> {
                try {
                    GoogleSignInAccount account = requireDriveAccount();
                    String token = getDriveAccessToken(account);
                    String folder = ensureDriveFolder(token, account.getEmail());
                    String raw = dataUrl == null ? "" : dataUrl.trim();
                    int comma = raw.indexOf(',');
                    String mime = "image/jpeg";
                    if (raw.startsWith("data:")) {
                        int semi = raw.indexOf(';');
                        if (semi > 5) mime = raw.substring(5, semi);
                    }
                    if (comma >= 0) raw = raw.substring(comma + 1);
                    if (raw.isEmpty()) throw new Exception("Dữ liệu ảnh trống");
                    byte[] bytes = Base64.decode(raw, Base64.DEFAULT);
                    String name = (fileName == null || fileName.trim().isEmpty() ? "image.jpg" : fileName.trim())
                        .replaceAll("[^a-zA-Z0-9._-]", "_");
                    JSONObject meta = new JSONObject();
                    meta.put("name", name); meta.put("mimeType", mime);
                    meta.put("parents", new JSONArray().put(folder));
                    String boundary = "QuanLyCayAPK_" + System.currentTimeMillis();
                    URL url = new URL("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType");
                    HttpURLConnection c = (HttpURLConnection) url.openConnection();
                    c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(20000); c.setReadTimeout(30000);
                    c.setRequestProperty("Authorization", "Bearer " + token);
                    c.setRequestProperty("Content-Type", "multipart/related; boundary=" + boundary);
                    try (OutputStream out = c.getOutputStream()) {
                        out.write(("--" + boundary + "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" + meta.toString() + "\r\n").getBytes(StandardCharsets.UTF_8));
                        out.write(("--" + boundary + "\r\nContent-Type: " + mime + "\r\n\r\n").getBytes(StandardCharsets.UTF_8));
                        out.write(bytes);
                        out.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
                    }
                    String response = readHttpResponse(c);
                    int uploadCode = c.getResponseCode();
                    JSONObject result = new JSONObject(response);
                    if (uploadCode < 200 || uploadCode >= 300 || !result.has("id")) throw new Exception("Drive không lưu được ảnh (HTTP " + uploadCode + "): " + response);
                    String uploadedId = result.getString("id");
                    // Verify a real non-empty file exists in the target folder before we let
                    // Firestore replace Base64 with drive://. This prevents false-success sync.
                    URL verifyUrl = new URL("https://www.googleapis.com/drive/v3/files/" + URLEncoder.encode(uploadedId, "UTF-8") + "?fields=id,name,mimeType,parents,size");
                    HttpURLConnection verify = (HttpURLConnection) verifyUrl.openConnection();
                    verify.setRequestMethod("GET"); verify.setConnectTimeout(15000); verify.setReadTimeout(20000);
                    verify.setRequestProperty("Authorization", "Bearer " + token);
                    String verifyText = readHttpResponse(verify); int verifyCode = verify.getResponseCode();
                    JSONObject verified = new JSONObject(verifyText);
                    if (verifyCode < 200 || verifyCode >= 300 || !verified.has("id")) throw new Exception("Drive nhận yêu cầu tải ảnh nhưng không xác minh lại được file (HTTP " + verifyCode + "): " + verifyText);
                    JSONArray parents = verified.optJSONArray("parents"); boolean inTargetFolder = false;
                    if (parents != null) for (int i = 0; i < parents.length(); i++) if (folder.equals(parents.optString(i))) inTargetFolder = true;
                    if (!inTargetFolder || verified.optLong("size", 0) <= 0) throw new Exception("Ảnh được tạo nhưng không nằm trong thư mục QuanLyCayAPK_Images hoặc file rỗng. Hãy kiểm tra đúng tài khoản Drive.");
                    deliverDriveResult(cb, new JSONObject().put("ok", true).put("id", uploadedId).put("name", verified.optString("name", name)).put("size", verified.optLong("size", bytes.length)).put("folderId", folder).toString());
                } catch (Exception e) { deliverDriveResult(cb, driveErrorJson(e)); }
            });
        }

        @JavascriptInterface
        public void downloadDriveImage(String fileId, String callbackId) {
            final String cb = safeCallbackId(callbackId);
            DRIVE_EXECUTOR.execute(() -> {
                try {
                    if (fileId == null || !fileId.matches("[A-Za-z0-9_-]{10,}")) throw new Exception("Mã ảnh Drive không hợp lệ");
                    GoogleSignInAccount account = requireDriveAccount();
                    String token = getDriveAccessToken(account);
                    URL url = new URL("https://www.googleapis.com/drive/v3/files/" + URLEncoder.encode(fileId, "UTF-8") + "?alt=media");
                    HttpURLConnection c = (HttpURLConnection) url.openConnection();
                    c.setRequestMethod("GET"); c.setConnectTimeout(20000); c.setReadTimeout(30000);
                    c.setRequestProperty("Authorization", "Bearer " + token);
                    int code = c.getResponseCode();
                    if (code < 200 || code >= 300) throw new Exception("Không đọc được ảnh Drive (HTTP " + code + "): " + readHttpResponse(c));
                    String mime = c.getContentType();
                    if (mime == null || !mime.toLowerCase(java.util.Locale.ROOT).startsWith("image/")) mime = "image/jpeg";
                    int mimeSemi = mime.indexOf(';'); if (mimeSemi > 0) mime = mime.substring(0, mimeSemi).trim();
                    byte[] bytes;
                    try (InputStream in = c.getInputStream(); java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
                        byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n); bytes = out.toByteArray();
                    }
                    String dataUrl = "data:" + mime + ";base64," + Base64.encodeToString(bytes, Base64.NO_WRAP);
                    deliverDriveResult(cb, new JSONObject().put("ok", true).put("dataUrl", dataUrl).toString());
                } catch (Exception e) { deliverDriveResult(cb, driveErrorJson(e)); }
            });
        }

        private GoogleSignInAccount requireDriveAccount() throws Exception {
            GoogleSignInAccount a = GoogleSignIn.getLastSignedInAccount(MainActivity.this);
            if (a == null || !GoogleSignIn.hasPermissions(a, new Scope(DRIVE_SCOPE))) throw new Exception("Chưa kết nối Google Drive. Hãy bấm KẾT NỐI GOOGLE DRIVE trước.");
            return a;
        }

        private String getDriveAccessToken(GoogleSignInAccount account) throws Exception {
            String scopes = "oauth2:" + DRIVE_SCOPE;
            try { return GoogleAuthUtil.getToken(MainActivity.this, account.getAccount(), scopes); }
            catch (UserRecoverableAuthException e) { throw new Exception("Google cần cấp lại quyền Drive. Hãy kết nối Google Drive và chấp nhận quyền truy cập.", e); }
        }

        private String ensureDriveFolder(String token, String email) throws Exception {
            String key = "folder_id_" + safePreferenceKey(email);
            android.content.SharedPreferences prefs = getSharedPreferences("drive_store", MODE_PRIVATE);
            String saved = prefs.getString(key, "");
            if (!saved.isEmpty()) {
                try {
                    URL checkUrl = new URL("https://www.googleapis.com/drive/v3/files/" + URLEncoder.encode(saved, "UTF-8") + "?fields=id,name,mimeType");
                    HttpURLConnection check = (HttpURLConnection) checkUrl.openConnection();
                    check.setRequestMethod("GET"); check.setConnectTimeout(10000); check.setReadTimeout(15000); check.setRequestProperty("Authorization", "Bearer " + token);
                    JSONObject checkJson = new JSONObject(readHttpResponse(check));
                    if (check.getResponseCode() >= 200 && check.getResponseCode() < 300 && DRIVE_FOLDER_NAME.equals(checkJson.optString("name")) && "application/vnd.google-apps.folder".equals(checkJson.optString("mimeType"))) return saved;
                } catch (Exception ignored) { }
                prefs.edit().remove(key).apply();
            }
            String q = "name='" + DRIVE_FOLDER_NAME + "' and mimeType='application/vnd.google-apps.folder' and trashed=false";
            URL listUrl = new URL("https://www.googleapis.com/drive/v3/files?q=" + URLEncoder.encode(q, "UTF-8") + "&pageSize=10&fields=files(id,name,mimeType)");
            HttpURLConnection list = (HttpURLConnection) listUrl.openConnection();
            list.setRequestMethod("GET"); list.setConnectTimeout(15000); list.setReadTimeout(20000); list.setRequestProperty("Authorization", "Bearer " + token);
            int code = list.getResponseCode();
            if (code >= 200 && code < 300) {
                JSONObject json = new JSONObject(readHttpResponse(list)); JSONArray files = json.optJSONArray("files");
                if (files != null && files.length() > 0) {
                    String found = files.getJSONObject(0).getString("id");
                    prefs.edit().putString(key, found).apply();
                    return found;
                }
            } else {
                throw new Exception("Không kiểm tra được thư mục Drive (HTTP " + code + "): " + readHttpResponse(list));
            }
            JSONObject meta = new JSONObject().put("name", DRIVE_FOLDER_NAME).put("mimeType", "application/vnd.google-apps.folder");
            URL createUrl = new URL("https://www.googleapis.com/drive/v3/files?fields=id,name");
            HttpURLConnection create = (HttpURLConnection) createUrl.openConnection();
            create.setRequestMethod("POST"); create.setDoOutput(true); create.setConnectTimeout(15000); create.setReadTimeout(20000);
            create.setRequestProperty("Authorization", "Bearer " + token); create.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            try (OutputStream out = create.getOutputStream()) { out.write(meta.toString().getBytes(StandardCharsets.UTF_8)); }
            String response = readHttpResponse(create);
            JSONObject result = new JSONObject(response);
            if (create.getResponseCode() < 200 || create.getResponseCode() >= 300 || !result.has("id")) throw new Exception("Không tạo được thư mục Drive: " + response);
            String id = result.getString("id");
            getSharedPreferences("drive_store", MODE_PRIVATE).edit().putString(key, id).apply();
            return id;
        }

        private String readHttpResponse(HttpURLConnection c) throws Exception {
            InputStream in = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null) return "";
            try (InputStream stream = in; java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
                byte[] b = new byte[4096]; int n; while ((n = stream.read(b)) > 0) out.write(b, 0, n);
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            }
        }

        private String safePreferenceKey(String value) { return (value == null ? "default" : value.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9_-]", "_")); }
        private String safeCallbackId(String value) { return value != null && value.matches("[A-Za-z0-9_]{1,80}") ? value : "__driveBridgeInvalidCallback"; }
        private String driveErrorJson(Exception e) { try { return new JSONObject().put("ok", false).put("error", e == null ? "Lỗi Google Drive" : String.valueOf(e.getMessage())).toString(); } catch (Exception ignored) { return "{\"ok\":false,\"error\":\"Lỗi Google Drive\"}"; } }
        private void deliverDriveResult(String callbackId, String resultJson) {
            final String cb = safeCallbackId(callbackId); final String payload = resultJson == null ? "{}" : resultJson;
            runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("if(window.__driveBridgeResponse)window.__driveBridgeResponse(" + JSONObject.quote(cb) + "," + JSONObject.quote(payload) + ");", null); });
        }

        @JavascriptInterface
        public void pickTikTokShippingPdf(String callbackId) {
            final String cb = safeJsCallback(callbackId, "__tiktokPdfImportResult");
            runOnUiThread(() -> {
                try {
                    pendingTikTokPdfCallbackId = cb;
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/pdf");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, TIKTOK_PDF_PICK_REQ);
                } catch (Exception e) {
                    pendingTikTokPdfCallbackId = "";
                    JSONObject result = new JSONObject();
                    try { result.put("ok", false).put("error", "Không mở được trình chọn PDF: " + e.getMessage()); } catch (Exception ignored) { }
                    deliverTikTokPdfResult(cb, result);
                }
            });
        }

        @JavascriptInterface
        public void scanTikTokShippingBarcode(String callbackId) {
            final String cb = safeJsCallback(callbackId, "__tiktokBarcodeResult");
            runOnUiThread(() -> {
                try {
                    GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                        .setBarcodeFormats(Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39, Barcode.FORMAT_ITF, Barcode.FORMAT_CODABAR)
                        .build();
                    // Restrict to linear shipping-label barcodes; do not accidentally scan the TikTok promotional QR.
                    GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(MainActivity.this, options);
                    scanner.startScan()
                        .addOnSuccessListener(barcode -> {
                            JSONObject result = new JSONObject();
                            try { result.put("ok", true).put("value", barcode == null ? "" : String.valueOf(barcode.getRawValue() == null ? "" : barcode.getRawValue())); } catch (Exception ignored) { }
                            deliverTikTokBarcodeResult(cb, result);
                        })
                        .addOnCanceledListener(() -> {
                            JSONObject result = new JSONObject();
                            try { result.put("ok", false).put("cancelled", true).put("error", "Đã hủy quét mã."); } catch (Exception ignored) { }
                            deliverTikTokBarcodeResult(cb, result);
                        })
                        .addOnFailureListener(error -> {
                            JSONObject result = new JSONObject();
                            try { result.put("ok", false).put("error", "Không mở được máy quét: " + (error == null ? "lỗi không rõ" : error.getMessage())); } catch (Exception ignored) { }
                            deliverTikTokBarcodeResult(cb, result);
                        });
                } catch (Exception e) {
                    JSONObject result = new JSONObject();
                    try { result.put("ok", false).put("error", "Máy quét mã chưa sẵn sàng: " + e.getMessage()); } catch (Exception ignored) { }
                    deliverTikTokBarcodeResult(cb, result);
                }
            });
        }

        @JavascriptInterface
        public void ocrShippingImage(String dataUrl, String callback) {
            // Keep this signature in sync with index.html:
            // AndroidBridge.ocrShippingImage(dataUrl, "__callbackName")
            final String cb = (callback == null
                    || !callback.matches("[A-Za-z_$][A-Za-z0-9_$]*"))
                    ? "__shippingOcrResult" : callback;

            try {
                String raw = dataUrl == null ? "" : dataUrl.trim();
                int comma = raw.indexOf(',');
                if (comma >= 0) raw = raw.substring(comma + 1);
                if (raw.isEmpty()) throw new IllegalArgumentException("Ảnh OCR rỗng");

                byte[] bytes = Base64.decode(raw, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bitmap == null) throw new IllegalArgumentException("Không giải mã được ảnh");

                InputImage image = InputImage.fromBitmap(bitmap, 0);
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    .process(image)
                    .addOnSuccessListener(result -> {
                        String recognized = result == null || result.getText() == null
                                ? "" : result.getText();
                        deliverOcrResult(cb, recognized);
                        bitmap.recycle();
                    })
                    .addOnFailureListener(error -> {
                        deliverOcrResult(cb, "");
                        bitmap.recycle();
                        runOnUiThread(() -> Toast.makeText(
                                MainActivity.this,
                                "OCR không đọc được ảnh. Hãy thử chụp rõ nhãn hơn.",
                                Toast.LENGTH_LONG
                        ).show());
                    });
            } catch (Exception error) {
                deliverOcrResult(cb, "");
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "Không xử lý được ảnh OCR. Hãy chọn/chụp lại ảnh.",
                        Toast.LENGTH_LONG
                ).show());
            }
        }

        private void deliverOcrResult(String callbackName, String recognizedText) {
            String safeCallback = (callbackName != null
                    && callbackName.matches("[A-Za-z_$][A-Za-z0-9_$]*"))
                    ? callbackName : "__shippingOcrResult";
            String quotedCallback = org.json.JSONObject.quote(safeCallback);
            String js = "if(window[" + quotedCallback + "])window[" + quotedCallback + "]("
                    + org.json.JSONObject.quote(recognizedText == null ? "" : recognizedText)
                    + ");";
            runOnUiThread(() -> {
                if (webView != null) webView.evaluateJavascript(js, null);
            });
        }

        @JavascriptInterface
        public void sendToFlashLabel(String jobName) {
            final String safeName = (jobName == null || jobName.trim().isEmpty() ? "ROLL-CAY-CANH-LABEL" : jobName).replaceAll("[^a-zA-Z0-9._-]", "_");
            runOnUiThread(() -> {
                if (webView == null) return;
                webView.evaluateJavascript("(function(){var e=document.getElementById('orderPrintArea');return e?e.outerHTML:''})()", htmlRaw -> {
                    try {
                        String html = sanitizePrintHtml(decodeJavascriptString(htmlRaw));
                        if (html == null || html.trim().length() < 20) throw new Exception("Không có nội dung nhãn");
                        WebView pv = new WebView(MainActivity.this);
                        pv.setBackgroundColor(Color.WHITE);
                        pv.getSettings().setJavaScriptEnabled(false);
                        pv.setVisibility(View.INVISIBLE);
                        root.addView(pv, new FrameLayout.LayoutParams(780, 1200));
                        pv.setWebViewClient(new WebViewClient(){ @Override public void onPageFinished(WebView v,String u){
                            v.postDelayed(() -> {
                                try {
                                    Bitmap bm=Bitmap.createBitmap(780,1200,Bitmap.Config.ARGB_8888);
                                    v.draw(new android.graphics.Canvas(bm));
                                    shareBitmapToFlashLabel(bm,safeName);
                                } catch(Exception e){ Toast.makeText(MainActivity.this,"Không tạo được nhãn: "+safeError(e),Toast.LENGTH_LONG).show(); }
                                finally { root.removeView(v); v.destroy(); }
                            },350);
                        }});
                        pv.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
                    } catch(Exception e){ Toast.makeText(MainActivity.this,"FlashLabel lỗi: "+safeError(e),Toast.LENGTH_LONG).show(); }
                });
            });
        }

        private void shareBitmapToFlashLabel(Bitmap bm, String name) {
            try {
                ContentValues values=new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME,name+".png");
                values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");
                if(Build.VERSION.SDK_INT>=29) values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/ROLL CAY CANH");
                Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
                if(uri==null) throw new Exception("Không tạo được ảnh nhãn");
                try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception("Không mở được ảnh");bm.compress(Bitmap.CompressFormat.PNG,100,out);}
                Intent send=new Intent(Intent.ACTION_SEND); send.setType("image/png"); send.putExtra(Intent.EXTRA_STREAM,uri); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                String[] pkgs={"com.flashlabel.flashlabelpro","com.extralife.flashlabel"};
                for(String pkg:pkgs){try{if(getPackageManager().getLaunchIntentForPackage(pkg)!=null){send.setPackage(pkg);startActivity(send);return;}}catch(Exception ignored){}}
                startActivity(Intent.createChooser(send,"Chọn FlashLabel để in"));
            }catch(Exception e){Toast.makeText(MainActivity.this,"Không gửi được sang FlashLabel: "+safeError(e),Toast.LENGTH_LONG).show();}
        }

        @JavascriptInterface
        public void printA4Page(String jobName) {
            final String safeName = (jobName == null || jobName.trim().isEmpty())
                    ? "ROLL-CAY-CANH-BAO-GIA"
                    : jobName.replaceAll("[^a-zA-Z0-9._-]", "_");
            final boolean orderLabel = safeName.startsWith("ROLL-CAY-CANH-");
            runOnUiThread(() -> {
                try {
                    if (webView == null) {
                        Toast.makeText(MainActivity.this, "WebView chưa sẵn sàng", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    final PrintAttributes attributes = buildPrintAttributes(orderLabel);
                    webView.evaluateJavascript(CAPTURE_PRINT_HTML_JS, raw -> {
                        try {
                            final String html = sanitizePrintHtml(decodeJavascriptString(raw));
                            startIsolatedPrint(safeName, html, attributes);
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Không chuẩn bị được nội dung in: " + safeError(e), Toast.LENGTH_LONG).show();
                        }
                    });
                } catch (Throwable e) {
                    Toast.makeText(MainActivity.this, "Không thể mở chức năng in: " + safeError(e), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void printOrder65x100(String jobName) {
            final String safeName=(jobName==null||jobName.trim().isEmpty()?"ROLL-CAY-CANH-ORDER-65X100":jobName).replaceAll("[^a-zA-Z0-9._-]","_");
            runOnUiThread(()->{if(webView==null){Toast.makeText(MainActivity.this,"WebView chưa sẵn sàng",Toast.LENGTH_SHORT).show();return;} webView.evaluateJavascript(CAPTURE_PRINT_HTML_JS,raw->{try{startIsolatedPrint(safeName,sanitizePrintHtml(decodeJavascriptString(raw)),buildPrintAttributes(true));}catch(Exception e){Toast.makeText(MainActivity.this,"Không chuẩn bị được đơn in: "+safeError(e),Toast.LENGTH_LONG).show();}});});
        }

        @JavascriptInterface
        public void exportPdf(String jobName) {
            final String safeName=(jobName==null||jobName.trim().isEmpty()?"Bao-gia-ROLL-GARDEN":jobName).replaceAll("[^a-zA-Z0-9._-]","_");
            runOnUiThread(()->{if(webView==null){Toast.makeText(MainActivity.this,"WebView chưa sẵn sàng",Toast.LENGTH_SHORT).show();return;} webView.evaluateJavascript(CAPTURE_PRINT_HTML_JS,raw->{try{startPdfExport(safeName,sanitizePrintHtml(decodeJavascriptString(raw)));}catch(Exception e){Toast.makeText(MainActivity.this,"Không chuẩn bị được PDF: "+safeError(e),Toast.LENGTH_LONG).show();}});});
        }

        public void printCurrentPage(String jobName) {
            final String safeName = (jobName == null || jobName.trim().isEmpty())
                    ? "ROLL-CAY-CANH"
                    : jobName.replaceAll("[^a-zA-Z0-9._-]", "_");
            runOnUiThread(() -> {
                if (webView == null) {
                    Toast.makeText(MainActivity.this, "WebView chưa sẵn sàng", Toast.LENGTH_SHORT).show();
                    return;
                }
                final PrintAttributes attributes = buildPrintAttributes(false);
                webView.evaluateJavascript(CAPTURE_PRINT_HTML_JS, raw -> {
                    try {
                        final String html = sanitizePrintHtml(decodeJavascriptString(raw));
                        startIsolatedPrint(safeName, html, attributes);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Không chuẩn bị được nội dung in: " + safeError(e), Toast.LENGTH_LONG).show();
                    }
                });
            });
        }

        public boolean saveFile(String filename, String base64, String mimeType) {
            try {
                String safeName = filename == null ? "bao-cao.csv" : filename.replaceAll("[^a-zA-Z0-9._-]", "_");
                if (!safeName.toLowerCase().endsWith(".csv")) safeName = safeName + ".csv";
                final String outputName = safeName;
                byte[] bytes = Base64.decode(base64 == null ? "" : base64, Base64.DEFAULT);
                if (bytes.length == 0) throw new Exception("Nội dung file rỗng");

                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, outputName);
                    values.put(MediaStore.Downloads.MIME_TYPE,
                            mimeType == null ? "text/csv" : mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH,
                            Environment.DIRECTORY_DOWNLOADS + "/ROLL CAY CANH");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("Không tạo được file trong Tải xuống");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("Không mở được file đích");
                        out.write(bytes);
                        out.flush();
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "✅ Đã xuất file: Tải xuống / ROLL CAY CANH / " + outputName,
                            Toast.LENGTH_LONG).show());
                    return true;
                }

                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Không tạo được thư mục Tải xuống");
                File file = new File(dir, outputName);
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(bytes);
                    out.flush();
                }
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "✅ Đã lưu file trong thư mục Tải xuống / " + outputName,
                        Toast.LENGTH_LONG).show());
                return true;
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "❌ Không lưu được file: " + safeError(e), Toast.LENGTH_LONG).show());
                return false;
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        try { cleanupPrintWebView(activePrintWebView); } catch (Exception ignored) {}
        try { mainHandler.removeCallbacksAndMessages(null); } catch (Exception ignored) {}
        try { if (webView != null) webView.destroy(); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
