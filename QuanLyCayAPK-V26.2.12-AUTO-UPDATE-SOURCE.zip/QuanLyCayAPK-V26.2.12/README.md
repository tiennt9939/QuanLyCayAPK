# QuanLyCayAPK — V26.2.12 tự cập nhật + tối ưu lưu trữ + TikTok PDF

This release carries forward the V26.2.3 coordinate-based PDF extraction fix and adds catalog-aware product matching plus its regression tests. It does not change the existing wage/inventory/account business logic.

## Build identity
- `versionName`: `26.2.12`
- `versionCode`: `64`
- Android package: `com.quanlycay.apk`
- Build: GitHub Actions manual workflow `.github/workflows/build-apk.yml`

## Root cause and fix
The supplied 12-page TikTok Shop PDF uses visually aligned product table columns. PDFBox's ordinary text stream can interleave table column labels/values with other content, while the previous JavaScript fallback assumed contiguous blocks. That is why the app found tracking numbers and Order IDs but dropped plant/SKU/Qty. This release keeps native coordinate-based text reconstruction, selects the best of three extraction variants, then matches each product to the current app catalog. Product Name text after a dash is ignored; Combo N is plants per sale unit and Qty counts sale units. Unique name/size matches are auto-filled; unresolved ambiguity remains for Admin review except the explicit Combo 5 Cẩm tú mai C6/C7 → Cẩm tú mai C7 rule. If Admin manually confirms another valid mapping, that recognition rule is saved locally and reused for subsequent labels with the same normalized identity, Combo count and explicit size set.

## Safety boundary
The change does not edit Firestore data, Firestore Rules behavior, database schema, catalog or catalog prices, user accounts/permissions, wage formula, inventory calculations, image/Drive storage, or order completion. PDF import still stages labels only; an Admin confirms or corrects the catalog map and explicitly creates/assigns orders. The PDF queue itself has per-label checkboxes, select-all, a target-mode selector (shared pool or specific employee), and one bulk-action button. The app never invents catalog entries or changes inventory just because a PDF was read.

## Verification performed
- `python3 tools/preflight.py`
- Every `tools/*_test.js` test, including `tiktok_pdf_real_layout_regression_test.js`
- JavaScript syntax checks for all inline blocks and `tiktok-label-import.js`
- Sanitized product table fragments from all 12 supplied PDF pages: 12/12 parsed with a product and positive Qty.

## Device validation still required
The Java coordinate extractor has not been compiled in GitHub Actions or exercised on a physical Android device from this environment. Run the included manual build workflow and install/test the resulting APK with the original PDF before using it for live assignments. If Gradle compilation fails, do not install the APK; inspect the workflow diagnostics first.

## GitHub mobile workflow — build and publish updater APK

1. Upload `QuanLyCayAPK-V26.2.12-AUTO-UPDATE-SOURCE.zip` into the repository root (a file kept only on the phone is not visible to Actions). For future releases, upload the new versioned ZIP too; keep each ZIP filename versioned consistently.
2. Upload the supplied `build-apk-v26.2.12-auto-update.yml` to `.github/workflows/build-apk.yml`, or use the workflow already included in the ZIP.
3. Open Actions → **Build ROLL CAY CANH — GitHub Release + In-App Updater** → **Run workflow**. Leave `source_zip` blank to build the highest-version `*AUTO-UPDATE-SOURCE.zip`, or enter a precise ZIP filename.
4. For GitHub Release publication, configure both Actions secrets: `DEBUG_KEYSTORE_BASE64` (the exact signing keystore) and `EXPECTED_APK_CERT_SHA256` (the 64-hex SHA-256 certificate fingerprint of the APK currently installed). The workflow checks the built APK fingerprint and blocks publication if it differs. Without both secrets, only the build artifact is produced.
5. The first installation of V26.2.12 is manual because an already-installed V26.2.11 APK cannot gain native update code remotely. Once V26.2.12 is installed and a compatible signing key is configured, later published versions can be checked and installed from inside the app.
6. Install only an APK from a successful build and verify that Android accepts the signature. Back up any local-only data before changing signing keys or uninstalling.

## PDF catalog matching behavior
- Plant-name token matching ignores marketing text after a dash, while size detection still checks the complete Product Name, SKU and Seller SKU so a C9 after a dash is not discarded.
- Combo N is N plants per sold unit, and PDF Qty is the number of combos. The app computes N × Qty.
- Each imported plant must resolve to a row from the currently loaded app catalog. A unique name/size match is prefilled. Ambiguous/missing size choices remain for Admin review; no catalog row is fabricated and no order is created until Admin assigns it.
- `tools/tiktok_catalog_matcher_test.js` validates catalog matching against `app/src/main/assets/data.json`, including the agreed Combo 5 Cẩm tú mai C6/C7 → existing C7 catalog row behavior and Qty 2 → 10 plants.

## Confirmed and learned recognition rules
- `Combo 5 cây cẩm tú mai thái C6, Combo 5 C7` maps to the existing Cẩm tú mai C7 catalog row; Qty 2 means 10 plants.
- When Admin fixes a different ambiguous mapping, the app persists a normalized recognition rule locally for future equivalent labels. A C9 or different Combo/name signature will not inherit the rule.
- Rules are device-local (localStorage), not synced to other Admin devices.


## V26.2.10 — Hoàn tất đơn bằng một ảnh

- Mọi đơn đóng hàng chỉ cần 1 ảnh bằng chứng để hoàn tất, gồm đơn riêng, đơn chung, TT, ĐN và đơn TikTok nhập từ PDF.
- Ảnh nên thể hiện được kiện hàng và nhãn vận đơn rõ ràng trong cùng khung hình. Đơn TT thông thường OCR mã vận đơn từ ảnh duy nhất; đơn đã xác minh bằng quét mã/PDF giữ nguyên kết quả đó.
- Ảnh vẫn phải tải lên Google Drive thành công và đơn chỉ được xác nhận hoàn tất sau khi Firestore xác nhận ghi thành công. Công thức tiền công, tồn kho, phân công và schema dữ liệu không đổi.
- **Bắt buộc:** publish tệp `firestore.rules` đi kèm source này vào đúng Firebase project, nếu không rules cũ có thể vẫn yêu cầu 2 ảnh và từ chối hoàn tất.


## In-app update

- The app checks the public GitHub Releases endpoint for this repository every 24 hours and when the user opens the Sync panel; the user can also check manually.
- Updates are offered as a download and Android package-installer handoff. Android still requires user confirmation; this is not a silent installer.
- The updater only accepts HTTPS release assets from `github.com/tiennt9939/QuanLyCayAPK/releases/download/`. It requires a matching `.apk.sha256` sidecar and verifies SHA-256 before opening Android's installer.
- The build workflow publishes `v26.2.12` and later APK assets to GitHub Releases only when both `DEBUG_KEYSTORE_BASE64` and `EXPECTED_APK_CERT_SHA256` Actions secrets are configured and the certificate fingerprint matches. Keep that secret identical across releases. Never commit the keystore or its base64 string to the repository.
- **Signing compatibility warning:** Android only updates an installed package when the certificate matches. Set `EXPECTED_APK_CERT_SHA256` to the 64-hex SHA-256 signer fingerprint of the APK currently installed, and `DEBUG_KEYSTORE_BASE64` to that exact signing keystore. The workflow compares the built APK fingerprint before publishing. A different key causes Android to reject an update; do not uninstall the existing app before backing up local-only data.
- A V26.2.11 APK does not contain the new bridge/UI, so the initial upgrade to V26.2.12 must be installed manually once. In-app updates work for later releases that use the same signing key.
