# QuanLyCayAPK V26.2.12 — In-app updater audit

## Why V26.2.11 lacked the feature
V26.2.11 source contained no Android bridge for querying GitHub releases, downloading a new APK, verifying a checksum, or invoking Android's package installer. Its workflow uploaded a short-lived Actions artifact only; artifacts are not the public update feed used by installed apps.

## Added
- Version is `26.2.12`, versionCode `64`; package remains `com.quanlycay.apk`.
- Sync panel adds app-version information, manual update check, release notes, and download/install action.
- The app automatically checks latest public GitHub Releases at most once per 24 hours, and when the device reconnects to the internet. It does not download or install without user action.
- Native bridge queries `https://api.github.com/repos/tiennt9939/QuanLyCayAPK/releases/latest`.
- Downloads are restricted to HTTPS release asset URLs for this repository. The APK is not opened until the sidecar `.apk.sha256` is downloaded and SHA-256 verified. APK download size is capped at 150 MB.
- Android opens the package installer through `FileProvider`; Android install permission and the confirmation UI remain user-controlled.
- Workflow attempts to publish a public GitHub Release containing the APK and its checksum only when both `DEBUG_KEYSTORE_BASE64` and `EXPECTED_APK_CERT_SHA256` are configured and the built APK fingerprint matches the expected installed-app certificate. If either secret is missing, the build artifact still uploads, but Release publication is skipped. If the APK certificate does not match the configured fingerprint, the build fails before publication.

## Critical deployment limitation
A V26.2.11 app cannot display or invoke new updater code before being upgraded once. Install V26.2.12 manually the first time. Thereafter, automatic update requires that every APK use the exact signing key that signed the installed package. Set `EXPECTED_APK_CERT_SHA256` to the SHA-256 certificate fingerprint from the currently installed APK, and `DEBUG_KEYSTORE_BASE64` to that exact signing keystore. The workflow compares fingerprints and blocks publication on mismatch; creating a different key does not preserve update compatibility. If this cannot be confirmed, export/verify all local-only data and plan a safe one-time migration before switching keys.

## What was preserved
No changes intentionally made to Firestore schema/rules, catalog matching, PDF parsing, bulk assignment, barcode verification, Drive image upload rules, one-photo completion, wage formulas, inventory calculations, or retention behavior from V26.2.11.

## Verification in this work session
- `python3 tools/preflight.py`: PASS.
- All 18 `tools/*_test.js` tests: PASS, including `app_update_contract_test.js`.
- JavaScript syntax checks: all 6 inline blocks plus the external TikTok PDF parser PASS.
- Android manifest, FileProvider paths, styles XML and GitHub Actions YAML parse: PASS.
- The module explicitly sets `buildFeatures { buildConfig = true }` for AGP 8.x, because native updater code reads `BuildConfig.VERSION_NAME` and `BuildConfig.VERSION_CODE`.
- Android SDK/Gradle is not installed in this environment, so no APK build/install is claimed; run the GitHub Actions workflow to perform actual compilation, APK signature verification, and artifact/release publication.


## Workflow hotfix after first Actions failure
- The first build failed because the workflow required SHA-256 extraction even when `SIGNING_ENABLED=false`. Fingerprint parsing is now conditional on stable signing being enabled; unsigned-from-our-managed-key debug builds still must pass `apksigner verify`, then upload the artifact without publishing a Release.
- Stable keystore is now installed at `$HOME/.android/debug.keystore`, the path Gradle's default `assembleDebug` signing configuration actually uses. The previous `app/debug.keystore` location was ineffective.
- With both signing secrets absent, a successful build uploads an APK artifact but intentionally skips GitHub Release publication. In-app update distribution remains unavailable until the installed app signing identity is safely confirmed and configured.
