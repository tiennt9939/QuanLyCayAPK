'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const preflight = fs.readFileSync(path.join(root, 'tools/preflight.py'), 'utf8');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/build-apk.yml'), 'utf8');

assert(gradle.includes('versionName = "26.2.96"') && gradle.includes('versionCode = 148'), 'V26.2.96 / code 148 must be installable over V26.2.92');
assert(preflight.includes('versionName = "26.2.96"') && preflight.includes('versionCode = 148'), 'preflight must enforce current metadata');
assert(workflow.includes('V26.2.96') && workflow.includes('*AUTO-UPDATE-SOURCE.zip'), 'auto-build workflow must watch source ZIP and name V26.2.96');

// Verify a recorded report displays the canonical item snapshot instead of recalculating
// product mapping from this employee device's local PDF-mapping cache.
const displayStart = html.indexOf('function dailyShipmentRawProductDisplayItems(row){');
const displayEnd = html.indexOf('\nfunction renderDailyShipmentPanel(){', displayStart);
assert(displayStart >= 0 && displayEnd > displayStart, 'shipment display helpers must exist');
let mappingCalls = 0;
const displayContext = {
  esc: v => String(v ?? ''),
  Math, Number, String, Array,
  dailyShipmentMappedItems: () => { mappingCalls++; throw new Error('Chưa đối chiếu đủ sản phẩm: Nguyệt quế Thái'); },
};
vm.runInNewContext(html.slice(displayStart, displayEnd), displayContext, { filename: 'shipment-display-helpers.js' });
const canonical = displayContext.dailyShipmentDisplayPlantHtml(
  { trackingNo: '862652114050', status: 'recorded', products: [{ productName: 'Tên PDF cũ', qty: 2 }] },
  { status: 'recorded', items: [{ plantName: 'Nguyệt quế Thái', size: 'C7', qty: 2 }] },
  { ready: false, reason: 'Đã ghi báo cáo' }
);
assert(canonical.includes('Nguyệt quế Thái') && canonical.includes('× <b>2</b>'), 'recorded report should show recorded plant snapshot and qty');
assert(!canonical.includes('Chưa đối chiếu đủ sản phẩm') && mappingCalls === 0, 'recorded row must not run local mapping validation');

// A row marked recorded while its report details are still syncing must not show a red
// mapping warning; it may display the raw PDF product name as neutral reference only.
const recordedPendingSync = displayContext.dailyShipmentDisplayPlantHtml(
  { trackingNo: '862652114050', status: 'recorded', products: [{ productName: 'Nguyệt quế Thái', qty: 2 }] },
  null,
  { ready: false, reason: 'Đã ghi báo cáo' }
);
assert(recordedPendingSync.includes('tên trên nhãn PDF') && !recordedPendingSync.includes('⚠️') && !recordedPendingSync.includes('Chưa đối chiếu đủ sản phẩm'), 'recorded row without loaded report must use neutral PDF reference, not false mapping warning');

// True unresolved, unrecorded rows must remain guarded and visible as warnings.
const unresolved = displayContext.dailyShipmentDisplayPlantHtml(
  { trackingNo: '862602696370', status: 'ready', products: [{ productName: 'Cây Táo Thái sân bóng', qty: 1 }] },
  null,
  { ready: false, reason: 'Chưa đối chiếu đủ sản phẩm: Cây Táo Thái sân bóng' }
);
assert(unresolved.includes('⚠️') && unresolved.includes('Chưa đối chiếu đủ sản phẩm'), 'truly unresolved unrecorded row must continue to warn');
assert(html.includes("if(dailyShipmentReportByTracking(t)||row?.status==='recorded')return {ready:false,recorded:true,reason:'Đã ghi báo cáo'}"), 'scanner readiness gate must stay intact for recorded rows');

// Test the actual Firestore read helper with a mocked SDK. It reads by tracking document ID,
// so scan date can differ from the PDF import date without a date-filter miss.
const apiStart = html.indexOf('  async function loadDailyShipmentScanRecordsByTrackingNos(trackingNumbers){');
const apiEnd = html.indexOf('\n  async function checkDailyShipmentClaims(', apiStart);
assert(apiStart >= 0 && apiEnd > apiStart, 'tracking-targeted Firestore API must exist');
const docsById = {
  '862652114050': { exists: true, id: '862652114050', data: () => ({ trackingNo: '862652114050', status: 'recorded', date: '2026-10-22', report: { id: 'daily_862652114050', trackingNo: '862652114050', status: 'recorded', date: '2026-10-22', items: [{ plantName: 'Nguyệt quế Thái', qty: 2 }] }, orderPatch: { trackingNo: '862652114050', status: 'recorded', date: '2026-10-21' }, actorUid: 'admin-uid', updatedAtMs: 123 }) },
  '862602696370': { exists: false, id: '862602696370', data: () => ({}) },
};
const fetchedIds = [];
const apiContext = {
  user: { uid: 'employee-uid' },
  normalizeTracking: value => String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, ''),
  db: { collection: name => ({ doc: id => ({ get: async () => { assert.strictEqual(name, 'dailyShipmentScans'); fetchedIds.push(id); return docsById[id] || { exists: false, id, data: () => ({}) }; } }) }) },
  Set, Array, String, Number, Promise,
};
vm.runInNewContext(html.slice(apiStart, apiEnd), apiContext, { filename: 'tracking-report-firestore-api.js' });
(async () => {
  const records = await apiContext.loadDailyShipmentScanRecordsByTrackingNos(['862 652 114050', '862602696370', '862652114050']);
  assert.deepStrictEqual(fetchedIds, ['862652114050', '862602696370'], 'tracking reads must normalize and de-duplicate exact document IDs');
  assert.strictEqual(records.length, 1, 'missing scan documents should not produce fake reports');
  assert.strictEqual(records[0].status, 'recorded');
  assert.strictEqual(records[0].date, '2026-10-22', 'report date must be retained even when different from PDF import date');
  assert.strictEqual(records[0].orderPatch.date, '2026-10-21', 'PDF import date in the order patch must be preserved');

  // Merge the cross-day report into the employee queue: report date remains scan date,
  // while the existing assigned PDF row keeps its import date and employee owner.
  const mergeStart = html.indexOf('function dailyShipmentMergeReportAndOrderFromCloud(scans){');
  const mergeEnd = html.indexOf('async function refreshDailyShipmentCloudScanRecords(', mergeStart);
  assert(mergeStart >= 0 && mergeEnd > mergeStart, 'cloud report merge helper must exist');
  const mergeContext = {
    D: { dailyShipmentOrders: [{ trackingNo: '862652114050', date: '2026-10-21', status: 'ready', assignedUid: 'employee-uid', assignmentRequired: true, products: [{ productName: 'Nguyệt quế Thái', qty: 2 }] }], dailyShipmentReports: [] },
    dailyShipmentApplyResetMarkers: () => false,
    dailyShipmentIsStaleResetReport: () => false,
    invalidateInventoryIndexes: () => {},
    dailyShipmentPersistLocalBackup: () => {},
    normalizeTracking: value => String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, ''),
    Array, Map, JSON, String,
  };
  vm.runInNewContext(html.slice(mergeStart, mergeEnd), mergeContext, { filename: 'daily-shipment-cloud-merge.js' });
  const merged = mergeContext.dailyShipmentMergeReportAndOrderFromCloud(records);
  assert.strictEqual(merged, true, 'cross-day cloud report should change the employee cache');
  assert.strictEqual(mergeContext.D.dailyShipmentReports[0].status, 'recorded');
  assert.strictEqual(mergeContext.D.dailyShipmentOrders[0].status, 'recorded', 'the shared employee PDF row should become recorded');
  assert.strictEqual(mergeContext.D.dailyShipmentOrders[0].date, '2026-10-21', 'merge must preserve original PDF import date');
  assert.strictEqual(mergeContext.D.dailyShipmentOrders[0].assignedUid, 'employee-uid', 'merge must preserve the assigned employee identity');

  assert(html.includes("if(st.role==='packer')requestDailyShipmentCloudScanRecordsByTracking(rows,'day')"), 'employee daily-shipment panel must request reports by assigned tracking number');
  assert(html.includes("const rowsToSync=packerDailyShipmentLabelsCache.filter(r=>String(r?.date||'')===date||String(r?.status||'')==='recorded'||!!dailyShipmentReportByTracking(r?.trackingNo))"), 'employee order list must target the selected PDF date and known recorded labels without reading all history');
  assert(html.includes('loadDailyShipmentScanRecordsByTrackingNos,previewDailyShipmentReset'), 'tracking lookup must be exposed through CloudSync state');
  console.log('V26.2.96 EMPLOYEE SHIPMENT RECONCILIATION DISPLAY TEST PASS');
})().catch(error => { console.error(error); process.exitCode = 1; });
