# V26.1.8 — Phân loại đơn hàng, đếm đủ và thu gọn đơn hoàn tất

## Thay đổi
- Màn hình Admin: các đơn chưa hoàn tất có bộ lọc Tất cả / Đơn chung / Đơn riêng / ĐN / TT / ĐD, mỗi bộ lọc hiển thị số lượng đầy đủ. Không còn giới hạn danh sách ở 30 đơn.
- Màn hình nhân viên: hiển thị số đếm đầy đủ cho đơn chung chưa ai nhận, đơn đã nhận/được phân công và các loại ĐN / TT / ĐD. Thêm bộ lọc theo nhóm.
- Chuông thông báo: đưa đơn chung chưa ai nhận vào tổng số của nhân viên; popup thông báo có bộ lọc Đơn chung / Đơn riêng / ĐN / TT / ĐD và không còn cắt danh sách ở 30 đơn.
- Đơn chung đã được nhận vẫn mang nhãn Đơn chung; nhân viên nhận chỉ nhìn thấy đơn chung chưa ai nhận và đơn đã gán cho chính mình.
- Đơn hoàn tất của Admin và nhân viên được đặt trong vùng xổ xuống, mặc định thu gọn; tiêu đề hiện tổng số đơn và thống kê theo ĐN / TT / ĐD. Trạng thái được giữ khi danh sách cập nhật trực tiếp.
- Danh sách ĐD cần bổ sung OCR vẫn hiện thành hàng công việc riêng để nhân viên không bỏ sót xử lý nhãn.
- Không thay đổi Firestore Rules, luồng nhận đơn chung, điều kiện hai ảnh cho đơn chung, OCR TT, Drive hoặc công thức tiền công Cẩm tú mai C7/C9.

## Firestore Rules và Indexes
- Phiên bản này chỉ thay đổi giao diện danh sách và logic đếm/lọc ở client; không bổ sung trường dữ liệu hay thay đổi schema. Không cần thay Rules/Indexes mới nếu Rules và composite index `packingOrders` (`assignmentMode`, `assignedUid`, `status`) từ V26.1.7 đã được triển khai đúng.
- Nếu đơn chung chưa hiển thị, kiểm tra Rules V26.1.7 đã Publish và index liên quan đang `Enabled`.

## Cách kiểm tra
1. Trên Admin, kiểm tra các số Đơn chung / Đơn riêng / ĐN / TT / ĐD khớp danh sách Firestore; bộ lọc thay đổi danh sách nhưng không đổi trạng thái đơn.
2. Trên nhân viên, kiểm tra tổng đơn chung bằng số đơn `open_pool` đang chờ nhận trên màn hình đó; khi nhận, đơn rời nhóm chờ nhận và vào danh sách đơn của nhân viên nhận.
3. Kiểm tra Đã hoàn tất chỉ hiện số và breakdown khi tải màn hình; chạm tiêu đề mới xem danh sách, chạm lần nữa để thu gọn.
4. Bấm chuông thông báo và kiểm tra popup cũng bao gồm đơn chung chưa ai nhận, số tổng đúng và danh sách không bị cắt ở 30 đơn.
5. Chạy `node tools/order_list_grouping_test.js` cùng bộ tests của workflow.

## Phiên bản
- `versionName = 26.1.8`
- `versionCode = 50`
