# ROLL CÂY CẢNH — V26.1.7 Shared Pool Orders

## Mục tiêu

Bổ sung loại **Đơn chung** ở giao diện Admin phân công. Admin không chọn tên nhân viên mà chọn `🌐 ĐƠN CHUNG · TẤT CẢ NHÂN VIÊN ĐỀU THẤY`. Tất cả tài khoản có vai trò Nhân viên đóng hàng đều xem được đơn chung đang chờ nhận.

## Luồng hoạt động

1. Admin tạo đơn chung. Đơn được lưu trong `packingOrders` với `assignmentMode: "open_pool"`, `assignedUid: ""`, `employee: ""`, trạng thái `pending`.
2. Nhân viên bấm **NHẬN ĐƠN & ĐÓNG HÀNG**. Firestore transaction kiểm tra đơn vẫn chưa có người nhận và gán cho UID, mã nhân viên, tên nhân viên của người đăng nhập. Người nhận đầu tiên thắng; các nhân viên còn lại không thể nhận cùng đơn.
3. Sau khi nhận, đơn chuyển từ danh sách Đơn chung sang Đơn đã nhận của nhân viên đó và mở luôn giao diện chụp ảnh.
4. Đơn chung yêu cầu **đủ 2 ảnh cho mọi loại đơn**, kể cả ĐD. Đơn TT vẫn cần OCR/mã vận đơn hợp lệ ở ảnh 2; quy trình OCR ĐD hôm sau vẫn được giữ.
5. Admin luôn xem được tất cả đơn. Khi một nhân viên đã nhận nhưng quên hoàn tất, Admin có thể dùng **ADMIN HOÀN TẤT · KHÔNG ẢNH** trên chính đơn đó. Đơn chưa được ai nhận không thể ghi nhận tiền công vì chưa xác định người hưởng lương.

## Bảo vệ dữ liệu / quyền

- Nhân viên chỉ được đọc đơn được phân công cho UID của mình và các đơn chung đang `pending` chưa được nhận.
- Nhân viên chỉ được claim đơn chung chưa gán; thao tác claim chỉ được sửa trường nhận đơn, không được sửa cây, kích thước, số lượng, trạng thái hay tiền công.
- Nhân viên chỉ được hoàn tất đơn đã thuộc UID của mình, kèm chứng cứ ảnh theo loại đơn.
- Admin giữ quyền xem, chỉnh lý và hoàn tất thay; không tạo đơn trùng khi một đơn chung được nhận.
- Giá tiền công được chốt theo từng dòng đơn như trước; các quy tắc Cẩm tú mai C7/C9, tồn kho, lưu ảnh Drive và báo cáo không đổi.

## BẮT BUỘC trước khi thử tính năng

### 1. Publish Firestore Rules

Mở Firebase Console → đúng dự án Firebase của app → Firestore Database → Rules. Dán nội dung của `firestore.rules` trong gói ZIP (hoặc dùng tệp `firestore-v26.1.7-shared-pool-orders.rules` đính kèm riêng), rồi nhấn **Publish**. Không chỉ cài APK: Rules không được cập nhật tự động qua build APK.

### 2. Tạo composite index cho danh sách Đơn chung

Tệp `firestore.indexes.json` trong gói này mô tả index cho collection `packingOrders`, các trường tăng dần:
- `assignmentMode`
- `assignedUid`
- `status`

Nếu không dùng Firebase CLI để triển khai index, vào Firebase Console → Firestore Database → Indexes → Composite → Create index, chọn Collection ID `packingOrders`, Query scope `Collection`, thêm 3 trường trên theo thứ tự và chọn Ascending. Chờ trạng thái index là **Enabled** trước khi thử.

### 3. Build APK bằng GitHub Actions

- Tải ZIP `QuanLyCayAPK-V26.1.7-SHARED-POOL-ORDERS.zip` lên thư mục gốc repository.
- Đặt workflow đính kèm tại `.github/workflows/build-apk.yml` (ghi đè workflow build cũ nếu đang dùng tên này).
- Mở GitHub Actions, chạy workflow **Build ROLL CAY CANH V26.1.7 — Shared Pool Orders**.
- Chỉ cài artifact `QuanLyCayAPK-V26.1.7-SHARED-POOL-ORDERS-debug` khi trạng thái build là **Success**.

## Kiểm thử đã chạy trong môi trường làm việc

Đạt: `tools/preflight.py`, kiểm tra retention, kiểm tra tiền công C7/C9, kiểm tra lưu ảnh Drive, kiểm tra giao diện nhân viên, kiểm tra Admin hoàn tất không ảnh, kiểm tra riêng đơn chung/claim/Rules/index, cú pháp 5 khối JavaScript và phân tích cú pháp YAML workflow. Firestore Rules đã được kiểm tra cân bằng dấu ngoặc ở mức tĩnh.

**Chưa được xác nhận:** chưa chạy build Gradle/Android SDK ở môi trường này và chưa thử giao dịch trên Firebase thật. Sau khi deploy Rules/index và build APK trên GitHub, cần thử bằng hai tài khoản nhân viên: cả hai thấy đơn chung; tài khoản bấm nhận trước được gán đơn; tài khoản còn lại mất đơn đó; người nhận hoàn tất đủ 2 ảnh; Admin thấy đơn đã nhận và có thể hoàn tất thay nếu nhân viên quên.
