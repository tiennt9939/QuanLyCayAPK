/* Offline TikTok Shop label parser. Stores only order/product identifiers, never recipient address/phone. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.TikTokLabelImport=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';
  function compact(value){return String(value??'').replace(/\s+/g,' ').trim()}
  function normalize(value){return String(value??'').toUpperCase().replace(/[^A-Z0-9]/g,'')}
  function keyForProduct(p){
    const raw=[p?.productName,p?.sku,p?.sellerSku].map(v=>compact(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()).join('|');
    let h=2166136261;
    for(let i=0;i<raw.length;i++){h^=raw.charCodeAt(i);h=Math.imul(h,16777619)}
    return 'ttp_'+(h>>>0).toString(36);
  }
  function expectedPlantsPerSoldUnit(product){
    // Combo N tặng M means N regular plants plus M bonus plants per sold unit.
    // Prefer SKU fields for the combo count, but accept labels where PDF extraction puts
    // the count into Product Name. Never treat the PDF Qty column as the gift count.
    const fields=[product?.sku,product?.sellerSku,product?.productName].map(compact).filter(Boolean);
    const text=fields.join(' ');
    const combo=text.match(/\bcombo\s*(?:x\s*)?(\d{1,3})\b/i);
    if(combo){
      const comboCount=Number(combo[1])||0;
      const gift=text.match(/\btặng\s*(\d{1,3})\b/i)||text.match(/\btang\s*(\d{1,3})\b/i);
      return comboCount+(gift?(Number(gift[1])||0):0);
    }
    const count=text.match(/\b(\d{1,3})\s*(?:cây|chậu)\b/i);
    return count?(Number(count[1])||0):0;
  }
  function repairWrappedComboGiftProduct(product){
    if(!product||typeof product!=='object')return product;
    const name=compact(product.productName),sku=compact(product.sku);
    const combo=name.match(/\bcombo\s*(?:x\s*)?(\d{1,3})\b/i);
    const giftCount=sku.match(/^(\d{1,3})$/);
    // Observed GHN/TikTok PDF layout: the full product-name cell ends with a detached
    // "tặng", while the adjacent SKU cell contains only "1". Rebuild the SKU so the
    // app does not mistake Combo 4 tặng 1 for Combo 4 and block the 5-plant mapping.
    if(!combo||!giftCount||!/(?:\btặng|\btang)\s*$/i.test(name))return product;
    const comboCount=Number(combo[1])||0,gift=Number(giftCount[1])||0;
    if(comboCount<1||gift<1||comboCount+gift>100)return product;
    product.productName=compact(name.replace(combo[0],' ').replace(/\b(?:tặng|tang)\s*$/i,' '));
    product.sku=`Combo ${comboCount} tặng ${gift}`;
    product.mapKey=keyForProduct(product);
    return product;
  }
  function stripProductDescription(value){
    // Normalize only the plant-identity prefix for catalog matching. Preserve numeric
    // height ranges (25-35cm) and explicit sizes, while cutting known SEO/botanical
    // description continuations found in TikTok product labels.
    let text=compact(value);
    const rangePlaceholder='__ROLL_HEIGHT_RANGE__';
    text=text.replace(/(\d)\s*[-–—]\s*(\d)(?=\s*cm\b)/gi,`$1${rangePlaceholder}$2`);
    text=text.split(/\s[-–—]\s|[-–—]/,1)[0].trim();
    const folded=foldVietnamese(text);
    const markers=[
      ' anh sang gian tiep',' anh sang truc tiep',' phu hop moi khong gian',
      ' trang tri phong thuy',' trang tri vuon',' do am cao',' tan xoe dung nuoc',
      ' no quanh',' san vuon',' trong nha',' de ban',' de trong',
      ' cham soc de dang',' la lua chon',' mang den',' tao diem nhan',
      ' philodendron',' sang gian tiep',' tan xoe',' nuoc loc',' giu am',
      ' phun suong',' vi tri',' tranh gio lua',' ( cay sanh hoa',' cay sanh hoa',' + cao'
    ];
    let cut=-1;
    for(const marker of markers){const i=folded.indexOf(marker);if(i>=0&&(cut<0||i<cut))cut=i;}
    if(cut>0)text=text.slice(0,cut).trim();
    text=text.replace(/[\s(,+-]+$/,'').trim();
    return text.replaceAll(rangePlaceholder,'-');
  }
  function foldVietnamese(value){
    return compact(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase();
  }
  function sizeTokens(value){
    const raw=foldVietnamese(value).toUpperCase();
    return [...new Set([...raw.matchAll(/\b([CT])\s*(\d{1,2})\b/g)].map(m=>m[1]+m[2]))];
  }
  // Confirmed user rule for Nguyệt quế: height on the TikTok label determines pot size.
  // 15–20 cm => C7; 20–30 cm => C9. Do not apply these height aliases to other plants.
  function nguyetQueHeightSize(product){
    const text=foldVietnamese([product?.productName,product?.sku,product?.sellerSku].map(compact).filter(Boolean).join(' '));
    if(!/nguyet\s+que/.test(text))return '';
    if(/\b15\s*[-–—]\s*20\s*cm\b/.test(text))return 'C7';
    if(/\b20\s*[-–—]\s*30\s*cm\b/.test(text))return 'C9';
    return '';
  }
  function catalogSizeTokens(row){
    const fromSize=sizeTokens(row?.size||'');
    const fromName=sizeTokens(row?.name||'');
    return [...new Set([...fromSize,...fromName])];
  }
  function plantNameTokens(value){
    let s=foldVietnamese(value);
    // Count and container text belongs to the sold unit, not to the catalog plant name.
    s=s.replace(/\bcombo\s*(?:x\s*)?\d{1,3}\b/g,' ')
       .replace(/\b\d{1,3}\s*(?:cay|chau)\b/g,' ')
       .replace(/\b[ct]\s*\d{1,2}\b/gi,' ')
       .replace(/\b(?:cay|chau)\b/g,' ')
       .replace(/[()\[\]{}.,:;|+_]/g,' ')
       .replace(/[^a-z0-9]+/g,' ');
    // Confirmed spelling variant on the supplied label: "Ruby Đỏ" is the same plant
    // as the catalog spelling "Rubi". SEO/marketing text is removed before tokenizing.
    const aliases={ruby:'rubi'};
    return [...new Set(s.split(/\s+/).filter(t=>t&&t!=='mac'&&t!=='dinh').map(t=>aliases[t]||t))];
  }
  function catalogRowNameTokens(row){
    const raw=String(row?.name||'');
    // Catalog rows sometimes duplicate a size in both name and size; size is resolved separately.
    return plantNameTokens(raw);
  }
  // Stable signature for Admin-confirmed recognition rules. It ignores case, Vietnamese accents,
  // punctuation, height ranges (15-20cm vs 20-30cm), and marketing text, but preserves plant identity,
  // Combo count and explicit C/T sizes so a C6/C7 rule cannot leak to a C9 label.
  function recognitionSignature(product){
    const productName=compact(product?.productName||'');
    // Height ranges (for example 15-20cm versus 20-30cm) are descriptive, not catalog pot sizes.
    // Remove them before trimming SEO text so the dash inside a range is not mistaken for the marketing separator.
    const identityName=productName.replace(/\b(?:cao\s*)?\d{1,3}\s*(?:[-–—]\s*\d{1,3}\s*)?cm\b/gi,' ');
    const identityTokens=[...new Set(plantNameTokens(stripProductDescription(identityName)).filter(t=>!['c','t','cao','cm'].includes(t)))].sort();
    const heightSize=nguyetQueHeightSize(product);
    const sizes=[...new Set([... [product?.productName,product?.sku,product?.sellerSku].flatMap(v=>sizeTokens(v||'')),...(heightSize?[heightSize]:[])])].sort();
    const perUnit=Math.max(1,Number(expectedPlantsPerSoldUnit(product))||1);
    if(!identityTokens.length)return '';
    return JSON.stringify({v:2,identityTokens,sizes,perUnit});
  }
  function applyRecognitionRule(product,catalog,rules){
    const signature=recognitionSignature(product);
    const rule=signature&&rules&&typeof rules==='object'?rules[signature]:null;
    if(!rule||!Array.isArray(rule.lines)||!rule.lines.length)return {matched:false};
    const expected=Math.max(1,Number(expectedPlantsPerSoldUnit(product))||1);
    const rows=(Array.isArray(catalog)?catalog:[]).map((entry,index)=>{
      const p=entry?.p&&typeof entry.p==='object'?entry.p:entry;
      return {p,key:String(entry?._key||entry?.key||p?.catalogId||p?.plantId||p?.id||''),idx:Number.isInteger(Number(entry?.i))?Number(entry.i):(Number.isInteger(Number(entry?._index))?Number(entry._index):index)};
    });
    const lines=[];let total=0;
    for(const saved of rule.lines){
      const catalogKey=String(saved?.catalogKey||'');
      const perUnit=Number(saved?.perUnit);
      if(!catalogKey||!Number.isInteger(perUnit)||perUnit<1||perUnit>100)return {matched:false};
      const matches=rows.filter(r=>r.key===catalogKey&&r.p&&!r.p.deleted);
      if(matches.length!==1)return {matched:false};
      const hit=matches[0];
      lines.push({catalogKey,perUnit,index:hit.idx,name:String(hit.p.name||''),size:String(hit.p.size||'')});
      total+=perUnit;
    }
    if(total!==expected)return {matched:false};
    // A previously saved/manual rule must never override a single explicit size in the current label.
    // Example: SKU says C9, so a stale saved mapping to C7 must be ignored after app update.
    const explicitSizes=[...new Set([product?.productName,product?.sku,product?.sellerSku].flatMap(v=>sizeTokens(v||'')))];
    if(explicitSizes.length===1){
      const explicit=explicitSizes[0];
      const compatible=lines.every(line=>{
        const row=rows.find(r=>r.key===line.catalogKey);
        return row&&catalogSizeTokens(row.p).includes(explicit);
      });
      if(!compatible)return {matched:false,staleRule:true,reason:`Quy tắc lưu cũ không khớp kích thước ${explicit} trên nhãn; đối chiếu lại theo kích thước ghi rõ.`};
    }
    return {matched:true,learnedRule:true,signature,reason:'Đã nhận diện theo quy tắc Admin đã xác nhận trước đó.',perUnit:total,lines};
  }
  function matchCatalogProduct(product,catalog){
    const rawName=compact(product?.productName||'');
    // The dash may introduce SEO copy, but size can appear after it (e.g. "trái nhỏ chậu C9").
    // Keep the original Product Name for size extraction while trimming description only for plant-name tokens.
    const sourceName=stripProductDescription(rawName);
    const fields=[['productName',rawName],['sku',compact(product?.sku||'')],['sellerSku',compact(product?.sellerSku||'')]];
    const sizesByField=fields.map(([field,value])=>({field,sizes:sizeTokens(value)})).filter(x=>x.sizes.length);
    const explicitSizes=[...new Set(sizesByField.flatMap(x=>x.sizes))];
    const heightSize=nguyetQueHeightSize(product);
    const allExplicitSizes=[...new Set([...explicitSizes,...(heightSize?[heightSize]:[])])];
    const sourceTokenSet=new Set(fields.flatMap(([field,value])=>plantNameTokens(field==='productName'?sourceName:value)));
    // Some PDF layouts split the word "thái" across the Product Name and SKU columns.
    // The plant identity plus an explicit height range identifies the Nguyệt quế Thái catalog family.
    if(heightSize&&/nguyet\s+que/.test(foldVietnamese([rawName,product?.sku,product?.sellerSku].join(' '))))sourceTokenSet.add('thai');
    const sourceTokens=[...sourceTokenSet];
    const qtyPerUnit=Math.max(1,Number(expectedPlantsPerSoldUnit(product))||1);
    const rows=(Array.isArray(catalog)?catalog:[]).map((entry,index)=>{
      const p=entry?.p&&typeof entry.p==='object'?entry.p:entry;
      const idx=Number.isInteger(Number(entry?.i))?Number(entry.i):(Number.isInteger(Number(entry?._index))?Number(entry._index):index);
      const key=String(entry?._key||entry?.key||p?.catalogId||p?.plantId||p?.id||'');
      const nameTokens=catalogRowNameTokens(p);
      const allPresent=nameTokens.length>0&&nameTokens.every(t=>sourceTokens.includes(t));
      const overlap=nameTokens.filter(t=>sourceTokens.includes(t)).length;
      return {p,idx,key,nameTokens,allPresent,overlap,sizeTokens:catalogSizeTokens(p),name:String(p?.name||''),size:String(p?.size||'')};
    }).filter(r=>r.p&&!r.p.deleted&&r.nameTokens.length&&r.allPresent);
    const toCandidate=r=>({key:r.key,index:r.idx,name:r.name,size:r.size});
    if(!rawName||!sourceTokens.length)return {matched:false,reason:'Tên sản phẩm chưa đủ để đối chiếu danh mục.',perUnit:qtyPerUnit,candidates:[]};
    if(!rows.length)return {matched:false,reason:'Không tìm thấy cây tương ứng trong danh mục hiện có.',perUnit:qtyPerUnit,candidates:[]};

    // Confirmed business rule: Combo 5 Cẩm tú mai sold under a C6/C7 mixed-size title
    // maps to the existing Cẩm tú mai C7 row. Do not generalize this exception to other plants,
    // combo counts, or labels that also contain C9/C10/C11 evidence.
    const sourceNameTokens=plantNameTokens(sourceName);
    const isCamTuMaiCombo5=qtyPerUnit===5 && ['cam','tu','mai'].every(t=>sourceNameTokens.includes(t)) &&
      allExplicitSizes.length===2 && allExplicitSizes.includes('C6') && allExplicitSizes.includes('C7');
    if(isCamTuMaiCombo5){
      const c7=rows.filter(r=>r.nameTokens.includes('cam')&&r.nameTokens.includes('tu')&&r.nameTokens.includes('mai')&&r.sizeTokens.includes('C7'));
      if(c7.length===1){const hit=c7[0];return {matched:true,reason:'Quy tắc đã chốt: Combo 5 Cẩm tú mai ghi C6/C7 ghép vào Cẩm tú mai C7.',perUnit:5,key:hit.key,index:hit.idx,name:hit.name,size:hit.size,sizeSource:'confirmedBusinessRule',candidates:[toCandidate(hit)]};}
      if(c7.length>1)return {matched:false,reason:'Quy tắc Combo 5 Cẩm tú mai C6/C7 yêu cầu C7 nhưng danh mục có nhiều dòng C7 trùng nhau; Admin cần xác nhận.',perUnit:5,candidates:c7.map(toCandidate),needsReview:true};
    }
    // Any explicit disagreement between Product Name, SKU and Seller SKU is a hard stop unless
    // the exact Cẩm tú mai Combo 5 business rule above applies.
    // A multi-size product name (C6,C7) is ambiguous even if only one of those sizes exists locally.
    const heightConflicts=!!heightSize&&explicitSizes.some(size=>size!==heightSize);
    const conflictingFields=sizesByField.filter(x=>x.sizes.length!==1||explicitSizes.some(z=>!x.sizes.includes(z)));
    if(heightConflicts||conflictingFields.length||allExplicitSizes.length>1){
      return {matched:false,reason:'Tên sản phẩm, SKU hoặc Seller SKU nêu nhiều kích thước hoặc mâu thuẫn nhau; Admin cần xác nhận.',perUnit:qtyPerUnit,candidates:rows.map(toCandidate),needsReview:true,sizeEvidence:sizesByField};
    }
    let candidates=rows;
    let sizeSource='';
    const explicitSize=allExplicitSizes[0]||'';
    if(explicitSize){
      candidates=rows.filter(r=>r.sizeTokens.includes(explicitSize));
      sizeSource=sizesByField.find(x=>x.sizes.includes(explicitSize))?.field||(heightSize?'heightRange':'');
      if(!candidates.length){
        return {matched:false,reason:`Nhãn nêu kích thước ${explicitSize} nhưng không có dòng danh mục tương ứng.`,perUnit:qtyPerUnit,candidates:rows.map(toCandidate),needsReview:true};
      }
    }else{
      // User rule: when the label does not state a size, default to C7 only.
      // Never silently substitute another size just because it is the sole catalog row.
      const c7=rows.filter(r=>r.sizeTokens.includes('C7'));
      if(c7.length){candidates=c7;sizeSource='defaultC7';}
      else return {matched:false,reason:'Nhãn không ghi kích thước và danh mục không có dòng C7 để áp dụng mặc định; Admin cần chọn.',perUnit:qtyPerUnit,candidates:rows.map(toCandidate),needsReview:true};
    }
    if(candidates.length!==1){
      return {matched:false,reason:candidates.length?'Tên cây và kích thước khớp nhiều dòng danh mục; cần Admin chọn đúng.':'Không khớp được một dòng danh mục duy nhất.',perUnit:qtyPerUnit,candidates:candidates.map(toCandidate),needsReview:true};
    }
    const hit=candidates[0];
    return {matched:true,reason:sizeSource==='defaultC7'?'Không ghi kích thước: áp dụng mặc định C7 và khớp duy nhất.':'Khớp duy nhất tên cây và kích thước với danh mục hiện có.',perUnit:qtyPerUnit,key:hit.key,index:hit.idx,name:hit.name,size:hit.size,sizeSource,candidates:[toCandidate(hit)]};
  }
  function extractTracking(text){
    const raw=String(text||'').toUpperCase();
    // Accept occasional spaces/hyphens inserted by PDF text extraction, then normalize the result.
    const patterns=[/\b862(?:[ \t-]?\d){9}\b/g,/\b530(?:[ \t-]?\d){9}\b/g,/\bV[ \t-]*N[ \t-]*G[ \t-]*H(?:[ \t-]?[A-Z0-9]){8,26}\b/g,/\bG[ \t-]*H[ \t-]*V[ \t-]*N(?:[ \t-]?[A-Z0-9]){4,26}\b/g];
    const matches=patterns.flatMap(pattern=>raw.match(pattern)||[]);
    return [...new Set(matches.map(normalize).filter(Boolean))];
  }
  function carrierFor(tracking){
    const t=normalize(tracking);
    if(/^VNGH\d{8,12}$/.test(t)||/^GHVN[A-Z0-9]{4,26}$/.test(t))return 'GHN';
    if(/^862\d{9}$/.test(t))return 'J&T Express';
    if(/^530\d{9}$/.test(t))return 'J&T Cargo';
    return '';
  }
  function parseProductRows(lines, headerIndex, totalIndex, options={}){
    const header=String(lines[headerIndex]||'');
    const skuStart=header.indexOf('SKU');
    const sellerStart=header.indexOf('Seller SKU');
    const qtyStart=header.lastIndexOf('Qty');
    if(skuStart<0||sellerStart<=skuStart||qtyStart<=sellerStart)return [];
    const startCandidates=[];
    for(let i=headerIndex+1;i<totalIndex;i++){
      const line=String(lines[i]||'').replace(/\r/g,'');
      if(!line.trim()||/Qty\s*Total\s*:/i.test(line))continue;
      // Do not rely on the Qty header's character offset: PDF exporters sometimes
      // place the value a few columns earlier or omit trailing whitespace entirely.
      const qtyMatch=line.match(/(?:^|\s)(\d{1,3})\s*$/);
      if(qtyMatch){
        const qty=Number(qtyMatch[1]);
        const qtyIndex=qtyMatch.index+qtyMatch[0].lastIndexOf(qtyMatch[1]);
        // A wrapped Product Name or SKU continuation can itself end in a number
        // (e.g. "Combo 4" or "tặng 1"). Do not treat it as a sold Qty unless the
        // number is near the real Qty column. Apply this to other text representations
        // too; otherwise a malformed extraction can invent a second product.
        const alignedFloor=Math.max(sellerStart+1,Math.round(qtyStart*0.68));
        const headerLooksAligned=options.alignedColumns||/\s{3,}/.test(header);
        if(headerLooksAligned&&qtyIndex<alignedFloor)continue;
        const hasEarlierTableText=lines.slice(headerIndex+1,i).some(value=>String(value||'').trim()&&!/Qty\s*Total\s*:/i.test(String(value||'')));
        // Some PDF extractors emit the Qty in its own right-aligned line. It is valid
        // when the product/SKU cells were emitted immediately above it.
        if(Number.isInteger(qty)&&qty>0&&qty<=1000&&(line.slice(0,qtyIndex).trim()||hasEarlierTableText))
          startCandidates.push({index:i,qty,qtyIndex});
      }
    }
    const products=[];
    for(let n=0;n<startCandidates.length;n++){
      // In TikTok labels the Qty is frequently printed on the FIRST baseline of a
      // product, while its name/description wraps onto following baselines. Start each
      // row at its own Qty anchor and let its wrapped lines remain with that product
      // until the next Qty anchor. Previously, lines after Qty=1 were incorrectly
      // prepended to the NEXT product, merging two plant names into one.
      const candidateIndex=startCandidates[n].index;
      // Preserve any lines before the very first Qty anchor for layouts that print Qty
      // on the final wrapped baseline. For subsequent rows, start at that row's own anchor.
      const start=n===0?headerIndex+1:candidateIndex;
      const end=n+1<startCandidates.length?startCandidates[n+1].index:totalIndex;
      const col={name:[],sku:[],seller:[]};
      for(let i=start;i<end;i++){
        const line=String(lines[i]||'').replace(/\r/g,'');
        if(!line.trim()||/Qty\s*Total\s*:/i.test(line))continue;
        const rowEnd=i===candidateIndex?startCandidates[n].qtyIndex:line.length;
        const bounded=line.slice(0,rowEnd);
        const cells=[bounded.slice(0,Math.min(skuStart,bounded.length)),
          bounded.slice(Math.min(skuStart,bounded.length),Math.min(sellerStart,bounded.length)),
          bounded.slice(Math.min(sellerStart,bounded.length))];
        ['name','sku','seller'].forEach((field,j)=>{const cell=compact(cells[j]);if(cell)col[field].push(cell)});
      }
      const product={productName:compact(col.name.join(' ')),sku:compact(col.sku.join(' ')),sellerSku:compact(col.seller.join(' ')),qty:startCandidates[n].qty};
      if(!product.productName&&!product.sku&&!product.sellerSku)continue;
      product.mapKey=keyForProduct(product);
      products.push(product);
    }
    return products;
  }
  function parsePageText(text,pageNumber,options={}){
    text=String(text??'');
    const tracks=extractTracking(text);
    const orderIds=[...new Set([...text.matchAll(/\bOrder\s*ID\s*:[ \t]*((?:\d[ \t-]*){12,25})/gi)].map(m=>normalize(m[1])).filter(x=>/^\d{12,25}$/.test(x)))];
    const lines=text.split(/\r?\n/);
    let headerIndex=lines.findIndex(line=>/Product\s*Name/i.test(line)&&/Seller\s*SKU/i.test(line)&&/Qty/i.test(line));
    let totalIndex=lines.findIndex((line,i)=>i>(headerIndex<0?-1:headerIndex)&&/Qty\s*Total\s*:/i.test(line));
    const qtyTotalMatch=text.match(/Qty\s*Total\s*:\s*(\d{1,4})/i);
    const qtyTotal=qtyTotalMatch?Number(qtyTotalMatch[1]):0;
    if(totalIndex<0)totalIndex=lines.length;
    let products=headerIndex>=0?parseProductRows(lines,headerIndex,totalIndex,options):[];
    // Fallback for the standard PDFTextStripper mode, which may emit table
    // columns as separate blocks. Read only each label/value block until its blank separator.
    if(!products.length){
      const findLabel=(label,from=0)=>lines.findIndex((v,i)=>i>=from&&new RegExp('^\\s*'+label+'\\s*$','i').test(String(v||'')));
      const blockAfter=index=>{
        if(index<0)return [];
        const values=[];
        for(let i=index+1;i<lines.length;i++){
          const value=String(lines[i]||'').trim();
          if(!value) break
          values.push(value);
        }
        return values;
      };
      const productHeader=findLabel('Product Name');
      const skuHeader=findLabel('SKU',Math.max(0,productHeader+1));
      const sellerHeader=findLabel('Seller SKU',Math.max(0,skuHeader+1));
      const qtyHeader=findLabel('Qty',Math.max(0,sellerHeader+1));
      const totalLine=lines.findIndex((v,i)=>i>Math.max(qtyHeader,sellerHeader)&&/^\s*Qty\s*Total\s*:/i.test(String(v||'')));
      if(productHeader>=0&&skuHeader>productHeader&&sellerHeader>skuHeader&&qtyHeader>sellerHeader&&totalLine>qtyHeader){
        const name=compact(blockAfter(productHeader).join(' '));
        const sku=compact(blockAfter(skuHeader).join(' '));
        const sellerSku=compact(blockAfter(sellerHeader).join(' '));
        const qtyValues=blockAfter(qtyHeader).filter(v=>/^\d{1,3}$/.test(v)).map(Number).filter(v=>v>0&&v<=1000);
        if(name&&qtyValues.length){const product={productName:name,sku,sellerSku,qty:qtyValues[0]};product.mapKey=keyForProduct(product);products.push(product)}
      }
    }
    // Layout-independent fallback for a product row where the quantity column shifts left.
    if(!products.length&&headerIndex>=0){
      const header=String(lines[headerIndex]||'');
      const skuStart=header.indexOf('SKU'),sellerStart=header.indexOf('Seller SKU');
      const fallback=[];
      if(skuStart>=0&&sellerStart>skuStart){
        for(let i=headerIndex+1;i<totalIndex;i++){
          const line=String(lines[i]||'');const m=line.match(/(?:^|\s)(\d{1,3})\s*$/);if(!m)continue;
          const qty=Number(m[1]),end=m.index+m[0].lastIndexOf(m[1]);if(!Number.isInteger(qty)||qty<1||qty>1000)continue;
          const alignedFloor=Math.max(sellerStart+1,Math.round(header.lastIndexOf('Qty')*0.68));
          if((options.alignedColumns||/\s{3,}/.test(header))&&end<alignedFloor)continue;
          const before=line.slice(0,end).trim();if(!before)continue;
          const product={productName:compact(before.slice(0,Math.min(skuStart,before.length))),sku:compact(before.slice(Math.min(skuStart,before.length),Math.min(sellerStart,before.length))),sellerSku:compact(before.slice(Math.min(sellerStart,before.length))),qty};
          if(product.productName||product.sku||product.sellerSku){product.mapKey=keyForProduct(product);fallback.push(product)}
        }
      }
      products=fallback;
    }
    // Repair wrapped Combo N tặng M regardless of which PDF text representation won.
    products.forEach(repairWrappedComboGiftProduct);
    const reasons=[];
    if(tracks.length!==1)reasons.push(tracks.length?'Có nhiều mã vận đơn khác nhau trên một trang':'Không đọc được mã vận đơn hợp lệ');
    if(orderIds.length!==1)reasons.push(orderIds.length?'Có nhiều Order ID khác nhau trên một trang':'Không đọc được Order ID');
    if(!products.length)reasons.push('Không tách được dòng sản phẩm/SKU/Qty');
    return {page:Number(pageNumber||0)||0,trackingNo:tracks.length===1?tracks[0]:'',carrier:tracks.length===1?carrierFor(tracks[0]):'',orderId:orderIds.length===1?orderIds[0]:'',products,qtyTotal,status:reasons.length?'needs_review':'ready',reviewReason:reasons.join('; ')};
  }
  function parsePage(page){
    if(!page||typeof page!=='object')return parsePageText(page,page?.page||page?.pageNumber||0);
    const pageNo=page.page||page.pageNumber||0;
    // Android PDFBox can return: (1) a layout-preserving stream, (2) standard stream order,
    // and (3) a visual-coordinate reconstruction. Test all available representations and
    // choose the one with the strongest product evidence instead of trusting the first text.
    const representations=[
      {value:page.visualText,alignedColumns:true},
      {value:page.text,alignedColumns:false},
      {value:page.fallbackText,alignedColumns:false}
    ].filter((item,index,all)=>typeof item.value==='string'&&item.value.trim()&&all.findIndex(other=>other.value===item.value)===index);
    const candidates=representations.map(item=>parsePageText(item.value,pageNo,{alignedColumns:item.alignedColumns}));
    if(!candidates.length)return parsePageText('',pageNo);
    const score=row=>{
      const products=Array.isArray(row.products)?row.products:[];
      // Prefer complete table rows over a malformed extraction that treats a wrapped
      // description/SKU fragment as another product. A legitimate multi-product order
      // still scores well when each row carries a SKU/Seller SKU and Qty.
      const evidence=products.reduce((sum,p)=>{
        const hasSku=!!compact(p.sku),hasSeller=!!compact(p.sellerSku);
        return sum+(p.productName?3:0)+(hasSku?8:0)+(hasSeller?5:0)+(Number(p.qty)>0?5:0)+(!hasSku&&!hasSeller?-5:0);
      },0);
      const quantitySum=products.reduce((sum,p)=>sum+Math.max(0,Number(p.qty)||0),0);
      const qtyConsistency=row.qtyTotal>0?(quantitySum===row.qtyTotal?90:-(120+Math.min(800,Math.abs(quantitySum-row.qtyTotal)*100))):0;
      return (row.status==='ready'?1000:0)+evidence+qtyConsistency+(row.trackingNo?3:0)+(row.orderId?2:0);
    };
    let best=candidates[0];
    for(let i=1;i<candidates.length;i++)if(score(candidates[i])>score(best))best=candidates[i];
    // qtyTotal is parser-internal evidence; don't persist it into daily order data.
    delete best.qtyTotal;
    return best;
  }
  function parsePages(pages){
    const parsed=(Array.isArray(pages)?pages:[]).map(parsePage);
    // A TikTok label may span two PDF pages: page one contains the barcode/product rows,
    // while the next page contains only Qty Total/footer and repeats the same Order ID.
    // Merge continuation pages by exact Order ID (or exact tracking when Order ID is absent)
    // before creating daily-shipment rows, so one physical order cannot become two orders.
    const rows=[],byOrder=new Map(),byTracking=new Map();
    const productSig=p=>[normalize(p?.productName),normalize(p?.sku),normalize(p?.sellerSku),String(Number(p?.qty)||0)].join('|');
    for(const incoming of parsed){
      const orderId=String(incoming.orderId||'').trim();
      const tracking=normalize(incoming.trackingNo||'');
      let prior=(orderId&&byOrder.get(orderId))||(tracking&&byTracking.get(tracking))||null;
      const conflictingTracking=prior&&tracking&&normalize(prior.trackingNo)!==tracking;
      const conflictingOrder=prior&&orderId&&prior.orderId&&String(prior.orderId)!==orderId;
      if(prior&&!conflictingTracking&&!conflictingOrder&&(!(prior.products||[]).length||!(incoming.products||[]).length)){
        // Merge only same-order continuation pages. A repeated tracking with different Order IDs
        // is not merged and is flagged as a duplicate below.
        const seen=new Set((prior.products||[]).map(productSig));
        for(const product of incoming.products||[]){const sig=productSig(product);if(!seen.has(sig)){prior.products.push(product);seen.add(sig)}}
        if(!prior.trackingNo&&incoming.trackingNo)prior.trackingNo=incoming.trackingNo;
        if(!prior.carrier&&incoming.carrier)prior.carrier=incoming.carrier;
        if(!prior.orderId&&incoming.orderId)prior.orderId=incoming.orderId;
        prior.page=prior.page||incoming.page;
        prior.sourcePages=[...new Set([...(prior.sourcePages||[prior.page]),incoming.page])];
        const totalProducts=(prior.products||[]).reduce((n,p)=>n+Math.max(0,Number(p.qty)||0),0);
        if(prior.trackingNo&&prior.orderId&&prior.products.length&&(!prior.qtyTotal||totalProducts===prior.qtyTotal||totalProducts>=prior.qtyTotal)){
          prior.status='ready';
          prior.reviewReason='';
        }else{
          prior.status='needs_review';
          prior.reviewReason=[prior.reviewReason,incoming.reviewReason].filter(Boolean).join('; ');
        }
        prior.qtyTotal=Math.max(Number(prior.qtyTotal)||0,Number(incoming.qtyTotal)||0);
      }else{
        const row={...incoming,products:[...(incoming.products||[])],sourcePages:[incoming.page]};
        rows.push(row);
        if(orderId&&!byOrder.has(orderId))byOrder.set(orderId,row);
        if(tracking&&!byTracking.has(tracking))byTracking.set(tracking,row);
      }
    }
    const seenTracking=new Map();
    rows.forEach(row=>{if(!row.trackingNo)return;const key=normalize(row.trackingNo);seenTracking.set(key,(seenTracking.get(key)||0)+1)});
    rows.forEach(row=>{if(row.trackingNo&&(seenTracking.get(normalize(row.trackingNo))||0)>1){row.status='needs_review';row.reviewReason=[row.reviewReason,'Mã vận đơn trùng trong cùng PDF'].filter(Boolean).join('; ')}});
    rows.forEach(row=>{delete row.qtyTotal});
    return rows;
  }
  return {compact,normalize,keyForProduct,expectedPlantsPerSoldUnit,stripProductDescription,foldVietnamese,sizeTokens,nguyetQueHeightSize,plantNameTokens,recognitionSignature,applyRecognitionRule,matchCatalogProduct,extractTracking,carrierFor,parseProductRows,parsePage,parsePages};
});
