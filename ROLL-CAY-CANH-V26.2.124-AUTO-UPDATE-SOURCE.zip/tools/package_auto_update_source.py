#!/usr/bin/env python3
"""Create the complete, correctly named source ZIP watched by GitHub Actions."""
from pathlib import Path
import argparse
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "settings.gradle.kts",
    "build.gradle.kts",
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/assets/index.html",
    "app/src/main/assets/tiktok-label-import.js",
    "app/src/main/java/com/quanlycay/apk/MainActivity.java",
    "app/src/main/java/com/quanlycay/apk/ShippingBarcodeScannerActivity.java",
    "tools/preflight.py",
    "tools/package_auto_update_source.py",
    ".github/workflows/build-apk.yml",
]
EXCLUDED_DIRS = {".git", ".gradle", "build", "__pycache__", ".idea"}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT.parent,
                        help="Folder to write ZIP/checksum into (default: parent of project root)")
    args = parser.parse_args()
    gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
    version_match = re.search(r'versionName\s*=\s*"([0-9]+(?:\.[0-9]+)+)"', gradle)
    code_match = re.search(r'versionCode\s*=\s*(\d+)', gradle)
    if not version_match or not code_match:
        raise SystemExit("ERROR: thiếu versionName/versionCode hợp lệ trong app/build.gradle.kts")
    version, code = version_match.group(1), int(code_match.group(1))
    if code <= 167:
        raise SystemExit("ERROR: versionCode phải lớn hơn bản stable code 167 để cài đè được")
    missing = [name for name in REQUIRED if not (ROOT / name).is_file()]
    if missing:
        raise SystemExit("ERROR: thiếu file nguồn bắt buộc: " + ", ".join(missing))
    workflow = (ROOT / ".github/workflows/build-apk.yml").read_text(encoding="utf-8")
    if "**/*AUTO-UPDATE-SOURCE.zip" not in workflow or "expected_archive" not in workflow:
        raise SystemExit("ERROR: workflow chưa cấu hình trigger và xác thực tên ZIP auto-update")

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = output_dir / f"ROLL-CAY-CANH-V{version}-AUTO-UPDATE-SOURCE.zip"
    # Create a deterministic source archive with the project files at ZIP root; never bundle APKs,
    # old source archives, build output, VCS state, or local caches.
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=8) as zf:
        for path in sorted(ROOT.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(ROOT)
            if any(part in EXCLUDED_DIRS for part in rel.parts):
                continue
            if path.suffix.lower() in {".apk", ".aab", ".zip", ".keystore", ".jks", ".pyc"}:
                continue
            if path.name in {".DS_Store"}:
                continue
            # Do not package the build-specific local keystore, even if a developer has one.
            if path.name.endswith((".apk.sha256",)) or "debug.keystore" in rel.parts:
                continue
            zf.write(path, rel.as_posix())

    with zipfile.ZipFile(archive) as zf:
        names = set(zf.namelist())
        missing = [name for name in REQUIRED if name not in names]
        if missing:
            archive.unlink(missing_ok=True)
            raise SystemExit("ERROR: ZIP không chứa file bắt buộc ở đúng đường dẫn: " + ", ".join(missing))
        if any(name.startswith(("v116audit/", "login_audit/", "perf_audit/", "perf_base114/", "roll113_audit/")) for name in names):
            archive.unlink(missing_ok=True)
            raise SystemExit("ERROR: phát hiện thư mục audit lồng trong source ZIP")
    import hashlib
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    checksum = output_dir / f"ROLL-CAY-CANH-V{version}-SHA256.txt"
    checksum.write_text(f"{digest}  {archive.name}\n", encoding="utf-8")
    print(f"SOURCE_ZIP={archive}")
    print(f"VERSION={version} / versionCode={code}")
    print(f"SHA256={digest}")
    print(f"ARCHIVE_ENTRIES={len(names)}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
