V25.10 SURGICAL FIX: packer UI is hard-isolated from admin entry panel; acceptAssignedOrder no longer blocks on sessionReady/ensureActionSession; role remains /users/{uid}.role and assignedUid is ownership check.

# ROLL CÂY CẢNH V25.9 — Stability/Data Lock

## Mục tiêu
Bản này chỉ sửa đúng hai nhóm lỗi đang cần xử lý:
1. Luồng **Admin phân công → Nhân viên nhận đơn → Đơn đã nhận cần hoàn thành → chụp ảnh → hoàn thành**.
2. Không để dữ liệu `packingOrders` cũ trong `/apps/roll-cay-canh` được nhập ngược lại sau **Đồng bộ**.

## Nguyên tắc dữ liệu
- `/packingOrders` là **nguồn dữ liệu canonical duy nhất** cho đơn phân công.
- UID được lấy từ Firebase Authentication.
- Vai trò được lấy từ `/users/{uid}.role`.
- `assignedUid` chỉ dùng để xác định đơn thuộc về nhân viên nào; **không bao giờ dùng để suy ra role**.
- `packingOrders` cũ nằm trong `apps.data` không được merge vào dữ liệu hiện tại.
- Không đổi Firestore Rules trong bản này.
- Không đổi `data.json` nền: 6 nhân viên, 99 dòng danh mục, 6 mức đơn giá; file được giữ nguyên từ V20.7/V25.8.

## Luồng nhận đơn
- Nút chuông không chặn bởi trạng thái UI tạm thời.
- Khi bấm **NHẬN ĐƠN**, ứng dụng chờ Firebase Auth/Profile ổn định rồi lấy UID thật.
- Chỉ tài khoản có `role=packer` và có `assignedUid` trùng UID mới được nhận.
- Đơn đã nhận được quản lý trong danh sách **Đơn đã nhận · cần hoàn thành** trên thiết bị nhân viên.
- Hoàn thành bắt buộc có ảnh; ảnh được lưu trực tiếp vào document `/packingOrders/{orderId}` cùng trạng thái `completed`.
- Admin xem lại được ảnh bằng chứng từ đơn hoàn thành.

## Kiểm tra tĩnh đã thực hiện
- 5/5 JavaScript blocks của `index.html` qua `node --check`.
- `data.json` đối chiếu giữ nguyên baseline 6 nhân viên / 99 danh mục / 6 đơn giá.
- Workflow GitHub được bổ sung bước kiểm tra JavaScript + dữ liệu trước khi build APK.

> Lưu ý: môi trường kiểm tra hiện tại không có Android SDK/Gradle, nên chưa thể tuyên bố APK runtime đã build/đã chạy thực tế. GitHub Actions sẽ thực hiện bước build Android thật.
- Thao tác đơn trong `/packingOrders` không còn cập nhật `quanlycay_local_updated`, nên hoạt động nhận/xóa/hoàn thành đơn không thể làm app hiểu nhầm rằng toàn bộ dữ liệu kho/danh mục trên máy mới hơn Cloud rồi ghi đè ngược.
- Nút chuông không truy cập trực tiếp biến Firestore nằm trong closure; việc đọc lại đơn được thực hiện qua API `CloudSync`.
