# ROLL CÂY CẢNH V25.10 — SURGICAL ASSIGNMENT FIX

This version is a surgical correction on V25.9. No Firebase Rules changes and no business-data migration.

## Only corrected
1. Packer UI can never display the Admin manual packing-entry panel.
2. Packer notification "NHẬN ĐƠN" no longer uses `sessionReady` / `ensureActionSession()` as a blocking gate.
3. The real Firebase Auth UID is read from the authenticated app state and matched against `packingOrders/{orderId}.assignedUid`.
4. Packer role is taken only from `/users/{uid}.role`; `assignedUid` never determines role.
5. After receiving, the order is shown in the packer's accepted/pending-completion list.
6. Existing proof-photo and completion flow is preserved.

## Explicitly NOT changed
- catalog / rates / employees / daily / opening data
- Firebase Rules
- Admin assignment UI
- stock/inventory/report functions
- existing layout outside the assignment/packer isolation fix
