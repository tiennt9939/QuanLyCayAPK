# QuanLyCayAPK V26.2.4 — TikTok PDF Catalog Match Fix

## Requirements implemented
- Match parsed TikTok products only against the active app catalog. The parser never creates synthetic plant names or catalog rows.
- For Product Name matching, ignore all text after the first hyphen/en dash/em dash.
- Interpret `Combo N ...` as N plants per sold unit; PDF `Qty` counts sold units. Therefore effective plant quantity is `N × Qty`.
- Prioritize size tokens present in Product Name when a listed set such as `C6,C7` includes exactly one size actually present in the app catalog. For the agreed example, `Combo 5 cây cẩm tú mai thái C6,C7 - ...`, the current starter catalog uniquely includes `Cẩm tú mai · C7`, so one combo maps to 5 C7 plants and Qty 2 maps to 10 C7 plants.
- Products with missing size, duplicate catalog rows, no matching row, or unresolved/conflicting size remain unmapped for Admin selection; no guessing. The assignment button remains blocked until mappings validate.
- Never overwrite an existing mapping saved by Admin. Auto mapping only fills absent mappings.
- Queue list displays catalog mapping and computed actual plant quantity where resolved. The form pre-fills the Combo plant count while Admin resolves an ambiguous catalog row.

## Source scope
Only TikTok PDF mapping UI/parser, related test/preflight/build workflow, documentation, and Android version metadata changed. Firestore collections/schema/rules, account permissions, inventory arithmetic, wages, Drive persistence, and order completion logic were not intentionally changed.

## Tests executed
- All 14 `tools/*_test.js` scripts passed.
- `python3 tools/preflight.py` passed.
- JavaScript syntax checked for 6 inline script blocks and `tiktok-label-import.js`.
- Catalog matcher tests cover Nguyệt quế C7/C9, Combo 5 Cẩm tú mai C6/C7 → available C7, Qty 2 → 10 plants, ignored description after dash, ambiguous no-size Vàng Bạc, and unknown plant rejection.
- Existing real-layout fixture continues to assert all 12 PDF page table samples contain product + Qty.

## Remaining validation
This environment does not have Android SDK/Gradle installed, so APK compilation and real-device validation are still required in GitHub Actions before installing. The earlier GitHub integration allowed reads but denied write/branch creation (HTTP 403), so this source bundle and workflow must be uploaded by the repository owner.


## V26.2.4 — PDF recognition and shared-pool bulk assignment follow-up

- A label with no explicit size defaults to C7 only when exactly one matching C7 catalog row exists. The matcher will not substitute another size because it is the only catalog row.
- Sizes are extracted from the complete Product Name, including size tokens after a dash, and from SKU/Seller SKU. Conflicting or multiple explicit sizes require Admin review.
- PDF import now creates a pending shared-pool order after product mapping; it does not assign directly to one employee.
- Admin can tick unclaimed shared orders and transfer the selected orders to one active packer in a batch. Each transition uses a Firestore transaction and rejects orders that are completed, already claimed, or no longer in the shared pool.
- No payroll formula, stock formula, order-item quantity calculation, image proof requirement, Firestore schema, or Firestore rules were changed.
- The current seed catalog contains two `Táo thái` rows with blank size and no explicit `Táo thái C9` row. A label that explicitly says C9 is therefore held for Admin review rather than silently mapped to an unknown/blank-size row.
- Regression coverage: `tools/tiktok_catalog_matcher_test.js`, `tools/tiktok_pdf_bulk_assignment_test.js`, and the existing full JavaScript test suite.
