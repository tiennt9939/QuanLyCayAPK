# Audit report — QuanLyCayAPK V26.2.4 PDF recognition + bulk assignment

## Source baseline
- Derived from the handover archive `QuanLyCayAPK-V26.2.4-TIKTOK-PDF-CATALOG-MATCH-FIX.zip`.
- Android application ID: `com.quanlycay.apk`.
- versionName remains `26.2.4`; versionCode remains `56` to preserve the supplied V26.2.4 baseline.
- No V26.2.5 source was used.

## Implemented
1. Catalog matcher extracts size tokens from the complete Product Name, SKU and Seller SKU, including a size token after a dash.
2. Explicit disagreement or multiple sizes requires manual Admin review.
3. No explicit size defaults to C7 only when a unique matching C7 catalog row exists. The matcher never silently selects another size just because it is the only catalog candidate.
4. Combo N is retained as plants per sold unit; PDF Qty remains sold units and is multiplied exactly once when mapping the order items.
5. Confirmed TikTok PDF labels create pending shared-pool orders first. They are not assigned to an employee at creation.
6. Admin can tick one or multiple unclaimed shared orders, select one active packer, and transfer them in one action. Each transfer uses a Firestore transaction and checks the order is still pending, still shared, and not already claimed. This prevents racing a packer who claims the order first.
7. The existing barcode verification and photo completion flow is unchanged.

## Important catalog finding
The bundled seed catalog has two `Táo thái` rows with blank size and no explicit `Táo thái C9` row. The provided TikTok label explicitly says C9 in Product Name and SKU. The matcher therefore leaves it for Admin review instead of silently mapping C9 to a blank-size row. Add/confirm the correct C9 row in the live catalog before expecting automatic matching.

## Regression results
- `python3 tools/preflight.py`: PASS.
- All 15 `tools/*_test.js` tests: PASS, including `tiktok_pdf_bulk_assignment_test.js`.
- Inline JavaScript syntax check: PASS.
- Real PDF layout regression: 12/12 existing fixture pages include product rows and positive Qty.

## APK build status
This environment has Java 21 but no Android SDK, Gradle installation, Android platform packages, or network DNS access to download them. Therefore no APK was built or signed in this environment, and no APK artifact is claimed. The GitHub Actions workflow was updated to include the new regression test and retains the build/sign/verify/artifact steps. Run the workflow manually in GitHub Actions to produce the actual APK artifact.

## Preserved
No changes were made to payroll formulas, inventory equations, wage rules, Firestore schema, Firestore rules, Google Drive image persistence, or completion photo requirements.
