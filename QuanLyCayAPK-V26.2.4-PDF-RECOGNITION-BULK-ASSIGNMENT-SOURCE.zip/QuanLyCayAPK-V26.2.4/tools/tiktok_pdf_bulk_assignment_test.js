const assert = require('assert');
const fs = require('fs');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const parser = fs.readFileSync('app/src/main/assets/tiktok-label-import.js', 'utf8');

// PDF labels are staged, then confirmed mappings create a shared order first.
assert(/async function assignImportedTikTokLabel\(trackingNo\)/.test(html));
const pdfAssign = html.slice(html.indexOf('async function assignImportedTikTokLabel'), html.indexOf('async function renderTikTokLabelImport'));
assert(/assignmentMode:'open_pool'/.test(pdfAssign), 'PDF import must create shared-pool orders first');
assert(/assignedUid:''/.test(pdfAssign) && /employee:''/.test(pdfAssign), 'New PDF shared orders must not be preassigned');
assert(/TẠO ĐƠN CHUNG/.test(html), 'PDF queue must expose the shared-order creation action');
assert(/async function adminBulkAssignSharedOrders\(\)/.test(html), 'Admin bulk assignment action missing');
assert(/toggleBulkSharedOrderSelection/.test(html) && /toggleAllVisibleSharedOrders/.test(html), 'Admin needs per-order and select-all checkboxes');
assert(/st\.adminAssignOpenPoolOrder\(String\(row\.id\),target\)/.test(html), 'Bulk assignment must use the atomic CloudSync transition');
assert(/Chuyển \$\{eligible\.length\} đơn chung sang đơn riêng/.test(html), 'Bulk assignment needs a confirmation before moving orders');
assert(/async function adminAssignOpenPoolOrder\(id,target\)/.test(html), 'Atomic server-side assignment function missing');
const atomic = html.slice(html.indexOf('async function adminAssignOpenPoolOrder'), html.indexOf('async function claimOpenPoolOrder'));
assert(/runTransaction/.test(atomic), 'Bulk assignment must be race-safe against a packer claiming the order');
assert(atomic.includes("String(row.assignmentMode||'')!=='open_pool'||String(row.assignedUid||'').trim()"), 'Only unclaimed shared orders may be bulk-assigned');
assert(/assignmentMode:'assigned',assignedUid:uid,employee:employeeName,employeeId/.test(atomic), 'Assignment must move orders from shared to private');
assert(/nêu nhiều kích thước hoặc mâu thuẫn/.test(parser), 'Conflicting sizes must require manual review');
assert(/default to C7/.test(parser), 'No-size fallback must be C7 only');
console.log('TIKTOK PDF SHARED-POOL + ADMIN BULK ASSIGNMENT TEST PASS');
