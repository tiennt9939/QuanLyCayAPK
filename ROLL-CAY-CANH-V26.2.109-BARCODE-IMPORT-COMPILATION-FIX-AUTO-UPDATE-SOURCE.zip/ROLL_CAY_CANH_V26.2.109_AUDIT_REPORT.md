# V26.2.109 Audit — Barcode import compilation fix

Observed build failure from GitHub Actions run `40250699647`: `:app:compileDebugJavaWithJavac`, 12 unresolved symbols, all related to `Barcode` and constants/types referenced from MainActivity. Corrected import from `com.google.mlkit.vision.barcode.Barcode` to `com.google.mlkit.vision.barcode.common.Barcode`; kept the ML Kit scanning APIs and dependency unchanged.

Added a regression check to `tools/pdf_image_barcode_tracking_fallback_test.js` to prevent the old import returning. Bumped Android metadata to versionName `26.2.109`, versionCode `161`.

Business behavior is unchanged: no changes to parsing, OCR, barcode scan behavior, plant recognition, assignment, payroll, stock, Firestore schema, Google Drive or local-data retention.

Source checks must be run by GitHub Actions. No Android build is claimed until the workflow compiles `assembleDebug` and successfully verifies the APK signature.
