'use strict';
const assert = require('assert');
const parser = require('../app/src/main/assets/tiktok-label-import.js');

// Reproduce the reported GHN/TikTok label: Product Name wraps onto a second line,
// while the SKU itself wraps "Combo 4" / "tặng 1". That "1" is NOT Qty.
const header = 'Product Name'.padEnd(44) + 'SKU'.padEnd(20) + 'Seller SKU'.padEnd(28) + 'Qty';
const first = 'Cây Ruby Đỏ - Nắng màu đỏ rực'.padEnd(44) + 'Combo 4'.padEnd(20) + ''.padEnd(28) + '1';
const continuation = 'phù hợp mọi không gian'.padEnd(44) + 'tặng 1';
const visualText = [
  'VNGH80920580311',
  'Order ID: 586572630683191051',
  header,
  first,
  continuation,
  'Qty Total: 1'
].join('\n');
// Simulate alternative non-spatial extraction which previously gained a higher score
// by inventing two product rows from one line and its continuation.
const malformedText = [
  'VNGH80920580311',
  'Order ID: 586572630683191051',
  header,
  'Cây Ruby Đỏ - Nắng màu đỏ rực Combo 4'.padEnd(44) + ''.padEnd(20) + ''.padEnd(28) + '1',
  'phù hợp mọi không gian tặng 1',
  'Qty Total: 1'
].join('\n');
const row = parser.parsePage({page: 1, visualText, text: malformedText});
assert.strictEqual(row.status, 'ready', JSON.stringify(row));
assert.strictEqual(row.products.length, 1, `One PDF product must not be split: ${JSON.stringify(row.products)}`);
assert(row.products[0].productName.includes('Cây Ruby Đỏ - Nắng màu đỏ rực'), row.products[0].productName);
assert(row.products[0].productName.includes('phù hợp mọi không gian'), row.products[0].productName);
assert(/Combo 4/.test(row.products[0].sku) && /tặng 1/i.test(row.products[0].sku), row.products[0].sku);
assert.strictEqual(row.products[0].qty, 1, 'Qty column is one sold unit, not the bonus count');
assert.strictEqual(parser.expectedPlantsPerSoldUnit(row.products[0]), 5, 'Combo 4 tặng 1 must map to five physical plants per sold unit');
assert.strictEqual(parser.expectedPlantsPerSoldUnit({productName:'Cây A', sku:'Combo 4', sellerSku:''}), 4, 'A combo without a gift retains the original count');
assert.strictEqual(parser.expectedPlantsPerSoldUnit({productName:'Cây A', sku:'Combo 4 tặng 2', sellerSku:''}), 6, 'Gift quantity is added to the combo size');

// Exact observed extraction failure: the PDF parser returns the final title fragment
// with a dangling "tặng" and the adjacent SKU field contains only the number 1.
const brokenPage = {
  page: 2,
  text: [
    'VNGH80920580311', 'Order ID: 586572630683191051',
    'Product Name',
    'Cây Ruby Đỏ - Nắng màu đỏ rực Combo 4 phù hợp mọi không gian tặng', '',
    'SKU', '1', '',
    'Seller SKU', '',
    'Qty', '1', 'Qty Total: 1'
  ].join('\n')
};
const repaired = parser.parsePage(brokenPage);
assert.strictEqual(repaired.status, 'ready', JSON.stringify(repaired));
assert.strictEqual(repaired.products.length, 1, JSON.stringify(repaired.products));
assert.strictEqual(repaired.products[0].productName, 'Cây Ruby Đỏ - Nắng màu đỏ rực phù hợp mọi không gian');
assert.strictEqual(repaired.products[0].sku, 'Combo 4 tặng 1');
assert.strictEqual(repaired.products[0].qty, 1);
assert.strictEqual(parser.expectedPlantsPerSoldUnit(repaired.products[0]), 5);
console.log('TIKTOK PDF COMBO-GIFT REGRESSION PASS: ordinary and malformed layouts normalize to one row, SKU Combo 4 tặng 1, five physical plants');
