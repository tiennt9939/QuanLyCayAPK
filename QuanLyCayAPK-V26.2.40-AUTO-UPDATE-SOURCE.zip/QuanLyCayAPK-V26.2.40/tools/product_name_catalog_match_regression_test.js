'use strict';
const assert = require('assert');
const parser = require('../app/src/main/assets/tiktok-label-import.js');

// Real label wording shown in the user's images. Only Product Name identifies the plant;
// SKU/Seller SKU below are intentionally misleading to prove they cannot alter plant identity.
const catalog = [
  { _key: 'hib-c8', _index: 0, name: 'Giâm bụt thấp nhiều màu', size: 'C8' },
  { _key: 'quynh-c9', _index: 1, name: 'Quỳnh Anh', size: 'C9' },
  { _key: 'ruby-c7', _index: 2, name: 'Cây Ruby Đỏ', size: 'C7' },
  { _key: 'other-c7', _index: 3, name: 'Hoa hồng', size: 'C7' }
];

const hibiscusName = 'Combo 2 chậu Hoa Giâm Bụt nhiều màu hoa nở quanh năm + cây trang trí sân vườn';
const hibiscus = parser.matchCatalogProduct({
  productName: hibiscusName,
  sku: 'Mặc định',
  sellerSku: 'Quỳnh Anh sân nụ',
  qty: 1
}, catalog);
assert.strictEqual(hibiscus.matched, false, 'C8 must not silently substitute for the established C7 default when size is absent');
assert.strictEqual(hibiscus.needsReview, true);
assert.deepStrictEqual(hibiscus.candidates.map(x => x.key), ['hib-c8'], 'Product Name must identify the unique Giâm bụt catalog entry and ignore conflicting Seller SKU words');
assert.deepStrictEqual(parser.plantIdentityTokens(hibiscusName), ['giam', 'but', 'nhieu', 'mau']);
assert(!parser.plantIdentityTokens(hibiscusName).includes('trang'), 'generic garden/marketing copy must be ignored');

const quynhName = 'Combo 2 chậu Quỳnh Anh sẵn nụ hoa nở quanh năm + cây trang trí sân vườn';
const quynh = parser.matchCatalogProduct({
  productName: quynhName,
  sku: 'Mặc định',
  sellerSku: 'Giâm Bụt nhiều màu',
  qty: 1
}, catalog);
assert.strictEqual(quynh.matched, false, 'C9 must not silently substitute for the established C7 default when size is absent');
assert.strictEqual(quynh.needsReview, true);
assert.deepStrictEqual(quynh.candidates.map(x => x.key), ['quynh-c9'], 'Quỳnh Anh must not be merged with Giâm Bụt based on Seller SKU');
assert.deepStrictEqual(parser.plantIdentityTokens(quynhName), ['quynh', 'anh']);

const rubyName = 'Cây Ruby Đỏ - Nắng màu đỏ rực phù hợp mọi không gian';
const ruby = parser.matchCatalogProduct({
  productName: rubyName,
  sku: 'Combo 4 tặng 1',
  sellerSku: 'Hoa hồng',
  qty: 2
}, catalog);
assert.strictEqual(ruby.matched, true, JSON.stringify(ruby));
assert.strictEqual(ruby.key, 'ruby-c7', 'SKU/Seller SKU must not change Ruby Red plant identity');
assert.strictEqual(parser.expectedPlantsPerSoldUnit({ productName: rubyName, sku: 'Combo 4 tặng 1', sellerSku: '', qty: 2 }), 5);
assert.strictEqual(2 * parser.expectedPlantsPerSoldUnit({ productName: rubyName, sku: 'Combo 4 tặng 1', sellerSku: '', qty: 2 }), 10);

// Two legitimate products with wrapped descriptions must stay as two Product Name rows.
const header = 'Product Name'.padEnd(44) + 'SKU'.padEnd(20) + 'Seller SKU'.padEnd(28) + 'Qty';
const line = (name, sku, seller, qty) => name.padEnd(44) + sku.padEnd(20) + seller.padEnd(28) + String(qty);
const pageText = [
  '862513534747',
  'Order ID: 586592942005519593',
  header,
  line('Combo 2 chậu Hoa Giâm Bụt nhiều màu', 'Mặc định', '', 1),
  'hoa nở quanh năm + cây trang trí sân vườn',
  line('Combo 2 chậu Quỳnh Anh sẵn nụ', 'Mặc định', '', 1),
  'hoa nở quanh năm + cây trang trí sân vườn',
  'Qty Total: 2'
].join('\n');
const parsed = parser.parsePage({ page: 1, visualText: pageText });
assert.strictEqual(parsed.status, 'ready', JSON.stringify(parsed));
assert.strictEqual(parsed.products.length, 2, JSON.stringify(parsed.products));
assert(parsed.products[0].productName.includes('Hoa Giâm Bụt'), parsed.products[0].productName);
assert(parsed.products[1].productName.includes('Quỳnh Anh'), parsed.products[1].productName);
assert.strictEqual(parsed.products[0].qty, 1);
assert.strictEqual(parsed.products[1].qty, 1);

console.log('PRODUCT NAME CATALOG MATCH REGRESSION PASS: plant identity uses Product Name only, marketing descriptions ignored, Ruby 4+1 Qty2=10, hibiscus/quynh rows stay separate');
