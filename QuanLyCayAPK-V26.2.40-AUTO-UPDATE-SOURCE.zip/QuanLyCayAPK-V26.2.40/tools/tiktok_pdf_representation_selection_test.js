'use strict';
const assert = require('assert');
const parser = require('../app/src/main/assets/tiktok-label-import.js');

const header = 'Product Name'.padEnd(44) + 'SKU'.padEnd(20) + 'Seller SKU'.padEnd(28) + 'Qty';
const row = (name, sku, seller, qty) => name.padEnd(44) + sku.padEnd(20) + seller.padEnd(28) + String(qty);
const tracking = 'VNGH80722500317';
const orderId = '586598035483625074';

// The coordinate-preserving representation is valid; plain PDFTextStripper text collapses
// the gaps so old parser logic sliced the product title at the wrong header offsets and invented rows.
const visual = [
  tracking,
  `Order ID: ${orderId}`,
  header,
  row('Cây Ruby Đỏ - Nắng màu đỏ rực', 'Combo 4', '', 1),
  row('phù hợp mọi không gian', 'tặng 1', '', ''),
  'Qty Total: 1'
].join('\n');
const collapsed = visual.replace(/ {5,}/g, ' ');
const parsed = parser.parsePage({ page: 4, visualText: visual, text: collapsed, fallbackText: collapsed });
assert.strictEqual(parsed.status, 'ready', JSON.stringify(parsed));
assert.strictEqual(parsed.products.length, 1, `wrapped description must not become a product: ${JSON.stringify(parsed.products)}`);
assert(parsed.products[0].productName.includes('Cây Ruby Đỏ'), parsed.products[0].productName);
assert(/Combo 4/.test(parsed.products[0].sku) && /tặng 1/i.test(parsed.products[0].sku), parsed.products[0].sku);
assert.strictEqual(parsed.products[0].qty, 1);
assert.strictEqual(parsed.qtyTotal, 1);
assert.strictEqual(parser.expectedPlantsPerSoldUnit(parsed.products[0]), 5);

// Quantity 2 remains two sold units, not two physical plants: four + one gift per unit = 10.
const rubyQty2 = { productName: 'Cây Ruby Đỏ - Nắng màu đỏ rực phù hợp mọi không gian', sku: 'Combo 4 tặng 1', sellerSku: '', qty: 2 };
assert.strictEqual(2 * parser.expectedPlantsPerSoldUnit(rubyQty2), 10);

// Two legitimate product names must remain two rows; the generic description line after each
// title is not a separate plant. Both sales Qty values must reconcile to Qty Total.
const twoProducts = [
  '862513534747',
  'Order ID: 586592942005519593',
  header,
  row('Combo 2 chậu Hoa Giâm Bụt nhiều màu', 'Mặc định', '', 1),
  row('hoa nở quanh năm + cây trang trí sân vườn', '', '', ''),
  row('Combo 2 chậu Quỳnh Anh sân nụ', 'Mặc định', '', 1),
  row('hoa nở quanh năm + cây trang trí sân vườn', '', '', ''),
  'Qty Total: 2'
].join('\n');
const flower = parser.parsePage({ page: 5, visualText: twoProducts, text: twoProducts.replace(/ {5,}/g, ' ') });
assert.strictEqual(flower.status, 'ready', JSON.stringify(flower));
assert.strictEqual(flower.products.length, 2, JSON.stringify(flower.products));
assert(flower.products[0].productName.includes('Hoa Giâm Bụt'), flower.products[0].productName);
assert(flower.products[1].productName.includes('Quỳnh Anh'), flower.products[1].productName);
assert.strictEqual(flower.qtyTotal, 2);
assert.strictEqual(flower.products.reduce((n, p) => n + p.qty, 0), 2);
assert.deepStrictEqual(parser.plantIdentityTokens('phù hợp mọi k'), []);

console.log('TIKTOK PDF REPRESENTATION SELECTION PASS: visual columns win, fragment rows rejected, Qty Total reconciled, Ruby combo and hibiscus/quynh remain correct');
