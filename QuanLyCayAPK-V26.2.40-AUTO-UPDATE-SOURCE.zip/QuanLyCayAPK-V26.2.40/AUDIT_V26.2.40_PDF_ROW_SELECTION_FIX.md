# V26.2.40 — PDF row selection and stale queue repair audit

## Scope
- Based on the existing V26.2.39 / versionCode 91 source; no project rebuild.
- Version bumped to V26.2.40 / versionCode 92 for the existing AUTO-UPDATE-SOURCE workflow.
- Business schemas, wage logic, inventory logic, Firebase order-completion transaction and Drive upload logic were not intentionally changed.

## Confirmed causes from code inspection
1. `parsePage()` scored the visual-coordinate representation, normal PDFTextStripper representation and fallback representation only by product/SKU evidence. A collapsed representation could win because false split rows produced extra SKU/Seller-SKU text, even when the visual-coordinate representation preserved the table columns.
2. `Qty Total` was not used to score alternative representations. Therefore candidate rows whose quantities did not reconcile to the printed table total were not sufficiently penalized.
3. `stripProductDescription()` did not remove truncated marketing fragments such as `phù hợp mọi k`; those fragments could survive as a separate plant-looking entry.
4. The re-import repair path compared quality scores only. A stale split with extra fake SKU/Seller-SKU cells could outrank the newly parsed single row and block parser-upgrade repair.

## Changes
- Prefer aligned visual extraction when quality is comparable, and score candidates using the printed `Qty Total` against the sum of product-row quantities.
- Penalize product fragments whose Product Name yields no plant identity after description stripping.
- Strip known marketing-description prefixes even when the PDF extraction truncates the phrase.
- Stamp parser version 80 into parsed label rows. On re-import, a newer parser can repair an unlinked stale queue row only when the new row is ready, each product has a name/positive Qty, and `Qty Total` reconciles. Existing/assigned/linked packing orders remain protected from replacement.
- Add a regression test for aligned visual text competing with collapsed text, Ruby Đỏ Combo 4 tặng 1, Qty 1 and Qty 2, truncated marketing fragments, and the distinct Hoa Giâm Bụt / Quỳnh Anh product rows.
- Update hard-coded test version assertions to V26.2.40 / code 92.

## Verification performed in this environment
- `python3 tools/preflight.py`: PASS.
- All 43 `tools/*_test.js` files: PASS.
- JavaScript syntax: 6 inline script blocks plus external `tiktok-label-import.js`: PASS.
- XML parse for Android XML resources: PASS.
- ZIP integrity: verified before delivery.

## Not verified
- Android APK build in GitHub Actions.
- Installation and tests on a physical Android phone.
- Live Firestore catalog/rule reads and writes.
- Actual Google Drive upload from a real device.

The parser tests use sanitized synthetic text representations transcribed from the observed label layout; they do not constitute a live-PDF or real-device test.
