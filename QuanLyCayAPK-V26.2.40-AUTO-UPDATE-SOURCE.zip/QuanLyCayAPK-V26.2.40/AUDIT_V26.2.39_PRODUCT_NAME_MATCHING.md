# Audit V26.2.39 — TikTok Shop Product Name matching

## Source and release metadata
- Based on the supplied `QuanLyCayAPK-V26.2.36-AUTO-UPDATE-SOURCE.zip`; this is an incremental change, not a rebuild from scratch.
- Android `versionName`: `26.2.39`; `versionCode`: `91`.
- Existing Android application ID, Gradle configuration, Firebase schema/rules, payroll, inventory, Drive, and order-completion code remain based on the supplied source.
- The existing `build-apk.yml` is retained. No replacement workflow was introduced.

## Findings before change
1. `matchCatalogProduct()` formed the source plant-name tokens by concatenating `Product Name`, `SKU`, and `Seller SKU`. Fragments from SKU/Seller SKU could therefore cause an unrelated plant to be added to or selected as a candidate.
2. `stripProductDescription()` previously removed only a dash suffix. Phrases such as `hoa nở quanh năm`, `sẵn nụ`, and `+ cây trang trí sân vườn` remained in name tokens and prevented matching.
3. Visual-layout parsing accepted row-ending quantities as far left as 68% of the Qty header index, which was unnecessarily permissive for continuation text in the wrapped columns.
4. Seven existing test guards hard-coded the former source version, causing the workflow to fail before Gradle assembled an APK after version increments.

## Changes
- Plant-name identity is now derived from `Product Name` only. SKU/Seller SKU cannot supply identity tokens or change the selected plant name.
- Known marketing/description suffixes are removed before identity tokenization. `Hoa Giâm Bụt` is normalized to the catalog identity `Giâm bụt` for matching, while meaningful terms such as `nhiều màu` remain.
- Catalog matching supports a short Product Name identity matching a longer catalog label (and the reverse) only where one token set contains the other. The best lexical match is preferred; competing sizes/candidates still pass through the existing safety checks and can require Admin review.
- Existing combo arithmetic remains intact: `Combo 4 tặng 1` means 5 physical plants per sold unit; Qty 2 means 10 plants. Sale Qty remains separately stored.
- Tightened the visual-row Qty alignment floor from 68% to 82% of the Qty header position to reduce false product starts from wrapped text.
- Updated existing version-contract tests for V26.2.39/code 91 and added `tools/product_name_catalog_match_regression_test.js` for the Ruby Red, Hibiscus, Quỳnh Anh, misleading SKU/Seller SKU, description suffix, and wrapped two-product cases.

## Validation run in this environment
- `python3 tools/preflight.py`: PASS.
- All `tools/*_test.js`: 42/42 PASS.
- JavaScript syntax: 6 inline `<script>` blocks plus `tiktok-label-import.js`: PASS.
- App XML parsing: PASS.
- ZIP integrity and required Android source paths: checked during package validation.

## Important limits
- This validation does not constitute a GitHub Actions APK build, installation test, or a live Firebase/Google Drive integration test.
- Regression labels were encoded from the user-provided screenshots into sanitized text fixtures; the actual PDF binary was not available in this audit. Real-world PDF extraction, device behavior, and live catalog matching must be confirmed after the workflow produces an APK and it is tried in the app.
- No Firestore schema or existing data was migrated or modified by these source changes.
