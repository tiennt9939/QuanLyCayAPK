# ROLL CÂY CẢNH V26.2.36 — Continuous scan + pre-photo duplicate guard

## Requested behavior delivered in source
- Added a continuous scan session that cycles scan → duplicate/order/catalog validation → capture package + label photo → Drive upload → Firestore completion → next scan without needing to tap the scan button for every order.
- Duplicate claim is checked before photo capture is unlocked. The claim request and direct order read start in parallel; if the claim already exists, the app immediately rejects the code without waiting for the order read.
- The native scanner displays the duplicate/rejection reason, keeps the photo capture button hidden, and resets into scanning after the brief warning.
- Added a native `NGƯNG QUÉT` button and a fixed WebView stop button that stays above the completion modal while Drive/Firebase completion is running.
- Re-checks claim and order state after photo capture to catch cross-device races; the Firestore completion transaction remains the final atomic protection.

## Safety behavior preserved
- `shipmentTrackingClaims` is still checked and written atomically with order completion.
- Current packer assignment or secure open-pool claim is required.
- Catalog name/size/quantity validation must pass before capture and again before auto-completion.
- The Drive upload must succeed before the completion transaction can finish.
- The continuous loop resumes only after a confirmed `completed` state. Failures stop the loop and surface an error rather than skipping an order.
- No wage formula, inventory equation, order schema, catalog mapping, delivery-report date, or retention rule was intentionally changed.

## Verification performed
- 41/41 Node.js regression tests passed, including `continuous_scan_duplicate_preflight_test.js`.
- `python3 tools/preflight.py` passed, including the updated native bridge method count.
- Node syntax validation passed for 4 inline JavaScript blocks plus `tiktok-label-import.js`.
- Android Manifest, styles, and FileProvider XML parsed successfully.
- ZIP archive integrity checked after packaging.

## Not verified
- This environment does not have the Android SDK or Gradle installed/wired, and the source archive does not include a Gradle wrapper; no real APK build was performed.
- No live Firebase/Google Drive integration test or physical-device timing test was run. The app must be built using the repository's existing GitHub Actions workflow and exercised on-device before claiming production success.
