# V26.2.36 — Quét liên tục, chặn trùng trước khi chụp

## Luồng sử dụng
- Nhân viên bấm **BẮT ĐẦU QUÉT LIÊN TỤC** một lần.
- Máy quét đọc mã GHN/J&T, WebView kiểm tra với Firestore trước khi hiện nút chụp.
- Nếu mã đã có claim, đơn đã hoàn tất, đơn không được phân công/nhận từ đơn chung, hoặc danh mục cây/kích thước không xác minh được, ứng dụng báo lỗi ngay và giữ nút chụp ẩn. Sau thông báo, máy quét tiếp tục chờ mã kế tiếp.
- Nếu mã hợp lệ, nhân viên chụp ảnh kiện hàng + nhãn trong cùng màn hình.
- Sau chụp, ứng dụng kiểm tra lại mã/đơn để bắt trường hợp nhân viên khác hoàn tất trong lúc đang chụp. Ảnh phải được Drive xác nhận lưu thành công trước khi giao dịch hoàn tất được ghi vào Firestore.
- Chỉ sau khi Firestore xác nhận hoàn tất, camera tự mở lượt quét tiếp theo; không cần bấm lại nút quét.
- Có **NGƯNG QUÉT** trong camera và nút dừng nổi cố định trên màn hình ứng dụng, kể cả khi hộp hoàn tất đơn đang mở.

## Bảo vệ dữ liệu
- Giữ transaction chống trùng `shipmentTrackingClaims` và kiểm tra trạng thái đơn ngay trước chụp + sau chụp.
- Chỉ chấp nhận đơn đúng tài khoản hiện tại hoặc đơn chung được nhận bằng transaction first-claim-wins.
- `validateOrderCatalogForAutoComplete(row)` vẫn bắt buộc; sai tên cây, kích thước, số lượng, danh mục rỗng hoặc danh mục mơ hồ sẽ dừng trước khi chụp.
- Không ghi hoàn tất, tồn kho hoặc tiền công trước khi ảnh Drive được lưu và Firebase xác nhận transaction thành công.
- Khi lưu ảnh/Firebase lỗi, phiên quét dừng để nhân viên xử lý; không âm thầm bỏ qua đơn lỗi và không khởi tạo đơn mới.

## Kiểm tra
Xem `REPORT_V26.2.36_CONTINUOUS_SCAN_PREPHOTO_DUPLICATE_GUARD.md`.
