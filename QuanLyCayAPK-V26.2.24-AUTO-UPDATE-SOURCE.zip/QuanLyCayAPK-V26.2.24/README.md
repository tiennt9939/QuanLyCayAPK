# QuanLyCayAPK / ROLL CÂY CẢNH — V26.2.24

V26.2.23 sửa hàng đợi nhãn PDF cũ: khi mở mục PDF, ứng dụng đối chiếu nhãn tạm với toàn bộ đơn trên Firestore, bao gồm đơn đã hoàn tất những ngày trước. Nhãn trùng vận đơn với đơn đã có sẽ tự được gỡ khỏi danh sách tạm; đơn thật, lịch sử, tồn kho và tiền công không bị xóa. Tiếp tục giữ chỉ báo đỏ/vàng/xanh khi nhân viên hoàn tất đơn. Build version `26.2.23`, versionCode `75`.

Luồng một ảnh, lưu Google Drive trước khi ghi đơn, xác minh mã vận đơn TT, bảo vệ chống trùng vận đơn, tiền công, tồn kho, nhập PDF TikTok, Firestore schema và cập nhật ứng dụng được giữ nguyên từ V26.2.19.


V26.2.23 bổ sung đối chiếu mã vận đơn theo ID tài liệu `tiktok_<tracking>` đối với đơn TikTok cũ thiếu trường shipmentTrackingNo; các đơn đã hoàn tất vẫn được giữ nguyên.


Bổ sung thao tác Admin `DỌN NHÃN PDF TẠM ĐÃ XỬ LÝ` cho hàng đợi nhãn cũ không còn liên kết chắc chắn với đơn do thiếu metadata lịch sử. Thao tác chỉ xóa queue PDF cục bộ sau khi xác nhận; không xóa dữ liệu đơn/tiền công/kho trên Firebase. Khi Admin hoàn tất đơn, bản mới làm mới snapshot đơn và hàng đợi ngay lập tức để tự gỡ các nhãn có liên kết tracking/ID rõ ràng.


## V26.2.24 — Ghép PDF hôm nay vào hàng dư ĐD đã chốt hôm qua

Khi Admin nhập PDF TikTok Shop, ứng dụng thử ghép nhãn có đủ Order ID + mã vận đơn vào đơn ĐD đã hoàn tất nhưng đang `shipmentOcrPending=true`. Chỉ tự ghép khi danh mục cây, kích thước và tổng số lượng khớp chính xác, và mỗi nhãn/đơn ĐD đều có một cặp duy nhất. Nếu có nhiều ứng viên, Admin chọn thủ công trên dòng nhãn PDF.

Thao tác ghép chỉ bổ sung Order ID, mã vận đơn và metadata liên kết trên bản ghi ĐD đã tồn tại; không tạo đơn đóng hàng mới, không chạy lại quy trình hoàn tất, không thay đổi nhân viên, tiền công, trạng thái hoàn tất, cây/số lượng hay tồn kho. Claim mã vận đơn được ghi trong cùng giao dịch Firestore để chống trùng. Mã đơn TikTok được đưa vào báo cáo tìm kiếm vận đơn. Build version `26.2.24`, versionCode `76`.
