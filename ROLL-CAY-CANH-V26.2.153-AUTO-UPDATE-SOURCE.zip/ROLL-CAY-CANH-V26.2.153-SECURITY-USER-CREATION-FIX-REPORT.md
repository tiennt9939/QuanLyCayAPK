# ROLL CÂY CẢNH V26.2.153 — bảo vệ tài khoản khi xác minh hồ sơ lỗi

## Nguồn và phạm vi

- Tiếp tục trực tiếp từ source người dùng cung cấp: V26.2.152, versionCode 204.
- Bản mới: V26.2.153, versionCode 205, package `com.quanlycay.apk`.
- Không viết lại ứng dụng; không thay đổi mô hình dữ liệu, schema Firestore, Firestore Rules, công thức tiền công, logic tồn kho, nhận diện PDF/TikTok, hoặc quy trình quét/chia đơn.

## Thay đổi

- Giữ nguyên sửa lỗi stale employee link trên tài khoản Admin trong V26.2.152.
- Sửa an toàn luồng cấp tài khoản: Firebase Auth và Firestore là hai dịch vụ riêng. Khi ghi hồ sơ `/users/{uid}` đã có thể thành công nhưng bước đọc xác minh tiếp theo bị `permission-denied` hoặc timeout, app không còn tự xóa tài khoản Auth mới tạo.
- App thông báo rõ trạng thái chưa xác định và hướng dẫn Admin kiểm tra `Authentication` cùng `/users`, sau đó thử liên kết lại bằng đúng email/mật khẩu vừa tạo. Điều này tránh trường hợp xóa Auth nhưng để lại hồ sơ Firestore mồ côi.
- Khi lỗi xảy ra, app vẫn đăng xuất secondary Auth session như trước.

## Kiểm tra

- Có regression test riêng `tools/user_creation_auth_orphan_safety_test.js` để khóa hành vi không tự xóa Auth khi kết quả ghi/đọc hồ sơ chưa xác định.
- - `tools/preflight.py`: PASS — V26.2.153 / code 205.
- Full JavaScript regression suite: 140/140 PASS.
- JavaScript syntax: 9 inline script blocks + 3 external assets PASS.

## Rủi ro còn lại cần xử lý ở giai đoạn tiếp theo

- `employeeId` trong một số luồng vẫn là chỉ số mảng `D.employees` thay vì ID ổn định. Xóa một nhân viên ở giữa danh sách có thể làm các chỉ số nhân viên phía sau dịch chuyển trong khi hồ sơ tài khoản cũ vẫn giữ chỉ số trước đó. Không tự chuyển sang ID mới trong bản vá này vì đây là thay đổi dữ liệu/migration cần thiết kế tương thích ngược và kiểm thử dữ liệu thật.
- Chưa có kết nối Firebase production để xác minh live; không thực hiện bất kỳ ghi/xóa dữ liệu production nào.
- Chưa build APK trong môi trường này vì thiếu Gradle, Android SDK và `gradlew`; gói bàn giao là source ZIP. Build phải chạy qua workflow của repository và được kiểm thử trên Firebase/Drive test project trước khi phát hành.
