# ROLL CÂY CẢNH V26.2.134 — GAS / Google Sheets auto-cutover

- Android `versionName`: `26.2.134`; `versionCode`: `186`.
- Package: `com.quanlycay.apk`.
- Based on V26.2.131; this is a continuation of the current project, not a rebuild from scratch.

## What changed

1. Added app-private, atomic JSON storage APIs for durable per-record offline queues.
2. Persists TikTok PDF staging labels in Android app-private storage, with WebView localStorage retained as a compatibility cache.
3. Adds an offline outbox per daily shipment scan. Each entry retains its tracking code, assigned employee, plant/wage snapshot, assignment revision, operation ID, and native photo path. No Base64 photo is duplicated into the report outbox.
4. Admin bulk scan can use already-cached labels and assignments when cloud refresh or duplicate pre-check cannot be reached. It warns that queued items have not yet been accepted by Firebase.
5. Uses shorter cloud setup timeouts and queues likely connection/time-out failures locally rather than waiting indefinitely.
6. On reconnection/foreground/manual retry, syncs each outbox entry sequentially. Before backend cutover Firestore is the migration source; after the verified server-side cutover the app routes business reads/writes to Apps Script + Sheets. The backend enforces duplicate/assignment checks and operation IDs.
7. Uploads photos to Google Drive separately. A photo is acknowledged/deleted from native pending storage only after Drive upload and Firebase attachment are confirmed.
8. Pending photo metadata keeps up to 1,000 local entries instead of 300; the per-record native outbox is the authoritative recovery path for offline scan reports.

## Important offline behavior

- Offline scanning requires the PDF labels, assignment, plant mapping and employee wage data to have been downloaded and saved on this phone before the network is lost. New remote assignments/orders will not appear until sync.
- Offline-queued scans are not counted as server-confirmed wages or inventory changes until Firebase accepts them.
- If the assignment changed, another device claimed the tracking number, or a conflicting report exists, the item is retained in `needs_review`; it is not silently re-awarded. Admin must inspect it after reconnecting.
- Native per-record queues live in Android app-private storage. They survive a normal app restart/update but can be lost if app data is cleared or the app is uninstalled. Do not clear application data before the queue is empty.
- Firebase Authentication remains the sign-in/token provider. Google Sheets is the business-data backend after the verified cutover, and Google Drive continues to store photos. Payroll formulas, inventory logic, plant recognition, and the existing data model are preserved.

## Verification

- `python3 tools/preflight.py`: PASS.
- All 115 files matching `tools/*_test.js`: PASS.
- Inline JavaScript syntax: 9 script blocks plus all external JS modules and the Apps Script source: PASS.
- GAS auto-cutover gate test: PASS.
- Android APK build: not run in this environment (no Android SDK/Gradle installation or Gradle wrapper in this workspace).
- No live Firebase/Drive acceptance test and no physical-device offline/reconnect test were run. GitHub Actions must build the source, followed by a controlled device test before production use.

## GAS migration and cutover

- The Apps Script source in `Code.gs` adds an admin-only import route that works while ordinary GAS business writes are still disabled. Imported paths are restricted to the app collection roots.
- The migration copies and reads back every known Firestore collection/document, compares serialized data and computes a document checksum; it does not delete or mutate Firestore source records.
- Only after full verification does Apps Script store the migration report and enable `ROLL_GAS_CUTOVER_COMPLETED` and `ROLL_GAS_COMPAT_WRITES_ENABLED`. The next app load routes business data to GAS.
- If the GAS health check cannot be reached, the app blocks synchronization instead of silently falling back to Firestore.
- Before releasing, replace Apps Script `Code.gs` with the bundled version and redeploy the existing Web App URL. Keep `ROLL_GAS_COMPAT_WRITES_ENABLED=false` before migration; the admin import route is separately gated. Do not set `ROLL_GAS_CUTOVER_COMPLETED` manually.

## GitHub Actions

The source archive must be named exactly `ROLL-CAY-CANH-V26.2.134-AUTO-UPDATE-SOURCE.zip` and must contain the Android project files at the ZIP root. Push it to the repository root on `main` to trigger `.github/workflows/build-apk.yml`. For publishing an in-app update Release, configure repository secrets `DEBUG_KEYSTORE_BASE64` (the stable signing keystore) and `EXPECTED_APK_CERT_SHA256` (the expected signing certificate SHA-256). Without the expected fingerprint, GitHub Actions can still create an APK Artifact but deliberately skips publishing a Release to avoid an incompatible signature.
