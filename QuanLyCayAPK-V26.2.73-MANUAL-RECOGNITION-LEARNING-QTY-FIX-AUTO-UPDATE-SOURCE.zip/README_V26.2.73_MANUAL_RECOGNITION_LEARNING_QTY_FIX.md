# ROLL CÂY CẢNH V26.2.73 — Đối chiếu thủ công, dạy app nhận diện và sửa Qty

## Vì sao cần bản này
Đối chiếu từ PDF TikTokSeller_1792396156214.pdf do người dùng cung cấp (không đóng gói PDF hoặc dữ liệu người nhận vào source):
- Trang 3: `Lài trà siêu hoa thơm nở quanh năm`; SKU `2 chậu 20-30cm`; Qty `2`. Màn hình app đang ghép `Trà lài · C9` với `4 cây/đơn vị`, làm trạng thái thành “Chưa đối chiếu đủ”. Đúng phải là `2 cây/đơn vị × Qty 2 = 4 cây`.
- Trang 6: `Combo 2 cây ... (Ngọc Ngân + Phú Quý)`; Qty `1`. Nếu đối chiếu thành hai dòng cây thì tổng hai dòng phải là 2 cây (thường 1 Ngọc Ngân + 1 Phú Quý), không phải 2 cây ở từng dòng.
- Trang 10: `Combo của tháng | 4 chậu quỳnh anh ...`; SKU `Mặc định`; Qty `2`. Mỗi đơn vị có 4 chậu nên tổng dự kiến 8 cây. Cụm quảng cáo `Combo của tháng` và `sẵn nụ hoa` không được coi là tên cây.

## Thay đổi
1. Đưa nút **QUẢN LÝ / THÊM / SỬA QUY TẮC NHẬN DIỆN** ngay vào khu vực đối chiếu sản phẩm TikTok.
2. Mỗi thẻ sản phẩm có nút **XÁC NHẬN ĐỐI CHIẾU & DẠY APP CHO LẦN SAU**. Chỉ lưu quy tắc khi cây/quy cách hợp lệ và tổng cây trong mỗi đơn vị khớp với số lượng ghi trên nhãn. Quy tắc dùng hệ thống lưu Cloud nhận diện hiện có.
3. Nếu thẻ chỉ có một dòng cây và số cây/đơn vị sai, app báo rõ phép tính Qty, cho Admin bấm sửa về đúng số cây/đơn vị rồi xác nhận học. Với combo nhiều dòng, Admin chỉnh từng dòng sao cho tổng bằng số cây của một đơn vị bán, ví dụ 1 + 1 = 2.
4. Làm rõ trường số lượng là **cây trong mỗi đơn vị bán, chưa nhân Qty PDF**. Qty chỉ được nhân trong bước tính tổng cây.
5. Lưu khoảng chiều cao (ví dụ 20–30cm) trong chữ ký quy tắc đã xác nhận để quy tắc Trà lài C9 không bị áp dụng nhầm cho nhãn 15–20cm.
6. Tách cụm tiếp thị `Combo của tháng` và `sẵn nụ hoa` khỏi token tên cây để parser có thể tìm tên `Quỳnh Anh` trong danh mục khi có dòng phù hợp.
7. Giữ nguyên Firebase schema và logic tồn kho/tiền công; không có thay đổi nào ghi nhận tiền công chỉ từ bước đối chiếu PDF.

## Cách sử dụng sau khi cài APK mới
- Mở mục nhập PDF TikTok và đến thẻ `Lài trà...`.
- Chọn đúng dòng cây/quy cách (trong ảnh hiện là `Trà lài · C9`).
- Bấm nút sửa số cây/đơn vị về **2**. App sẽ xác nhận phép tính Qty 2 → 4 cây và lưu quy tắc sau khi đối chiếu hợp lệ.
- Lần nhập sau có cùng tên/SKU/khoảng chiều cao, app sẽ thử dùng quy tắc đã học. Nếu quy tắc chưa đồng bộ Cloud, app phải báo lỗi đồng bộ thay vì coi nó đã dùng chung giữa các thiết bị.
- Với `Combo 2 cây (Ngọc Ngân + Phú Quý)`, đặt số cây từng dòng sao cho tổng là 2 (ví dụ 1 và 1), sau đó bấm xác nhận/dạy app.

## Kiểm thử
- `python3 tools/preflight.py`: PASS.
- Toàn bộ `tools/*_test.js`: 67/67 PASS.
- Kiểm tra cú pháp JavaScript: 4 inline blocks + parser PDF ngoài: PASS.
- Bài test riêng cho các trường PDF trang 3 và trang 10: PASS.

## Giới hạn xác minh
Source đã được kiểm tra tự động; APK chưa được build trong môi trường này do không có Android SDK/Gradle. Chưa xác nhận live Firebase/Google Drive trên thiết bị. Build bằng GitHub Actions, sau đó kiểm tra thao tác lưu quy tắc với tài khoản Admin và dữ liệu danh mục thực tế.

- `versionName`: 26.2.73
- `versionCode`: 125
- Package: `com.quanlycay.apk`
