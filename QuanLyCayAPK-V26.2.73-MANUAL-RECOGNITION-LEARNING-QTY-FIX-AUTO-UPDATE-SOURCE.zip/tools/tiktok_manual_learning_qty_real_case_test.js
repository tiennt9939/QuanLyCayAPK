'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const parser = require('../app/src/main/assets/tiktok-label-import.js');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const gradle=fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8');
assert(gradle.includes('versionName = "26.2.73"') && gradle.includes('versionCode = 125'),'V26.2.73 metadata is required');

// Real uploaded PDF page 3: Product Name = “Lài trà siêu hoa thơm nở quanh năm”,
// SKU = “2 chậu 20-30cm”, Qty = 2. Cloud catalog row can be named “Trà lài”, size C9.
const laiTra={productName:'Lài trà siêu hoa thơm nở quanh năm',rawProductName:'Lài trà siêu hoa thơm nở quanh năm',sku:'2 chậu 20-30cm',sellerSku:'',qty:2};
assert.equal(parser.expectedPlantsPerSoldUnit(laiTra),2,'2 chậu is the count per sold unit, not the number including PDF Qty');
const c9={name:'Trà lài',size:'C9',catalogId:'traliai-c9',_key:'traliai-c9',_index:101};
const learnedKey=parser.recognitionSignature(laiTra);
assert(learnedKey.includes('20-30cm'),'Manual learned rule signature must preserve the printed height range');
const learned=parser.applyRecognitionRule(laiTra,[c9],{[learnedKey]:{lines:[{catalogKey:'traliai-c9',perUnit:2}]}});
assert.equal(learned.matched,true,JSON.stringify(learned));
assert.equal(learned.lines[0].name,'Trà lài');
assert.equal(laiTra.qty*learned.perUnit,4,'Qty 2 must yield 4 plants, never store 4 as the per-unit count');
const otherHeight={...laiTra,sku:'2 chậu 15-20cm'};
assert.notEqual(parser.recognitionSignature(otherHeight),learnedKey,'A learned 20-30cm mapping must not leak to a 15-20cm label');

// Real uploaded PDF page 10: “Combo của tháng | 4 chậu quỳnh anh…”, SKU Mặc định, Qty 2.
const quynh={productName:'Combo của tháng| 4 chậu quỳnh anh sẵn nụ hoa nở quanh năm trang trí sân vườn',rawProductName:'Combo của tháng| 4 chậu quỳnh anh sẵn nụ hoa nở quanh năm trang trí sân vườn',sku:'Mặc định',sellerSku:'',qty:2};
assert.equal(parser.expectedPlantsPerSoldUnit(quynh),4);
const quynhC7={name:'Quỳnh Anh',size:'C7',catalogId:'quynhanh-c7',_key:'quynhanh-c7',_index:20};
const qMatch=parser.matchCatalogProduct(quynh,[quynhC7]);
assert.equal(qMatch.matched,true,JSON.stringify(qMatch));
assert.equal(qMatch.perUnit,4);
assert.equal(quynh.qty*qMatch.perUnit,8,'Four pots per sale and PDF Qty 2 must total eight plants');

// Product-specific UI must expose direct rule management and a one-line count correction.
assert(html.includes('QUẢN LÝ / THÊM / SỬA QUY TẮC NHẬN DIỆN'),'Recognition-rule management button must be visible in the mapping area');
assert(html.includes('XÁC NHẬN ĐỐI CHIẾU & DẠY APP CHO LẦN SAU'),'Every product card must let Admin explicitly save the confirmed mapping');
assert(html.includes('function setTikTokProductMapToExpected(key)'),'Single-line mapping must offer a one-tap per-unit count correction');
assert(html.includes('async function confirmAndLearnTikTokProductRule(key)'),'Explicit manual mapping must save a shared recognition rule');
console.log('V26.2.73 MANUAL RECOGNITION + REAL PDF QTY REGRESSION PASS');
