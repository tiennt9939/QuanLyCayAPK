# QuanLyCayAPK / ROLL CÂY CẢNH — V26.2.73

V26.2.73 bổ sung thao tác đối chiếu thủ công và dạy app nhận diện nhãn TikTok. Nút quản lý quy tắc hiện trực tiếp trong khu vực đối chiếu sản phẩm; mỗi thẻ có nút xác nhận để lưu mapping đã kiểm tra lên Cloud. Với nhãn ghi `2 chậu` và Qty `2`, số cây nhập trong mapping phải là `2 cây/đơn vị`, để tổng là `2 × 2 = 4`; app hiển thị phép tính và có nút sửa cho trường hợp chỉ một dòng cây. Parser cũng loại cụm quảng cáo `Combo của tháng`/`sẵn nụ hoa` khi tìm tên cây, giữ khoảng chiều cao trong chữ ký quy tắc và không tự suy đoán một quy cách khác.

Chi tiết: `README_V26.2.73_MANUAL_RECOGNITION_LEARNING_QTY_FIX.md`. Build version `26.2.73`, versionCode `125`. Source đã qua preflight và 67 bài test JavaScript; APK và Firebase thực tế chưa được xác minh trong môi trường này.

---

# QuanLyCayAPK / ROLL CÂY CẢNH — V26.2.28

V26.2.28 sửa việc tách sai sản phẩm TikTok khi tên/SKU xuống dòng trong PDF. Nhãn `Combo 4 tặng 1` giữ thành một dòng sản phẩm; SKU được giữ nguyên và số cây mỗi đơn vị là 5, trong khi Qty PDF vẫn bằng 1 đơn vị bán. Parser ưu tiên cột Qty thật và không nhầm số `1` ở cuối SKU thành một đơn hàng thứ hai. Bản sửa không thay đổi tiền công, tồn kho hoặc schema Firestore. Nếu nhãn lỗi đã nằm trong hàng đợi tạm từ phiên bản cũ, import lại chính PDF sau khi nâng cấp sẽ cập nhật nhãn tạm chưa phân công; đơn đã liên kết/đã phân công không bị ghi đè.

# QuanLyCayAPK / ROLL CÂY CẢNH — V26.2.24

V26.2.23 sửa hàng đợi nhãn PDF cũ: khi mở mục PDF, ứng dụng đối chiếu nhãn tạm với toàn bộ đơn trên Firestore, bao gồm đơn đã hoàn tất những ngày trước. Nhãn trùng vận đơn với đơn đã có sẽ tự được gỡ khỏi danh sách tạm; đơn thật, lịch sử, tồn kho và tiền công không bị xóa. Tiếp tục giữ chỉ báo đỏ/vàng/xanh khi nhân viên hoàn tất đơn. Build version `26.2.23`, versionCode `75`.

Luồng một ảnh, lưu Google Drive trước khi ghi đơn, xác minh mã vận đơn TT, bảo vệ chống trùng vận đơn, tiền công, tồn kho, nhập PDF TikTok, Firestore schema và cập nhật ứng dụng được giữ nguyên từ V26.2.19.


V26.2.23 bổ sung đối chiếu mã vận đơn theo ID tài liệu `tiktok_<tracking>` đối với đơn TikTok cũ thiếu trường shipmentTrackingNo; các đơn đã hoàn tất vẫn được giữ nguyên.


Bổ sung thao tác Admin `DỌN NHÃN PDF TẠM ĐÃ XỬ LÝ` cho hàng đợi nhãn cũ không còn liên kết chắc chắn với đơn do thiếu metadata lịch sử. Thao tác chỉ xóa queue PDF cục bộ sau khi xác nhận; không xóa dữ liệu đơn/tiền công/kho trên Firebase. Khi Admin hoàn tất đơn, bản mới làm mới snapshot đơn và hàng đợi ngay lập tức để tự gỡ các nhãn có liên kết tracking/ID rõ ràng.


## V26.2.24 — Ghép PDF hôm nay vào hàng dư ĐD đã chốt hôm qua

Khi Admin nhập PDF TikTok Shop, ứng dụng thử ghép nhãn có đủ Order ID + mã vận đơn vào đơn ĐD đã hoàn tất nhưng đang `shipmentOcrPending=true`. Chỉ tự ghép khi danh mục cây, kích thước và tổng số lượng khớp chính xác, và mỗi nhãn/đơn ĐD đều có một cặp duy nhất. Nếu có nhiều ứng viên, Admin chọn thủ công trên dòng nhãn PDF.

Thao tác ghép chỉ bổ sung Order ID, mã vận đơn và metadata liên kết trên bản ghi ĐD đã tồn tại; không tạo đơn đóng hàng mới, không chạy lại quy trình hoàn tất, không thay đổi nhân viên, tiền công, trạng thái hoàn tất, cây/số lượng hay tồn kho. Claim mã vận đơn được ghi trong cùng giao dịch Firestore để chống trùng. Mã đơn TikTok được đưa vào báo cáo tìm kiếm vận đơn. Build version `26.2.24`, versionCode `76`.

## V26.2.71 — Admin quét thay ngay trên bảng chia nhãn PDF

Ở V26.2.70, nút quét thay nằm trong thẻ phân công đơn đóng hàng khác, không hiện trên bảng **Chia việc theo nhóm cây** đang dùng để giao nhãn PDF. V26.2.71 thêm nút **ADMIN QUÉT THAY · GHI CÔNG [tên nhân viên]** ngay tại nhãn đã giao; Firebase đối chiếu lại UID nhân viên, UID Admin, phiên phân công và claim mã vận đơn trước khi ghi. Tiền công vẫn theo nhân viên được giao; UID Admin được lưu riêng để kiểm tra lịch sử.

Hướng dẫn: `README_V26.2.71_ADMIN_SCAN_FROM_PDF_ASSIGNMENT_BOARD.md`. Build version `26.2.71`, versionCode `123`.
## V26.2.72 — Admin quét hàng loạt theo nhân viên

Bỏ thao tác quét thay từng nhãn. Trong bảng **Chia việc theo nhóm cây**, Admin chọn nhân viên tại mục **Admin quét thay cho nhân viên đã giao** rồi bấm **ADMIN QUÉT HÀNG LOẠT**. Ứng dụng chuẩn bị một phiên quét gồm các nhãn hợp lệ đã giao cho đúng UID nhân viên đó trong ngày đang chọn; đơn đã ghi, đã khóa hoặc cần kiểm tra cây sẽ bị bỏ qua. Máy quét nhận mã trong danh sách phiên và tự chụp ảnh, còn tiền công vẫn thuộc nhân viên được giao. Firebase giữ xác minh UID Admin, UID nhân viên, phiên phân công và claim chống trùng.

Hướng dẫn: `README_V26.2.72_ADMIN_BATCH_SCAN_BY_EMPLOYEE.md`. Build version `26.2.72`, versionCode `124`.
