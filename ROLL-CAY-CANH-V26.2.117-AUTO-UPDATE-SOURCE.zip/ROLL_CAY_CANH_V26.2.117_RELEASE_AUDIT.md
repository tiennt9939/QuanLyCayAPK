# ROLL CÂY CẢNH V26.2.117 — Login hang audit/fix

## Baseline and release
- Baseline: V26.2.115 source ZIP.
- Version: 26.2.117; Android versionCode 169.
- Scope: login feedback and Firestore profile-check error handling only, plus release metadata and preflight assertions.

## Root cause found in source
The `auth.onAuthStateChanged` handler awaited `ensureProfile()` inside the same broad `try` used for post-login hydration. A Firestore profile read/write failure could fall into the generic catch, which marked the app ready and started listeners without explicitly restoring the login gate or showing a profile-specific error. This could look like the login button had frozen.

## Fixes
- Show a clear status while Firebase authentication and Firestore profile/permission checks are running.
- Bound the Firebase sign-in wait to 20 seconds and show a retry/network message if it does not respond.
- Bound profile validation wait to 15 seconds; on timeout or Firestore permission/network error, keep the login gate visible and show a specific diagnostic message.
- Do not bypass Firestore authorization, auto-grant permissions, reset data, or change catalog/payroll/inventory/order schemas.
- Version metadata updated to 26.2.117 / code 169.

## Validation performed
- `python tools/preflight.py`: PASS.
- `104/104` bài kiểm thử hồi quy JavaScript: PASS.
- Cú pháp 4 script nội tuyến không rỗng và `tiktok-label-import.js`: PASS.
- ZIP packaging contract: đúng tên `ROLL-CAY-CANH-V26.2.117-AUTO-UPDATE-SOURCE.zip`, source nằm trực tiếp ở ZIP root, xác thực tên ZIP khớp metadata trong Gradle.
- JavaScript syntax is rechecked during this release validation. APK compilation and live Firebase login are not claimed without the corresponding environment.
- Release-specific preflight asserts verify timeout diagnostics and permission-denied visibility.

## Not verified / limitations
- No Android APK build performed in this environment (no confirmed Android SDK/Gradle build environment).
- No live Firebase/Firestore credentials or emulator available; real device login and deployed Rules still need runtime verification.
- A timeout does not cancel the underlying Firebase request; it ensures the UI gives feedback rather than waiting indefinitely.
