# QuanLyCayAPK / ROLL CÂY CẢNH — V26.2.21

V26.2.21 sửa hàng đợi nhãn PDF cũ: khi mở mục PDF, ứng dụng đối chiếu nhãn tạm với toàn bộ đơn trên Firestore, bao gồm đơn đã hoàn tất những ngày trước. Nhãn trùng vận đơn với đơn đã có sẽ tự được gỡ khỏi danh sách tạm; đơn thật, lịch sử, tồn kho và tiền công không bị xóa. Tiếp tục giữ chỉ báo đỏ/vàng/xanh khi nhân viên hoàn tất đơn. Build version `26.2.21`, versionCode `73`.

Luồng một ảnh, lưu Google Drive trước khi ghi đơn, xác minh mã vận đơn TT, bảo vệ chống trùng vận đơn, tiền công, tồn kho, nhập PDF TikTok, Firestore schema và cập nhật ứng dụng được giữ nguyên từ V26.2.19.
