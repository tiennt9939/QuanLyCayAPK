const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const start = html.indexOf('function tiktokLiveOrderForLabel(row,orders){');
const end = html.indexOf('function tiktokLabelIsSelectable(row){', start);
assert(start >= 0 && end > start, 'TikTok queue reconcile helpers missing');
const source = html.slice(start, end);
const queue = [
  { trackingNo: '86257329001', status: 'ready', packingOrderId: '', importedAtMs: 100, products: [{ productName: 'yesterday completed order' }] },
  { trackingNo: '86257329002', status: 'ready', packingOrderId: '', importedAtMs: 200, products: [{ productName: 'new order today' }] }
];
const fullOrders = [
  { id: 'order-yesterday-1', shipmentTrackingNo: '86257329001', status: 'completed', assignmentMode: 'assigned', assignedUid: 'packer-1', employee: 'Nhân viên A', assignedAtMs: 300 }
];
const context = {
  tiktokLabelQueue: queue,
  tiktokSelectedTrackingNos: new Set(['86257329001']),
  normalizeTracking: value => String(value || '').replace(/[^a-z0-9]/gi, '').toUpperCase(),
  saveTikTokLocalState: () => true,
  D: { packingOrders: [] },
  orderNotificationState: { rows: [] },
  window: { CloudSync: { state: () => ({ role: 'admin', user: { uid: 'admin-1' }, adminListOrders: async () => fullOrders }) } },
  console
};
vm.createContext(context);
vm.runInContext(source, context);
context.reconcileTikTokLabelQueueWithLiveOrders(queue, fullOrders);
const result = context.pruneTikTokProcessedLabelsFromQueue(fullOrders);
assert.strictEqual(result.removed, 1, 'A stale local label must be removed when its tracking matches a completed Firestore order');
assert.strictEqual(result.labels.length, 1, 'Only the truly new, unlinked label should remain');
assert.strictEqual(result.labels[0].trackingNo, '86257329002');
assert.strictEqual(context.tiktokSelectedTrackingNos.size, 0, 'Old selections must be removed after reconciliation');
assert.strictEqual(fullOrders.length, 1, 'Reconciliation must not delete or mutate the authoritative order collection');
assert(/await refreshTikTokQueueOrdersFromCloud\(false\)/.test(html), 'Admin PDF panel must refresh/reconcile the local queue against the full Firestore order collection');
assert(/const result=await st\.adminListOrders\(\)/.test(html), 'The queue refresher must query the full admin order collection');
console.log('TIKTOK PDF COMPLETED-ORDER RECONCILIATION PASS: old completed label pruned; new unlinked label preserved; Firebase orders untouched');
