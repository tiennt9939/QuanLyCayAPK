plugins { id("com.android.application") }

android {
    namespace = "com.quanlycay.apk"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.quanlycay.apk"
        minSdk = 23
        targetSdk = 35
        versionCode = 35
        versionName = "25.6.0"
    }
}
