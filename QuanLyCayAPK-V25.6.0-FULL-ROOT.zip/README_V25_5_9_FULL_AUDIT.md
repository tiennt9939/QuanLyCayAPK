# V25.5.9 — FULL AUDIT / STABLE ROOT

Base: V25.5.8 payroll/advance source.

## Fixed in this release

1. **Printing stability**
   - Quote printing uses native `ISO_A4` media size.
   - Order printing keeps a custom `65 x 100 mm` media size.
   - Printing is isolated in a temporary, software-rendered WebView so the live app WebView is not passed directly to the Android print engine.
   - The old `FixedAttributesPrintAdapter` wrapper is removed.
   - Print content is captured as the prepared print area plus the page head styles only; app scripts are removed before the print WebView loads.

2. **Payroll export**
   - Native Android export to `Downloads/ROLL CAY CANH` is kept and now validates that a non-empty CSV file was written.
   - Success/failure is shown to the user.
   - Payroll export contains daily detail, cumulative net, employee totals, and salary advances.

3. **Salary advances**
   - Admin can select employee/date/amount/note and save the advance.
   - Available-to-advance amount is shown.
   - An advance cannot exceed earned cumulative payroll minus prior advances up to the selected date.
   - Advances are deducted from cumulative net payroll and exported.
   - Data is stored in `D.salaryAdvances` and included in the shared Cloud document.

4. **New catalog plants / assignment**
   - New catalog rows receive an explicit stable `catalogId`, `deleted:false`, and timestamp.
   - Assignment refresh uses the current active local catalog after a best-effort Cloud merge, so a new plant is not discarded when Cloud is temporarily stale.
   - Admin has a manual refresh button in the assignment UI.
   - Plants with an empty size remain valid and display as `Không ghi kích thước`.

5. **Combo/order quantity rule**
   - `1` means exactly `1 plant/order`.
   - `2..100` means exactly that many actual plants/order.
   - No second multiplier is applied.
   - Firestore rules now accept `packSize` from `1..100`.

6. **Existing requirements retained**
   - Admin/packer role separation.
   - Assigned-order notification flow.
   - Employee photo completion requirement (2 photos).
   - Wage calculation from actual completed order quantities and size rates.
   - Date range payroll and per-employee detail.
   - Quote A4 / order 65x100 printing layouts.

## Validation

- `tools/preflight.py`: PASS
- JavaScript syntax: PASS (5 script blocks)
- Exactly one `@JavascriptInterface`: PASS
- Version: 25.5.9 / code 34
- Local full Gradle build was not available in this environment; GitHub Actions is the required final Android build verification.

## Important

Publish the included `firestore.rules` to Firebase if the project still uses older rules. The new combo rule for `1..100` is required for a `1 cây/đơn` order to be accepted by Firestore.
