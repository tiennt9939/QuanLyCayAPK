# V25.5.7

- Hardened Android printing by removing the custom PrintDocumentAdapter wrapper that could crash asynchronously on some print providers.
- Order printing keeps the 65 x 100 mm media request; quote printing keeps A4.
- Payroll tab now has a clearer summary table and per-employee detail view for a selected date range.
- Existing combo rule remains: packSize is the actual number of plants per order (1..100), not a multiplier applied twice.
