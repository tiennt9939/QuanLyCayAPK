# V25.5.9 — Ứng lương

- Thêm `salaryAdvances` vào dữ liệu nghiệp vụ, đồng bộ cùng `/apps/roll-cay-canh`.
- Admin có thể ghi nhận ứng lương theo nhân viên, ngày, số tiền và ghi chú.
- Khoản ứng được trừ khỏi lũy kế thực nhận: `lương gộp - ứng lương`.
- Bảng lương tổng hợp hiển thị Lương gộp, Đã ứng và Thực nhận.
- Chi tiết từng nhân viên hiển thị ứng theo ngày và lũy kế thực nhận.
- Có danh sách khoản ứng trong kỳ và cho phép xóa khoản ứng sai.
- Xuất bảng lương CSV có cột ứng lương, thực nhận và chi tiết ứng.
- Giữ nguyên logic combo: 1 cây/đơn = 1 cây; 2 cây/đơn = 2 cây; ... 100 cây/đơn = 100 cây.


## V25.5.9 audit fixes
- Isolated print WebView to reduce runtime crashes during A4 quote / 65x100 order printing.
- A4 printing now uses native ISO_A4 media size.
- Payroll CSV export keeps a native Android Downloads path with success/error feedback.
- Salary advance shows available-to-advance amount and cannot exceed earned cumulative net.
- New catalog plants are explicitly marked active and can be refreshed in assignment UI.
- Firestore allows real order quantity 1..100 per order, matching combo logic.
