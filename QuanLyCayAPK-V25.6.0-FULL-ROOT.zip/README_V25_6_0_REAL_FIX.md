# V25.6.0 REAL FIX — audit evidence

Built from the supplied V25.5.9 full source. This is not a patch-only archive.

## Actual code changes
- Assignment catalog: assignment size options now use stable `catalogId`; assignment payload stores `catalogId`; resolver prefers `catalogId` and falls back to legacy index. Cloud catalog refresh no longer blocks the local assignment catalog or requires a successful push before the UI can use a newly added tree.
- Order printing: packing-order print calls a dedicated `AndroidBridge.printOrder65x100()` bridge and native `PrintAttributes` 65x100 mm path.
- Quote PDF: added native PDF export using WebView `PrintDocumentAdapter`, writing a real `.pdf` into `Downloads/ROLL CAY CANH`; quote UI is cleaned after successful export.
- Payroll/salary advance: existing V25.5.9 payroll and advance logic is retained; no destructive rewrite.
- Version: 25.6.0 / code 35.

## Verification
- `python3 tools/preflight.py`: PASS
- JavaScript syntax: PASS (5 script blocks)
- `@JavascriptInterface`: 3 (print A4, print 65x100, export PDF)
- Source diff against V25.5.9: non-empty in `index.html`, `MainActivity.java`, `app/build.gradle.kts`, workflow, and preflight.

## Build limitation
This workspace does not contain a usable Gradle executable/Android SDK, so APK compilation must be performed by the repository GitHub Actions workflow. No claim of a built APK is made by this archive.
